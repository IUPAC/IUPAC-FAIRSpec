(function(){var P$=Clazz.newPackage("com.actelion.research.chem.mmp"),I$=[[0,'java.io.File','java.io.PrintWriter','java.io.BufferedReader','java.io.FileReader']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MMPFragments");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.temp=$I$(1).createTempFile$S$S("fragments", ".tmp");
this.fragmentsWriter=Clazz.new_($I$(2,1).c$$java_io_File,[this.temp]);
this.numberOfLines=0;
},1);

C$.$fields$=[['I',['numberOfLines'],'O',['temp','java.io.File','fragmentsWriter','java.io.PrintWriter']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.fragmentsWriter.println$S("key1FragmentIndex\tkey2FragmentIndex\tvalueFragmentIndex\tcutType\tmoleculeIndex");
}, 1);

Clazz.newMeth(C$, 'addFragments$I$java_util_List',  function (moleculeIndex, moleculeIndexesID) {
for (var moleculeIndexID, $moleculeIndexID = moleculeIndexesID.iterator$(); $moleculeIndexID.hasNext$()&&((moleculeIndexID=($moleculeIndexID.next$())),1);) {
this.addFragments$I$com_actelion_research_chem_mmp_MMPFragmenter_MoleculeIndexID(moleculeIndex, moleculeIndexID);
}
});

Clazz.newMeth(C$, 'addFragments$I$com_actelion_research_chem_mmp_MMPFragmenter_MoleculeIndexID',  function (moleculeIndex, moleculeIndexID) {
var keysSize=moleculeIndexID.getKeysIDAtoms$();
var keysIndex=moleculeIndexID.getKeysIndex$();
if (keysSize.length == 1) {
this.fragmentsWriter.println$S(Integer.toString$I(keysIndex[0]) + "\t\t" + Integer.toString$I(moleculeIndexID.getValueIndex$()) + "\t1\t" + Integer.toString$I(moleculeIndex) );
} else {
this.fragmentsWriter.println$S(Integer.toString$I(keysIndex[0]) + "\t" + Integer.toString$I(keysIndex[1]) + "\t" + Integer.toString$I(moleculeIndexID.getValueIndex$()) + "\t2\t" + Integer.toString$I(moleculeIndex) );
}++this.numberOfLines;
});

Clazz.newMeth(C$, 'writeFragments$java_io_PrintWriter',  function (printWriter) {
this.fragmentsWriter.close$();
printWriter.println$S("<mmpFragments>");
printWriter.println$S("<column properties>");
printWriter.println$S("<columnName=\"key1FragmentIndex\">");
printWriter.println$S("<columnName=\"key2FragmentIndex\">");
printWriter.println$S("<columnName=\"valueFragmentIndex\">");
printWriter.println$S("<columnName=\"cutType\">");
printWriter.println$S("<columnName=\"moleculeIndex\">");
printWriter.println$S("</column properties>");
var br=Clazz.new_([Clazz.new_($I$(4,1).c$$java_io_File,[this.temp])],$I$(3,1).c$$java_io_Reader);
var strLine;
while ((strLine=br.readLine$()) != null ){
printWriter.println$S(strLine);
}
br.close$();
this.temp.delete$();
printWriter.println$S("</mmpFragments>");
});

Clazz.newMeth(C$, 'getFragmentsCount$',  function () {
return this.numberOfLines;
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:39 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
