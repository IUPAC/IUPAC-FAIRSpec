(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore.generator"),p$1={},I$=[[0,'com.actelion.research.chem.interactionstatistics.InteractionDistanceStatistics','java.util.HashMap']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AtomTypeMap");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['hmAtomType_Index','java.util.HashMap','arrAtomType','int[]']]
,['O',['INSTANCE','com.actelion.research.chem.descriptor.flexophore.generator.AtomTypeMap']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
p$1.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'init',  function () {
var interactionDistanceStatistics=$I$(1).getInstance$();
var liAtomTypes=interactionDistanceStatistics.getAtomTypes$();
this.hmAtomType_Index=Clazz.new_([liAtomTypes.size$()],$I$(2,1).c$$I);
this.arrAtomType=Clazz.array(Integer.TYPE, [liAtomTypes.size$()]);
for (var i=0; i < liAtomTypes.size$(); i++) {
var atType=(liAtomTypes.get$I(i)).$c();
this.hmAtomType_Index.put$O$O(Integer.valueOf$I(atType), Integer.valueOf$I(i));
this.arrAtomType[i]=atType;
}
}, p$1);

Clazz.newMeth(C$, 'getIndex$I',  function (atomType) {
return (this.hmAtomType_Index.get$O(Integer.valueOf$I(atomType))).$c();
});

Clazz.newMeth(C$, 'getAtomType$I',  function (index) {
return this.arrAtomType[index];
});

Clazz.newMeth(C$, 'getInstance$',  function () {
if (C$.INSTANCE == null ) {
{
C$.INSTANCE=Clazz.new_(C$);
}}return C$.INSTANCE;
}, 1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
var interactionDistanceStatistics=$I$(1).getInstance$();
var liAtomTypes=interactionDistanceStatistics.getAtomTypes$();
var atomTypeMap=C$.getInstance$();
for (var i=0; i < liAtomTypes.size$(); i++) {
var atType=(liAtomTypes.get$I(i)).$c();
var index=atomTypeMap.getIndex$I(atType);
var atType2=atomTypeMap.getAtomType$I(index);
if (atType != atType2) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Error in algorithm!"]);
}}
System.out.println$S("Done for " + liAtomTypes.size$() + " atom types" );
}, 1);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:37 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
