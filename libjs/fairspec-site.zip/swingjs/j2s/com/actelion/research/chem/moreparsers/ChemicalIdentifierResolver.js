(function(){var P$=Clazz.newPackage("com.actelion.research.chem.moreparsers"),p$1={},I$=[[0,'com.actelion.research.chem.moreparsers.ParserUtils','com.actelion.research.chem.SmilesParser','com.actelion.research.chem.MolfileParser']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ChemicalIdentifierResolver");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.source="pubchem";
},1);

C$.$fields$=[['Z',['keepHydrogenMap'],'S',['type','source']]]

Clazz.newMeth(C$, 'c$$S$Z',  function (type, keepHydrogenMap) {
;C$.$init$.apply(this);
this.type=type;
this.keepHydrogenMap=keepHydrogenMap;
}, 1);

Clazz.newMeth(C$, 'setSource$S',  function (source) {
this.source=source;
return this;
});

Clazz.newMeth(C$, 'resolve$com_actelion_research_chem_StereoMolecule$S',  function (mol, code) {
var url;
switch (this.source) {
default:
case "cir":
url=p$1.getChemicalIdentifierResolverURL$S.apply(this, [code]);
break;
case "pubchem":
url=p$1.getPubChemURL$S.apply(this, [code]);
break;
}
if (url == null ) {
return false;
}var data=$I$(1).getURLContentsAsString$S(url);
System.out.println$S(this.getClass$().getName$() + "\n -for " + code + "\n -url " + url );
switch (this.source) {
case "cir":
try {
Clazz.new_($I$(2,1)).parse$com_actelion_research_chem_StereoMolecule$S(mol, data);
return true;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
return false;
} else {
throw e;
}
}
case "pubchem":
return data != null  && Clazz.new_($I$(3,1).c$$I,[this.keepHydrogenMap ? 1 : 0]).parse$com_actelion_research_chem_StereoMolecule$S(mol, data) ;
}
return false;
});

Clazz.newMeth(C$, 'getChemicalIdentifierResolverURL$S',  function (code) {
code=$I$(1).escapeCIRQuery$S(code);
switch (this.type) {
case "inchi":
case "inchikey":
case "name":
return "https://cactus.nci.nih.gov/chemical/structure/XX/smiles".replace$CharSequence$CharSequence("XX", code);
}
System.out.println$S("ChemicalIdentifierResolver: CIR type " + this.type + " not implemented" );
return null;
}, p$1);

Clazz.newMeth(C$, 'getPubChemURL$S',  function (code) {
code=$I$(1).escapePubChemQuery$S(code);
switch (this.type) {
case "inchi":
code=$I$(1,"escapePubChemQuery$S",[code.substring$I(8)]);
return "https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/inchi/SDF?record_type=2d&inchi=" + code;
case "inchikey":
return "https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/inchikey/XX/SDF?record_type=2d".replace$CharSequence$CharSequence("XX", code);
case "name":
return "https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/XX/SDF?record_type=2d".replace$CharSequence$CharSequence("XX", code);
}
System.out.println$S(this.getClass$().getName$() + " pubchem type " + this.type + " not implemented" );
return null;
}, p$1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:39 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
