(function(){var P$=Clazz.newPackage("com.actelion.research.chem.moreparsers"),p$1={},I$=[[0,'com.actelion.research.chem.moreparsers.CDXMLParser','com.actelion.research.chem.moreparsers.ParserUtils','com.actelion.research.chem.StereoMolecule','java.io.BufferedReader','java.io.StringReader','com.actelion.research.chem.moreparsers.CDX2CDXML','com.actelion.research.chem.coords.CoordinateInventor']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CDXParser", null, 'com.actelion.research.chem.moreparsers.XmlReader', [['com.actelion.research.chem.moreparsers.CDXMLParser','com.actelion.research.chem.moreparsers.CDXMLParser.CDXReaderI']]);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['doCleanCoordinates'],'O',['parser','com.actelion.research.chem.moreparsers.CDXMLParser','mol','com.actelion.research.chem.StereoMolecule']]]

Clazz.newMeth(C$, 'setCleanCoordinates$',  function () {
this.doCleanCoordinates=true;
});

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
this.parser=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_moreparsers_CDXMLParser_CDXReaderI,[this]);
}, 1);

Clazz.newMeth(C$, 'parseFile$S',  function (path) {
var cdx=$I$(2).getURLContentsAsBytes$S(path);
var mol=Clazz.new_($I$(3,1));
return (Clazz.new_(C$).parse$com_actelion_research_chem_StereoMolecule$BA(mol, cdx) ? mol : null);
}, 1);

Clazz.newMeth(C$, 'parse$com_actelion_research_chem_StereoMolecule$S',  function (mol, cdxml) {
this.mol=mol;
this.reader=Clazz.new_([Clazz.new_($I$(5,1).c$$S,[cdxml])],$I$(4,1).c$$java_io_Reader);
this.err=this.parseXML$();
if (this.err != null ) return false;
this.parser.finalizeParsing$();
p$1.createMolecule.apply(this, []);
return true;
});

Clazz.newMeth(C$, 'parse$com_actelion_research_chem_StereoMolecule$BA',  function (mol, cdx) {
return (p$1.get$com_actelion_research_chem_StereoMolecule$BA.apply(this, [mol, cdx]) != null );
});

Clazz.newMeth(C$, 'get$com_actelion_research_chem_StereoMolecule$BA',  function (mol, cdx) {
if (cdx == null  || cdx.length == 0 ) return null;
try {
var cdxml;
if (cdx[0] == 86) {
cdxml=$I$(6).fromCDX$BA(cdx);
} else {
cdxml= String.instantialize(cdx, "utf-8");
}return (Clazz.new_(C$).parse$com_actelion_research_chem_StereoMolecule$S(mol, cdxml) && mol.getAllAtoms$() > 0  ? mol : null);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
return null;
} else {
throw e;
}
}
}, p$1);

Clazz.newMeth(C$, 'processStartElement$S$S',  function (localName, nodeName) {
this.parser.processStartElement$S$java_util_Map(localName, this.atts);
});

Clazz.newMeth(C$, 'processEndElement$S',  function (localName) {
this.parser.processEndElement$S$S(localName, this.chars.toString());
});

Clazz.newMeth(C$, 'setKeepChars$Z',  function (TF) {
C$.superclazz.prototype.setKeepChars$Z.apply(this, [TF]);
});

Clazz.newMeth(C$, 'handleCoordinates$java_util_Map',  function (atts) {
this.parser.setAtom$S$java_util_Map("p", atts);
});

Clazz.newMeth(C$, 'getBondOrder$S',  function (key) {
switch (key) {
case "1":
case "single":
return 1;
case "2":
case "double":
return 2;
case "3":
case "triple":
return 4;
case "up":
return 257;
case "down":
return 129;
case "either":
return -1;
case "null":
return 0;
case "delocalized":
return 8;
default:
case "partial":
return 16;
}
});

Clazz.newMeth(C$, 'createMolecule',  function () {
var bs=this.parser.bsAtoms;
for (var i=bs.nextSetBit$I(0); i >= 0; i=bs.nextSetBit$I(i + 1)) {
var a=this.parser.getAtom$I(i);
var ia=this.mol.addAtom$D$D(a.x, -a.y);
a.index=ia;
this.mol.setAtomCharge$I$I(ia, a.formalCharge);
this.mol.setAtomicNo$I$I(ia, a.elementNumber);
if (a.isotope != null ) this.mol.setAtomMass$I$I(ia, this.parser.parseInt$S(a.isotope));
}
bs=this.parser.bsBonds;
for (var i=bs.nextSetBit$I(0); i >= 0; i=bs.nextSetBit$I(i + 1)) {
var bond=this.parser.getBond$I(i);
var ib=this.mol.addBond$I$I(bond.atom1.index, bond.atom2.index);
this.mol.setBondType$I$I(ib, bond.order);
}
if (this.doCleanCoordinates || this.parser.hasConnectedFragments$() ) {
this.mol.ensureHelperArrays$I(15);
Clazz.new_($I$(7,1).c$$I,[0]).invent$com_actelion_research_chem_StereoMolecule(this.mol);
}}, p$1);

Clazz.newMeth(C$, 'warn$S',  function (warning) {
System.err.println$S(warning);
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:39 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
