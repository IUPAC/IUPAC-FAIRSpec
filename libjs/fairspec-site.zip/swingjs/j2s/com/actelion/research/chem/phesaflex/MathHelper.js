(function(){var P$=Clazz.newPackage("com.actelion.research.chem.phesaflex"),I$=[[0,'com.actelion.research.chem.Coordinates']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MathHelper");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getRotMatrixDerivative$com_actelion_research_chem_Coordinates$D$com_actelion_research_chem_CoordinatesAA',  function (u, theta, dR) {
var cosTheta=Math.cos(theta);
var sinTheta=Math.asin(theta);
dR[0][0]=Clazz.new_($I$(1,1).c$$D$D$D,[2 * u.x - 2 * u.x * cosTheta , 0, 0]);
dR[0][1]=Clazz.new_($I$(1,1).c$$D$D$D,[u.y - u.y * cosTheta, u.x - u.x * cosTheta, -sinTheta]);
dR[0][2]=Clazz.new_($I$(1,1).c$$D$D$D,[u.z - u.z * cosTheta, sinTheta, u.x - u.x * cosTheta]);
dR[1][0]=Clazz.new_($I$(1,1).c$$D$D$D,[u.y - u.y * cosTheta, u.x - u.x * cosTheta, sinTheta]);
dR[1][1]=Clazz.new_($I$(1,1).c$$D$D$D,[0, 2 * u.y - 2 * u.y * cosTheta , 0]);
dR[1][2]=Clazz.new_($I$(1,1).c$$D$D$D,[-sinTheta, u.z - u.z * cosTheta, u.y - u.y * cosTheta]);
dR[2][0]=Clazz.new_($I$(1,1).c$$D$D$D,[u.z - u.z * cosTheta, -sinTheta, u.x - u.x * cosTheta]);
dR[2][1]=Clazz.new_($I$(1,1).c$$D$D$D,[sinTheta, u.z - u.z * cosTheta, u.y - u.y * cosTheta]);
dR[2][2]=Clazz.new_($I$(1,1).c$$D$D$D,[0, 0, 2 * u.z - 2 * u.z * cosTheta ]);
}, 1);

Clazz.newMeth(C$, 'getRotMatrix$com_actelion_research_chem_Coordinates$D$DAA',  function (u, theta, R) {
var cosTheta=Math.cos(theta);
var sinTheta=Math.asin(theta);
R[0][0]=cosTheta + u.x * u.x * (1 - cosTheta) ;
R[0][1]=u.x * u.y - u.x * u.y * cosTheta  - u.z * sinTheta;
R[0][2]=u.x * u.z - u.x * u.z * cosTheta  + u.y * sinTheta;
R[1][0]=u.y * u.x - u.y * u.x * cosTheta  + u.z * sinTheta;
R[1][1]=cosTheta + u.y * u.y - u.y * u.y * cosTheta ;
R[1][2]=u.y * u.z - u.y * u.z * cosTheta  - u.x * sinTheta;
R[2][0]=u.z * u.x - u.z * u.x * cosTheta  - u.y * sinTheta;
R[2][1]=u.z * u.y - u.z * u.y * cosTheta  + u.x * sinTheta;
R[2][2]=cosTheta + u.z * u.z - u.z * u.z * cosTheta ;
}, 1);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:40 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
