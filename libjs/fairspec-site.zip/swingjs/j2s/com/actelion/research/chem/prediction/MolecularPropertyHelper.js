(function(){var P$=Clazz.newPackage("com.actelion.research.chem.prediction"),I$=[[0,'com.actelion.research.chem.prediction.PropertySpecification','com.actelion.research.chem.prediction.CLogPPredictor','com.actelion.research.chem.prediction.SolubilityPredictor','com.actelion.research.chem.prediction.PolarSurfaceAreaPredictor','com.actelion.research.chem.conf.MolecularFlexibilityCalculator','com.actelion.research.chem.prediction.FastMolecularComplexityCalculator','com.actelion.research.chem.prediction.MolecularShapeCalculator','com.actelion.research.chem.prediction.ToxicityPredictor','com.actelion.research.chem.AtomFunctionAnalyzer']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MolecularPropertyHelper");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['SPEC','com.actelion.research.chem.prediction.PropertySpecification[]']]]

Clazz.newMeth(C$, 'calculateProperty$com_actelion_research_chem_StereoMolecule$I',  function (mol, type) {
return (type == 0) ? mol.getMolweight$() : (type == 1) ? Clazz.new_($I$(2,1)).assessCLogP$com_actelion_research_chem_StereoMolecule(mol) : (type == 2) ? Clazz.new_($I$(3,1)).assessSolubility$com_actelion_research_chem_StereoMolecule(mol) : (type == 3) ? Clazz.new_($I$(4,1)).assessPSA$com_actelion_research_chem_StereoMolecule(mol) : (type == 4) ? C$.getHDonorCount$com_actelion_research_chem_StereoMolecule(mol) : (type == 5) ? C$.getHAcceptorCount$com_actelion_research_chem_StereoMolecule(mol) : (type == 9) ? mol.getRotatableBondCount$() : (type == 6) ? Clazz.new_($I$(5,1)).calculateMolecularFlexibility$com_actelion_research_chem_StereoMolecule(mol) : (type == 7) ? $I$(6).assessComplexity$com_actelion_research_chem_StereoMolecule(mol) : (type == 8) ? $I$(7).assessShape$com_actelion_research_chem_StereoMolecule(mol) : (type == 10) ? mol.getStereoCenterCount$() : (type == 11) ? mol.getRingSet$().getSize$() : (type == 12) ? mol.getAromaticRingCount$() : (type == 13) ? C$.getBasicNitrogenCount$com_actelion_research_chem_StereoMolecule(mol) : (type == 14) ? C$.getAcidicOxygenCount$com_actelion_research_chem_StereoMolecule(mol) : (type == 15) ? C$.getToxicityRisk$com_actelion_research_chem_StereoMolecule(mol) : NaN;
}, 1);

Clazz.newMeth(C$, 'getPropertyCount$',  function () {
return C$.SPEC.length;
}, 1);

Clazz.newMeth(C$, 'getPropertyName$I',  function (type) {
return C$.SPEC[type].name;
}, 1);

Clazz.newMeth(C$, 'getPropertyCode$I',  function (type) {
return C$.SPEC[type].code;
}, 1);

Clazz.newMeth(C$, 'getPreferredMin$I',  function (type) {
return C$.SPEC[type].min;
}, 1);

Clazz.newMeth(C$, 'getPreferredMax$I',  function (type) {
return C$.SPEC[type].max;
}, 1);

Clazz.newMeth(C$, 'getRangeMin$I',  function (type) {
return C$.SPEC[type].rangeMin;
}, 1);

Clazz.newMeth(C$, 'getRangeMax$I',  function (type) {
return C$.SPEC[type].rangeMax;
}, 1);

Clazz.newMeth(C$, 'getValuation$D$D$D$D',  function (value, min, max, halfWidth) {
if (Double.isNaN$D(value)) return NaN;
var v=1.0;
if (!Double.isNaN$D(min)) v*=1.0 / (1.0 + Math.exp((min - value) / halfWidth));
if (!Double.isNaN$D(max)) v*=1.0 / (1.0 + Math.exp((value - max) / halfWidth));
return v;
}, 1);

Clazz.newMeth(C$, 'getTypeFromCode$S',  function (code) {
for (var i=0; i < C$.SPEC.length; i++) if (C$.SPEC[i].code.equals$O(code)) return i;

return -1;
}, 1);

Clazz.newMeth(C$, 'getTypeFromName$S',  function (name) {
for (var i=0; i < C$.SPEC.length; i++) if (C$.SPEC[i].name.equals$O(name)) return i;

return -1;
}, 1);

Clazz.newMeth(C$, 'getMinText$I',  function (type) {
return C$.SPEC[type].min;
}, 1);

Clazz.newMeth(C$, 'getMaxText$I',  function (type) {
return C$.SPEC[type].max;
}, 1);

Clazz.newMeth(C$, 'getHalfFitnessWidth$I',  function (type) {
return C$.SPEC[type].halfWidth;
}, 1);

Clazz.newMeth(C$, 'getToxicityRisk$com_actelion_research_chem_StereoMolecule',  function (mol) {
var result=0;
var tp=Clazz.new_($I$(8,1));
for (var riskType=0; riskType < 4; riskType++) {
var risk=tp.assessRisk$com_actelion_research_chem_StereoMolecule$I$com_actelion_research_calc_ThreadMaster(mol, riskType, null);
if (risk == 2) result+=1;
 else if (risk == 3) result+=2;
}
return result;
}, 1);

Clazz.newMeth(C$, 'getHAcceptorCount$com_actelion_research_chem_StereoMolecule',  function (mol) {
var count=0;
for (var atom=0; atom < mol.getAllAtoms$(); atom++) if (mol.getAtomicNo$I(atom) == 7 || mol.getAtomicNo$I(atom) == 8 ) ++count;

return count;
}, 1);

Clazz.newMeth(C$, 'getHDonorCount$com_actelion_research_chem_StereoMolecule',  function (mol) {
var count=0;
for (var atom=0; atom < mol.getAllAtoms$(); atom++) if ((mol.getAtomicNo$I(atom) == 7 || mol.getAtomicNo$I(atom) == 8 ) && mol.getAllHydrogens$I(atom) > 0 ) ++count;

return count;
}, 1);

Clazz.newMeth(C$, 'getBasicNitrogenCount$com_actelion_research_chem_StereoMolecule',  function (mol) {
var count=0;
mol.ensureHelperArrays$I(7);
for (var atom=0; atom < mol.getAtoms$(); atom++) if ($I$(9).isBasicNitrogen$com_actelion_research_chem_StereoMolecule$I(mol, atom)) ++count;

return count;
}, 1);

Clazz.newMeth(C$, 'getAcidicOxygenCount$com_actelion_research_chem_StereoMolecule',  function (mol) {
var count=0;
mol.ensureHelperArrays$I(7);
for (var atom=0; atom < mol.getAtoms$(); atom++) if ($I$(9).isAcidicOxygen$com_actelion_research_chem_StereoMolecule$I(mol, atom)) ++count;

return count;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.SPEC=Clazz.array($I$(1), -1, [Clazz.new_($I$(1,1).c$$S$S$S$S$F$F$F,["molweight", "Molecular weight", "", "400", 50.0, 0.0, 800.0]), Clazz.new_($I$(1,1).c$$S$S$S$S$F$F$F,["cLogP", "cLogP", "", "4", 0.5, 0.0, 8.0]), Clazz.new_($I$(1,1).c$$S$S$S$S$F$F$F,["cLogS", "cLogS", "-4", "", 0.5, -8.0, 2.0]), Clazz.new_($I$(1,1).c$$S$S$S$S$F$F$F,["tpsa", "Polar surface area", "", "120", 20.0, 0.0, 250.0]), Clazz.new_($I$(1,1).c$$S$S$S$S$F$F$F,["donors", "H-Donors", "", "5", 0.5, 0, 8.0]), Clazz.new_($I$(1,1).c$$S$S$S$S$F$F$F,["acceptors", "H-Acceptors", "", "10", 1.0, 0, 16.0]), Clazz.new_($I$(1,1).c$$S$S$S$S$F$F$F,["flexibility", "Molecular flexibility", "0.3", "0.7", 0.05, 0.0, 1.0]), Clazz.new_($I$(1,1).c$$S$S$S$S$F$F$F,["complexity", "Molecular complexity", "0.8", "", 0.05, 0.0, 1.0]), Clazz.new_($I$(1,1).c$$S$S$S$S$F$F$F,["shape", "Molecular shape", "", "0.5", 0.05, 0.0, 1.0]), Clazz.new_($I$(1,1).c$$S$S$S$S$F$F$F,["rotatableBonds", "Rotatable bond count", "", "4", 5.0, 0.0, 20.0]), Clazz.new_($I$(1,1).c$$S$S$S$S$F$F$F,["stereoCenters", "Stereo center count", "1", "3", 2.0, 0.0, 8.0]), Clazz.new_(["smallRings", "Ring count (<= 7 atoms)", "2", "", 1.0, 0.0, 10.0],$I$(1,1).c$$S$S$S$S$F$F$F), Clazz.new_($I$(1,1).c$$S$S$S$S$F$F$F,["aromaticRings", "Aromatic ring count", "", "2", 1.0, 0.0, 6.0]), Clazz.new_($I$(1,1).c$$S$S$S$S$F$F$F,["basicN", "Basic nitrogen count", "1", "", 0.5, 0.0, 6.0]), Clazz.new_($I$(1,1).c$$S$S$S$S$F$F$F,["acidicO", "Acidic oxygen count", "1", "", 0.5, 0, 6.0]), Clazz.new_($I$(1,1).c$$S$S$S$S$F$F$F,["toxicity", "Toxicity Risk", "", "2", 3.0, 0, 8.0])]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:40 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
