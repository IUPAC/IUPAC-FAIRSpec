(function(){var P$=Clazz.newPackage("com.actelion.research.chem.phesa.pharmacophore.pp"),p$1={},I$=[[0,'java.util.ArrayList','com.actelion.research.chem.Coordinates','StringBuilder','com.actelion.research.chem.phesaflex.MathHelper',['com.actelion.research.chem.phesa.pharmacophore.pp.IPharmacophorePoint','.Functionality']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AcceptorPoint", null, null, 'com.actelion.research.chem.phesa.pharmacophore.pp.IPharmacophorePoint');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['acceptorAtom','interactionClass','acceptorID'],'O',['neighbours','java.util.List','directionality','com.actelion.research.chem.Coordinates','+center']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$I$java_util_List$I',  function (mol, a, neighbours, interactionClass) {
C$.c$$com_actelion_research_chem_StereoMolecule$I$java_util_List$I$I.apply(this, [mol, a, neighbours, interactionClass, 0]);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_phesa_pharmacophore_pp_AcceptorPoint',  function (aP) {
;C$.$init$.apply(this);
this.acceptorAtom=aP.acceptorAtom;
this.neighbours=Clazz.new_($I$(1,1));
for (var neighbour, $neighbour = aP.neighbours.iterator$(); $neighbour.hasNext$()&&((neighbour=($neighbour.next$()).intValue$()),1);) {
this.neighbours.add$O(Integer.valueOf$I(neighbour));
}
this.directionality=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_Coordinates,[aP.directionality]);
this.interactionClass=aP.interactionClass;
this.center=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_Coordinates,[aP.center]);
this.acceptorID=aP.acceptorID;
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$I$java_util_List$I$I',  function (mol, a, neighbours, interactionClass, acceptorID) {
;C$.$init$.apply(this);
this.acceptorAtom=a;
this.neighbours=neighbours;
this.interactionClass=interactionClass;
this.acceptorID=acceptorID;
this.updateCoordinates$com_actelion_research_chem_CoordinatesA(mol.getAtomCoordinates$());
}, 1);

Clazz.newMeth(C$, 'c$$S$com_actelion_research_chem_StereoMolecule',  function (ppString, mol) {
;C$.$init$.apply(this);
p$1.decode$S$com_actelion_research_chem_StereoMolecule.apply(this, [ppString, mol]);
}, 1);

Clazz.newMeth(C$, 'fromString$S$com_actelion_research_chem_StereoMolecule',  function (ppString, mol) {
return Clazz.new_(C$.c$$S$com_actelion_research_chem_StereoMolecule,[ppString, mol]);
}, 1);

Clazz.newMeth(C$, 'updateCoordinates$com_actelion_research_chem_CoordinatesA',  function (coords) {
this.center=Clazz.new_($I$(2,1).c$$D$D$D,[coords[this.acceptorAtom].x, coords[this.acceptorAtom].y, coords[this.acceptorAtom].z]);
if (this.neighbours.size$() == 1) {
var aa1=(this.neighbours.get$I(0)).$c();
this.directionality=this.center.subC$com_actelion_research_chem_Coordinates(coords[aa1]);
} else if (this.neighbours.size$() == 2 && this.acceptorID != 0 ) {
var aa1=(this.neighbours.get$I(0)).$c();
var v1=this.center.subC$com_actelion_research_chem_Coordinates(coords[aa1]);
var aa2=(this.neighbours.get$I(1)).$c();
var v2=coords[aa2].subC$com_actelion_research_chem_Coordinates(this.center);
var rotAxis=v1.cross$com_actelion_research_chem_Coordinates(v2).unit$();
var theta=this.acceptorID == 1 ? 0.7853981633974483 : -0.7853981633974483;
this.directionality=v1.rotate$com_actelion_research_chem_Coordinates$D(rotAxis, theta);
} else if (this.neighbours.size$() == 3) {
var aa1=(this.neighbours.get$I(0)).$c();
var aa2=(this.neighbours.get$I(1)).$c();
var aa3=(this.neighbours.get$I(2)).$c();
var v1=this.center.subC$com_actelion_research_chem_Coordinates(coords[aa1]).unit$();
var v2=this.center.subC$com_actelion_research_chem_Coordinates(coords[aa2]).unit$();
var v3=this.center.subC$com_actelion_research_chem_Coordinates(coords[aa3]).unit$();
this.directionality=v3.add$com_actelion_research_chem_Coordinates(v2).add$com_actelion_research_chem_Coordinates(v1);
} else {
var aa1=(this.neighbours.get$I(0)).$c();
var aa2=(this.neighbours.get$I(1)).$c();
var v1=this.center.subC$com_actelion_research_chem_Coordinates(coords[aa1]).unit$();
var v2=this.center.subC$com_actelion_research_chem_Coordinates(coords[aa2]).unit$();
this.directionality=v1.addC$com_actelion_research_chem_Coordinates(v2);
}this.directionality.unit$();
});

Clazz.newMeth(C$, 'getCenter$',  function () {
return this.center;
});

Clazz.newMeth(C$, 'getDirectionality$',  function () {
return this.directionality;
});

Clazz.newMeth(C$, 'encode$',  function () {
var molVolString=Clazz.new_($I$(3,1));
molVolString.append$S("a");
molVolString.append$S(" ");
molVolString.append$S(Integer.toString$I(this.acceptorAtom));
molVolString.append$S(" ");
molVolString.append$S(Integer.toString$I(this.interactionClass));
molVolString.append$S(" ");
molVolString.append$S(Integer.toString$I(this.acceptorID));
molVolString.append$S(" ");
for (var neighbour, $neighbour = this.neighbours.iterator$(); $neighbour.hasNext$()&&((neighbour=($neighbour.next$())),1);) {
molVolString.append$O(neighbour);
molVolString.append$S(" ");
}
return molVolString.toString().trim$();
});

Clazz.newMeth(C$, 'decode$S$com_actelion_research_chem_StereoMolecule',  function (ppString, mol) {
var strings=ppString.split$S(" ");
this.acceptorAtom=(Integer.decode$S(strings[1])).$c();
this.interactionClass=(Integer.decode$S(strings[2])).$c();
this.acceptorID=(Integer.decode$S(strings[3])).$c();
this.neighbours=Clazz.new_($I$(1,1));
for (var i=4; i < strings.length; i++) {
this.neighbours.add$O(Integer.decode$S(strings[i]));
}
this.updateCoordinates$com_actelion_research_chem_CoordinatesA(mol.getAtomCoordinates$());
}, p$1);

Clazz.newMeth(C$, 'getSimilarity$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint',  function (pp) {
if (Clazz.instanceOf(pp, "com.actelion.research.chem.phesa.pharmacophore.pp.AcceptorPoint")) {
return 1.0;
}return 0.0;
});

Clazz.newMeth(C$, 'getInteractionClass$',  function () {
return this.interactionClass;
});

Clazz.newMeth(C$, 'getCenterID$',  function () {
return this.acceptorAtom;
});

Clazz.newMeth(C$, 'setCenterID$I',  function (centerID) {
this.acceptorAtom=centerID;
});

Clazz.newMeth(C$, 'setDirectionality$com_actelion_research_chem_Coordinates',  function (directionality) {
this.directionality=directionality;
});

Clazz.newMeth(C$, 'getAcceptorID$',  function () {
return this.acceptorID;
});

Clazz.newMeth(C$, 'getDirectionalityDerivativeCartesian$DA$DA$com_actelion_research_chem_Coordinates$D',  function (grad, v, di, sim) {
if (this.neighbours.size$() == 1) {
var aa1=(this.neighbours.get$I(0)).$c();
grad[3 * this.acceptorAtom]=sim * di.x / 3.0;
grad[3 * this.acceptorAtom + 1]=sim * di.y / 3.0;
grad[3 * this.acceptorAtom + 2]=sim * di.z / 3.0;
grad[3 * aa1]=sim * -di.x / 3.0;
grad[3 * aa1 + 1]=sim * -di.y / 3.0;
grad[3 * aa1 + 2]=sim * -di.z / 3.0;
} else if (this.neighbours.size$() == 2 && this.acceptorID != 0 ) {
var centerCoords=Clazz.new_($I$(2,1).c$$D$D$D,[v[3 * this.acceptorAtom], v[3 * this.acceptorAtom + 1], v[3 * this.acceptorAtom + 2]]);
var c2=(this.neighbours.get$I(0)).$c();
var c2Coords=Clazz.new_($I$(2,1).c$$D$D$D,[v[3 * c2], v[3 * c2 + 1], v[3 * c2 + 2]]);
var v1=centerCoords.subC$com_actelion_research_chem_Coordinates(c2Coords);
var c1=(this.neighbours.get$I(1)).$c();
var c1Coords=Clazz.new_($I$(2,1).c$$D$D$D,[v[3 * c1], v[3 * c1 + 1], v[3 * c1 + 2]]);
var v2=c1Coords.subC$com_actelion_research_chem_Coordinates(centerCoords);
var u=v1.cross$com_actelion_research_chem_Coordinates(v2).unit$();
var theta=this.acceptorID == 1 ? 0.7853981633974483 : -0.7853981633974483;
var r=Clazz.array(Double.TYPE, [3, 3]);
var drdu=Clazz.array($I$(2), [3, 3]);
var drdc1=Clazz.array(Double.TYPE, [3, 3]);
$I$(4).getRotMatrix$com_actelion_research_chem_Coordinates$D$DAA(u, theta, r);
$I$(4).getRotMatrixDerivative$com_actelion_research_chem_Coordinates$D$com_actelion_research_chem_CoordinatesAA(u, theta, drdu);
var dv2dc1=Clazz.new_($I$(2,1).c$$D$D$D,[1, 1, 1]);
var dudc1=dv2dc1.cross$com_actelion_research_chem_Coordinates(v1);
drdc1[0][0]=drdu[0][0].dot$com_actelion_research_chem_Coordinates(dudc1);
drdc1[0][1]=drdu[0][1].dot$com_actelion_research_chem_Coordinates(dudc1);
drdc1[0][2]=drdu[0][2].dot$com_actelion_research_chem_Coordinates(dudc1);
drdc1[1][0]=drdu[1][0].dot$com_actelion_research_chem_Coordinates(dudc1);
drdc1[1][1]=drdu[1][1].dot$com_actelion_research_chem_Coordinates(dudc1);
drdc1[1][2]=drdu[1][2].dot$com_actelion_research_chem_Coordinates(dudc1);
drdc1[2][0]=drdu[2][0].dot$com_actelion_research_chem_Coordinates(dudc1);
drdc1[2][1]=drdu[2][2].dot$com_actelion_research_chem_Coordinates(dudc1);
drdc1[2][2]=drdu[2][2].dot$com_actelion_research_chem_Coordinates(dudc1);
var dddc1=Clazz.new_($I$(2,1).c$$D$D$D,[drdc1[0][0] * v1.x + drdc1[0][1] * v1.y + drdc1[0][2] * v1.z, drdc1[1][0] * v1.x + drdc1[1][1] * v1.y + drdc1[2][1] * v1.z, drdc1[2][0] * v1.x + drdc1[2][1] * v1.y + drdc1[2][2] * v1.z]);
grad[3 * c1]+=sim * dddc1.x / 3.0;
grad[3 * c1 + 1]+=sim * dddc1.y / 3.0;
grad[3 * c1 + 2]+=sim * dddc1.z / 3.0;
var dv1dc2=Clazz.new_($I$(2,1).c$$D$D$D,[-1, -1, -1]);
var dv2dc2=dv1dc2;
var dudc2=dv1dc2.cross$com_actelion_research_chem_Coordinates(v2).add$com_actelion_research_chem_Coordinates(dv2dc2.cross$com_actelion_research_chem_Coordinates(v1));
var drdc2=drdc1;
drdc2[0][0]=drdu[0][0].dot$com_actelion_research_chem_Coordinates(dudc2);
drdc2[0][1]=drdu[0][1].dot$com_actelion_research_chem_Coordinates(dudc2);
drdc2[0][2]=drdu[0][2].dot$com_actelion_research_chem_Coordinates(dudc2);
drdc2[1][0]=drdu[1][0].dot$com_actelion_research_chem_Coordinates(dudc2);
drdc2[1][1]=drdu[1][1].dot$com_actelion_research_chem_Coordinates(dudc2);
drdc2[1][2]=drdu[1][2].dot$com_actelion_research_chem_Coordinates(dudc2);
drdc2[2][0]=drdu[2][0].dot$com_actelion_research_chem_Coordinates(dudc2);
drdc2[2][1]=drdu[2][2].dot$com_actelion_research_chem_Coordinates(dudc2);
drdc2[2][2]=drdu[2][2].dot$com_actelion_research_chem_Coordinates(dudc2);
var dddc2=Clazz.new_($I$(2,1).c$$D$D$D,[drdc1[0][0] * v1.x + drdc1[0][1] * v1.y + drdc1[0][2] * v1.z + r[0][0] * dv1dc2.x + r[0][1] * dv1dc2.y + r[0][2] * dv1dc2.z, drdc1[1][0] * v1.x + drdc1[1][1] * v1.y + drdc1[1][2] * v1.z + r[1][0] * dv1dc2.x + r[1][1] * dv1dc2.y + r[1][2] * dv1dc2.z, drdc1[2][0] * v1.x + drdc1[2][1] * v1.y + drdc1[2][2] * v1.z + r[2][0] * dv1dc2.x + r[2][1] * dv1dc2.y + r[2][2] * dv1dc2.z]);
grad[3 * c2]+=sim * dddc2.x / 3.0;
grad[3 * c2 + 1]+=sim * dddc2.y / 3.0;
grad[3 * c2 + 2]+=sim * dddc2.z / 3.0;
var dv1da=dv2dc1;
var duda=dv1da.cross$com_actelion_research_chem_Coordinates(v2);
var drda=drdc1;
drda[0][0]=drdu[0][0].dot$com_actelion_research_chem_Coordinates(duda);
drda[0][1]=drdu[0][1].dot$com_actelion_research_chem_Coordinates(duda);
drda[0][2]=drdu[0][2].dot$com_actelion_research_chem_Coordinates(duda);
drda[1][0]=drdu[1][0].dot$com_actelion_research_chem_Coordinates(duda);
drda[1][1]=drdu[1][1].dot$com_actelion_research_chem_Coordinates(duda);
drda[1][2]=drdu[1][2].dot$com_actelion_research_chem_Coordinates(duda);
drda[2][0]=drdu[2][0].dot$com_actelion_research_chem_Coordinates(duda);
drda[2][1]=drdu[2][2].dot$com_actelion_research_chem_Coordinates(duda);
drda[2][2]=drdu[2][2].dot$com_actelion_research_chem_Coordinates(duda);
var ddda=Clazz.new_($I$(2,1).c$$D$D$D,[drda[0][0] * v1.x + drda[0][1] * v1.y + drda[0][2] * v1.z + r[0][0] * dv1da.x + r[0][1] * dv1da.y + r[0][2] * dv1da.z, drda[1][0] * v1.x + drda[1][1] * v1.y + drda[1][2] * v1.z + r[1][0] * dv1da.x + r[1][1] * dv1da.y + r[1][2] * dv1da.z, drda[2][0] * v1.x + drda[2][1] * v1.y + drda[2][2] * v1.z + r[2][0] * dv1da.x + r[2][1] * dv1da.y + r[2][2] * dv1da.z]);
grad[3 * this.acceptorAtom]+=sim * ddda.x / 3.0;
grad[3 * this.acceptorAtom + 1]+=sim * ddda.y / 3.0;
grad[3 * this.acceptorAtom + 2]+=sim * ddda.z / 3.0;
} else if (this.neighbours.size$() == 3) {
var aa1=(this.neighbours.get$I(0)).$c();
var aa2=(this.neighbours.get$I(1)).$c();
var aa3=(this.neighbours.get$I(2)).$c();
grad[3 * this.acceptorAtom]+=sim * 3 * di.x  / 3.0;
grad[3 * this.acceptorAtom + 1]+=sim * 3 * di.y  / 3.0;
grad[3 * this.acceptorAtom + 2]+=sim * 3 * di.z  / 3.0;
grad[3 * aa1]+=sim * -di.x / 3.0;
grad[3 * aa1 + 1]+=sim * -di.y / 3.0;
grad[3 * aa1 + 2]+=sim * -di.z / 3.0;
grad[3 * aa2]+=sim * -di.x / 3.0;
grad[3 * aa2 + 1]+=sim * -di.y / 3.0;
grad[3 * aa2 + 2]+=sim * -di.z / 3.0;
grad[3 * aa3]+=sim * -di.x / 3.0;
grad[3 * aa3 + 1]+=sim * -di.y / 3.0;
grad[3 * aa3 + 2]+=sim * -di.z / 3.0;
} else {
var aa1=(this.neighbours.get$I(0)).$c();
var aa2=(this.neighbours.get$I(1)).$c();
grad[3 * this.acceptorAtom]+=sim * 2 * di.x  / 3.0;
grad[3 * this.acceptorAtom + 1]+=sim * 2 * di.y  / 3.0;
grad[3 * this.acceptorAtom + 2]+=sim * 2 * di.z  / 3.0;
grad[3 * aa1]+=sim * -di.x / 3.0;
grad[3 * aa1 + 1]+=sim * -di.y / 3.0;
grad[3 * aa1 + 2]+=sim * -di.z / 3.0;
grad[3 * aa2]+=sim * -di.x / 3.0;
grad[3 * aa2 + 1]+=sim * -di.y / 3.0;
grad[3 * aa2 + 2]+=sim * -di.z / 3.0;
}});

Clazz.newMeth(C$, 'updateAtomIndices$IA',  function (map) {
this.acceptorAtom=map[this.acceptorAtom];
for (var i=0; i < this.neighbours.size$(); i++) {
var neighbour=map[(this.neighbours.get$I(i)).$c()];
this.neighbours.set$I$O(i, Integer.valueOf$I(neighbour));
}
});

Clazz.newMeth(C$, 'getAtomIndices$',  function () {
var a=Clazz.array(Integer.TYPE, -1, [this.acceptorAtom]);
return a;
});

Clazz.newMeth(C$, 'copyPharmacophorePoint$',  function () {
return Clazz.new_(C$.c$$com_actelion_research_chem_phesa_pharmacophore_pp_AcceptorPoint,[this]);
});

Clazz.newMeth(C$, 'getFunctionalityIndex$',  function () {
return $I$(5).ACCEPTOR.getIndex$();
});

Clazz.newMeth(C$, 'getRotatedDirectionality$DAA$D',  function (rotMatrix, scaleFactor) {
var directMod=Clazz.new_($I$(2,1));
directMod=this.directionality.rotateC$DAA(rotMatrix);
directMod.scale$D(scaleFactor);
return directMod;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:39 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
