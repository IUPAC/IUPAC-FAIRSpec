(function(){var P$=Clazz.newPackage("com.actelion.research.chem.prediction"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "MolecularShapeCalculator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'assessShape$com_actelion_research_chem_StereoMolecule',  function (mol) {
mol.ensureHelperArrays$I(7);
if (mol.getAtoms$() == 0) return -1;
if (mol.getBonds$() == 0) return 0;
var maxLength=0;
for (var atom=0; atom < mol.getAtoms$(); atom++) if (mol.getConnAtoms$I(atom) == 1 || mol.isRingAtom$I(atom) ) maxLength=Math.max(maxLength, C$.findHighestAtomDistance$com_actelion_research_chem_StereoMolecule$I(mol, atom));

return (maxLength + 1) / mol.getAtoms$();
}, 1);

Clazz.newMeth(C$, 'findHighestAtomDistance$com_actelion_research_chem_StereoMolecule$I',  function (mol, startAtom) {
var graphLevel=Clazz.array(Integer.TYPE, [mol.getAtoms$()]);
var graphAtom=Clazz.array(Integer.TYPE, [mol.getAtoms$()]);
graphAtom[0]=startAtom;
graphLevel[startAtom]=1;
var current=0;
var highest=0;
while (current <= highest){
var parent=graphAtom[current];
for (var i=0; i < mol.getConnAtoms$I(parent); i++) {
var candidate=mol.getConnAtom$I$I(parent, i);
if (graphLevel[candidate] == 0) {
graphAtom[++highest]=candidate;
graphLevel[candidate]=graphLevel[parent] + 1;
}}
++current;
}
return graphLevel[graphAtom[highest]] - 1;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:40 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
