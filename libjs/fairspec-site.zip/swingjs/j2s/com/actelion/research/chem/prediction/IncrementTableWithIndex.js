(function(){var P$=Clazz.newPackage("com.actelion.research.chem.prediction"),I$=[[0,'java.util.ArrayList','java.io.BufferedReader','java.io.InputStreamReader','java.nio.charset.StandardCharsets','com.actelion.research.chem.descriptor.DescriptorHandlerLongFFP512','com.actelion.research.chem.prediction.IncrementTableRecordWithIndex']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "IncrementTableWithIndex");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['mRecords','java.util.ArrayList']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.mRecords=Clazz.new_($I$(1,1));
}, 1);

Clazz.newMeth(C$, 'c$$S',  function (filename) {
;C$.$init$.apply(this);
var theReader=Clazz.new_([Clazz.new_([this.getClass$().getResourceAsStream$S(filename), $I$(4).UTF_8],$I$(3,1).c$$java_io_InputStream$java_nio_charset_Charset)],$I$(2,1).c$$java_io_Reader);
var header=theReader.readLine$();
if (!header.equals$O("<index version 1.2.1>")) throw Clazz.new_(Clazz.load('Exception').c$$S,["index version mismatch"]);
var descriptorHandler=Clazz.new_($I$(5,1));
this.mRecords=Clazz.new_($I$(1,1));
while (true){
var theLine=theReader.readLine$();
if (theLine == null ) break;
var firstTab=theLine.indexOf$I("\t");
if (firstTab == -1) throw Clazz.new_(Clazz.load('Exception').c$$S,["line without TAB"]);
var secondTab=theLine.indexOf$I$I("\t", firstTab + 1);
if (secondTab == -1) throw Clazz.new_(Clazz.load('Exception').c$$S,["line without second TAB"]);
var index=descriptorHandler.decode$S(theLine.substring$I$I(0, firstTab));
var idcode=theLine.substring$I$I(firstTab + 1, secondTab);
var increment=Double.valueOf$S(theLine.substring$I(secondTab + 1)).doubleValue$();
this.mRecords.add$O(Clazz.new_($I$(6,1).c$$S$JA$D,[idcode, index, increment]));
}
theReader.close$();
}, 1);

Clazz.newMeth(C$, 'addElement$S$JA$D',  function (idcode, index, increment) {
this.mRecords.add$O(Clazz.new_($I$(6,1).c$$S$JA$D,[idcode, index, increment]));
});

Clazz.newMeth(C$, 'getSize$',  function () {
return this.mRecords.size$();
});

Clazz.newMeth(C$, 'getFragment$I',  function (i) {
return this.mRecords.get$I(i).mIDCode;
});

Clazz.newMeth(C$, 'getIndex$I',  function (i) {
return this.mRecords.get$I(i).mIndex;
});

Clazz.newMeth(C$, 'getIncrement$I',  function (i) {
return this.mRecords.get$I(i).mIncrement;
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:40 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
