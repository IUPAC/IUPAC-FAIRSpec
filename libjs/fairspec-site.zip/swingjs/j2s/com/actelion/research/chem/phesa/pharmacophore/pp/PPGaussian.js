(function(){var P$=Clazz.newPackage("com.actelion.research.chem.phesa.pharmacophore.pp"),I$=[[0,'com.actelion.research.chem.Coordinates','java.util.Base64','StringBuilder','com.actelion.research.chem.phesa.EncodeFunctions','com.actelion.research.chem.phesa.pharmacophore.pp.PharmacophorePointFactory','com.actelion.research.chem.PeriodicTable']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PPGaussian", null, 'com.actelion.research.chem.phesa.Gaussian3D');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['pp','com.actelion.research.chem.phesa.pharmacophore.pp.IPharmacophorePoint']]]

Clazz.newMeth(C$, 'c$$I$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint',  function (atomicNo, pp) {
;C$.superclazz.c$$I$I$com_actelion_research_chem_Coordinates$D.apply(this,[pp.getCenterID$(), atomicNo, pp.getCenter$(), 1.0]);C$.$init$.apply(this);
this.pp=pp;
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_phesa_pharmacophore_pp_PPGaussian',  function (original) {
;C$.superclazz.c$$I$I$com_actelion_research_chem_Coordinates$D.apply(this,[original.atomId, original.atomicNo, Clazz.new_($I$(1,1).c$$com_actelion_research_chem_Coordinates,[original.center]), original.weight]);C$.$init$.apply(this);
this.pp=original.pp.copyPharmacophorePoint$();
}, 1);

Clazz.newMeth(C$, 'c$$S$com_actelion_research_chem_StereoMolecule',  function (encodedGaussian, mol) {
Clazz.super_(C$, this);
this.decode$S$com_actelion_research_chem_StereoMolecule(encodedGaussian, mol);
}, 1);

Clazz.newMeth(C$, 'fromString$S$com_actelion_research_chem_StereoMolecule',  function (encodedGaussian, mol) {
return Clazz.new_(C$.c$$S$com_actelion_research_chem_StereoMolecule,[encodedGaussian, mol]);
}, 1);

Clazz.newMeth(C$, 'getRotatedDirectionality$DAA$D',  function (rotMatrix, scaleFactor) {
var directMod=this.pp.getRotatedDirectionality$DAA$D(rotMatrix, scaleFactor);
return directMod;
});

Clazz.newMeth(C$, 'getVectorSimilarity$com_actelion_research_chem_phesa_pharmacophore_pp_PPGaussian$com_actelion_research_chem_Coordinates',  function (ppGauss2, directionalityMod) {
return this.pp.getVectorSimilarity$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint$com_actelion_research_chem_Coordinates(ppGauss2.getPharmacophorePoint$(), directionalityMod);
});

Clazz.newMeth(C$, 'getVectorSimilarity$com_actelion_research_chem_phesa_pharmacophore_pp_PPGaussian',  function (ppGauss2) {
return this.getVectorSimilarity$com_actelion_research_chem_phesa_pharmacophore_pp_PPGaussian$com_actelion_research_chem_Coordinates(ppGauss2, ppGauss2.getPharmacophorePoint$().getDirectionality$());
});

Clazz.newMeth(C$, 'getPharmacophorePoint$',  function () {
return this.pp;
});

Clazz.newMeth(C$, 'setAtomId$I',  function (atomID) {
this.pp.setCenterID$I(atomID);
});

Clazz.newMeth(C$, 'getAtomId$',  function () {
return this.pp.getCenterID$();
});

Clazz.newMeth(C$, 'getSimilarity$com_actelion_research_chem_phesa_pharmacophore_pp_PPGaussian$com_actelion_research_chem_Coordinates',  function (ppGauss2, directionality) {
var ppSimilarity=1.0;
var vectorSim=this.getVectorSimilarity$com_actelion_research_chem_phesa_pharmacophore_pp_PPGaussian$com_actelion_research_chem_Coordinates(ppGauss2, directionality);
var similarity=(Math.max(0, vectorSim) + 2 * ppSimilarity) / 3.0;
return similarity;
});

Clazz.newMeth(C$, 'getSimilarity$com_actelion_research_chem_phesa_pharmacophore_pp_PPGaussian',  function (ppGauss2) {
return this.getSimilarity$com_actelion_research_chem_phesa_pharmacophore_pp_PPGaussian$com_actelion_research_chem_Coordinates(ppGauss2, ppGauss2.getPharmacophorePoint$().getDirectionality$());
});

Clazz.newMeth(C$, 'getInteractionSimilarity$com_actelion_research_chem_phesa_pharmacophore_pp_PPGaussian',  function (ppGauss2) {
return this.pp.getSimilarity$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint(ppGauss2.pp);
});

Clazz.newMeth(C$, 'setCenter$com_actelion_research_chem_Coordinates',  function (center) {
this.center=center;
this.pp.getCenter$().x=center.x;
this.pp.getCenter$().y=center.y;
this.pp.getCenter$().z=center.z;
});

Clazz.newMeth(C$, 'encode$',  function () {
var encoder=$I$(2).getEncoder$();
var molVolString=Clazz.new_($I$(3,1));
molVolString.append$S(Integer.toString$I(this.atomicNo));
molVolString.append$S(" ");
molVolString.append$S(encoder.encodeToString$BA($I$(4).doubleToByteArray$D(this.weight)));
molVolString.append$S(" ");
molVolString.append$S(this.pp.encode$());
return molVolString.toString();
});

Clazz.newMeth(C$, 'decode$S$com_actelion_research_chem_StereoMolecule',  function (string64, mol) {
var decoder=$I$(2).getDecoder$();
var strings=string64.split$S(" ");
if (strings.length == 1) {
return;
}this.atomicNo=(Integer.decode$S(strings[0])).$c();
this.weight=$I$(4,"byteArrayToDouble$BA",[decoder.decode$BA(strings[1].getBytes$())]);
var sb=Clazz.new_($I$(3,1));
for (var i=2; i < strings.length; i++) {
sb.append$S(strings[i]);
sb.append$S(" ");
}
this.pp=$I$(5,"fromString$S$com_actelion_research_chem_StereoMolecule",[sb.toString(), mol]);
this.center=this.pp.getCenter$();
this.alpha=this.calculateWidth$();
this.volume=this.calculateVolume$();
this.coeff=this.calculateHeight$();
this.atomId=this.pp.getCenterID$();
});

Clazz.newMeth(C$, 'calculateHeight$',  function () {
return 2.82842712475;
});

Clazz.newMeth(C$, 'transform$com_actelion_research_chem_alignment3d_transformation_Transformation',  function (transformation) {
if (!(Clazz.instanceOf(transformation, "com.actelion.research.chem.alignment3d.transformation.TransformationSequence"))) {
this.pp.applyTransformation$com_actelion_research_chem_alignment3d_transformation_Transformation(transformation);
this.center=this.pp.getCenter$();
} else {
var seq=transformation;
for (var trans, $trans = seq.getTransformations$().iterator$(); $trans.hasNext$()&&((trans=($trans.next$())),1);) {
this.pp.applyTransformation$com_actelion_research_chem_alignment3d_transformation_Transformation(trans);
this.center=this.pp.getCenter$();
}
}});

Clazz.newMeth(C$, 'updateCoordinates$com_actelion_research_chem_CoordinatesA',  function (coords) {
this.pp.updateCoordinates$com_actelion_research_chem_CoordinatesA(coords);
this.center=this.pp.getCenter$();
});

Clazz.newMeth(C$, 'updateAtomIndeces$IA',  function (map) {
this.atomId=map[this.atomId];
this.pp.updateAtomIndices$IA(map);
});

Clazz.newMeth(C$, 'calculateWidth$',  function () {
var vdwR=$I$(6).getElement$I(this.atomicNo).getVDWRadius$();
return 2.41798793102 / (vdwR * vdwR);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:39 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
