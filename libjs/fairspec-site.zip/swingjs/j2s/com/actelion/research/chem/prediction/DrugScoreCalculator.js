(function(){var P$=Clazz.newPackage("com.actelion.research.chem.prediction"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "DrugScoreCalculator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'calculate$D$D$D$D$IA',  function (mCLogP, mSolubility, mMolweight, mDruglikeness, toxRisks) {
var cLogPScore=1 / (1 + Math.exp(mCLogP - 5));
var solubilityScore=1 - 1 / (1 + Math.exp(mSolubility + 5));
var molweightScore=1 / (1 + Math.exp(0.012 * mMolweight - 6));
var drugLikenessScore=1 - 1 / (1 + Math.exp(mDruglikeness));
var drugScore=(0.5 + cLogPScore / 2) * (0.5 + solubilityScore / 2) * (0.5 + molweightScore / 2) * (0.5 + drugLikenessScore / 2) ;
for (var i=0; toxRisks != null  && i < toxRisks.length ; i++) {
if (toxRisks[i] == 2) drugScore*=0.8;
 else if (toxRisks[i] == 3) drugScore*=0.6;
}
return drugScore;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:40 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
