(function(){var P$=Clazz.newPackage("com.actelion.research.chem.optimization"),I$=[[0,'com.actelion.research.chem.docking.DockingUtils','com.actelion.research.chem.alignment3d.transformation.Quaternion','com.actelion.research.chem.alignment3d.transformation.ExponentialMap']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MCHelper");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['torsionHelper','com.actelion.research.chem.conf.BondRotationHelper','mcsRotBondIndeces','int[]','random','java.util.Random']]
,['D',['TEMPERATURE','MOVE_AMPLITUDE']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_conf_BondRotationHelper$IA$java_util_Random',  function (torsionHelper, mcsRotBondIndeces, random) {
;C$.$init$.apply(this);
this.torsionHelper=torsionHelper;
this.mcsRotBondIndeces=mcsRotBondIndeces;
this.random=random;
}, 1);

Clazz.newMeth(C$, 'randomPerturbation$com_actelion_research_chem_conf_Conformer$DA',  function (conf, state) {
if (this.mcsRotBondIndeces == null ) {
var num=((3 * this.random.nextDouble$())|0);
if (num == 0) {
var shift=$I$(1).randomVectorInSphere$java_util_Random(this.random).scale$D(C$.MOVE_AMPLITUDE);
state[0]+=shift.x;
state[1]+=shift.y;
state[2]+=shift.z;
} else if (num == 1) {
var r=this.getGyrationRadius$com_actelion_research_chem_conf_Conformer(conf);
var rot=$I$(1).randomVectorInSphere$java_util_Random(this.random).scale$D(C$.MOVE_AMPLITUDE / r);
var angle=rot.dist$();
var q=Clazz.new_($I$(2,1).c$$D$D$D$D,[1.0, 0.0, 0.0, 0.0]);
if (angle > 1.0E-4 ) {
var axis=rot.scale$D(1.0 / angle);
q=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_Coordinates$D,[axis, angle]);
}var em=Clazz.new_($I$(3,1).c$$D$D$D,[state[3], state[4], state[5]]);
var qOrig=em.toQuaternion$();
q.multiply$com_actelion_research_chem_alignment3d_transformation_Quaternion(qOrig);
var emNew=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_alignment3d_transformation_Quaternion,[q]);
state[3]=emNew.getP$().x;
state[4]=emNew.getP$().y;
state[5]=emNew.getP$().z;
} else {
this.torsionPerturbation$com_actelion_research_chem_conf_Conformer$DA(conf, state);
}} else {
if (this.torsionHelper.getRotatableBonds$().length == 0) return;
 else if (this.mcsRotBondIndeces.length == 0) return;
var rnd=this.random.nextDouble$();
rnd*=180.0;
var rotateBy=this.random.nextBoolean$() ? rnd : -rnd;
rotateBy=rotateBy * 3.141592653589793 / 180.0;
var bond=this.mcsRotBondIndeces[this.random.nextInt$I(this.mcsRotBondIndeces.length)];
var previousAngle=state[6 + bond];
var newAngle=previousAngle + rotateBy;
if (newAngle > 3.141592653589793 ) {
newAngle-=6.283185307179586;
}state[6 + bond]=newAngle;
}});

Clazz.newMeth(C$, 'torsionPerturbation$com_actelion_research_chem_conf_Conformer$DA',  function (ligConf, state) {
if (this.torsionHelper.getRotatableBonds$().length == 0) return;
var rnd=this.random.nextDouble$();
rnd*=180.0;
var rotateBy=this.random.nextBoolean$() ? rnd : -rnd;
rotateBy=rotateBy * 3.141592653589793 / 180.0;
var bond=this.random.nextInt$I(this.torsionHelper.getRotatableBonds$().length);
var previousAngle=state[6 + bond];
var newAngle=previousAngle + rotateBy;
if (newAngle > 3.141592653589793 ) {
newAngle-=6.283185307179586;
}state[6 + bond]=newAngle;
});

Clazz.newMeth(C$, 'getGyrationRadius$com_actelion_research_chem_conf_Conformer',  function (conf) {
var com=$I$(1).getCOM$com_actelion_research_chem_conf_Conformer(conf);
var r=0.0;
var counter=0;
for (var a=0; a < conf.getMolecule$().getAtoms$(); a++) {
var c=conf.getCoordinates$I(a);
r+=c.distanceSquared$com_actelion_research_chem_Coordinates(com);
++counter;
}
r/=counter;
return Math.sqrt(r);
});

Clazz.newMeth(C$, 'setTorsionHelper$com_actelion_research_chem_conf_BondRotationHelper',  function (torsionHelper) {
this.torsionHelper=torsionHelper;
});

Clazz.newMeth(C$, 'setMcsRotBondIndeces$IA',  function (mcsRotBondIndeces) {
this.mcsRotBondIndeces=mcsRotBondIndeces;
});

Clazz.newMeth(C$, 'accept$D$D',  function (oldScore, newScore) {
var accept=false;
if (newScore > oldScore ) accept=true;
 else {
var delta=-(newScore - oldScore);
var p=Math.exp(-delta / C$.TEMPERATURE);
var rnd=this.random.nextDouble$();
if (rnd < p ) accept=true;
}return accept;
});

C$.$static$=function(){C$.$static$=0;
C$.TEMPERATURE=0.0043;
C$.MOVE_AMPLITUDE=2.0;
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:39 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
