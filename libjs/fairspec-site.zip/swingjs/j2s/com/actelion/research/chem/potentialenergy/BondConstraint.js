(function(){var P$=Clazz.newPackage("com.actelion.research.chem.potentialenergy"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "BondConstraint", null, null, 'com.actelion.research.chem.potentialenergy.PotentialEnergyTerm');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['targetValue'],'O',['conf','com.actelion.research.chem.conf.Conformer','bondAtoms','int[]']]
,['D',['FORCE_CONSTANT']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_conf_Conformer$IA$D',  function (conf, bondAtoms, targetDistance) {
;C$.$init$.apply(this);
this.conf=conf;
this.bondAtoms=bondAtoms;
this.targetValue=targetDistance;
}, 1);

Clazz.newMeth(C$, 'getFGValue$DA',  function (gradient) {
var a1=this.bondAtoms[0];
var a2=this.bondAtoms[1];
var c1=this.conf.getCoordinates$I(a1);
var c2=this.conf.getCoordinates$I(a2);
var d=c1.subC$com_actelion_research_chem_Coordinates(c2);
var dist=d.dist$();
var dGrad;
var prefactor=C$.FORCE_CONSTANT * (dist - this.targetValue);
dGrad=d.scaleC$D(prefactor).scaleC$D(1.0 / Math.max(dist, 1.0E-8));
gradient[3 * a1]+=dGrad.x;
gradient[3 * a1 + 1]+=dGrad.y;
gradient[3 * a1 + 2]+=dGrad.z;
gradient[3 * a2]-=dGrad.x;
gradient[3 * a2 + 1]-=dGrad.y;
gradient[3 * a2 + 2]-=dGrad.z;
var distTerm=(dist - this.targetValue);
return 0.5 * C$.FORCE_CONSTANT * distTerm * distTerm ;
});

C$.$static$=function(){C$.$static$=0;
C$.FORCE_CONSTANT=50.0;
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:40 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
