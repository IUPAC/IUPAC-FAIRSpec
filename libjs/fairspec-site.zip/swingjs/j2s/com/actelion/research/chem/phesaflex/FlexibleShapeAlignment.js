(function(){var P$=Clazz.newPackage("com.actelion.research.chem.phesaflex"),p$1={},I$=[[0,'com.actelion.research.chem.phesa.MolecularVolume','java.util.HashMap',['com.actelion.research.chem.alignment3d.PheSAAlignmentOptimizer','.PheSASetting'],'com.actelion.research.chem.phesa.PheSAAlignment','com.actelion.research.chem.conf.Conformer','com.actelion.research.chem.conf.BondRotationHelper','com.actelion.research.chem.phesaflex.EvaluableFlexibleOverlap','com.actelion.research.chem.optimization.OptimizerLBFGS','java.util.Random','com.actelion.research.chem.optimization.MCHelper','java.util.Arrays',['com.actelion.research.chem.alignment3d.PheSAAlignmentOptimizer','.SimilarityMode'],'com.actelion.research.chem.alignment3d.transformation.TransformationSequence','com.actelion.research.chem.forcefield.mmff.ForceFieldMMFF94','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.forcefield.mmff.MMFFPositionConstraint']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "FlexibleShapeAlignment");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['refMol','com.actelion.research.chem.StereoMolecule','+fitMol','refVol','com.actelion.research.chem.phesa.MolecularVolume','+fitVol','ffOptions','java.util.Map','settings','com.actelion.research.chem.alignment3d.PheSAAlignmentOptimizer.PheSASetting']]]

Clazz.newMeth(C$, 'getSettings$',  function () {
return this.settings;
});

Clazz.newMeth(C$, 'setSettings$com_actelion_research_chem_alignment3d_PheSAAlignmentOptimizer_PheSASetting',  function (settings) {
this.settings=settings;
});

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule',  function (refMol, fitMol) {
C$.c$$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_phesa_MolecularVolume$com_actelion_research_chem_phesa_MolecularVolume.apply(this, [refMol, fitMol, Clazz.new_($I$(1,1).c$$com_actelion_research_chem_StereoMolecule,[refMol]), Clazz.new_($I$(1,1).c$$com_actelion_research_chem_StereoMolecule,[fitMol])]);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_phesa_MolecularVolume$com_actelion_research_chem_phesa_MolecularVolume',  function (refMol, fitMol, refVol, fitVol) {
;C$.$init$.apply(this);
this.refMol=refMol;
this.fitMol=fitMol;
this.refVol=refVol;
this.fitVol=fitVol;
this.ffOptions=Clazz.new_($I$(2,1));
this.ffOptions.put$O$O("dielectric constant", Double.valueOf$D(4.0));
this.settings=Clazz.new_($I$(3,1));
}, 1);

Clazz.newMeth(C$, 'align$',  function () {
var result=Clazz.array(Double.TYPE, [3]);
var shapeAlign=Clazz.new_($I$(4,1).c$$com_actelion_research_chem_phesa_MolecularVolume$com_actelion_research_chem_phesa_MolecularVolume,[this.refVol, this.fitVol]);
var e0=this.calcMin$com_actelion_research_chem_StereoMolecule(this.fitMol);
if (Double.isNaN$D(e0)) {
System.err.println$S("no force field parameters for this structure");
return result;
}this.restrainedRelaxation$com_actelion_research_chem_StereoMolecule$D(this.fitMol, e0);
var isHydrogen=Clazz.array(Boolean.TYPE, [this.fitMol.getAllAtoms$()]);
for (var at=0; at < this.fitMol.getAllAtoms$(); at++) {
isHydrogen[at]=this.fitMol.getAtomicNo$I(at) == 1;
}
var fitConf=Clazz.new_($I$(5,1).c$$com_actelion_research_chem_StereoMolecule,[this.fitMol]);
var torsionHelper=Clazz.new_([fitConf.getMolecule$(), true],$I$(6,1).c$$com_actelion_research_chem_StereoMolecule$Z);
var eval=Clazz.new_($I$(7,1).c$$com_actelion_research_chem_phesa_PheSAAlignment$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_BondRotationHelper$com_actelion_research_chem_alignment3d_PheSAAlignmentOptimizer_PheSASetting$ZA$java_util_Map,[shapeAlign, this.refMol, fitConf, torsionHelper, this.settings, isHydrogen, this.ffOptions]);
eval.setState$DA(eval.getState$());
eval.setE0$D(e0);
var opt=Clazz.new_($I$(8,1).c$$I$D,[200, 0.001]);
var t0=opt.optimize$com_actelion_research_chem_optimization_Evaluable(eval)[0];
var random=Clazz.new_($I$(9,1).c$$J,[12345]);
var mcHelper=Clazz.new_($I$(10,1).c$$com_actelion_research_chem_conf_BondRotationHelper$IA$java_util_Random,[torsionHelper, null, random]);
var success=torsionHelper.getRotatableBonds$().length != 0;
var v=eval.getState$();
var told=t0;
if (success) {
for (var i=0; i < 50; i++) {
var vold=$I$(11).stream$DA(v).toArray$();
mcHelper.torsionPerturbation$com_actelion_research_chem_conf_Conformer$DA(fitConf, v);
eval.setState$DA(v);
eval.setE0$D(e0);
opt=Clazz.new_($I$(8,1).c$$I$D,[200, 0.001]);
opt.optimize$com_actelion_research_chem_optimization_Evaluable(eval);
var tnew=p$1.getSimilarity$com_actelion_research_chem_phesaflex_EvaluableFlexibleOverlap$com_actelion_research_chem_phesa_PheSAAlignment.apply(this, [eval, shapeAlign]);
if (!mcHelper.accept$D$D(told, tnew)) {
v=vold;
eval.setState$DA(v);
} else {
eval.getState$DA(v);
told=tnew;
}}
}var alignedConf=eval.getFitConf$();
for (var a=0; a < alignedConf.getMolecule$().getAllAtoms$(); a++) {
this.fitMol.setAtomX$I$D(a, alignedConf.getX$I(a));
this.fitMol.setAtomY$I$D(a, alignedConf.getY$I(a));
this.fitMol.setAtomZ$I$D(a, alignedConf.getZ$I(a));
}
result=p$1.getResult.apply(this, []);
return result;
});

Clazz.newMeth(C$, 'getSimilarity$com_actelion_research_chem_phesaflex_EvaluableFlexibleOverlap$com_actelion_research_chem_phesa_PheSAAlignment',  function (eval, shapeAlign) {
var tversky=this.settings.getSimMode$() !== $I$(12).TANIMOTO ;
var ppWeight=this.settings.getPpWeight$();
var tverskyCoeff=this.settings.getSimMode$() === $I$(12).TVERSKY  ? 0.95 : 0.050000000000000044;
var Obb=eval.getFGValueShapeSelf$DA$com_actelion_research_chem_phesa_ShapeVolume$Z(Clazz.array(Double.TYPE, [3 * this.fitMol.getAllAtoms$()]), shapeAlign.getMolGauss$(), false);
var Oaa=eval.getFGValueShapeSelf$DA$com_actelion_research_chem_phesa_ShapeVolume$Z(Clazz.array(Double.TYPE, [3 * this.refMol.getAllAtoms$()]), shapeAlign.getRefMolGauss$(), true);
var Oab=eval.getFGValueShape$DA(Clazz.array(Double.TYPE, [3 * this.fitMol.getAllAtoms$()]));
var Tshape=0.0;
if (tversky) Tshape=Oab / (tverskyCoeff * Obb + (1.0 - tverskyCoeff) * Oaa);
 else Tshape=Oab / (Oaa + Obb - Oab);
if (!tversky && Tshape > 1.0  ) Tshape=1.0;
var correctionFactor=shapeAlign.getRefMolGauss$().getPPGaussians$().size$() / shapeAlign.getRefMolGauss$().getPPGaussians$().stream$().mapToDouble$java_util_function_ToDoubleFunction(((P$.FlexibleShapeAlignment$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "FlexibleShapeAlignment$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.ToDoubleFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsDouble$com_actelion_research_chem_phesa_pharmacophore_pp_PPGaussian','applyAsDouble$O'],  function (g) { return (g.getWeight$.apply(g, []));});
})()
), Clazz.new_(P$.FlexibleShapeAlignment$lambda1.$init$,[this, null]))).sum$();
var ObbPP=eval.getFGValueSelfPP$com_actelion_research_chem_phesa_ShapeVolume$Z(shapeAlign.getMolGauss$(), false);
var OaaPP=eval.getFGValueSelfPP$com_actelion_research_chem_phesa_ShapeVolume$Z(shapeAlign.getRefMolGauss$(), true);
var OabPP=eval.getFGValuePP$();
var Tpp=0.0;
if (shapeAlign.getRefMolGauss$().getPPGaussians$().isEmpty$() && shapeAlign.getMolGauss$().getPPGaussians$().isEmpty$() ) Tpp=1.0;
 else {
if (tversky) Tpp=OabPP / (tverskyCoeff * ObbPP + (1.0 - tverskyCoeff) * OaaPP);
 else Tpp=(OabPP / (OaaPP + ObbPP - OabPP));
}Tpp*=correctionFactor;
if (!tversky && Tshape > 1.0  ) Tshape=1.0;
if (!tversky && Tpp > 1.0  ) Tpp=1.0;
return (1.0 - ppWeight) * Tshape + ppWeight * Tpp;
}, p$1);

Clazz.newMeth(C$, 'getResult',  function () {
var sequence=Clazz.new_($I$(13,1));
var pa=Clazz.new_([this.fitMol, this.refMol, this.settings.getPpWeight$()],$I$(4,1).c$$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$D);
var r=pa.findAlignment$DAA$com_actelion_research_chem_alignment3d_transformation_TransformationSequence$Z$com_actelion_research_chem_alignment3d_PheSAAlignmentOptimizer_SimilarityMode(Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [0.0, 0.0, 0.0, 0.0, 0.0, 0.0])]), sequence, false, this.settings.getSimMode$());
return Clazz.array(Double.TYPE, -1, [r[0], r[1], r[2], r[3]]);
}, p$1);

Clazz.newMeth(C$, 'calcMin$com_actelion_research_chem_StereoMolecule',  function (fitMol) {
try {
$I$(14).initialize$S("MMFF94s+");
var forceField=Clazz.new_([Clazz.new_($I$(15,1).c$$com_actelion_research_chem_Molecule,[fitMol]), "MMFF94s+", this.ffOptions],$I$(14,1).c$$com_actelion_research_chem_StereoMolecule$S$java_util_Map);
forceField.minimise$();
return forceField.getTotalEnergy$();
} catch (rte) {
if (Clazz.exceptionOf(rte,"RuntimeException")){
return NaN;
} else {
throw rte;
}
}
});

Clazz.newMeth(C$, 'restrainedRelaxation$com_actelion_research_chem_StereoMolecule$D',  function (fitMol, e0) {
$I$(14).initialize$S("MMFF94s+");
var init=0.2;
var notRelaxed=true;
var maxCycles=10;
var cycles=0;
while (notRelaxed && cycles < maxCycles ){
var forceField=Clazz.new_($I$(14,1).c$$com_actelion_research_chem_StereoMolecule$S$java_util_Map,[fitMol, "MMFF94s+", this.ffOptions]);
var constraint=Clazz.new_($I$(16,1).c$$com_actelion_research_chem_StereoMolecule$D$D,[fitMol, 50, init]);
forceField.addEnergyTerm$com_actelion_research_chem_forcefield_mmff_EnergyTerm(constraint);
forceField.minimise$();
var e=forceField.getTotalEnergy$();
notRelaxed=(e > e0 ) && (e - e0 > 10.0 ) ;
init+=0.2;
++cycles;
}
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:40 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
