(function(){var P$=Clazz.newPackage("com.actelion.research.chem.phesa.pharmacophore.pp"),p$1={},I$=[[0,'com.actelion.research.chem.Coordinates','java.util.ArrayList','StringBuilder',['com.actelion.research.chem.phesa.pharmacophore.pp.IPharmacophorePoint','.Functionality']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ChargePoint", null, null, 'com.actelion.research.chem.phesa.pharmacophore.pp.IPharmacophorePoint');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['chargeAtom','charge'],'O',['neighbours','java.util.List','center','com.actelion.research.chem.Coordinates']]
,['O',['directionality','com.actelion.research.chem.Coordinates']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$I$java_util_List$I',  function (mol, a, neighbours, charge) {
;C$.$init$.apply(this);
if (charge == 0) throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["charge should not be 0 "]);
this.chargeAtom=a;
this.neighbours=neighbours;
this.charge=charge;
this.updateCoordinates$com_actelion_research_chem_CoordinatesA(mol.getAtomCoordinates$());
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_phesa_pharmacophore_pp_ChargePoint',  function (cP) {
;C$.$init$.apply(this);
this.chargeAtom=cP.chargeAtom;
this.charge=cP.charge;
this.center=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_Coordinates,[cP.center]);
this.neighbours=Clazz.new_($I$(2,1));
for (var neighbour, $neighbour = cP.neighbours.iterator$(); $neighbour.hasNext$()&&((neighbour=($neighbour.next$()).intValue$()),1);) {
this.neighbours.add$O(Integer.valueOf$I(neighbour));
}
}, 1);

Clazz.newMeth(C$, 'getCenter$',  function () {
return this.center;
});

Clazz.newMeth(C$, 'updateCoordinates$com_actelion_research_chem_CoordinatesA',  function (coords) {
var com=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_Coordinates,[coords[this.chargeAtom]]);
if (this.neighbours != null ) {
for (var neighbour, $neighbour = this.neighbours.iterator$(); $neighbour.hasNext$()&&((neighbour=($neighbour.next$()).intValue$()),1);) {
com.add$com_actelion_research_chem_Coordinates(coords[neighbour]);
}
com.scale$D(1.0 / (this.neighbours.size$() + 1));
}this.center=com;
});

Clazz.newMeth(C$, 'getDirectionality$',  function () {
return C$.directionality;
});

Clazz.newMeth(C$, 'getRotatedDirectionality$DAA$D',  function (rotMatrix, scaleFactor) {
var directMod=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_Coordinates,[C$.directionality]);
return directMod;
});

Clazz.newMeth(C$, 'c$$S$com_actelion_research_chem_StereoMolecule',  function (ppString, mol) {
;C$.$init$.apply(this);
p$1.decode$S$com_actelion_research_chem_StereoMolecule.apply(this, [ppString, mol]);
}, 1);

Clazz.newMeth(C$, 'fromString$S$com_actelion_research_chem_StereoMolecule',  function (ppString, mol) {
return Clazz.new_(C$.c$$S$com_actelion_research_chem_StereoMolecule,[ppString, mol]);
}, 1);

Clazz.newMeth(C$, 'decode$S$com_actelion_research_chem_StereoMolecule',  function (ppString, mol) {
var strings=ppString.split$S(" ");
this.chargeAtom=(Integer.decode$S(strings[1])).$c();
this.charge=(Integer.decode$S(strings[2])).$c();
this.neighbours=Clazz.new_($I$(2,1));
for (var i=3; i < strings.length; i++) {
this.neighbours.add$O(Integer.decode$S(strings[i]));
}
this.updateCoordinates$com_actelion_research_chem_CoordinatesA(mol.getAtomCoordinates$());
}, p$1);

Clazz.newMeth(C$, 'encode$',  function () {
var molVolString=Clazz.new_($I$(3,1));
molVolString.append$S("i");
molVolString.append$S(" ");
molVolString.append$S(Integer.toString$I(this.chargeAtom));
molVolString.append$S(" ");
molVolString.append$S(Integer.toString$I(this.charge));
molVolString.append$S(" ");
for (var neighbour, $neighbour = this.neighbours.iterator$(); $neighbour.hasNext$()&&((neighbour=($neighbour.next$())),1);) {
molVolString.append$O(neighbour);
molVolString.append$S(" ");
}
return molVolString.toString().trim$();
});

Clazz.newMeth(C$, 'getSimilarity$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint',  function (pp) {
var result=0.0;
if (Clazz.instanceOf(pp, "com.actelion.research.chem.phesa.pharmacophore.pp.ChargePoint")) {
result=this.charge * (pp).charge > 0 ? 1.0 : 0.0;
}return result;
});

Clazz.newMeth(C$, 'getCenterID$',  function () {
return this.chargeAtom;
});

Clazz.newMeth(C$, 'setCenterID$I',  function (centerID) {
this.chargeAtom=centerID;
});

Clazz.newMeth(C$, 'setDirectionality$com_actelion_research_chem_Coordinates',  function (directionality) {
return;
});

Clazz.newMeth(C$, 'getCharge$',  function () {
return this.charge;
});

Clazz.newMeth(C$, 'updateAtomIndices$IA',  function (map) {
this.chargeAtom=map[this.chargeAtom];
for (var i=0; i < this.neighbours.size$(); i++) {
var neighbour=map[(this.neighbours.get$I(i)).$c()];
this.neighbours.set$I$O(i, Integer.valueOf$I(neighbour));
}
});

Clazz.newMeth(C$, 'getAtomIndices$',  function () {
var a=Clazz.array(Integer.TYPE, -1, [this.chargeAtom]);
return a;
});

Clazz.newMeth(C$, 'copyPharmacophorePoint$',  function () {
return Clazz.new_(C$.c$$com_actelion_research_chem_phesa_pharmacophore_pp_ChargePoint,[this]);
});

Clazz.newMeth(C$, 'getDirectionalityDerivativeCartesian$DA$DA$com_actelion_research_chem_Coordinates$D',  function (grad, v, di, sim) {
return;
});

Clazz.newMeth(C$, 'getVectorSimilarity$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint$com_actelion_research_chem_Coordinates',  function (pp2, directionalityMod) {
return 1.0;
});

Clazz.newMeth(C$, 'getVectorSimilarity$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint',  function (pp2) {
return 1.0;
});

Clazz.newMeth(C$, 'getFunctionalityIndex$',  function () {
if (this.charge < 0) return $I$(4).NEG_CHARGE.getIndex$();
 else return $I$(4).POS_CHARGE.getIndex$();
});

Clazz.newMeth(C$, 'getChargeAtom$',  function () {
return this.chargeAtom;
});

Clazz.newMeth(C$, 'setChargeAtom$I',  function (chargeAtom) {
this.chargeAtom=chargeAtom;
});

Clazz.newMeth(C$, 'getNeighbours$',  function () {
return this.neighbours;
});

Clazz.newMeth(C$, 'setNeighbours$java_util_List',  function (neighbours) {
this.neighbours=neighbours;
});

C$.$static$=function(){C$.$static$=0;
C$.directionality=Clazz.new_($I$(1,1).c$$D$D$D,[1.0, 0.0, 0.0]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:39 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
