(function(){var P$=Clazz.newPackage("com.actelion.research.chem.prediction"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "IncrementTableRecordWithIndex");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['mIncrement'],'S',['mIDCode'],'O',['mIndex','long[]']]]

Clazz.newMeth(C$, 'c$$S$JA$D',  function (idcode, index, increment) {
;C$.$init$.apply(this);
this.mIDCode=idcode;
this.mIndex=index;
this.mIncrement=increment;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:40 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
