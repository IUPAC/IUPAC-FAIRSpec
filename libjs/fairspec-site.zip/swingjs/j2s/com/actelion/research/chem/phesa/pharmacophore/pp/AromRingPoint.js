(function(){var P$=Clazz.newPackage("com.actelion.research.chem.phesa.pharmacophore.pp"),p$1={},I$=[[0,'com.actelion.research.chem.Coordinates','java.util.ArrayList','StringBuilder','com.actelion.research.util.ArrayUtils',['com.actelion.research.chem.phesa.pharmacophore.pp.IPharmacophorePoint','.Functionality']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AromRingPoint", null, null, 'com.actelion.research.chem.phesa.pharmacophore.pp.IPharmacophorePoint');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['referenceAtom'],'O',['ringAtoms','java.util.List','center','com.actelion.research.chem.Coordinates']]
,['O',['directionality','com.actelion.research.chem.Coordinates']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$I$java_util_List',  function (mol, a, ringAtoms) {
;C$.$init$.apply(this);
this.referenceAtom=a;
this.ringAtoms=ringAtoms;
this.updateCoordinates$com_actelion_research_chem_CoordinatesA(mol.getAtomCoordinates$());
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_phesa_pharmacophore_pp_AromRingPoint',  function (aP) {
;C$.$init$.apply(this);
this.referenceAtom=aP.referenceAtom;
this.center=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_Coordinates,[aP.center]);
this.ringAtoms=Clazz.new_($I$(2,1));
for (var ringAtom, $ringAtom = aP.ringAtoms.iterator$(); $ringAtom.hasNext$()&&((ringAtom=($ringAtom.next$()).intValue$()),1);) {
this.ringAtoms.add$O(Integer.valueOf$I(ringAtom));
}
}, 1);

Clazz.newMeth(C$, 'getCenter$',  function () {
return this.center;
});

Clazz.newMeth(C$, 'updateCoordinates$com_actelion_research_chem_CoordinatesA',  function (coords) {
var com=Clazz.new_($I$(1,1).c$$D$D$D,[0, 0, 0]);
for (var ringAtom, $ringAtom = this.ringAtoms.iterator$(); $ringAtom.hasNext$()&&((ringAtom=($ringAtom.next$()).intValue$()),1);) {
com.add$com_actelion_research_chem_Coordinates(coords[ringAtom]);
}
com.scale$D(1.0 / (this.ringAtoms.size$()));
this.center=com;
});

Clazz.newMeth(C$, 'getDirectionality$',  function () {
return C$.directionality;
});

Clazz.newMeth(C$, 'c$$S$com_actelion_research_chem_StereoMolecule',  function (ppString, mol) {
;C$.$init$.apply(this);
p$1.decode$S$com_actelion_research_chem_StereoMolecule.apply(this, [ppString, mol]);
}, 1);

Clazz.newMeth(C$, 'fromString$S$com_actelion_research_chem_StereoMolecule',  function (ppString, mol) {
return Clazz.new_(C$.c$$S$com_actelion_research_chem_StereoMolecule,[ppString, mol]);
}, 1);

Clazz.newMeth(C$, 'decode$S$com_actelion_research_chem_StereoMolecule',  function (ppString, mol) {
var strings=ppString.split$S(" ");
this.referenceAtom=(Integer.decode$S(strings[1])).$c();
this.ringAtoms=Clazz.new_($I$(2,1));
for (var i=2; i < strings.length; i++) {
this.ringAtoms.add$O(Integer.decode$S(strings[i]));
}
this.updateCoordinates$com_actelion_research_chem_CoordinatesA(mol.getAtomCoordinates$());
}, p$1);

Clazz.newMeth(C$, 'encode$',  function () {
var molVolString=Clazz.new_($I$(3,1));
molVolString.append$S("r");
molVolString.append$S(" ");
molVolString.append$S(Integer.toString$I(this.referenceAtom));
molVolString.append$S(" ");
for (var ringAtom, $ringAtom = this.ringAtoms.iterator$(); $ringAtom.hasNext$()&&((ringAtom=($ringAtom.next$())),1);) {
molVolString.append$O(ringAtom);
molVolString.append$S(" ");
}
return molVolString.toString().trim$();
});

Clazz.newMeth(C$, 'getSimilarity$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint',  function (pp) {
var result=0.0;
if (Clazz.instanceOf(pp, "com.actelion.research.chem.phesa.pharmacophore.pp.AromRingPoint")) {
result=1.0;
}return result;
});

Clazz.newMeth(C$, 'getCenterID$',  function () {
return this.referenceAtom;
});

Clazz.newMeth(C$, 'setCenterID$I',  function (centerID) {
this.referenceAtom=centerID;
});

Clazz.newMeth(C$, 'setDirectionality$com_actelion_research_chem_Coordinates',  function (directionality) {
return;
});

Clazz.newMeth(C$, 'updateAtomIndices$IA',  function (map) {
this.referenceAtom=map[this.referenceAtom];
for (var i=0; i < this.ringAtoms.size$(); i++) {
var neighbour=map[(this.ringAtoms.get$I(i)).$c()];
this.ringAtoms.set$I$O(i, Integer.valueOf$I(neighbour));
}
});

Clazz.newMeth(C$, 'getAtomIndices$',  function () {
return $I$(4).toIntArray$java_util_Collection(this.ringAtoms);
});

Clazz.newMeth(C$, 'copyPharmacophorePoint$',  function () {
return Clazz.new_(C$.c$$com_actelion_research_chem_phesa_pharmacophore_pp_AromRingPoint,[this]);
});

Clazz.newMeth(C$, 'getDirectionalityDerivativeCartesian$DA$DA$com_actelion_research_chem_Coordinates$D',  function (grad, v, di, sim) {
return;
});

Clazz.newMeth(C$, 'getVectorSimilarity$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint$com_actelion_research_chem_Coordinates',  function (pp2, directionalityMod) {
return 1.0;
});

Clazz.newMeth(C$, 'getVectorSimilarity$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint',  function (pp2) {
return 1.0;
});

Clazz.newMeth(C$, 'getFunctionalityIndex$',  function () {
return $I$(5).AROM_RING.getIndex$();
});

Clazz.newMeth(C$, 'getRotatedDirectionality$DAA$D',  function (rotMatrix, scaleFactor) {
var directMod=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_Coordinates,[C$.directionality]);
return directMod;
});

C$.$static$=function(){C$.$static$=0;
C$.directionality=Clazz.new_($I$(1,1).c$$D$D$D,[1.0, 0.0, 0.0]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:39 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
