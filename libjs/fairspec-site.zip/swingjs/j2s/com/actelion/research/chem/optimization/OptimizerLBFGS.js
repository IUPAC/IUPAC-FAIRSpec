(function(){var P$=Clazz.newPackage("com.actelion.research.chem.optimization"),I$=[[0,'java.util.Arrays','com.actelion.research.chem.optimization.Lnsrch']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "OptimizerLBFGS");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['minRMS'],'I',['maxIterations']]]

Clazz.newMeth(C$, 'c$$I$D',  function (maxIterations, minRMS) {
;C$.$init$.apply(this);
this.maxIterations=maxIterations;
this.minRMS=minRMS;
}, 1);

Clazz.newMeth(C$, 'optimize$com_actelion_research_chem_optimization_Evaluable',  function (eval) {
var initial=eval.getState$();
var N=initial.length;
var MSAV=N;
var alpha=Clazz.array(Double.TYPE, [MSAV]);
var rho=Clazz.array(Double.TYPE, [MSAV]);
var gamma=1;
var m=0;
var nErrors=0;
var grad=Clazz.array(Double.TYPE, [N]);
var f=eval.getFGValue$DA(grad);
var fOld=f;
var f0=f;
var gNorm;
var fMove=0;
if (N == 0) {
return eval.getState$();
}var oldX=initial;
var oldGradient=Clazz.array(Double.TYPE, [N]);
var s=Clazz.array(Double.TYPE, [MSAV, N]);
var y=Clazz.array(Double.TYPE, [MSAV, N]);
var h0=Clazz.array(Double.TYPE, [N]);
var q=Clazz.array(Double.TYPE, [N]);
var r=Clazz.array(Double.TYPE, [N]);
var restart=true;
var mUse=0;
var iteration;
for (iteration=1; iteration <= this.maxIterations; iteration++) {
if (restart) {
mUse=0;
f=eval.getFGValue$DA(grad);
gamma=1;
fMove=0.25 * C$.getNorm$DA(grad);
restart=false;
}gNorm=C$.getNorm$DA(grad);
var RMS=gNorm / Math.sqrt(N);
if (RMS < this.minRMS ) {
break;
} else if (nErrors > 2) {
break;
}m=(m + 1) % MSAV;
$I$(1).fill$DA$D(h0, gamma);
System.arraycopy$O$I$O$I$I(grad, 0, q, 0, N);
var k=m;
for (var j=0; j < mUse; j++) {
k=k == 0 ? MSAV - 1 : k - 1;
alpha[k]=0;
for (var i=0; i < N; i++) alpha[k]+=s[k][i] * q[i];

alpha[k]*=rho[k];
for (var i=0; i < N; i++) q[i]-=y[k][i] * alpha[k];

}
for (var i=0; i < N; i++) r[i]=h0[i] * q[i];

for (var j=0; j < mUse; j++) {
var beta=0;
for (var i=0; i < N; i++) beta+=y[k][i] * r[i];

beta*=rho[k];
for (var i=0; i < N; i++) r[i]+=s[k][i] * (alpha[k] - beta);

k=(k + 1) % MSAV;
}
for (var i=0; i < N; i++) {
r[i]=-r[i];
}
oldX=eval.getState$();
System.arraycopy$O$I$O$I$I(grad, 0, oldGradient, 0, N);
var res=$I$(2).minimizeEnergyAroundDirection$com_actelion_research_chem_optimization_Evaluable$D$DA$DA$D(eval, f, grad, r, fMove);
f=(res[0]).valueOf();
grad=res[1];
if (res[2] === Boolean.FALSE ) {
++nErrors;
restart=true;
}var ys=0;
var yy=0;
var newState=eval.getState$();
for (var i=0; i < N; i++) {
s[m][i]=newState[i] - oldX[i];
y[m][i]=grad[i] - oldGradient[i];
ys+=y[m][i] * s[m][i];
yy+=y[m][i] * y[m][i];
}
gamma=Math.abs(ys / yy);
if (ys == 0 ) {
restart=true;
continue;
}rho[m]=1.0 / ys;
fMove=fOld - f;
fOld=f;
mUse=Math.min(mUse + 1, MSAV);
}
if (f > f0 ) {
eval.setState$DA(initial);
f=f0;
}return eval.getState$();
});

Clazz.newMeth(C$, 'getRMS$DA',  function (vector) {
return Math.sqrt(C$.getNormSq$DA(vector) / vector.length);
}, 1);

Clazz.newMeth(C$, 'getNorm$DA',  function (vector) {
return Math.sqrt(C$.getNormSq$DA(vector));
}, 1);

Clazz.newMeth(C$, 'getNormSq$DA',  function (vector) {
var res=0;
for (var i=0; i < vector.length; i++) res+=vector[i] * vector[i];

return res;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:39 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
