(function(){var P$=Clazz.newPackage("com.actelion.research.chem.conf"),p$1={},I$=[[0,'com.actelion.research.chem.conf.TorsionDB','com.actelion.research.chem.conf.TorsionDescriptor']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "TorsionDescriptorHelper");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['mMol','com.actelion.research.chem.StereoMolecule','mRotatableBond','int[]','mAtomSequence','int[][]','+mRearAtom','mSymmetryClass','int[]']]
,['O',['SYMMETRY_REDUNDANCY_ANGLE','double[]','SYMMETRY','int[][]']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule',  function (mol) {
;C$.$init$.apply(this);
this.mMol=mol;
this.mMol.ensureHelperArrays$I(63);
this.mRotatableBond=C$.findRotatableBonds$com_actelion_research_chem_StereoMolecule(mol);
p$1.findAtomSequences.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$IA',  function (mol, rotatableBond) {
;C$.$init$.apply(this);
this.mMol=mol;
this.mMol.ensureHelperArrays$I(63);
this.mRotatableBond=rotatableBond;
p$1.findAtomSequences.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'getTorsionDescriptor$',  function () {
var torsion=Clazz.array(Float.TYPE, [this.mRotatableBond.length]);
var maxTorsion=Clazz.array(Float.TYPE, [this.mRotatableBond.length]);
for (var i=0; i < this.mRotatableBond.length; i++) {
torsion[i]=C$.getNormalizedTorsion$D$I($I$(1).calculateTorsionExtended$com_actelion_research_chem_StereoMolecule$IA(this.mMol, this.mAtomSequence[i]), this.mSymmetryClass[i]);
maxTorsion[i]=C$.SYMMETRY_REDUNDANCY_ANGLE[this.mSymmetryClass[i]];
}
return Clazz.new_($I$(2,1).c$$FA$FA,[torsion, maxTorsion]);
});

Clazz.newMeth(C$, 'getTorsionDescriptor$com_actelion_research_chem_conf_Conformer',  function (conformer) {
var torsion=Clazz.array(Float.TYPE, [this.mRotatableBond.length]);
var maxTorsion=Clazz.array(Float.TYPE, [this.mRotatableBond.length]);
for (var i=0; i < this.mRotatableBond.length; i++) {
torsion[i]=C$.getNormalizedTorsion$D$I($I$(1).calculateTorsionExtended$com_actelion_research_chem_conf_Conformer$IA(conformer, this.mAtomSequence[i]), this.mSymmetryClass[i]);
maxTorsion[i]=C$.SYMMETRY_REDUNDANCY_ANGLE[this.mSymmetryClass[i]];
}
return Clazz.new_($I$(2,1).c$$FA$FA,[torsion, maxTorsion]);
});

Clazz.newMeth(C$, 'findRotatableBonds$com_actelion_research_chem_StereoMolecule',  function (mol) {
mol.ensureHelperArrays$I(7);
var isRotatableBond=Clazz.array(Boolean.TYPE, [mol.getBonds$()]);
var count=0;
for (var bond=0; bond < mol.getBonds$(); bond++) {
if (C$.qualifiesAsDescriptorBond$com_actelion_research_chem_StereoMolecule$I(mol, bond)) {
isRotatableBond[bond]=true;
++count;
}}
var rotatableBond=Clazz.array(Integer.TYPE, [count]);
count=0;
for (var bond=0; bond < mol.getBonds$(); bond++) if (isRotatableBond[bond]) rotatableBond[count++]=bond;

return rotatableBond;
}, 1);

Clazz.newMeth(C$, 'qualifiesAsDescriptorBond$com_actelion_research_chem_StereoMolecule$I',  function (mol, bond) {
if (mol.getBondOrder$I(bond) != 1 || mol.isAromaticBond$I(bond)  || mol.getBondRingSize$I(bond) == 3 ) return false;
var bondAtom=Clazz.array(Integer.TYPE, [2]);
for (var i=0; i < 2; i++) {
bondAtom[i]=mol.getBondAtom$I$I(i, bond);
if (mol.isMarkedAtom$I(bondAtom[i]) || mol.getNonHydrogenNeighbourCount$I(bondAtom[i]) <= 1 ) return false;
}
if (C$.isLinearAtom$com_actelion_research_chem_StereoMolecule$I(mol, bondAtom[0]) || C$.isLinearAtom$com_actelion_research_chem_StereoMolecule$I(mol, bondAtom[1]) ) {
var maxBond=Clazz.array(Integer.TYPE, [1]);
maxBond[0]=bond;
var chainEndAtom=Clazz.array(Integer.TYPE, [2, null]);
for (var i=0; i < 2; i++) {
if (C$.isLinearAtom$com_actelion_research_chem_StereoMolecule$I(mol, bondAtom[i])) {
chainEndAtom[i]=Clazz.array(Integer.TYPE, [2]);
chainEndAtom[i][0]=bondAtom[1 - i];
chainEndAtom[i][1]=bondAtom[i];
if (!C$.getFirstNonSPAtom$com_actelion_research_chem_StereoMolecule$I$IA$IA(mol, bondAtom[1 - i], chainEndAtom[i], maxBond)) return false;
}}
if (maxBond != null  && bond != maxBond[0] ) return false;
for (var i=0; i < 2; i++) if (chainEndAtom[i] != null ) bondAtom[i]=chainEndAtom[i][1];

}for (var i=0; i < 2; i++) {
var connAtoms=mol.getConnAtoms$I(bondAtom[i]);
if (connAtoms == 1) return false;
var qualifiedConnAtoms=0;
for (var j=0; j < connAtoms; j++) {
var connAtom=mol.getConnAtom$I$I(bondAtom[i], j);
if (!mol.isMarkedAtom$I(connAtom)) ++qualifiedConnAtoms;
}
if (qualifiedConnAtoms < 2) return false;
}
return true;
}, 1);

Clazz.newMeth(C$, 'isLinearAtom$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
return mol.getConnAtoms$I(atom) == 2 && mol.getAtomPi$I(atom) == 2  && mol.getAtomicNo$I(atom) <= 7 ;
}, 1);

Clazz.newMeth(C$, 'getFirstNonSPAtom$com_actelion_research_chem_StereoMolecule$I$IA$IA',  function (mol, startAtom, atom, maxBond) {
for (var i=0; i < 2; i++) {
var nextAtom=mol.getConnAtom$I$I(atom[1], i);
if (nextAtom != atom[0]) {
if (nextAtom == startAtom) return false;
var nextBond=mol.getConnBond$I$I(atom[1], i);
atom[0]=atom[1];
atom[1]=nextAtom;
if (mol.getConnAtoms$I(nextAtom) == 1) return false;
if (maxBond != null  && !mol.isMarkedAtom$I(atom[0])  && !mol.isMarkedAtom$I(atom[1]) ) maxBond[0]=Math.max(maxBond[0], nextBond);
if (!C$.isLinearAtom$com_actelion_research_chem_StereoMolecule$I(mol, nextAtom)) return true;
return C$.getFirstNonSPAtom$com_actelion_research_chem_StereoMolecule$I$IA$IA(mol, startAtom, atom, maxBond);
}}
return false;
}, 1);

Clazz.newMeth(C$, 'findAtomSequences',  function () {
this.mAtomSequence=Clazz.array(Integer.TYPE, [this.mRotatableBond.length, 4]);
this.mRearAtom=Clazz.array(Integer.TYPE, [this.mRotatableBond.length, 2]);
this.mSymmetryClass=Clazz.array(Integer.TYPE, [this.mRotatableBond.length]);
var atom=Clazz.array(Integer.TYPE, [2]);
for (var i=0; i < this.mRotatableBond.length; i++) {
for (var j=0; j < 2; j++) {
atom[0]=this.mMol.getBondAtom$I$I(1 - j, this.mRotatableBond[i]);
atom[1]=this.mMol.getBondAtom$I$I(j, this.mRotatableBond[i]);
if (C$.isLinearAtom$com_actelion_research_chem_StereoMolecule$I(this.mMol, atom[1])) C$.getFirstNonSPAtom$com_actelion_research_chem_StereoMolecule$I$IA$IA(this.mMol, atom[0], atom, null);
this.mAtomSequence[i][1 + j]=atom[1];
this.mRearAtom[i][j]=atom[0];
}
var halfSymmetry1=p$1.getHalfSymmetry$I$I.apply(this, [this.mAtomSequence[i][1], this.mRearAtom[i][0]]);
var halfSymmetry2=p$1.getHalfSymmetry$I$I.apply(this, [this.mAtomSequence[i][2], this.mRearAtom[i][1]]);
this.mSymmetryClass[i]=C$.SYMMETRY[halfSymmetry1][halfSymmetry2];
this.mAtomSequence[i][0]=p$1.chooseSequenceEndAtom$I$I$I.apply(this, [this.mAtomSequence[i][1], this.mRearAtom[i][0], halfSymmetry1]);
this.mAtomSequence[i][3]=p$1.chooseSequenceEndAtom$I$I$I.apply(this, [this.mAtomSequence[i][2], this.mRearAtom[i][1], halfSymmetry2]);
}
}, p$1);

Clazz.newMeth(C$, 'getHalfSymmetry$I$I',  function (atom, rearAtom) {
if (this.mMol.getConnAtoms$I(atom) == 2) return 1;
var connAtom=p$1.getTerminalAtoms$I$I.apply(this, [atom, rearAtom]);
if (this.mMol.getConnAtoms$I(atom) == 3) {
if (this.mMol.getSymmetryRank$I(connAtom[0]) == this.mMol.getSymmetryRank$I(connAtom[1])) return p$1.isFlatAtom$I.apply(this, [atom]) ? 2 : 1;
 else return p$1.isFlatAtom$I.apply(this, [atom]) ? 1 : 0;
}if (this.mMol.getConnAtoms$I(atom) == 4) {
if (this.mMol.getSymmetryRank$I(connAtom[0]) == this.mMol.getSymmetryRank$I(connAtom[1]) && this.mMol.getSymmetryRank$I(connAtom[0]) == this.mMol.getSymmetryRank$I(connAtom[2]) ) return 3;
if (this.mMol.getSymmetryRank$I(connAtom[0]) == this.mMol.getSymmetryRank$I(connAtom[1]) || this.mMol.getSymmetryRank$I(connAtom[0]) == this.mMol.getSymmetryRank$I(connAtom[2])  || this.mMol.getSymmetryRank$I(connAtom[1]) == this.mMol.getSymmetryRank$I(connAtom[2]) ) return 1;
}return 0;
}, p$1);

Clazz.newMeth(C$, 'isFlatAtom$I',  function (atom) {
if ((this.mMol.getAtomPi$I(atom) == 1 && this.mMol.getAtomicNo$I(atom) < 10 ) || this.mMol.isAromaticAtom$I(atom) || this.mMol.isFlatNitrogen$I(atom)  ) return true;
return false;
}, p$1);

Clazz.newMeth(C$, 'getTerminalAtoms$I$I',  function (atom, rearAtom) {
var index=0;
var connAtom=Clazz.array(Integer.TYPE, [this.mMol.getConnAtoms$I(atom) - 1]);
for (var i=0; i < this.mMol.getConnAtoms$I(atom); i++) if (this.mMol.getConnAtom$I$I(atom, i) != rearAtom) connAtom[index++]=this.mMol.getConnAtom$I$I(atom, i);

return connAtom;
}, p$1);

Clazz.newMeth(C$, 'chooseSequenceEndAtom$I$I$I',  function (rootAtom, rearAtom, halfSymmetry) {
if (halfSymmetry == 1 && !p$1.isFlatAtom$I.apply(this, [rootAtom]) ) {
if (this.mMol.getConnAtoms$I(rootAtom) == 3) return -1;
if (this.mMol.getConnAtoms$I(rootAtom) == 3) {
var connAtom=p$1.getTerminalAtoms$I$I.apply(this, [rootAtom, rearAtom]);
if (this.mMol.getSymmetryRank$I(connAtom[0]) == this.mMol.getSymmetryRank$I(connAtom[1])) return connAtom[2];
if (this.mMol.getSymmetryRank$I(connAtom[0]) == this.mMol.getSymmetryRank$I(connAtom[2])) return connAtom[1];
 else return connAtom[0];
}}var maxRank=-1;
var maxRankAtom=-1;
for (var i=0; i < this.mMol.getConnAtoms$I(rootAtom); i++) {
var connAtom=this.mMol.getConnAtom$I$I(rootAtom, i);
if (connAtom != rearAtom && maxRank < this.mMol.getSymmetryRank$I(connAtom) ) {
maxRank=this.mMol.getSymmetryRank$I(connAtom);
maxRankAtom=connAtom;
}}
return maxRankAtom;
}, p$1);

Clazz.newMeth(C$, 'getNormalizedTorsion$D$I',  function (angle, symmetryClass) {
var limit=C$.SYMMETRY_REDUNDANCY_ANGLE[symmetryClass] / 2;
while (angle < -limit )angle+=6.283185307179586;

while (angle >= limit )angle-=C$.SYMMETRY_REDUNDANCY_ANGLE[symmetryClass];

return angle;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.SYMMETRY_REDUNDANCY_ANGLE=Clazz.array(Double.TYPE, -1, [6.283185307179586, 3.141592653589793, 2.0943951023931953, 1.0471975511965976]);
C$.SYMMETRY=Clazz.array(Integer.TYPE, -2, [Clazz.array(Integer.TYPE, -1, [0, 0, 0, 2]), Clazz.array(Integer.TYPE, -1, [0, 0, 1, 2]), Clazz.array(Integer.TYPE, -1, [0, 1, 1, 3]), Clazz.array(Integer.TYPE, -1, [2, 2, 3, 2])]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:36 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
