(function(){var P$=Clazz.newPackage("com.actelion.research.chem.phesaflex"),p$1={},I$=[[0,'com.actelion.research.chem.forcefield.mmff.ForceFieldMMFF94','com.actelion.research.chem.Coordinates','com.actelion.research.chem.alignment3d.transformation.Quaternion','com.actelion.research.chem.alignment3d.transformation.ExponentialMap','com.actelion.research.chem.conf.TorsionDB','com.actelion.research.chem.alignment3d.transformation.Translation','com.actelion.research.chem.alignment3d.transformation.Rotation','com.actelion.research.chem.alignment3d.transformation.TransformationSequence','com.actelion.research.chem.alignment3d.transformation.RotationDerivatives','com.actelion.research.chem.phesa.QuickMathCalculator']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "EvaluableFlexibleOverlap", null, null, 'com.actelion.research.chem.optimization.Evaluable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.e0=0.0;
},1);

C$.$fields$=[['D',['e0','oAA','oAApp'],'O',['fitConf','com.actelion.research.chem.conf.Conformer','refMol','com.actelion.research.chem.StereoMolecule','shapeAlign','com.actelion.research.chem.phesa.PheSAAlignment','isHydrogen','boolean[]','v','double[]','precalcPow','double[][]','precalcExp','double[]','ff','com.actelion.research.chem.forcefield.mmff.ForceFieldMMFF94','ffOptions','java.util.Map','settings','com.actelion.research.chem.alignment3d.PheSAAlignmentOptimizer.PheSASetting','origCoords','com.actelion.research.chem.Coordinates[]','+cachedCoords','dRdvi1','double[][]','+dRdvi2','+dRdvi3','origCOM','com.actelion.research.chem.Coordinates','torsionHelper','com.actelion.research.chem.conf.BondRotationHelper']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_phesa_PheSAAlignment$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_BondRotationHelper$com_actelion_research_chem_alignment3d_PheSAAlignmentOptimizer_PheSASetting$ZA$java_util_Map',  function (shapeAlign, refMol, fitConf, torsionHelper, settings, isHydrogen, ffOptions) {
;C$.$init$.apply(this);
$I$(1).initialize$S("MMFF94s+");
this.ffOptions=ffOptions;
this.shapeAlign=shapeAlign;
this.fitConf=fitConf;
this.isHydrogen=isHydrogen;
this.settings=settings;
this.refMol=refMol;
this.torsionHelper=torsionHelper;
p$1.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'init',  function () {
this.ff=Clazz.new_([this.fitConf.getMolecule$(), "MMFF94s+", this.ffOptions],$I$(1,1).c$$com_actelion_research_chem_StereoMolecule$S$java_util_Map);
this.setInitialState$();
this.origCoords=Clazz.array($I$(2), [this.fitConf.getMolecule$().getAllAtoms$()]);
this.cachedCoords=Clazz.array($I$(2), [this.fitConf.getMolecule$().getAllAtoms$()]);
this.origCOM=Clazz.new_($I$(2,1));
for (var a=0; a < this.fitConf.getMolecule$().getAllAtoms$(); a++) {
this.origCoords[a]=Clazz.new_([this.fitConf.getMolecule$().getCoordinates$I(a)],$I$(2,1).c$$com_actelion_research_chem_Coordinates);
this.cachedCoords[a]=Clazz.new_([this.fitConf.getMolecule$().getCoordinates$I(a)],$I$(2,1).c$$com_actelion_research_chem_Coordinates);
this.origCOM.add$com_actelion_research_chem_Coordinates(this.cachedCoords[a]);
}
this.origCOM.scale$D(1.0 / this.cachedCoords.length);
this.dRdvi1=Clazz.array(Double.TYPE, [3, 3]);
this.dRdvi2=Clazz.array(Double.TYPE, [3, 3]);
this.dRdvi3=Clazz.array(Double.TYPE, [3, 3]);
this.oAA=this.getFGValueShapeSelf$DA$com_actelion_research_chem_phesa_ShapeVolume$Z(Clazz.array(Double.TYPE, [3 * this.refMol.getAllAtoms$()]), this.shapeAlign.getRefMolGauss$(), true);
this.oAApp=this.getFGValueSelfPP$com_actelion_research_chem_phesa_ShapeVolume$Z(this.shapeAlign.getRefMolGauss$(), true);
}, p$1);

Clazz.newMeth(C$, 'setInitialState$',  function () {
var elements=3 + 3 + this.torsionHelper.getRotatableBonds$().length ;
this.v=Clazz.array(Double.TYPE, [elements]);
this.v[0]=0.0;
this.v[1]=0.0;
this.v[2]=0.0;
var quat=Clazz.new_($I$(3,1).c$$D$D$D$D,[1.0, 0.0, 0.0, 0.0]);
var emap=Clazz.new_($I$(4,1).c$$com_actelion_research_chem_alignment3d_transformation_Quaternion,[quat]);
this.v[3]=emap.getP$().x;
this.v[4]=emap.getP$().y;
this.v[5]=emap.getP$().z;
for (var b=0; b < this.torsionHelper.getRotatableBonds$().length; b++) {
var atoms=this.torsionHelper.getTorsionAtoms$()[b];
this.v[6 + b]=$I$(5).calculateTorsionExtended$com_actelion_research_chem_conf_Conformer$IA(this.fitConf, atoms);
}
});

Clazz.newMeth(C$, 'resetLigCoordinates',  function () {
for (var a=0; a < this.fitConf.getMolecule$().getAllAtoms$(); a++) {
this.fitConf.setX$I$D(a, this.origCoords[a].x);
this.fitConf.setY$I$D(a, this.origCoords[a].y);
this.fitConf.setZ$I$D(a, this.origCoords[a].z);
}
}, p$1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_phesaflex_EvaluableFlexibleOverlap',  function (e) {
;C$.$init$.apply(this);
this.shapeAlign=e.shapeAlign;
this.fitConf=e.fitConf;
this.isHydrogen=e.isHydrogen;
this.v=e.v;
this.precalcPow=e.precalcPow;
this.precalcExp=e.precalcExp;
p$1.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'setState$DA',  function (v) {
Clazz.assert(C$, this, function(){return this.v.length == v.length});
for (var i=0; i < v.length; i++) {
if (i > 5) {
if (v[i] > 3.141592653589793 ) {
v[i]-=6.283185307179586;
}}this.v[i]=v[i];
}
this.updateLigandCoordinates$();
this.shapeAlign.getMolGauss$().update$com_actelion_research_chem_conf_Conformer(this.fitConf);
});

Clazz.newMeth(C$, 'getState$DA',  function (v) {
for (var i=0; i < this.v.length; i++) {
v[i]=this.v[i];
}
return v;
});

Clazz.newMeth(C$, 'setE0$D',  function (e0) {
this.e0=e0;
});

Clazz.newMeth(C$, 'getState$',  function () {
return this.getState$DA(Clazz.array(Double.TYPE, [this.v.length]));
});

Clazz.newMeth(C$, 'getAlignment$',  function () {
return this.shapeAlign;
});

Clazz.newMeth(C$, 'updateLigandCoordinates$',  function () {
p$1.resetLigCoordinates.apply(this, []);
p$1.updateDihedralAngles.apply(this, []);
for (var a=0; a < this.fitConf.getMolecule$().getAllAtoms$(); a++) {
this.cachedCoords[a]=Clazz.new_([this.fitConf.getCoordinates$I(a)],$I$(2,1).c$$com_actelion_research_chem_Coordinates);
}
var eMap=Clazz.new_($I$(4,1).c$$D$D$D,[this.v[3], this.v[4], this.v[5]]);
var q=eMap.toQuaternion$();
var trans1=Clazz.new_([this.origCOM.scaleC$D(-1.0)],$I$(6,1).c$$com_actelion_research_chem_Coordinates);
var trans2=Clazz.new_($I$(6,1).c$$com_actelion_research_chem_Coordinates,[this.origCOM]);
var rot=Clazz.new_([q.getRotMatrix$().getArray$()],$I$(7,1).c$$DAA);
var t=Clazz.new_($I$(6,1).c$$D$D$D,[this.v[0], this.v[1], this.v[2]]);
var transformation=Clazz.new_($I$(8,1));
transformation.addTransformation$com_actelion_research_chem_alignment3d_transformation_Transformation(trans1);
transformation.addTransformation$com_actelion_research_chem_alignment3d_transformation_Transformation(rot);
transformation.addTransformation$com_actelion_research_chem_alignment3d_transformation_Transformation(trans2);
transformation.addTransformation$com_actelion_research_chem_alignment3d_transformation_Transformation(t);
transformation.apply$com_actelion_research_chem_conf_Conformer(this.fitConf);
});

Clazz.newMeth(C$, 'updateDihedralAngles',  function () {
for (var b=0; b < this.torsionHelper.getRotatableBonds$().length; b++) {
var targetTorsion=this.v[6 + b];
var atoms=this.torsionHelper.getTorsionAtoms$()[b];
var currentTorsion=$I$(5).calculateTorsionExtended$com_actelion_research_chem_conf_Conformer$IA(this.fitConf, atoms);
var deltaTorsion=targetTorsion - currentTorsion;
this.torsionHelper.rotateAroundBond$I$D$com_actelion_research_chem_conf_Conformer$Z(b, deltaTorsion, this.fitConf, false);
}
}, p$1);

Clazz.newMeth(C$, 'getFGValue$DA',  function (grad) {
var coordGrad=Clazz.array(Double.TYPE, [this.fitConf.getMolecule$().getAllAtoms$() * 3]);
var ePot=0.0;
var T=0.0;
var overlapGrad=Clazz.array(Double.TYPE, [coordGrad.length]);
var energyGrad=Clazz.array(Double.TYPE, [coordGrad.length]);
var selfOverlapGradFit=Clazz.array(Double.TYPE, [coordGrad.length]);
var oBB=this.getFGValueShapeSelf$DA$com_actelion_research_chem_phesa_ShapeVolume$Z(selfOverlapGradFit, this.shapeAlign.getMolGauss$(), false);
var oAB=this.getFGValueShape$DA(overlapGrad);
var oBBpp=this.getFGValueSelfPP$com_actelion_research_chem_phesa_ShapeVolume$Z(this.shapeAlign.getMolGauss$(), false);
var oABpp=this.getFGValuePP$();
this.ff.setState$DA(this.getCartState$());
this.ff.addGradient$DA(energyGrad);
ePot=this.ff.getTotalEnergy$();
var dOBB=selfOverlapGradFit;
var dOAB=overlapGrad;
var dOBB_dOAB=Clazz.array(Double.TYPE, [coordGrad.length]);
T=(1.0 - this.settings.getPpWeight$()) * (oAB / (oBB + this.oAA - oAB)) + this.settings.getPpWeight$() * (oABpp / (oBBpp + this.oAApp - oABpp));
var strainEnergy=ePot - this.e0;
var strainPrefactor=strainEnergy < 10.0  ? 0.0 : strainEnergy - 10.0;
var value=-T + 0.0625 * strainPrefactor * strainPrefactor ;
for (var i=0; i < coordGrad.length; i++) {
dOBB_dOAB[i]=dOBB[i] - dOAB[i];
}
var dT=Clazz.array(Double.TYPE, [coordGrad.length]);
for (var j=0; j < coordGrad.length; j++) {
dT[j]=(1.0 - this.settings.getPpWeight$()) * dOAB[j] * (1 / (this.oAA + oBB - oAB))  - (1.0 - this.settings.getPpWeight$()) * oAB * Math.pow(this.oAA + oBB - oAB, -2) * dOBB_dOAB[j] ;
}
for (var k=0; k < coordGrad.length; k++) {
coordGrad[k]=-dT[k] + strainPrefactor * 2 * 0.0625 * energyGrad[k] ;
}
for (var a=0; a < this.fitConf.getMolecule$().getAllAtoms$(); a++) {
grad[0]+=coordGrad[3 * a];
grad[1]+=coordGrad[3 * a + 1];
grad[2]+=coordGrad[3 * a + 2];
}
var p=Clazz.array(Double.TYPE, -1, [this.v[3], this.v[4], this.v[5]]);
var transformDerivatives=Clazz.new_($I$(9,1).c$$DA,[p]);
transformDerivatives.dRdv$I$DAA(0, this.dRdvi1);
transformDerivatives.dRdv$I$DAA(1, this.dRdvi2);
transformDerivatives.dRdv$I$DAA(2, this.dRdvi3);
for (var a=0; a < this.fitConf.getMolecule$().getAllAtoms$(); a++) {
var vi=this.cachedCoords[a];
var Tj_vi=vi.rotateC$DAA(this.dRdvi1);
grad[3]+=coordGrad[3 * a] * Tj_vi.x + coordGrad[3 * a + 1] * Tj_vi.y + coordGrad[3 * a + 2] * Tj_vi.z;
Tj_vi=vi.rotateC$DAA(this.dRdvi2);
grad[4]+=coordGrad[3 * a] * Tj_vi.x + coordGrad[3 * a + 1] * Tj_vi.y + coordGrad[3 * a + 2] * Tj_vi.z;
Tj_vi=vi.rotateC$DAA(this.dRdvi3);
grad[5]+=coordGrad[3 * a] * Tj_vi.x + coordGrad[3 * a + 1] * Tj_vi.y + coordGrad[3 * a + 2] * Tj_vi.z;
}
for (var b=0; b < this.torsionHelper.getRotatableBonds$().length; b++) {
var rotatedAtoms=this.torsionHelper.getSmallerSideAtomLists$()[b];
var j=this.torsionHelper.getRotationCenters$()[b];
var k=this.torsionHelper.getTorsionAtoms$()[b][1] == j ? this.torsionHelper.getTorsionAtoms$()[b][2] : this.torsionHelper.getTorsionAtoms$()[b][1];
var v1=this.fitConf.getCoordinates$I(k).subC$com_actelion_research_chem_Coordinates(this.fitConf.getCoordinates$I(j));
for (var i, $i = 0, $$i = rotatedAtoms; $i<$$i.length&&((i=($$i[$i])),1);$i++) {
var v2=this.fitConf.getCoordinates$I(i).subC$com_actelion_research_chem_Coordinates(this.fitConf.getCoordinates$I(j));
var dx_dphi=v1.cross$com_actelion_research_chem_Coordinates(v2);
grad[6 + b]+=dx_dphi.x * coordGrad[3 * i] + dx_dphi.y * coordGrad[3 * i + 1] + dx_dphi.z * coordGrad[3 * i + 2];
}
}
return value;
});

Clazz.newMeth(C$, 'getFGValueShape$DA',  function (grad) {
var molGauss=this.shapeAlign.getMolGauss$();
var refMolGauss=this.shapeAlign.getRefMolGauss$();
for (var i=0; i < grad.length; i++) {
grad[i]=0;
}
var totalOverlap=0.0;
for (var refAt, $refAt = refMolGauss.getAtomicGaussians$().iterator$(); $refAt.hasNext$()&&((refAt=($refAt.next$())),1);) {
var xi=refAt.getCenter$().x;
var yi=refAt.getCenter$().y;
var zi=refAt.getCenter$().z;
for (var fitAt, $fitAt = molGauss.getAtomicGaussians$().iterator$(); $fitAt.hasNext$()&&((fitAt=($fitAt.next$())),1);) {
var a=fitAt.getAtomId$();
var atomOverlap=0.0;
var xj=this.fitConf.getX$I(a);
var yj=this.fitConf.getY$I(a);
var zj=this.fitConf.getZ$I(a);
var dx=xi - xj;
var dy=yi - yj;
var dz=zi - zj;
var Rij2=dx * dx + dy * dy + dz * dz;
var alphaSum=refAt.getWidth$() + fitAt.getWidth$();
var gradientPrefactor=0.0;
if (Rij2 < 10.0 ) {
atomOverlap=refAt.getHeight$() * fitAt.getHeight$() * $I$(10).getInstance$().quickExp$D(-(refAt.getWidth$() * fitAt.getWidth$() * Rij2 ) / alphaSum) * $I$(10).getInstance$().getPrefactor$I$I(refAt.getAtomicNo$(), fitAt.getAtomicNo$()) ;
if (atomOverlap > 0.0 ) {
totalOverlap+=atomOverlap;
gradientPrefactor=atomOverlap * -2 * refAt.getWidth$() * fitAt.getWidth$()  / (refAt.getWidth$() + fitAt.getWidth$());
}}grad[3 * a]+=(xj - xi) * gradientPrefactor;
grad[3 * a + 1]+=(yj - yi) * gradientPrefactor;
grad[3 * a + 2]+=(zj - zi) * gradientPrefactor;
}
}
if (Clazz.instanceOf(refMolGauss, "com.actelion.research.chem.phesa.MolecularVolume")) {
for (var refVG, $refVG = (refMolGauss).getVolumeGaussians$().iterator$(); $refVG.hasNext$()&&((refVG=($refVG.next$())),1);) {
var xi=refVG.getCenter$().x;
var yi=refVG.getCenter$().y;
var zi=refVG.getCenter$().z;
for (var fitAt, $fitAt = molGauss.getAtomicGaussians$().iterator$(); $fitAt.hasNext$()&&((fitAt=($fitAt.next$())),1);) {
var a=fitAt.getAtomId$();
var atomOverlap=0.0;
var xj=this.v[3 * a];
var yj=this.v[3 * a + 1];
var zj=this.v[3 * a + 2];
var dx=xi - xj;
var dy=yi - yj;
var dz=zi - zj;
var Rij2=dx * dx + dy * dy + dz * dz;
var alphaSum=refVG.getWidth$() + fitAt.getWidth$();
var gradientPrefactor=0.0;
if (Rij2 < 10.0 ) {
atomOverlap=refVG.getRole$() * refVG.getHeight$() * fitAt.getHeight$() * $I$(10).getInstance$().quickExp$D(-(refVG.getWidth$() * fitAt.getWidth$() * Rij2 ) / alphaSum) * $I$(10).getInstance$().getPrefactor$I$I(refVG.getAtomicNo$(), fitAt.getAtomicNo$()) ;
if (Math.abs(atomOverlap) > 0.0 ) {
totalOverlap+=atomOverlap;
gradientPrefactor=atomOverlap * -2 * refVG.getWidth$() * fitAt.getWidth$()  / (refVG.getWidth$() + fitAt.getWidth$());
}}grad[3 * a]+=(xj - xi) * gradientPrefactor;
grad[3 * a + 1]+=(yj - yi) * gradientPrefactor;
grad[3 * a + 2]+=(zj - zi) * gradientPrefactor;
}
}
}return totalOverlap;
});

Clazz.newMeth(C$, 'getFGValuePP$',  function () {
var molGauss=this.shapeAlign.getMolGauss$();
var refMolGauss=this.shapeAlign.getRefMolGauss$();
var totalOverlap=0.0;
for (var refPP, $refPP = refMolGauss.getPPGaussians$().iterator$(); $refPP.hasNext$()&&((refPP=($refPP.next$())),1);) {
var xi=refPP.getCenter$().x;
var yi=refPP.getCenter$().y;
var zi=refPP.getCenter$().z;
for (var fitPP, $fitPP = molGauss.getPPGaussians$().iterator$(); $fitPP.hasNext$()&&((fitPP=($fitPP.next$())),1);) {
var atomOverlap=0.0;
var fitCenterModCoord=fitPP.getCenter$();
var xj=fitCenterModCoord.x;
var yj=fitCenterModCoord.y;
var zj=fitCenterModCoord.z;
var dx=xi - xj;
var dy=yi - yj;
var dz=zi - zj;
var Rij2=dx * dx + dy * dy + dz * dz;
var alphaSum=refPP.getWidth$() + fitPP.getWidth$();
if (Rij2 < 10.0 ) {
atomOverlap=refPP.getWeight$() * refPP.getHeight$() * fitPP.getHeight$() * $I$(10).getInstance$().quickExp$D(-(refPP.getWidth$() * fitPP.getWidth$() * Rij2 ) / alphaSum) * $I$(10).getInstance$().getPrefactor$I$I(refPP.getAtomicNo$(), fitPP.getAtomicNo$()) ;
if (atomOverlap > 0.0 ) {
var sim=refPP.getInteractionSimilarity$com_actelion_research_chem_phesa_pharmacophore_pp_PPGaussian(fitPP);
atomOverlap*=sim;
totalOverlap+=atomOverlap;
}}}
}
return totalOverlap;
});

Clazz.newMeth(C$, 'getFGValueShapeSelf$DA$com_actelion_research_chem_phesa_ShapeVolume$Z',  function (grad, molGauss, rigid) {
for (var i=0; i < grad.length; i++) {
grad[i]=0;
}
var totalOverlap=0.0;
for (var refAt, $refAt = molGauss.getAtomicGaussians$().iterator$(); $refAt.hasNext$()&&((refAt=($refAt.next$())),1);) {
for (var fitAt, $fitAt = molGauss.getAtomicGaussians$().iterator$(); $fitAt.hasNext$()&&((fitAt=($fitAt.next$())),1);) {
totalOverlap+=this.getGradientContributionSelf$com_actelion_research_chem_phesa_Gaussian3D$com_actelion_research_chem_phesa_Gaussian3D$DA$Z(refAt, fitAt, grad, rigid);
}
if (Clazz.instanceOf(molGauss, "com.actelion.research.chem.phesa.MolecularVolume")) {
for (var fitAt, $fitAt = (molGauss).getVolumeGaussians$().iterator$(); $fitAt.hasNext$()&&((fitAt=($fitAt.next$())),1);) {
totalOverlap+=this.getGradientContributionSelf$com_actelion_research_chem_phesa_Gaussian3D$com_actelion_research_chem_phesa_Gaussian3D$DA$Z(refAt, fitAt, grad, rigid);
}
}}
if (Clazz.instanceOf(molGauss, "com.actelion.research.chem.phesa.MolecularVolume")) {
for (var refAt, $refAt = (molGauss).getVolumeGaussians$().iterator$(); $refAt.hasNext$()&&((refAt=($refAt.next$())),1);) {
for (var fitAt, $fitAt = (molGauss).getVolumeGaussians$().iterator$(); $fitAt.hasNext$()&&((fitAt=($fitAt.next$())),1);) {
totalOverlap+=this.getGradientContributionSelf$com_actelion_research_chem_phesa_Gaussian3D$com_actelion_research_chem_phesa_Gaussian3D$DA$Z(refAt, fitAt, grad, rigid);
}
}
}return totalOverlap;
});

Clazz.newMeth(C$, 'getGradientContributionSelf$com_actelion_research_chem_phesa_Gaussian3D$com_actelion_research_chem_phesa_Gaussian3D$DA$Z',  function (refAt, fitAt, grad, rigid) {
var xi;
var yi;
var zi;
var xj;
var yj;
var zj;
var b=fitAt.getAtomId$();
var atomOverlap=0.0;
var a=refAt.getAtomId$();
if (rigid) {
xi=refAt.getCenter$().x;
yi=refAt.getCenter$().y;
zi=refAt.getCenter$().z;
} else {
xi=this.fitConf.getX$I(a);
yi=this.fitConf.getY$I(a);
zi=this.fitConf.getZ$I(a);
}if (rigid) {
xj=fitAt.getCenter$().x;
yj=fitAt.getCenter$().y;
zj=fitAt.getCenter$().z;
} else {
xj=this.fitConf.getX$I(b);
yj=this.fitConf.getY$I(b);
zj=this.fitConf.getZ$I(b);
}var dx=xi - xj;
var dy=yi - yj;
var dz=zi - zj;
var Rij2=dx * dx + dy * dy + dz * dz;
var alphaSum=refAt.getWidth$() + fitAt.getWidth$();
var gradientPrefactor=0.0;
var d=1.0;
if (Clazz.instanceOf(refAt, "com.actelion.research.chem.phesa.VolumeGaussian")) d*=(refAt).getRole$();
if (Clazz.instanceOf(fitAt, "com.actelion.research.chem.phesa.VolumeGaussian")) d*=(fitAt).getRole$();
if (Rij2 < 10.0 ) {
atomOverlap=d * refAt.getHeight$() * fitAt.getHeight$() * $I$(10).getInstance$().quickExp$D(-(refAt.getWidth$() * fitAt.getWidth$() * Rij2 ) / alphaSum) * $I$(10).getInstance$().getPrefactor$I$I(refAt.getAtomicNo$(), fitAt.getAtomicNo$()) ;
if (atomOverlap > 0.0 ) {
gradientPrefactor=atomOverlap * -2 * refAt.getWidth$() * fitAt.getWidth$()  / (refAt.getWidth$() + fitAt.getWidth$());
}}grad[3 * b]+=(2 * xj - 2 * xi) * gradientPrefactor;
grad[3 * b + 1]+=(2 * yj - 2 * yi) * gradientPrefactor;
grad[3 * b + 2]+=(2 * zj - 2 * zi) * gradientPrefactor;
return atomOverlap;
});

Clazz.newMeth(C$, 'getFGValueSelfPP$com_actelion_research_chem_phesa_ShapeVolume$Z',  function (molVol, rigid) {
var xi;
var yi;
var zi;
var xj;
var yj;
var zj;
var totalOverlap=0.0;
for (var refPP, $refPP = molVol.getPPGaussians$().iterator$(); $refPP.hasNext$()&&((refPP=($refPP.next$())),1);) {
if (rigid) {
xi=refPP.getCenter$().x;
yi=refPP.getCenter$().y;
zi=refPP.getCenter$().z;
} else {
xi=refPP.getCenter$().x;
yi=refPP.getCenter$().y;
zi=refPP.getCenter$().z;
}for (var fitPP, $fitPP = molVol.getPPGaussians$().iterator$(); $fitPP.hasNext$()&&((fitPP=($fitPP.next$())),1);) {
var atomOverlap=0.0;
if (rigid) {
xj=fitPP.getCenter$().x;
yj=fitPP.getCenter$().y;
zj=fitPP.getCenter$().z;
} else {
xj=fitPP.getCenter$().x;
yj=fitPP.getCenter$().y;
zj=fitPP.getCenter$().z;
}var dx=xi - xj;
var dy=yi - yj;
var dz=zi - zj;
var Rij2=dx * dx + dy * dy + dz * dz;
var alphaSum=fitPP.getWidth$() + fitPP.getWidth$();
if (Rij2 < 10.0 ) {
atomOverlap=refPP.getWeight$() * refPP.getHeight$() * fitPP.getHeight$() * $I$(10).getInstance$().quickExp$D(-(refPP.getWidth$() * fitPP.getWidth$() * Rij2 ) / alphaSum) * $I$(10).getInstance$().getPrefactor$I$I(refPP.getAtomicNo$(), fitPP.getAtomicNo$()) ;
if (atomOverlap > 0.0 ) {
var sim=refPP.getInteractionSimilarity$com_actelion_research_chem_phesa_pharmacophore_pp_PPGaussian(fitPP);
atomOverlap*=sim;
totalOverlap+=atomOverlap;
}}}
}
return totalOverlap;
});

Clazz.newMeth(C$, 'getCartState$',  function () {
var cartState=Clazz.array(Double.TYPE, [3 * this.fitConf.getMolecule$().getAllAtoms$()]);
for (var a=0; a < this.fitConf.getMolecule$().getAllAtoms$(); a++) {
cartState[3 * a]=this.fitConf.getCoordinates$I(a).x;
cartState[3 * a + 1]=this.fitConf.getCoordinates$I(a).y;
cartState[3 * a + 2]=this.fitConf.getCoordinates$I(a).z;
}
return cartState;
});

Clazz.newMeth(C$, 'getFitConf$',  function () {
return this.fitConf;
});

Clazz.newMeth(C$, 'clone$',  function () {
return Clazz.new_(C$.c$$com_actelion_research_chem_phesaflex_EvaluableFlexibleOverlap,[this]);
});

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:40 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
