(function(){var P$=Clazz.newPackage("com.actelion.research.chem.prediction"),I$=[[0,'com.actelion.research.chem.conf.ConformerSetGenerator','com.actelion.research.chem.Coordinates','com.actelion.research.calc.SingularValueDecomposition','java.util.Arrays']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "GlobularityCalculator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'assessGlobularity$com_actelion_research_chem_StereoMolecule$I',  function (mol, maxConformerCount) {
var cs=Clazz.new_($I$(1,1).c$$I$I$Z$J,[maxConformerCount, 3, false, 0]).generateConformerSet$com_actelion_research_chem_StereoMolecule(mol);
return C$.assessGlobularity$com_actelion_research_chem_conf_ConformerSet(cs);
}, 1);

Clazz.newMeth(C$, 'assessGlobularity$com_actelion_research_chem_conf_ConformerSet',  function (cs) {
if (cs == null  || cs.size$() == 0 ) return NaN;
var globularity=0.0;
for (var conf, $conf = cs.iterator$(); $conf.hasNext$()&&((conf=($conf.next$())),1);) globularity+=C$.assessGlobularityFromSVD$com_actelion_research_chem_conf_Conformer(conf);

return globularity / cs.size$();
}, 1);

Clazz.newMeth(C$, 'assessGlobularityFromSVD$com_actelion_research_chem_conf_Conformer',  function (conf) {
var atomCount=conf.getSize$();
var cog=Clazz.new_($I$(2,1));
for (var i=0; i < atomCount; i++) cog.add$com_actelion_research_chem_Coordinates(conf.getCoordinates$I(i));

cog.scale$D(1.0 / atomCount);
var squareMatrix=Clazz.array(Double.TYPE, [3, 3]);
for (var i=0; i < atomCount; i++) {
conf.getCoordinates$I(i).sub$com_actelion_research_chem_Coordinates(cog);
squareMatrix[0][0]+=conf.getX$I(i) * conf.getX$I(i);
squareMatrix[0][1]+=conf.getX$I(i) * conf.getY$I(i);
squareMatrix[0][2]+=conf.getX$I(i) * conf.getZ$I(i);
squareMatrix[1][0]+=conf.getY$I(i) * conf.getX$I(i);
squareMatrix[1][1]+=conf.getY$I(i) * conf.getY$I(i);
squareMatrix[1][2]+=conf.getY$I(i) * conf.getZ$I(i);
squareMatrix[2][0]+=conf.getZ$I(i) * conf.getX$I(i);
squareMatrix[2][1]+=conf.getZ$I(i) * conf.getY$I(i);
squareMatrix[2][2]+=conf.getZ$I(i) * conf.getZ$I(i);
}
var svd=Clazz.new_($I$(3,1).c$$DAA$com_actelion_research_calc_ProgressListener$com_actelion_research_calc_ThreadMaster,[squareMatrix, null, null]);
var u=svd.getU$();
var temp=Clazz.array(Double.TYPE, [3]);
for (var i=0; i < atomCount; i++) {
$I$(4).fill$DA$D(temp, 0);
var c=conf.getCoordinates$I(i);
for (var j=0; j < 3; j++) {
temp[j]+=c.x * u[0][j];
temp[j]+=c.y * u[1][j];
temp[j]+=c.z * u[2][j];
}
c.set$D$D$D(temp[0], temp[1], temp[2]);
}
var xmin=1.7976931348623157E308;
var xmax=4.9E-324;
var ymin=1.7976931348623157E308;
var ymax=4.9E-324;
var zmin=1.7976931348623157E308;
var zmax=4.9E-324;
for (var i=0; i < atomCount; i++) {
var c=conf.getCoordinates$I(i);
if (xmin > c.x ) xmin=c.x;
if (xmax < c.x ) xmax=c.x;
if (ymin > c.y ) ymin=c.y;
if (ymax < c.y ) ymax=c.y;
if (zmin > c.z ) zmin=c.z;
if (zmax < c.z ) zmax=c.z;
}
var dx=xmax - xmin;
var dy=ymax - ymin;
var dz=zmax - zmin;
return dx == 0.0  ? NaN : dz / dx;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:40 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
