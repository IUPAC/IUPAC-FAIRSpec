(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.svm"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Kernel", null, 'com.actelion.research.calc.regression.svm.QMatrix');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['gamma','coef0'],'I',['kernel_type','degree'],'O',['x','org.machinelearning.svm.libsvm.svm_node[][]','x_square','double[]']]]

Clazz.newMeth(C$, 'swap_index$I$I',  function (i, j) {
do {
var tmp=this.x[i];
this.x[i]=this.x[j];
this.x[j]=tmp;
} while (false);
if (this.x_square != null ) do {
var tmp=this.x_square[i];
this.x_square[i]=this.x_square[j];
this.x_square[j]=tmp;
} while (false);
});

Clazz.newMeth(C$, 'powi$D$I',  function (base, times) {
var tmp=base;
var ret=1.0;
for (var t=times; t > 0; t=(t/(2)|0)) {
if (t % 2 == 1) ret*=tmp;
tmp=tmp * tmp;
}
return ret;
}, 1);

Clazz.newMeth(C$, 'kernel_function$I$I',  function (i, j) {
switch (this.kernel_type) {
case 0:
return C$.dot$org_machinelearning_svm_libsvm_svm_nodeA$org_machinelearning_svm_libsvm_svm_nodeA(this.x[i], this.x[j]);
case 1:
return C$.powi$D$I(this.gamma * C$.dot$org_machinelearning_svm_libsvm_svm_nodeA$org_machinelearning_svm_libsvm_svm_nodeA(this.x[i], this.x[j]) + this.coef0, this.degree);
case 2:
return Math.exp(-this.gamma * (this.x_square[i] + this.x_square[j] - 2 * C$.dot$org_machinelearning_svm_libsvm_svm_nodeA$org_machinelearning_svm_libsvm_svm_nodeA(this.x[i], this.x[j])));
case 3:
return Math.tanh(this.gamma * C$.dot$org_machinelearning_svm_libsvm_svm_nodeA$org_machinelearning_svm_libsvm_svm_nodeA(this.x[i], this.x[j]) + this.coef0);
case 4:
return this.x[i][((this.x[j][0].value)|0)].value;
default:
return 0;
}
});

Clazz.newMeth(C$, 'c$$I$org_machinelearning_svm_libsvm_svm_nodeAA$org_machinelearning_svm_libsvm_svm_parameter',  function (l, x_, param) {
Clazz.super_(C$, this);
this.kernel_type=param.kernel_type;
this.degree=param.degree;
this.gamma=param.gamma;
this.coef0=param.coef0;
this.x=x_.clone$();
if (this.kernel_type == 2) {
this.x_square=Clazz.array(Double.TYPE, [l]);
for (var i=0; i < l; i++) this.x_square[i]=C$.dot$org_machinelearning_svm_libsvm_svm_nodeA$org_machinelearning_svm_libsvm_svm_nodeA(this.x[i], this.x[i]);

} else this.x_square=null;
}, 1);

Clazz.newMeth(C$, 'dot$org_machinelearning_svm_libsvm_svm_nodeA$org_machinelearning_svm_libsvm_svm_nodeA',  function (x, y) {
var sum=0;
var xlen=x.length;
var ylen=y.length;
var i=0;
var j=0;
while (i < xlen && j < ylen ){
if (x[i].index == y[j].index) sum+=x[i++].value * y[j++].value;
 else {
if (x[i].index > y[j].index) ++j;
 else ++i;
}}
return sum;
}, 1);

Clazz.newMeth(C$, 'k_function$org_machinelearning_svm_libsvm_svm_nodeA$org_machinelearning_svm_libsvm_svm_nodeA$org_machinelearning_svm_libsvm_svm_parameter',  function (x, y, param) {
switch (param.kernel_type) {
case 0:
return C$.dot$org_machinelearning_svm_libsvm_svm_nodeA$org_machinelearning_svm_libsvm_svm_nodeA(x, y);
case 1:
return C$.powi$D$I(param.gamma * C$.dot$org_machinelearning_svm_libsvm_svm_nodeA$org_machinelearning_svm_libsvm_svm_nodeA(x, y) + param.coef0, param.degree);
case 2:
{
var sum=0;
var xlen=x.length;
var ylen=y.length;
var i=0;
var j=0;
while (i < xlen && j < ylen ){
if (x[i].index == y[j].index) {
var d=x[i++].value - y[j++].value;
sum+=d * d;
} else if (x[i].index > y[j].index) {
sum+=y[j].value * y[j].value;
++j;
} else {
sum+=x[i].value * x[i].value;
++i;
}}
while (i < xlen){
sum+=x[i].value * x[i].value;
++i;
}
while (j < ylen){
sum+=y[j].value * y[j].value;
++j;
}
return Math.exp(-param.gamma * sum);
}case 3:
return Math.tanh(param.gamma * C$.dot$org_machinelearning_svm_libsvm_svm_nodeA$org_machinelearning_svm_libsvm_svm_nodeA(x, y) + param.coef0);
case 4:
return x[((y[0].value)|0)].value;
default:
return 0;
}
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:34 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
