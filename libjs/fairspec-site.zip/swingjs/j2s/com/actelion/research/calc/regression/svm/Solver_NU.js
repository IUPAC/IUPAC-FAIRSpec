(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.svm"),p$1={},p$2={},p$3={},I$=[[0,['com.actelion.research.calc.regression.svm.Cache','.head_t'],'com.actelion.research.calc.regression.svm.svm','com.actelion.research.calc.regression.svm.Cache','java.util.Random','com.actelion.research.calc.regression.svm.Solver','com.actelion.research.calc.regression.svm.SVC_Q','com.actelion.research.calc.regression.svm.Solver_NU','com.actelion.research.calc.regression.svm.ONE_CLASS_Q','com.actelion.research.calc.regression.svm.SVR_Q',['com.actelion.research.calc.regression.svm.Solver','.SolutionInfo'],['com.actelion.research.calc.regression.svm.svm','.decision_function'],'org.machinelearning.svm.libsvm.svm_problem','org.machinelearning.svm.libsvm.svm_node','org.machinelearning.svm.libsvm.svm_model','com.actelion.research.calc.regression.svm.Kernel','java.io.DataOutputStream','java.io.BufferedOutputStream','java.io.FileOutputStream','org.machinelearning.svm.libsvm.svm_parameter','java.util.StringTokenizer','java.io.BufferedReader','java.io.FileReader']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Solver_NU", null, 'com.actelion.research.calc.regression.svm.Solver');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['si','com.actelion.research.calc.regression.svm.Solver.SolutionInfo']]]

Clazz.newMeth(C$, 'Solve$I$com_actelion_research_calc_regression_svm_QMatrix$DA$BA$DA$D$D$D$com_actelion_research_calc_regression_svm_Solver_SolutionInfo$I$com_actelion_research_calc_ProgressController',  function (l, Q, p, y, alpha, Cp, Cn, eps, si, shrinking, pg) {
this.si=si;
C$.superclazz.prototype.Solve$I$com_actelion_research_calc_regression_svm_QMatrix$DA$BA$DA$D$D$D$com_actelion_research_calc_regression_svm_Solver_SolutionInfo$I$com_actelion_research_calc_ProgressController.apply(this, [l, Q, p, y, alpha, Cp, Cn, eps, si, shrinking, pg]);
});

Clazz.newMeth(C$, 'select_working_set$IA',  function (working_set) {
var Gmaxp=-Infinity;
var Gmaxp2=-Infinity;
var Gmaxp_idx=-1;
var Gmaxn=-Infinity;
var Gmaxn2=-Infinity;
var Gmaxn_idx=-1;
var Gmin_idx=-1;
var obj_diff_min=Infinity;
for (var t=0; t < this.active_size; t++) if (this.y[t] == 1) {
if (!this.is_upper_bound$I(t)) if (-this.G[t] >= Gmaxp ) {
Gmaxp=-this.G[t];
Gmaxp_idx=t;
}} else {
if (!this.is_lower_bound$I(t)) if (this.G[t] >= Gmaxn ) {
Gmaxn=this.G[t];
Gmaxn_idx=t;
}}
var ip=Gmaxp_idx;
var $in=Gmaxn_idx;
var Q_ip=null;
var Q_in=null;
if (ip != -1) Q_ip=this.Q.get_Q$I$I(ip, this.active_size);
if ($in != -1) Q_in=this.Q.get_Q$I$I($in, this.active_size);
for (var j=0; j < this.active_size; j++) {
if (this.y[j] == 1) {
if (!this.is_lower_bound$I(j)) {
var grad_diff=Gmaxp + this.G[j];
if (this.G[j] >= Gmaxp2 ) Gmaxp2=this.G[j];
if (grad_diff > 0 ) {
var obj_diff;
var quad_coef=this.QD[ip] + this.QD[j] - 2 * Q_ip[j];
if (quad_coef > 0 ) obj_diff=-(grad_diff * grad_diff) / quad_coef;
 else obj_diff=-(grad_diff * grad_diff) / 1.0E-12;
if (obj_diff <= obj_diff_min ) {
Gmin_idx=j;
obj_diff_min=obj_diff;
}}}} else {
if (!this.is_upper_bound$I(j)) {
var grad_diff=Gmaxn - this.G[j];
if (-this.G[j] >= Gmaxn2 ) Gmaxn2=-this.G[j];
if (grad_diff > 0 ) {
var obj_diff;
var quad_coef=this.QD[$in] + this.QD[j] - 2 * Q_in[j];
if (quad_coef > 0 ) obj_diff=-(grad_diff * grad_diff) / quad_coef;
 else obj_diff=-(grad_diff * grad_diff) / 1.0E-12;
if (obj_diff <= obj_diff_min ) {
Gmin_idx=j;
obj_diff_min=obj_diff;
}}}}}
if (Math.max(Gmaxp + Gmaxp2, Gmaxn + Gmaxn2) < this.eps  || Gmin_idx == -1 ) return 1;
if (this.y[Gmin_idx] == 1) working_set[0]=Gmaxp_idx;
 else working_set[0]=Gmaxn_idx;
working_set[1]=Gmin_idx;
return 0;
});

Clazz.newMeth(C$, 'be_shrunk$I$D$D$D$D',  function (i, Gmax1, Gmax2, Gmax3, Gmax4) {
if (this.is_upper_bound$I(i)) {
if (this.y[i] == 1) return (-this.G[i] > Gmax1 );
 else return (-this.G[i] > Gmax4 );
} else if (this.is_lower_bound$I(i)) {
if (this.y[i] == 1) return (this.G[i] > Gmax2 );
 else return (this.G[i] > Gmax3 );
} else return (false);
}, p$3);

Clazz.newMeth(C$, 'do_shrinking$',  function () {
var Gmax1=-Infinity;
var Gmax2=-Infinity;
var Gmax3=-Infinity;
var Gmax4=-Infinity;
var i;
for (i=0; i < this.active_size; i++) {
if (!this.is_upper_bound$I(i)) {
if (this.y[i] == 1) {
if (-this.G[i] > Gmax1 ) Gmax1=-this.G[i];
} else if (-this.G[i] > Gmax4 ) Gmax4=-this.G[i];
}if (!this.is_lower_bound$I(i)) {
if (this.y[i] == 1) {
if (this.G[i] > Gmax2 ) Gmax2=this.G[i];
} else if (this.G[i] > Gmax3 ) Gmax3=this.G[i];
}}
if (this.unshrink == false  && Math.max(Gmax1 + Gmax2, Gmax3 + Gmax4) <= this.eps * 10  ) {
this.unshrink=true;
this.reconstruct_gradient$();
this.active_size=this.l;
}for (i=0; i < this.active_size; i++) if (p$3.be_shrunk$I$D$D$D$D.apply(this, [i, Gmax1, Gmax2, Gmax3, Gmax4])) {
--this.active_size;
while (this.active_size > i){
if (!p$3.be_shrunk$I$D$D$D$D.apply(this, [this.active_size, Gmax1, Gmax2, Gmax3, Gmax4])) {
this.swap_index$I$I(i, this.active_size);
break;
}--this.active_size;
}
}
});

Clazz.newMeth(C$, 'calculate_rho$',  function () {
var nr_free1=0;
var nr_free2=0;
var ub1=Infinity;
var ub2=Infinity;
var lb1=-Infinity;
var lb2=-Infinity;
var sum_free1=0;
var sum_free2=0;
for (var i=0; i < this.active_size; i++) {
if (this.y[i] == 1) {
if (this.is_lower_bound$I(i)) ub1=Math.min(ub1, this.G[i]);
 else if (this.is_upper_bound$I(i)) lb1=Math.max(lb1, this.G[i]);
 else {
++nr_free1;
sum_free1+=this.G[i];
}} else {
if (this.is_lower_bound$I(i)) ub2=Math.min(ub2, this.G[i]);
 else if (this.is_upper_bound$I(i)) lb2=Math.max(lb2, this.G[i]);
 else {
++nr_free2;
sum_free2+=this.G[i];
}}}
var r1;
var r2;
if (nr_free1 > 0) r1=sum_free1 / nr_free1;
 else r1=(ub1 + lb1) / 2;
if (nr_free2 > 0) r2=sum_free2 / nr_free2;
 else r2=(ub2 + lb2) / 2;
this.si.r=(r1 + r2) / 2;
return (r1 - r2) / 2;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:34 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
