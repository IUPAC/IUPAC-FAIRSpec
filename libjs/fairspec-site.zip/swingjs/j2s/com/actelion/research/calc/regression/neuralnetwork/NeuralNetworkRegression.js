(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.neuralnetwork"),I$=[[0,'com.actelion.research.calc.regression.neuralnetwork.ParameterNeuralNetwork','smile.regression.NeuralNetwork','com.actelion.research.calc.Matrix']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "NeuralNetworkRegression", null, 'com.actelion.research.calc.regression.ARegressionMethod', 'Comparable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['neuralNetwork','smile.regression.NeuralNetwork']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
this.setParameterRegressionMethod$com_actelion_research_calc_regression_ParameterRegressionMethod(Clazz.new_($I$(1,1)));
System.setProperty$S$S("smile.threads", "1");
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_calc_regression_neuralnetwork_ParameterNeuralNetwork',  function (parameterNeuralNetwork) {
Clazz.super_(C$, this);
this.setParameterRegressionMethod$com_actelion_research_calc_regression_ParameterRegressionMethod(parameterNeuralNetwork);
}, 1);

Clazz.newMeth(C$, 'createModel$com_actelion_research_util_datamodel_ModelXYIndex',  function (modelXYIndexTrain) {
var YHat=null;
try {
var parameterNeuralNetwork=this.getParameter$();
if (modelXYIndexTrain.Y.cols$() != 1) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Only one column for y is allowed!"]);
}var X=modelXYIndexTrain.X.getArray$();
var y=modelXYIndexTrain.Y.getColAsDouble$I(0);
var arrNetworkArchitecture=Clazz.array(Integer.TYPE, [parameterNeuralNetwork.getArrInnerLayerArchitecture$().length + 2]);
System.arraycopy$O$I$O$I$I(parameterNeuralNetwork.getArrInnerLayerArchitecture$(), 0, arrNetworkArchitecture, 1, parameterNeuralNetwork.getArrInnerLayerArchitecture$().length);
arrNetworkArchitecture[0]=modelXYIndexTrain.X.cols$();
arrNetworkArchitecture[arrNetworkArchitecture.length - 1]=1;
this.neuralNetwork=Clazz.new_([parameterNeuralNetwork.getActivationFunction$(), arrNetworkArchitecture],$I$(2,1).c$$smile_regression_NeuralNetwork_ActivationFunction$IA);
this.neuralNetwork.learn$DAA$DA(X, y);
YHat=this.calculateYHat$com_actelion_research_calc_Matrix(modelXYIndexTrain.X);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
return YHat;
});

Clazz.newMeth(C$, 'calculateYHat$com_actelion_research_calc_Matrix',  function (X) {
var arrY=Clazz.array(Double.TYPE, [X.rows$()]);
for (var i=0; i < X.rows$(); i++) {
var arrRow=X.getRow$I(i);
var y=this.neuralNetwork.predict$DA(arrRow);
arrY[i]=y;
}
return Clazz.new_($I$(3,1).c$$Z$DA,[false, arrY]);
});

Clazz.newMeth(C$, 'calculateYHat$DA',  function (arrRow) {
var y;
{
y=this.neuralNetwork.predict$DA(arrRow);
}return y;
});

Clazz.newMeth(C$, ['compareTo$com_actelion_research_calc_regression_neuralnetwork_NeuralNetworkRegression','compareTo$O'],  function (o) {
return this.getParameter$().compareTo$com_actelion_research_calc_regression_ParameterRegressionMethod(o.getParameter$());
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:33 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
