place here files that will go into the site/ directory
such as html files that are not just the default versions