// JavaScript methods that use ES6 methods

 import(J2S.inchiPath + "/inchi-web-SwingJS.js");
