(function(){var P$=Clazz.newPackage("com"),I$=[[0,'com.actelion.research.chem.SmilesParser','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.CanonizerUtil',['com.actelion.research.chem.CanonizerUtil','.IDCODE_TYPE']]],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Test");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
var sp=Clazz.new_($I$(1,1));
var mol=Clazz.new_($I$(2,1));
sp.parse$com_actelion_research_chem_StereoMolecule$S(mol, "CC");
System.out.println$S(mol.getIDCode$());
mol.stripStereoInformation$();
System.out.println$S(mol.getIDCode$());
System.out.println$S($I$(3,"getIDCode$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_CanonizerUtil_IDCODE_TYPE$Z",[mol, $I$(4).NORMAL, false]));
System.out.println$S($I$(3,"getIDCode$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_CanonizerUtil_IDCODE_TYPE$Z",[mol, $I$(4).NOSTEREO, false]));
System.out.println$S($I$(3,"getIDCode$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_CanonizerUtil_IDCODE_TYPE$Z",[mol, $I$(4).NOSTEREO_TAUTOMER, false]));
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:45 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
