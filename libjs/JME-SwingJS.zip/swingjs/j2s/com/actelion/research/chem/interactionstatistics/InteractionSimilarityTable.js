(function(){var P$=Clazz.newPackage("com.actelion.research.chem.interactionstatistics"),I$=[[0,'java.text.DecimalFormat','java.util.HashMap','com.actelion.research.chem.interactionstatistics.InteractionDistanceStatistics',['com.actelion.research.chem.interactionstatistics.InteractionSimilarityTable','.InteractionDescriptor'],'java.util.ArrayList']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InteractionSimilarityTable", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['InteractionDescriptor',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['stats','com.actelion.research.chem.interactionstatistics.InteractionDistanceStatistics','keyToId','java.util.Map','iDsToDescriptor','com.actelion.research.chem.interactionstatistics.InteractionSimilarityTable.InteractionDescriptor[][]','similarityTable','double[][]','atomKeys','java.util.Set']]
,['O',['instance','com.actelion.research.chem.interactionstatistics.InteractionSimilarityTable']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.keyToId=Clazz.new_($I$(2,1));
this.stats=$I$(3).getInstance$();
this.atomKeys=this.stats.getAtomKeySet$();
var N=this.atomKeys.size$();
var index=0;
for (var key, $key = this.atomKeys.iterator$(); $key.hasNext$()&&((key=($key.next$()).intValue$()),1);) {
this.keyToId.putIfAbsent$O$O(Integer.valueOf$I(key), Integer.valueOf$I(index));
++index;
}
this.iDsToDescriptor=Clazz.array($I$(4), [N, N]);
for (var i, $i = this.atomKeys.iterator$(); $i.hasNext$()&&((i=($i.next$()).intValue$()),1);) {
for (var j, $j = this.atomKeys.iterator$(); $j.hasNext$()&&((j=($j.next$()).intValue$()),1);) {
var plf=this.stats.getFunction$I$I(i, j);
this.iDsToDescriptor[(this.keyToId.get$O(Integer.valueOf$I(i))).$c()][(this.keyToId.get$O(Integer.valueOf$I(j))).$c()]=Clazz.new_($I$(4,1).c$$com_actelion_research_chem_interactionstatistics_SplineFunction,[plf]);
}
}
this.similarityTable=Clazz.array(Double.TYPE, [N, N]);
for (var l1=0; l1 < N; l1++) {
for (var l2=l1; l2 < N; l2++) {
var sum=0;
var total=0;
for (var i=0; i < this.iDsToDescriptor.length; i++) {
var id1=this.iDsToDescriptor[i][l1];
var id2=this.iDsToDescriptor[i][l2];
var coeff=id1.N + id2.N;
sum+=id1.dist$com_actelion_research_chem_interactionstatistics_InteractionSimilarityTable_InteractionDescriptor(id2) * coeff;
total=(total+(coeff)|0);
}
this.similarityTable[l1][l2]=this.similarityTable[l2][l1]=total > 0 ? sum / total : 5;
}
}
}, 1);

Clazz.newMeth(C$, 'getInstance$',  function () {
if (C$.instance == null ) {
{
if (C$.instance == null ) {
C$.instance=Clazz.new_(C$);
}}}return C$.instance;
}, 1);

Clazz.newMeth(C$, 'getDistance$I$I',  function (type1, type2) {
var a=(this.keyToId.get$O(Integer.valueOf$I($I$(3).getInstance$().getKey$I(type1)))).$c();
var b=(this.keyToId.get$O(Integer.valueOf$I($I$(3).getInstance$().getKey$I(type2)))).$c();
return this.similarityTable[a][b];
});

Clazz.newMeth(C$, 'getDissimilarity$I$I',  function (type1, type2) {
var a=(this.keyToId.get$O(Integer.valueOf$I($I$(3).getInstance$().getKey$I(type1)))).$c();
var b=(this.keyToId.get$O(Integer.valueOf$I($I$(3).getInstance$().getKey$I(type2)))).$c();
var sum=0;
for (var i=0; i < this.similarityTable.length; i++) {
var diff=Math.abs(this.similarityTable[a][i] - this.similarityTable[b][i]);
sum+=diff;
}
return sum / this.similarityTable.length;
});

Clazz.newMeth(C$, 'getEquivalentTypes$I$D',  function (type, maxDist) {
type=$I$(3).getInstance$().getKey$I(type);
var res=Clazz.new_($I$(5,1));
for (var type2, $type2 = this.atomKeys.iterator$(); $type2.hasNext$()&&((type2=($type2.next$()).intValue$()),1);) {
if (this.getDissimilarity$I$I(type, type2) < maxDist ) {
res.add$O(Integer.valueOf$I(type2));
}}
return res;
});

C$.$static$=function(){C$.$static$=0;
C$.instance=null;
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.InteractionSimilarityTable, "InteractionDescriptor", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['optimalDist','optimalStrength'],'I',['N']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_interactionstatistics_SplineFunction',  function (plf) {
;C$.$init$.apply(this);
if (plf == null ) return;
this.N=plf.getTotalOccurences$();
try {
this.optimalStrength=100;
this.optimalDist=-1;
for (var d=1.6; d < 4.5 ; d+=0.05) {
var v=plf.getFGValue$D(d)[0];
if (this.optimalStrength < 0  && v > this.optimalStrength + 0.5  ) break;
if (v < this.optimalStrength ) {
this.optimalDist=d;
this.optimalStrength=v;
}}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'dist$com_actelion_research_chem_interactionstatistics_InteractionSimilarityTable_InteractionDescriptor',  function (d2) {
var s1=this.optimalDist > 0  ? this.optimalStrength : 0;
var m1=this.optimalDist > 0  ? this.optimalDist : 4.5;
var s2=d2.optimalDist > 0  ? d2.optimalStrength : 0;
var m2=d2.optimalDist > 0  ? d2.optimalDist : 4.5;
var dist1=Math.abs(m1 - m2) / (2.9);
var dist2=Math.abs(s2 - s1) > 2.0  ? 1.0 : Math.abs(s2 - s1) / 2.0;
return 0.5 * dist1 + 0.5 * dist2;
});

Clazz.newMeth(C$, 'toString',  function () {
return Clazz.new_($I$(1,1).c$$S,["0.0"]).format$D(this.optimalDist) + ":" + Clazz.new_($I$(1,1).c$$S,["0.00"]).format$D(this.optimalStrength) + " [" + this.N + "]" ;
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:54 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
