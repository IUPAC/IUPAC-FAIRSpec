(function(){var P$=Clazz.newPackage("com.actelion.research.chem.docking.scoring.chemscore"),p$1={},I$=[[0,'com.actelion.research.chem.Coordinates','java.util.ArrayList']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "HBTerm", null, null, 'com.actelion.research.chem.potentialenergy.PotentialEnergyTerm');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['isLigAtomDonor','isLigAtomAcceptor'],'D',['scale'],'I',['acceptor','donor','hydrogen'],'O',['receptor','com.actelion.research.chem.conf.Conformer','+ligand','acceptorNeighbours','int[]']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$I$Z$Z$IA$D',  function (receptor, ligand, acceptor, donor, hydrogen, isLigAtomAcceptor, isLigAtomDonor, acceptorNeighbours, scale) {
;C$.$init$.apply(this);
this.receptor=receptor;
this.ligand=ligand;
this.acceptor=acceptor;
this.donor=donor;
this.hydrogen=hydrogen;
this.acceptorNeighbours=acceptorNeighbours;
this.isLigAtomAcceptor=isLigAtomAcceptor;
this.isLigAtomDonor=isLigAtomDonor;
this.scale=scale;
Clazz.assert(C$, this, function(){return (isLigAtomDonor != isLigAtomAcceptor )});
}, 1);

Clazz.newMeth(C$, 'create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$I$Z$Z$IA$D',  function (receptor, ligand, acceptor, donor, hydrogen, isLigAtomAcceptor, isLigAtomDonor, acceptorNeighbours, scale) {
return Clazz.new_(C$.c$$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$I$Z$Z$IA$D,[receptor, ligand, acceptor, donor, hydrogen, isLigAtomAcceptor, isLigAtomDonor, acceptorNeighbours, scale]);
}, 1);

Clazz.newMeth(C$, 'getDistTerm$DA',  function (gradient) {
var a;
var h;
var grad=Clazz.new_($I$(1,1));
var energy=0.0;
if (this.isLigAtomAcceptor) a=this.ligand.getCoordinates$I(this.acceptor);
 else a=this.receptor.getCoordinates$I(this.acceptor);
if (this.isLigAtomDonor) h=this.ligand.getCoordinates$I(this.hydrogen);
 else h=this.receptor.getCoordinates$I(this.hydrogen);
var r=a.subC$com_actelion_research_chem_Coordinates(h);
var distSq=r.distSq$();
if (distSq < 6.25 ) {
var d=Math.sqrt(distSq);
var invert=false;
var distTerm=d - 1.85;
if (distTerm < 0 ) {
invert=true;
distTerm=-distTerm;
}if (distTerm < 0.25 ) {
energy=1.0;
} else if (distTerm > 0.65 ) {
energy=0.0;
} else {
var prefactor=-2.5 * (1.0 / d);
if (invert) prefactor*=-1;
grad=r.scaleC$D(prefactor);
grad.scale$D(this.scale);
if (distTerm < 0 ) grad.scaleC$D(-1.0);
if (this.isLigAtomAcceptor) {
gradient[3 * this.acceptor]+=grad.x;
gradient[3 * this.acceptor + 1]+=grad.y;
gradient[3 * this.acceptor + 2]+=grad.z;
} else {
gradient[3 * this.hydrogen]-=grad.x;
gradient[3 * this.hydrogen + 1]-=grad.y;
gradient[3 * this.hydrogen + 2]-=grad.z;
}energy=(0.65 - distTerm) / (0.4);
}}return energy;
}, p$1);

Clazz.newMeth(C$, 'getAngleTerm$DA$I$I$I$Z$Z$Z$D$D$D',  function (gradient, a1, a2, a3, isLigAtomA1, isLigAtomA2, isLigAtomA3, x0, x1, x2) {
var energy=0.0;
var c1;
var c2;
var c3;
if (isLigAtomA1) c1=this.ligand.getCoordinates$I(a1);
 else c1=this.receptor.getCoordinates$I(a1);
if (isLigAtomA2) c2=this.ligand.getCoordinates$I(a2);
 else c2=this.receptor.getCoordinates$I(a2);
if (isLigAtomA3) c3=this.ligand.getCoordinates$I(a3);
 else c3=this.receptor.getCoordinates$I(a3);
var r0=c1.subC$com_actelion_research_chem_Coordinates(c2).unit$();
var r1=c3.subC$com_actelion_research_chem_Coordinates(c2).unit$();
var dist0=c2.distance$com_actelion_research_chem_Coordinates(c1);
var dist1=c3.distance$com_actelion_research_chem_Coordinates(c2);
var cosTheta=r0.cosAngle$com_actelion_research_chem_Coordinates(r1);
var angleTerm=Math.acos(cosTheta) - x0;
var invert=false;
if (angleTerm < 0 ) {
angleTerm=-angleTerm;
invert=true;
}if (angleTerm < x1 ) energy=1.0;
 else if (angleTerm > x2 ) energy=0.0;
 else {
var prefactor=-1.0 / (x2 - x1);
if (invert) {
prefactor=-prefactor;
}energy=(x2 - angleTerm) / (x2 - x1);
var sinThetaSq=1.0 - cosTheta * cosTheta;
var sinTheta=1.0E-8;
if (sinThetaSq > 0.0 ) sinTheta=Math.sqrt(sinThetaSq);
var dCos_dS=Clazz.array(Double.TYPE, -1, [1.0 / dist0 * (r1.x - cosTheta * r0.x), 1.0 / dist0 * (r1.y - cosTheta * r0.y), 1.0 / dist0 * (r1.z - cosTheta * r0.z), 1.0 / dist1 * (r0.x - cosTheta * r1.x), 1.0 / dist1 * (r0.y - cosTheta * r1.y), 1.0 / dist1 * (r0.z - cosTheta * r1.z)]);
if (isLigAtomA1) {
gradient[3 * a1]+=prefactor * dCos_dS[0] / (-sinTheta);
gradient[3 * a1 + 1]+=prefactor * dCos_dS[1] / (-sinTheta);
gradient[3 * a1 + 2]+=prefactor * dCos_dS[2] / (-sinTheta);
}if (isLigAtomA2) {
gradient[3 * a2]+=prefactor * (-dCos_dS[0] - dCos_dS[3]) / (-sinTheta);
gradient[3 * a2 + 1]+=prefactor * (-dCos_dS[1] - dCos_dS[4]) / (-sinTheta);
gradient[3 * a2 + 2]+=prefactor * (-dCos_dS[2] - dCos_dS[5]) / (-sinTheta);
}if (isLigAtomA3) {
gradient[3 * a3]+=prefactor * dCos_dS[3] / (-sinTheta);
gradient[3 * a3 + 1]+=prefactor * dCos_dS[4] / (-sinTheta);
gradient[3 * a3 + 2]+=prefactor * dCos_dS[5] / (-sinTheta);
}}return energy;
}, p$1);

Clazz.newMeth(C$, 'getFGValue$DA',  function (gradient) {
var energies=Clazz.new_($I$(2,1));
var gradients=Clazz.new_($I$(2,1));
var energy=0.0;
var grad=Clazz.array(Double.TYPE, [gradient.length]);
energy=p$1.getDistTerm$DA.apply(this, [grad]);
if (energy != 0.0 ) {
energies.add$O(Double.valueOf$D(energy));
gradients.add$O(grad);
grad=Clazz.array(Double.TYPE, [gradient.length]);
energy=p$1.getAngleTerm$DA$I$I$I$Z$Z$Z$D$D$D.apply(this, [grad, this.donor, this.hydrogen, this.acceptor, this.isLigAtomDonor, this.isLigAtomDonor, this.isLigAtomAcceptor, 3.141592653589793, 0.5235987755982988, 1.3962634015954636]);
energies.add$O(Double.valueOf$D(energy));
gradients.add$O(grad);
for (var aa, $aa = 0, $$aa = this.acceptorNeighbours; $aa<$$aa.length&&((aa=($$aa[$aa])),1);$aa++) {
grad=Clazz.array(Double.TYPE, [gradient.length]);
energy=p$1.getAngleTerm$DA$I$I$I$Z$Z$Z$D$D$D.apply(this, [grad, aa, this.acceptor, this.hydrogen, this.isLigAtomAcceptor, this.isLigAtomAcceptor, this.isLigAtomDonor, 3.141592653589793, 1.3962634015954636, 1.7453292519943295]);
energies.add$O(Double.valueOf$D(energy));
gradients.add$O(grad);
}
} else energies.add$O(Double.valueOf$D(0.0));
var totGrad=Clazz.array(Double.TYPE, [gradient.length]);
var totEnergy=this.scale * -3.0;
for (var eng, $eng = energies.iterator$(); $eng.hasNext$()&&((eng=($eng.next$()).objectValue$()),1);) totEnergy*=eng;

for (var i=0; i < gradients.size$(); i++) {
var g=gradients.get$I(i);
for (var j=0; j < gradients.size$(); j++) {
if (i == j) continue;
var e=(energies.get$I(j)).valueOf();
var w=e * this.scale * -3.0 ;
for (var k=0; k < g.length; k++) g[k]*=w;

}
for (var l=0; l < totGrad.length; l++) {
totGrad[l]+=g[l];
}
}
for (var i=0; i < totGrad.length; i++) {
gradient[i]+=totGrad[i];
}
return totEnergy;
});

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:53 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
