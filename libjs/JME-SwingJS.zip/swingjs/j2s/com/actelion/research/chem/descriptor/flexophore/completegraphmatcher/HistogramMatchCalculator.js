(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore.completegraphmatcher");
/*c*/var C$=Clazz.newClass(P$, "HistogramMatchCalculator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getFractionOverlapIntegral$com_actelion_research_chem_descriptor_flexophore_DistHist$I$I$com_actelion_research_chem_descriptor_flexophore_DistHist$I$I',  function (dh1, indexDistHist1At1, indexDistHist1At2, dh2, indexDistHist2At1, indexDistHist2At2) {
var indexPostStartDistHist1=dh1.getIndexPosStartForDistHist$I$I(indexDistHist1At1, indexDistHist1At2);
var indexPostStartDistHist2=dh2.getIndexPosStartForDistHist$I$I(indexDistHist2At1, indexDistHist2At2);
var n=80;
var sumMin=0;
var sumMax=0;
for (var i=0; i < n; i++) {
var v1=dh1.getValueAtAbsolutePosition$I(indexPostStartDistHist1 + i);
var v2=dh2.getValueAtAbsolutePosition$I(indexPostStartDistHist2 + i);
sumMin+=Math.min(v1, v2);
sumMax+=Math.max(v1, v2);
}
var score=sumMin / sumMax;
return score;
}, 1);

Clazz.newMeth(C$, 'getFractionOverlappingBins$com_actelion_research_chem_descriptor_flexophore_DistHist$I$I$com_actelion_research_chem_descriptor_flexophore_DistHist$I$I',  function (dh1, indexDistHist1At1, indexDistHist1At2, dh2, indexDistHist2At1, indexDistHist2At2) {
var indexPostStartDistHist1=dh1.getIndexPosStartForDistHist$I$I(indexDistHist1At1, indexDistHist1At2);
var indexPostStartDistHist2=dh2.getIndexPosStartForDistHist$I$I(indexDistHist2At1, indexDistHist2At2);
var n=80;
var sumMin=0;
var sumMax=0;
var sum1=0;
var sum2=0;
for (var i=0; i < n; i++) {
var v1=(dh1.getValueAtAbsolutePosition$I(indexPostStartDistHist1 + i) == 0) ? 0 : 1;
var v2=(dh2.getValueAtAbsolutePosition$I(indexPostStartDistHist2 + i) == 0) ? 0 : 1;
sum1+=v1;
sum2+=v2;
sumMin+=Math.min(v1, v2);
sumMax+=Math.max(v1, v2);
}
var score=sumMin / Math.min(sum1, sum2);
return score;
}, 1);

Clazz.newMeth(C$, 'getPercentageOverlap$com_actelion_research_chem_descriptor_flexophore_DistHist$I$I$com_actelion_research_chem_descriptor_flexophore_DistHist$I$I',  function (dh1, indexDistHist1At1, indexDistHist1At2, dh2, indexDistHist2At1, indexDistHist2At2) {
var indexPostStartDistHist1=dh1.getIndexPosStartForDistHist$I$I(indexDistHist1At1, indexDistHist1At2);
var indexPostStartDistHist2=dh2.getIndexPosStartForDistHist$I$I(indexDistHist2At1, indexDistHist2At2);
var n=80;
var sumMin=0;
var sum1=0;
var sum2=0;
for (var i=0; i < n; i++) {
var v1=dh1.getValueAtAbsolutePosition$I(indexPostStartDistHist1 + i);
var v2=dh2.getValueAtAbsolutePosition$I(indexPostStartDistHist2 + i);
sumMin+=Math.min(v1, v2);
sum1+=v1;
sum2+=v2;
}
var score=sumMin / Math.max(sum1, sum2);
;return score;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:52 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
