(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore"),p$1={},I$=[[0,'java.util.ArrayList','java.util.HashSet','com.actelion.research.chem.Molecule3D','com.actelion.research.chem.descriptor.flexophore.PPNodeViz','com.actelion.research.chem.descriptor.flexophore.MDHIndexTables','com.actelion.research.chem.interactionstatistics.InteractionAtomTypeCalculator','com.actelion.research.chem.Coordinates','java.util.Collections',['com.actelion.research.chem.phesa.pharmacophore.pp.IPharmacophorePoint','.Functionality'],'java.util.Arrays','com.actelion.research.calc.ArrayUtilsCalc','com.actelion.research.chem.descriptor.flexophore.MolDistHist','com.actelion.research.chem.descriptor.flexophore.calculator.StructureCalculator','StringBuilder','StringBuffer','com.actelion.research.util.Formatter','java.util.StringTokenizer']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MolDistHistViz", null, 'com.actelion.research.chem.descriptor.flexophore.DistHist', ['java.io.Serializable', 'com.actelion.research.chem.descriptor.flexophore.IMolDistHist', 'com.actelion.research.util.graph.complete.ICompleteGraph']);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['finalized'],'B',['modeFlexophore'],'I',['flagsDescribe','numCNodes','numHeteroNodes'],'O',['liPPNodeViz','java.util.List','molecule3D','com.actelion.research.chem.Molecule3D','hsIndexMandatoryPPPoints','java.util.HashSet','arrWeight','double[]','liDistanceTable','java.util.List']]
,['O',['indexTables','com.actelion.research.chem.descriptor.flexophore.MDHIndexTables','COLORS','String[]']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
this.molecule3D=null;
this.flagsDescribe=1;
this.liPPNodeViz=Clazz.new_($I$(1,1));
this.hsIndexMandatoryPPPoints=Clazz.new_($I$(2,1));
this.modeFlexophore=0;
}, 1);

Clazz.newMeth(C$, 'c$$I',  function (nNodes) {
Clazz.super_(C$, this);
this.initHistogramArray$I(nNodes);
this.flagsDescribe=1;
this.hsIndexMandatoryPPPoints=Clazz.new_($I$(2,1));
this.modeFlexophore=0;
}, 1);

Clazz.newMeth(C$, 'c$$I$com_actelion_research_chem_Molecule3D',  function (nNodes, molecule3D) {
Clazz.super_(C$, this);
this.initHistogramArray$I(nNodes);
this.flagsDescribe=1;
if (molecule3D != null ) {
this.molecule3D=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_Molecule3D,[molecule3D]);
this.molecule3D.ensureHelperArrays$I(7);
this.molecule3D.stripSmallFragments$();
}this.hsIndexMandatoryPPPoints=Clazz.new_($I$(2,1));
this.modeFlexophore=0;
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz',  function (mdhv) {
Clazz.super_(C$, this);
this.hsIndexMandatoryPPPoints=Clazz.new_($I$(2,1));
mdhv.copy$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz(this);
this.flagsDescribe=1;
this.modeFlexophore=mdhv.modeFlexophore;
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_descriptor_flexophore_MolDistHist',  function (mdh) {
Clazz.super_(C$, this);
if (mdh.getNumPPNodes$() == 0) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Empty object given into constructor."]);
}mdh.copy$com_actelion_research_chem_descriptor_flexophore_DistHist(this);
this.modeFlexophore=mdh.getModeFlexophore$();
this.liPPNodeViz=Clazz.new_([mdh.getNumPPNodes$()],$I$(1,1).c$$I);
for (var i=0; i < mdh.getNumPPNodes$(); i++) {
var node=Clazz.new_([mdh.getNode$I(i)],$I$(4,1).c$$com_actelion_research_chem_descriptor_flexophore_PPNode);
this.liPPNodeViz.add$O(node);
}
this.hsIndexMandatoryPPPoints=Clazz.new_($I$(2,1));
this.realize$();
}, 1);

Clazz.newMeth(C$, 'createIndexTables$',  function () {
C$.indexTables=$I$(5).getInstance$();
}, 1);

Clazz.newMeth(C$, 'addMandatoryPharmacophorePoint$I',  function (indexPPNode) {
this.hsIndexMandatoryPPPoints.add$O(Integer.valueOf$I(indexPPNode));
});

Clazz.newMeth(C$, 'setNodeWeight$I$D',  function (indexNode, weight) {
if (!this.finalized) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["MolDistHistViz not finalized!"]);
}this.arrWeight[indexNode]=weight;
});

Clazz.newMeth(C$, 'resetNodeWeights$',  function () {
if (!this.finalized) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["MolDistHistViz not finalized!"]);
}for (var i=0; i < this.liPPNodeViz.size$(); i++) {
this.arrWeight[i]=1;
}
});

Clazz.newMeth(C$, 'removeInevitablePharmacophorePoint$I',  function (indexPPNode) {
this.hsIndexMandatoryPPPoints.remove$O(Integer.valueOf$I(indexPPNode));
});

Clazz.newMeth(C$, 'setModeFlexophore$B',  function (modeFlexophore) {
this.modeFlexophore=modeFlexophore;
for (var n, $n = this.liPPNodeViz.iterator$(); $n.hasNext$()&&((n=($n.next$())),1);) {
n.setModeFlexophore$B(modeFlexophore);
}
});

Clazz.newMeth(C$, 'setMarkAll$Z',  function (mark) {
for (var n, $n = this.liPPNodeViz.iterator$(); $n.hasNext$()&&((n=($n.next$())),1);) {
n.setMarked$Z(mark);
}
});

Clazz.newMeth(C$, 'setMark$I$Z',  function (index, mark) {
this.liPPNodeViz.get$I(index).setMarked$Z(mark);
});

Clazz.newMeth(C$, 'isMarked$I',  function (index) {
return this.liPPNodeViz.get$I(index).isMarked$();
});

Clazz.newMeth(C$, 'addNode$com_actelion_research_chem_descriptor_flexophore_PPNodeViz',  function (node) {
var index=this.liPPNodeViz.size$();
node.setIndex$I(this.liPPNodeViz.size$());
node.setModeFlexophore$B(this.modeFlexophore);
this.liPPNodeViz.add$O(node);
if (this.liPPNodeViz.size$() > this.getNumPPNodes$()) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["To many nodes added!"]);
}this.finalized=false;
return index;
});

Clazz.newMeth(C$, 'check$',  function () {
var bOK=true;
var nodes=this.getNumPPNodes$();
for (var i=0; i < nodes; i++) {
var node=this.getNode$I(i);
var ats=node.getInteractionTypeCount$();
for (var j=0; j < ats; j++) {
var inttype=node.getInteractionType$I(j);
var s=$I$(6).getString$I(inttype);
if (s.length$() == 0) {
bOK=false;
}}
}
return bOK;
});

Clazz.newMeth(C$, 'initHistogramArray$I',  function (size) {
C$.superclazz.prototype.initHistogramArray$I.apply(this, [size]);
this.liPPNodeViz=Clazz.new_($I$(1,1));
this.finalized=false;
});

Clazz.newMeth(C$, 'copy$',  function () {
return Clazz.new_(C$.c$$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz,[this]);
});

Clazz.newMeth(C$, 'copy$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz',  function (copy) {
C$.superclazz.prototype.copy$com_actelion_research_chem_descriptor_flexophore_DistHist.apply(this, [copy]);
copy.flagsDescribe=this.flagsDescribe;
if (this.molecule3D != null ) {
copy.molecule3D=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_Molecule3D,[this.molecule3D]);
copy.molecule3D.ensureHelperArrays$I(7);
}copy.liPPNodeViz=Clazz.new_($I$(1,1));
for (var i=0; i < this.liPPNodeViz.size$(); i++) {
copy.liPPNodeViz.add$O(Clazz.new_([this.liPPNodeViz.get$I(i)],$I$(4,1).c$$com_actelion_research_chem_descriptor_flexophore_PPNodeViz));
}
copy.numCNodes=this.numCNodes;
copy.numHeteroNodes=this.numHeteroNodes;
copy.finalized=this.finalized;
copy.hsIndexMandatoryPPPoints.clear$();
copy.hsIndexMandatoryPPPoints.addAll$java_util_Collection(this.hsIndexMandatoryPPPoints);
copy.arrWeight=Clazz.array(Double.TYPE, [this.arrWeight.length]);
System.arraycopy$O$I$O$I$I(this.arrWeight, 0, copy.arrWeight, 0, this.arrWeight.length);
});

Clazz.newMeth(C$, 'recalculateCoordPPPoints$',  function () {
for (var ppNodeViz, $ppNodeViz = this.liPPNodeViz.iterator$(); $ppNodeViz.hasNext$()&&((ppNodeViz=($ppNodeViz.next$())),1);) {
var liIndexAts=ppNodeViz.getListIndexOriginalAtoms$();
var arrAtIndex=Clazz.array(Integer.TYPE, [liIndexAts.size$()]);
for (var i=0; i < arrAtIndex.length; i++) {
arrAtIndex[i]=(liIndexAts.get$I(i)).$c();
}
var arrCoordinates=Clazz.array($I$(7), [arrAtIndex.length]);
for (var i=0; i < arrAtIndex.length; i++) {
var x=this.molecule3D.getAtomX$I(arrAtIndex[i]);
var y=this.molecule3D.getAtomY$I(arrAtIndex[i]);
var z=this.molecule3D.getAtomZ$I(arrAtIndex[i]);
arrCoordinates[i]=Clazz.new_($I$(7,1).c$$D$D$D,[x, y, z]);
}
var coordCenter=$I$(7).createBarycenter$com_actelion_research_chem_CoordinatesA(arrCoordinates);
ppNodeViz.setCoordinates$D$D$D(coordCenter.x, coordCenter.y, coordCenter.z);
}
});

Clazz.newMeth(C$, 'resetInevitablePharmacophorePoints$',  function () {
this.hsIndexMandatoryPPPoints.clear$();
});

Clazz.newMeth(C$, 'resetInfoColor$',  function () {
var size=this.getNumPPNodes$();
for (var i=0; i < size; i++) {
var node=this.getNode$I(i);
node.resetInfoColor$();
}
});

Clazz.newMeth(C$, 'createNodeIndex$',  function () {
for (var i=0; i < this.getNumPPNodes$(); i++) {
this.getNode$I(i).setIndex$I(i);
}
});

Clazz.newMeth(C$, 'getBondAtom$I$I',  function (index, bond) {
return C$.indexTables.getAtomPairsBondsTable$I(this.getNumPPNodes$())[index][bond];
});

Clazz.newMeth(C$, 'getConnAtom$I$I',  function (at, index) {
if (index >= at) ++index;
return index;
});

Clazz.newMeth(C$, 'getConnBond$I$I',  function (at, index) {
return C$.indexTables.getConnectionTable$I(this.getNumPPNodes$())[at][index];
});

Clazz.newMeth(C$, 'getIndexFromCoord$D$D$D',  function (x, y, z) {
var index=-1;
var c=Clazz.new_($I$(7,1).c$$D$D$D,[x, y, z]);
for (var i=0; i < this.getNumPPNodes$(); i++) {
var ppNodeViz=this.getNode$I(i);
if (ppNodeViz.getCoordinates$().equals$O(c)) {
index=i;
break;
}}
return index;
});

Clazz.newMeth(C$, 'getInfo$I',  function (index) {
return (this.getNode$I(index)).getMappingIndex$();
});

Clazz.newMeth(C$, 'getNode$I',  function (i) {
return this.liPPNodeViz.get$I(i);
});

Clazz.newMeth(C$, 'getNodes$',  function () {
return this.liPPNodeViz;
});

Clazz.newMeth(C$, 'set$java_util_List',  function (liPPNodeViz) {
this.liPPNodeViz=liPPNodeViz;
this.calculate$();
});

Clazz.newMeth(C$, 'set$com_actelion_research_chem_Molecule3D',  function (ff) {
if (ff != null ) this.molecule3D=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_Molecule3D,[ff]);
});

Clazz.newMeth(C$, 'setMappingIndex$I$I',  function (index, info) {
this.getNode$I(index).setMappingIndex$I(info);
});

Clazz.newMeth(C$, 'setSimilarityMappingNodes$I$F',  function (index, similarityMappingNodes) {
this.getNode$I(index).setSimilarityMappingNodes$F(similarityMappingNodes);
});

Clazz.newMeth(C$, 'getName$',  function () {
return this.molecule3D.getName$();
});

Clazz.newMeth(C$, 'setName$S',  function (name) {
this.molecule3D.setName$S(name);
});

Clazz.newMeth(C$, 'isOnlyCarbon$I',  function (index) {
var node=this.getNode$I(index);
var bOnlyCarbon=true;
for (var i=0; i < node.getInteractionTypeCount$(); i++) {
if (node.getAtomicNo$I(i) != 6) bOnlyCarbon=false;
}
return bOnlyCarbon;
});

Clazz.newMeth(C$, 'calcNumHeteroNodes',  function () {
var num=0;
for (var i=0; i < this.getNumPPNodes$(); i++) {
var node=this.getNode$I(i);
if (node.hasHeteroAtom$()) ++num;
}
return num;
}, p$1);

Clazz.newMeth(C$, 'canonize$',  function () {
for (var i=0; i < this.liPPNodeViz.size$(); i++) {
this.liPPNodeViz.get$I(i).realize$();
this.liPPNodeViz.get$I(i).sortInteractionTypes$();
}
var fin=false;
while (!fin){
fin=true;
for (var i=1; i < this.liPPNodeViz.size$(); i++) {
var cmp=p$1.compareNodes$I$I.apply(this, [i, i - 1]);
if (cmp < 0) {
fin=false;
this.swapNodes$I$I(i, i - 1);
}}
}
for (var i=0; i < this.liPPNodeViz.size$(); i++) {
this.liPPNodeViz.get$I(i).setIndex$I(i);
}
});

Clazz.newMeth(C$, 'compareNodes$I$I',  function (n1, n2) {
var cmp=0;
var pp1=this.liPPNodeViz.get$I(n1);
var pp2=this.liPPNodeViz.get$I(n2);
cmp=pp1.compareTo$com_actelion_research_chem_descriptor_flexophore_PPNode(pp2);
if (cmp == 0) {
var size=this.getNumPPNodes$() - 1;
var liN1=Clazz.new_($I$(1,1).c$$I,[size]);
var liN2=Clazz.new_($I$(1,1).c$$I,[size]);
for (var i=0; i < this.liPPNodeViz.size$(); i++) {
if (i != n1) {
liN1.add$O(this.getDistHist$I$I(n1, i));
}if (i != n2) {
liN2.add$O(this.getDistHist$I$I(n2, i));
}}
$I$(8,"sort$java_util_List$java_util_Comparator",[liN1, Clazz.new_(P$.MolDistHistViz$1CmpHists.$init$,[this, null])]);
$I$(8,"sort$java_util_List$java_util_Comparator",[liN2, Clazz.new_(P$.MolDistHistViz$1CmpHists.$init$,[this, null])]);
for (var i=0; i < liN1.size$(); i++) {
var cmpHist=p$1.compare$BA$BA.apply(this, [liN1.get$I(i), liN2.get$I(i)]);
if (cmpHist != 0) {
cmp=cmpHist;
break;
}}
}return cmp;
}, p$1);

Clazz.newMeth(C$, 'swapNodes$I$I',  function (n1, n2) {
var p1=this.liPPNodeViz.get$I(n1);
var size=this.getNumPPNodes$();
this.liPPNodeViz.set$I$O(n1, this.liPPNodeViz.get$I(n2));
this.liPPNodeViz.set$I$O(n2, p1);
for (var i=0; i < size; i++) {
if ((i != n1) && (i != n2) ) {
var histTmp=this.getDistHist$I$I(n1, i);
this.setDistHist$I$I$BA(n1, i, this.getDistHist$I$I(n2, i));
this.setDistHist$I$I$BA(n2, i, histTmp);
}}
var w1=this.arrWeight[n1];
this.arrWeight[n1]=this.arrWeight[n2];
this.arrWeight[n2]=w1;
});

Clazz.newMeth(C$, 'compare$BA$BA',  function (arr1, arr2) {
var cmp=0;
for (var i=0; i < arr1.length; i++) {
if (arr1[i] > arr2[i]) {
cmp=1;
break;
} else if (arr1[i] < arr2[i]) {
cmp=-1;
break;
}}
return cmp;
}, p$1);

Clazz.newMeth(C$, 'getNumCExclusiveNodes$',  function () {
return this.numCNodes;
});

Clazz.newMeth(C$, 'getNumHeteroNodes$',  function () {
return this.numHeteroNodes;
});

Clazz.newMeth(C$, 'getInevitablePharmacophorePoints$',  function () {
var li=Clazz.new_($I$(1,1).c$$java_util_Collection,[this.hsIndexMandatoryPPPoints]);
return li;
});

Clazz.newMeth(C$, 'getHashSetIndexInevitablePPPoints$',  function () {
return this.hsIndexMandatoryPPPoints;
});

Clazz.newMeth(C$, 'getNumMandatoryPharmacophorePoints$',  function () {
return this.hsIndexMandatoryPPPoints.size$();
});

Clazz.newMeth(C$, 'isMandatoryPharmacophorePoint$I',  function (indexNode) {
return this.hsIndexMandatoryPPPoints.contains$O(Integer.valueOf$I(indexNode));
});

Clazz.newMeth(C$, 'getWeightPharmacophorePoint$I',  function (indexNode) {
return this.arrWeight[indexNode];
});

Clazz.newMeth(C$, 'isAliphatic$I',  function (indexNode) {
var aliphatic=true;
var node=this.getNode$I(indexNode);
if (this.modeFlexophore == 1) {
if (5 == node.get$()[0]) {
aliphatic=true;
}} else {
for (var i=0; i < node.getInteractionTypeCount$(); i++) {
if (node.getAtomicNo$I(i) != 6) {
aliphatic=false;
break;
}}
}return aliphatic;
});

Clazz.newMeth(C$, 'isAcceptor$I',  function (indexNode) {
var acceptor=false;
var node=this.getNode$I(indexNode);
if (this.modeFlexophore == 1) {
if ($I$(9).ACCEPTOR.getIndex$() == node.get$()[0]) {
acceptor=true;
}} else {
for (var i=0; i < node.getInteractionTypeCount$(); i++) {
if (node.getAtomicNo$I(i) == 8 || node.getAtomicNo$I(i) == 7 ) {
acceptor=true;
break;
}}
}return acceptor;
});

Clazz.newMeth(C$, 'isDonor$I',  function (indexNode) {
var donor=false;
var node=this.getNode$I(indexNode);
if (this.modeFlexophore == 1) {
if ($I$(9).DONOR.getIndex$() == node.get$()[0]) {
donor=true;
}} else {
var liIndexAtom=node.getListIndexOriginalAtoms$();
var mol=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_Molecule3D,[this.molecule3D]);
mol.ensureHelperArrays$I(7);
for (var indexAtom, $indexAtom = liIndexAtom.iterator$(); $indexAtom.hasNext$()&&((indexAtom=($indexAtom.next$()).intValue$()),1);) {
if (mol.getAtomicNo$I(indexAtom) == 8 || mol.getAtomicNo$I(indexAtom) == 7 ) {
if (mol.getAllHydrogens$I(indexAtom) > 0) {
donor=true;
break;
}}}
}return donor;
});

Clazz.newMeth(C$, 'isAromatic$I',  function (indexNode) {
var aromatic=false;
var node=this.getNode$I(indexNode);
if (this.modeFlexophore == 1) {
if ($I$(9).AROM_RING.getIndex$() == node.get$()[0]) {
aromatic=true;
}}return aromatic;
});

Clazz.newMeth(C$, 'isChargePos$I',  function (indexNode) {
var charge=false;
var node=this.getNode$I(indexNode);
if (this.modeFlexophore == 1) {
if ($I$(9).POS_CHARGE.getIndex$() == node.get$()[0]) {
charge=true;
}}return charge;
});

Clazz.newMeth(C$, 'isChargeNeg$I',  function (indexNode) {
var charge=false;
var node=this.getNode$I(indexNode);
if (this.modeFlexophore == 1) {
if ($I$(9).NEG_CHARGE.getIndex$() == node.get$()[0]) {
charge=true;
}}return charge;
});

Clazz.newMeth(C$, 'calcNumCExclusiveNodes',  function () {
var num=0;
for (var i=0; i < this.getNumPPNodes$(); i++) {
var node=this.getNode$I(i);
if (node.isCarbonExclusiveNode$()) ++num;
}
return num;
}, p$1);

Clazz.newMeth(C$, 'realize$',  function () {
this.arrWeight=Clazz.array(Double.TYPE, [this.liPPNodeViz.size$()]);
$I$(10).fill$DA$D(this.arrWeight, 1.0);
var maxAtIndex=0;
for (var node, $node = this.liPPNodeViz.iterator$(); $node.hasNext$()&&((node=($node.next$())),1);) {
node.realize$();
if (this.molecule3D != null ) {
var a=node.getArrayIndexOriginalAtoms$();
maxAtIndex=Math.max(maxAtIndex, $I$(11).max$IA(a));
}}
if (this.molecule3D != null ) {
if (maxAtIndex > this.molecule3D.getAtoms$() - 1) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Error in Flexophore creation! Largest atom index in PPNode is higher than number of atoms in corresponding molecule!"]);
}}this.canonize$();
this.calculate$();
this.finalized=true;
});

Clazz.newMeth(C$, 'blurrSingleBinHistograms$',  function () {
var size=this.getNumPPNodes$();
var arr=Clazz.array(Byte.TYPE, [80]);
for (var i=0; i < size; i++) {
for (var j=0; j < size; j++) {
if (i == j) continue;
arr=this.getDistHist$I$I$BA(i, j, arr);
var occupied=0;
var counts=0;
for (var k=0; k < arr.length; k++) {
if (arr[k] > 0) {
++occupied;
counts+=arr[k];
}}
if (occupied == 1) {
if (counts >= 3) {
p$1.blurrSingleBinHistogram$BA.apply(this, [arr]);
this.setDistHist$I$I$BA(i, j, arr);
}}}
}
});

Clazz.newMeth(C$, 'blurrSingleBinHistogram$BA',  function (arr) {
var pos=-1;
for (var i=0; i < arr.length; i++) {
if (arr[i] > 0) {
pos=i;
break;
}}
var countCenter=arr[pos];
if ((pos == 0) || (pos == arr.length - 1) ) {
var countCenterBlurred=($b$[0] = (countCenter - (countCenter * 0.2)), $b$[0]);
var countBlurredBuddy=($b$[0] = (countCenter * 0.2), $b$[0]);
if (pos == 0) {
arr[0]=countCenterBlurred;
arr[1]=countBlurredBuddy;
} else if (pos == arr.length - 1) {
arr[arr.length - 1]=countCenterBlurred;
arr[arr.length - 2]=countBlurredBuddy;
}} else {
var countCenterBlurred=($b$[0] = (countCenter - (2.0 * countCenter * 0.2 )), $b$[0]);
var countBlurredBuddy=($b$[0] = (countCenter * 0.2), $b$[0]);
arr[pos - 1]=countBlurredBuddy;
arr[pos]=countCenterBlurred;
arr[pos + 1]=countBlurredBuddy;
}}, p$1);

Clazz.newMeth(C$, 'calculate$',  function () {
this.numCNodes=p$1.calcNumCExclusiveNodes.apply(this, []);
this.numHeteroNodes=p$1.calcNumHeteroNodes.apply(this, []);
});

Clazz.newMeth(C$, 'finalizeMolecule$com_actelion_research_chem_Molecule3D',  function (mol) {
var molecule3DCpy=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_Molecule3D,[mol]);
molecule3DCpy.ensureHelperArrays$I(7);
var hsAt2Del=Clazz.new_($I$(2,1));
for (var i=0; i < molecule3DCpy.getAllAtoms$(); i++) {
if (molecule3DCpy.getConnAtoms$I(i) == 0) hsAt2Del.add$O(Integer.valueOf$I(i));
}
var liAt2Del=Clazz.new_($I$(1,1).c$$java_util_Collection,[hsAt2Del]);
$I$(8).sort$java_util_List(liAt2Del);
$I$(8).reverse$java_util_List(liAt2Del);
for (var at, $at = liAt2Del.iterator$(); $at.hasNext$()&&((at=($at.next$())),1);) {
molecule3DCpy.deleteAtom$I((at).$c());
}
return molecule3DCpy;
}, 1);

Clazz.newMeth(C$, 'getMolDistHist$',  function () {
this.realize$();
var nPPNodes=this.getNumPPNodes$();
var mdh=Clazz.new_($I$(12,1).c$$I,[nPPNodes]);
for (var i=0; i < nPPNodes; i++) {
mdh.addNode$com_actelion_research_chem_descriptor_flexophore_PPNode(this.getNode$I(i));
}
for (var i=0; i < nPPNodes; i++) {
for (var j=i + 1; j < nPPNodes; j++) {
mdh.setDistHist$I$I$BA(i, j, this.getDistHist$I$I(i, j));
}
}
return mdh;
});

Clazz.newMeth(C$, 'getMaximumDistanceInPPPoint$I',  function (indexNode) {
var maxDist=0;
var node=this.getNode$I(indexNode);
var liIndexAtom=node.getListIndexOriginalAtoms$();
var liCoord=Clazz.new_($I$(1,1));
for (var atom, $atom = liIndexAtom.iterator$(); $atom.hasNext$()&&((atom=($atom.next$()).intValue$()),1);) {
var coord=this.molecule3D.getCoordinates$I(atom);
liCoord.add$O(coord);
}
for (var i=0; i < liCoord.size$(); i++) {
var c1=liCoord.get$I(i);
for (var j=i + 1; j < liCoord.size$(); j++) {
var c2=liCoord.get$I(j);
var dist=c1.distance$com_actelion_research_chem_Coordinates(c2);
if (dist > maxDist ) {
maxDist=dist;
}}
}
return maxDist;
});

Clazz.newMeth(C$, 'getMolecule$',  function () {
if (this.molecule3D == null ) return null;
return this.molecule3D;
});

Clazz.newMeth(C$, 'getMoleculeRemovedUnrelatedAtoms$',  function () {
var ff=C$.finalizeMolecule$com_actelion_research_chem_Molecule3D(this.molecule3D);
var hsIndexUnique=Clazz.new_($I$(2,1));
for (var i=0; i < this.getNumPPNodes$(); i++) {
var node=this.getNode$I(i);
var liOriginalIndex=node.getListIndexOriginalAtoms$();
hsIndexUnique.addAll$java_util_Collection(liOriginalIndex);
}
var liInd=Clazz.new_($I$(1,1).c$$java_util_Collection,[hsIndexUnique]);
var hsIndexOnPath=Clazz.new_($I$(2,1));
for (var i=0; i < liInd.size$(); i++) {
for (var j=i + 1; j < liInd.size$(); j++) {
var arrIndAtoms=$I$(13,"getAtomsOnPath$com_actelion_research_chem_Molecule3D$I$I",[ff, (liInd.get$I(i)).$c(), (liInd.get$I(j)).$c()]);
for (var k=0; k < arrIndAtoms.length; k++) {
hsIndexOnPath.add$O(Integer.valueOf$I(arrIndAtoms[k]));
}
}
}
hsIndexUnique.addAll$java_util_Collection(hsIndexOnPath);
for (var i=ff.getAllAtoms$() - 1; i >= 0; i--) {
if (!hsIndexUnique.contains$O(Integer.valueOf$I(i))) {
ff.deleteAtom$I(i);
}}
return ff;
});

Clazz.newMeth(C$, 'hashCode$',  function () {
var s=this.toString();
s=s.replace$CharSequence$CharSequence(" ", "");
return s.hashCode$();
});

Clazz.newMeth(C$, 'toStringInevitable$',  function () {
var sb=Clazz.new_($I$(14,1));
sb.append$S("Index inevitable ");
for (var index, $index = this.hsIndexMandatoryPPPoints.iterator$(); $index.hasNext$()&&((index=($index.next$()).intValue$()),1);) {
sb.append$S(index + " ");
}
sb.append$S("\n");
sb.append$S("Num inevitable " + this.hsIndexMandatoryPPPoints.size$());
return sb.toString();
});

Clazz.newMeth(C$, 'toString',  function () {
if (!this.finalized) this.realize$();
var b=Clazz.new_($I$(15,1));
b.append$S("[");
for (var i=0; i < this.getNumPPNodes$(); i++) {
b.append$S(this.getNode$I(i).toString());
if (i < this.getNumPPNodes$() - 1) {
b.append$S(" ");
} else {
b.append$S("]");
}}
for (var i=0; i < this.getNumPPNodes$(); i++) {
for (var j=i + 1; j < this.getNumPPNodes$(); j++) {
var arrHist=this.getDistHist$I$I(i, j);
if (arrHist != null ) b.append$S("[" + $I$(11).toString$BA(arrHist) + "]" );
}
}
return b.toString();
});

Clazz.newMeth(C$, 'toStringNodesText$',  function () {
if (!this.finalized) this.realize$();
var b=Clazz.new_($I$(15,1));
b.append$S("[");
for (var i=0; i < this.getNumPPNodes$(); i++) {
var ppNodeViz=this.getNode$I(i);
b.append$S(ppNodeViz.toString());
if (i < this.getNumPPNodes$() - 1) {
b.append$S(" ");
} else {
b.append$S("]");
}}
return b.toString();
});

Clazz.newMeth(C$, 'toStringPPNodesText$',  function () {
if (!this.finalized) this.realize$();
var b=Clazz.new_($I$(15,1));
b.append$S("[");
for (var i=0; i < this.getNumPPNodes$(); i++) {
var ppNodeViz=this.getNode$I(i);
b.append$S(ppNodeViz.toStringPPNodeText$());
if (i < this.getNumPPNodes$() - 1) {
b.append$S(" ");
} else {
b.append$S("]");
}}
return b.toString();
});

Clazz.newMeth(C$, 'toStringPPNodesElusive$',  function () {
if (!this.finalized) this.realize$();
var b=Clazz.new_($I$(15,1));
b.append$S("[");
for (var i=0; i < this.getNumPPNodes$(); i++) {
var ppNodeViz=this.getNode$I(i);
b.append$S(ppNodeViz.toStringElusive$());
if (i < this.getNumPPNodes$() - 1) {
b.append$S(" ");
} else {
b.append$S("]");
}}
return b.toString();
});

Clazz.newMeth(C$, 'toStringShort$',  function () {
if (!this.finalized) this.realize$();
var b=Clazz.new_($I$(15,1));
b.append$S("[");
for (var i=0; i < this.getNumPPNodes$(); i++) {
b.append$S(this.getNode$I(i).toStringShort$());
if (i < this.getNumPPNodes$() - 1) {
b.append$S(" ");
} else {
b.append$S("]");
}}
for (var i=0; i < this.getNumPPNodes$(); i++) {
for (var j=i + 1; j < this.getNumPPNodes$(); j++) {
var arrHist=this.getDistHist$I$I(i, j);
if (arrHist != null ) b.append$S("[" + $I$(11).toString$BA(arrHist) + "]" );
}
}
return b.toString();
});

Clazz.newMeth(C$, 'toStringShortWithWeights$',  function () {
if (!this.finalized) this.realize$();
var b=Clazz.new_($I$(15,1));
b.append$S("[");
for (var i=0; i < this.getNumPPNodes$(); i++) {
b.append$S($I$(16,"format1$Double",[Double.valueOf$D(this.arrWeight[i])]));
b.append$S(this.getNode$I(i).toStringShort$());
if (i < this.getNumPPNodes$() - 1) {
b.append$S(" ");
} else {
b.append$S("]");
}}
for (var i=0; i < this.getNumPPNodes$(); i++) {
for (var j=i + 1; j < this.getNumPPNodes$(); j++) {
var arrHist=this.getDistHist$I$I(i, j);
if (arrHist != null ) b.append$S("[" + $I$(11).toString$BA(arrHist) + "]" );
}
}
return b.toString();
});

Clazz.newMeth(C$, 'equals$O',  function (o) {
var bEQ=true;
var mdhv=null;
try {
mdhv=o;
} catch (e) {
if (Clazz.exceptionOf(e,"RuntimeException")){
return false;
} else {
throw e;
}
}
if (this.getNumPPNodes$() != mdhv.getNumPPNodes$()) return false;
for (var i=0; i < this.getNumPPNodes$(); i++) {
var n1=this.getNode$I(i);
var n2=mdhv.getNode$I(i);
if (!n1.equals$O(n2)) {
bEQ=false;
break;
}}
for (var i=0; i < this.getNumPPNodes$(); i++) {
for (var j=i + 1; j < this.getNumPPNodes$(); j++) {
var a1=this.getDistHist$I$I(i, j);
var a2=mdhv.getDistHist$I$I(i, j);
for (var k=0; k < a2.length; k++) {
if (a1[k] != a2[k]) {
bEQ=false;
break;
}}
}
}
return bEQ;
});

Clazz.newMeth(C$, 'setDistanceTables$java_util_List',  function (liDistanceTable) {
this.liDistanceTable=Clazz.new_($I$(1,1));
for (var ds, $ds = liDistanceTable.iterator$(); $ds.hasNext$()&&((ds=($ds.next$())),1);) {
var arrDT=Clazz.array(Float.TYPE, [ds.length, ds.length]);
for (var i=0; i < ds.length; i++) {
for (var j=0; j < ds.length; j++) {
arrDT[i][j]=ds[i][j];
}
}
this.liDistanceTable.add$O(arrDT);
}
});

Clazz.newMeth(C$, 'getDistanceTables$',  function () {
return this.liDistanceTable;
});

Clazz.newMeth(C$, 'formatDescription$S',  function (s) {
var st=Clazz.new_($I$(17,1).c$$S$S,[s, ","]);
var set=Clazz.new_($I$(2,1));
while (st.hasMoreTokens$()){
var tok=st.nextToken$().trim$();
if (!set.contains$O(tok)) {
set.add$O(tok);
}}
var li=Clazz.new_($I$(1,1).c$$java_util_Collection,[set]);
$I$(8).sort$java_util_List(li);
var sb=Clazz.new_($I$(14,1));
for (var i=0; i < li.size$(); i++) {
if (i > 0 && i < li.size$() - 1 ) {
sb.append$S(",");
}sb.append$S(li.get$I(i));
}
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'merge$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz$com_actelion_research_chem_descriptor_flexophore_MolDistHist',  function (mdhviz, mdh) {
if (mdh.getNumPPNodes$() != mdhviz.getNumPPNodes$()) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Size differs."]);
}for (var i=0; i < mdh.getNumPPNodes$(); i++) {
if (!mdh.getNode$I(i).equalAtoms$com_actelion_research_chem_descriptor_flexophore_PPNode(mdhviz.getNode$I(i))) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Node " + i + " differs. " + mdh.getNode$I(i) + "<>" + mdhviz.getNode$I(i) + " " + mdh.getNode$I(i).getAtomicNo$I(i) + " " + mdhviz.getNode$I(i).getAtomicNo$I(i) ]);
}}
for (var i=0; i < mdh.getNumPPNodes$(); i++) {
for (var j=1 + i; j < mdh.getNumPPNodes$(); j++) {
mdhviz.setDistHist$I$I$BA(i, j, mdh.getDistHist$I$I(i, j));
}
}
}, 1);

Clazz.newMeth(C$, 'summarizeAlkaneCluster$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz$I',  function (mdh, maxDistance) {
var liCluster=mdh.getClusterCenter$I(maxDistance);
var liIndexNode=Clazz.new_($I$(1,1));
for (var i=0; i < mdh.getNumPPNodes$(); i++) {
liIndexNode.add$O(Integer.valueOf$I(i));
}
for (var i=0; i < liCluster.size$(); i++) {
var cluster=liCluster.get$I(i);
var nodeCenter=mdh.getNode$I(cluster.getIndexCenter$());
var liIndexClusterNode=cluster.getClusterMember$();
for (var j=liIndexClusterNode.size$() - 1; j >= 0; j--) {
var node=mdh.getNode$I((liIndexClusterNode.get$I(j)).$c());
if (node.isCarbonExclusiveNode$()) {
liIndexNode.remove$O(liIndexClusterNode.get$I(j));
var sizeNode=node.getInteractionTypeCount$();
var added=false;
for (var k=0; k < sizeNode; k++) {
var interactionIdNode=node.getInteractionType$I(k);
if (!nodeCenter.containsInteractionID$I(interactionIdNode)) {
nodeCenter.add$I(interactionIdNode);
added=true;
}}
if (added) nodeCenter.realize$();
}}
}
var mdhSummary=Clazz.new_(C$.c$$I$com_actelion_research_chem_Molecule3D,[liIndexNode.size$(), mdh.getMolecule$()]);
for (var i=0; i < liIndexNode.size$(); i++) {
mdhSummary.addNode$com_actelion_research_chem_descriptor_flexophore_PPNodeViz(mdh.getNode$I((liIndexNode.get$I(i)).$c()));
}
for (var i=0; i < liIndexNode.size$(); i++) {
for (var j=i + 1; j < liIndexNode.size$(); j++) {
mdhSummary.setDistHist$I$I$BA(i, j, mdh.getDistHist$I$I((liIndexNode.get$I(i)).$c(), (liIndexNode.get$I(j)).$c()));
}
}
if (mdh.getDistanceTables$() != null ) {
var liDistanceArrayNodes=mdh.getDistanceTables$();
var liDistanceArrayNodesSummary=Clazz.new_($I$(1,1));
for (var arrDistanceNodes, $arrDistanceNodes = liDistanceArrayNodes.iterator$(); $arrDistanceNodes.hasNext$()&&((arrDistanceNodes=($arrDistanceNodes.next$())),1);) {
var arrDistanceNodesSummary=Clazz.array(Float.TYPE, [liIndexNode.size$(), liIndexNode.size$()]);
for (var i=0; i < liIndexNode.size$(); i++) {
for (var j=0; j < liIndexNode.size$(); j++) {
arrDistanceNodesSummary[i][j]=arrDistanceNodes[(liIndexNode.get$I(i)).$c()][(liIndexNode.get$I(j)).$c()];
}
}
liDistanceArrayNodesSummary.add$O(arrDistanceNodesSummary);
}
mdhSummary.liDistanceTable=liDistanceArrayNodesSummary;
}mdhSummary.realize$();
return mdhSummary;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.COLORS=Clazz.array(String, -1, ["aquamarine", "blue", "violet", "cyan", "green", "lavender", "lime", "limegreen", "linen", "magenta", "maroon", "olive", "purple", "red", "tan", "turquoise", "yellow"]);
};
var $b$ = new Int8Array(1);
;
(function(){/*l*/var C$=Clazz.newClass(P$, "MolDistHistViz$1CmpHists", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'java.util.Comparator', 2);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, ['compare$BA$BA','compare$O$O'],  function (arr1, arr2) {
var cmp=0;
for (var i=0; i < arr1.length; i++) {
if (arr1[i] > arr2[i]) {
cmp=1;
break;
} else if (arr1[i] < arr2[i]) {
cmp=-1;
break;
}}
return cmp;
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:51 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
