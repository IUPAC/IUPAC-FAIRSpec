(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),p$1={},I$=[[0,'java.util.TreeMap','java.io.BufferedReader','java.io.InputStreamReader','java.nio.charset.StandardCharsets','com.actelion.research.chem.io.DWARFileParser','com.actelion.research.chem.io.SDFileParser','java.util.TreeSet','java.io.BufferedWriter','java.io.OutputStreamWriter','java.io.FileOutputStream','com.actelion.research.chem.AtomTypeCalculator','com.actelion.research.chem.SimpleCanonizer']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AtomTypeList");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['mAtomTypeMode','mMaxAtoms','mMinAtoms'],'O',['mCountList','java.util.TreeMap','+mProbabilityList','mRingSizeAdjust','float[]']]]

Clazz.newMeth(C$, 'c$$I',  function (mode) {
;C$.$init$.apply(this);
this.mRingSizeAdjust=Clazz.array(Float.TYPE, [8]);
this.mCountList=Clazz.new_($I$(1,1));
this.mAtomTypeMode=mode;
this.mMinAtoms=10;
this.mMaxAtoms=50;
}, 1);

Clazz.newMeth(C$, 'c$$S$I',  function (filename, mode) {
C$.c$$I.apply(this, [mode]);
if (filename.endsWith$S(".typ")) {
var theReader=Clazz.new_([Clazz.new_([this.getClass$().getResourceAsStream$S(filename), $I$(4).UTF_8],$I$(3,1).c$$java_io_InputStream$java_nio_charset_Charset)],$I$(2,1).c$$java_io_Reader);
var version=theReader.readLine$();
if (!"AtomTypeList v1.1".equals$O(version)) {
throw Clazz.new_(Clazz.load('Exception').c$$S,["Outdated atom type list file."]);
}this.mAtomTypeMode=Integer.parseInt$S(theReader.readLine$());
if (this.mAtomTypeMode != mode) {
throw Clazz.new_(Clazz.load('Exception').c$$S,["Incompatible atom type mode."]);
}for (var i=0; i < 8; i++) this.mRingSizeAdjust[i]=Float.parseFloat$S(theReader.readLine$());

while (true){
var theLine=theReader.readLine$();
if (theLine == null ) break;
var tab=theLine.indexOf$I("\t");
this.mCountList.put$O$O( new Long(Long.parseLong$S(theLine.substring$I$I(0, tab))),  new Integer(Integer.parseInt$S(theLine.substring$I(tab + 1))));
}
theReader.close$();
return;
}var parser=filename.endsWith$S(".dwar") ? Clazz.new_($I$(5,1).c$$S,[filename]) : filename.endsWith$S(".sdf") ? Clazz.new_($I$(6,1).c$$S,[filename]) : null;
if (parser != null ) {
var moleculeCache=Clazz.new_($I$(7,1));
try {
while (parser.next$())this.processMolecule$com_actelion_research_chem_StereoMolecule$java_util_TreeSet(parser.getMolecule$(), moleculeCache);

} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
this.finalizeProcessMolecules$();
}}, 1);

Clazz.newMeth(C$, 'finalizeProcessMolecules$',  function () {
var ringSum=0.0;
for (var i=0; i < 8; i++) ringSum+=this.mRingSizeAdjust[i];

if (ringSum != 0 ) for (var i=0; i < 8; i++) this.mRingSizeAdjust[i]/=ringSum;

});

Clazz.newMeth(C$, 'calculateProbabilities$',  function () {
if (this.mProbabilityList == null ) {
var averageCount=0;
for (var count, $count = this.mCountList.values$().iterator$(); $count.hasNext$()&&((count=($count.next$())),1);) averageCount=(averageCount+((count).valueOf())|0);

averageCount=(averageCount/(this.mCountList.size$())|0);
this.mProbabilityList=Clazz.new_($I$(1,1));
for (var type, $type = this.mCountList.keySet$().iterator$(); $type.hasNext$()&&((type=($type.next$())),1);) this.mProbabilityList.put$O$O(type, Double.valueOf$D((this.mCountList.get$O(type)).valueOf() / averageCount));

}});

Clazz.newMeth(C$, 'writeTypeFile$S',  function (filename) {
try {
var writer=Clazz.new_([Clazz.new_([Clazz.new_($I$(10,1).c$$S,[filename]), $I$(4).UTF_8],$I$(9,1).c$$java_io_OutputStream$java_nio_charset_Charset)],$I$(8,1).c$$java_io_Writer);
writer.write$S("AtomTypeList v1.1");
writer.newLine$();
writer.write$S("" + this.mAtomTypeMode);
writer.newLine$();
for (var i=0; i < 8; i++) {
writer.write$S("" + new Float(this.mRingSizeAdjust[i]).toString());
writer.newLine$();
}
for (var type, $type = this.mCountList.keySet$().iterator$(); $type.hasNext$()&&((type=($type.next$())),1);) {
writer.write$S(type.toString() + "\t" + this.mCountList.get$O(type).toString() );
writer.newLine$();
}
writer.close$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'writeTextFile$S$I',  function (textfilename, mode) {
try {
var writer=Clazz.new_([Clazz.new_([Clazz.new_($I$(10,1).c$$S,[textfilename]), $I$(4).UTF_8],$I$(9,1).c$$java_io_OutputStream$java_nio_charset_Charset)],$I$(8,1).c$$java_io_Writer);
writer.write$S("AtomType\tFrequency\t" + $I$(11).getHeaderString$I(mode));
writer.newLine$();
for (var type, $type = this.mCountList.keySet$().iterator$(); $type.hasNext$()&&((type=($type.next$())),1);) {
writer.write$S(Long.toString$J((type).valueOf()) + "\t" + this.mCountList.get$O(type).toString() + "\t" + $I$(11,"getTypeString$J$I",[(type).valueOf(), mode]) );
writer.newLine$();
}
writer.close$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'getAtomTypeList$',  function () {
return this.mCountList;
});

Clazz.newMeth(C$, 'processMolecule$com_actelion_research_chem_StereoMolecule$java_util_TreeSet',  function (mol, moleculeCache) {
if (mol != null ) {
mol.stripIsotopInfo$();
mol.stripSmallFragments$();
mol.stripStereoInformation$();
mol.ensureHelperArrays$I(1);
var containsMetal=false;
for (var atom=0; atom < mol.getAtoms$(); atom++) {
if (mol.isMetalAtom$I(atom)) {
containsMetal=true;
break;
}}
if (!containsMetal && mol.getAtoms$() >= this.mMinAtoms  && mol.getAtoms$() <= this.mMaxAtoms ) {
var idcode=Clazz.new_($I$(12,1).c$$com_actelion_research_chem_ExtendedMolecule,[mol]).getIDCode$();
if (!moleculeCache.contains$O(idcode)) {
moleculeCache.add$O(idcode);
for (var atom=0; atom < mol.getAtoms$(); atom++) try {
p$1.addAtomType$Long.apply(this, [Long.valueOf$J($I$(11).getAtomType$com_actelion_research_chem_StereoMolecule$I$I(mol, atom, this.mAtomTypeMode))]);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}

var ringSet=mol.getRingSet$();
for (var ring=0; ring < ringSet.getSize$(); ring++) ++this.mRingSizeAdjust[ringSet.getRingSize$I(ring)];

}}}});

Clazz.newMeth(C$, 'addAtomType$Long',  function (atomType) {
var count=this.mCountList.get$O(atomType);
if (count == null ) this.mCountList.put$O$O(atomType, Integer.valueOf$I(1));
 else this.mCountList.put$O$O(atomType, Integer.valueOf$I(((count).$c() + 1)|0));
}, p$1);

Clazz.newMeth(C$, 'getCountFromType$J',  function (type) {
return this.mCountList.get$O( new Long(type)).intValue$();
});

Clazz.newMeth(C$, 'getProbabilityFromType$J',  function (type) {
return (this.mProbabilityList.get$O(Long.valueOf$J(type))).valueOf();
});

Clazz.newMeth(C$, 'getRingSizeAdjust$I',  function (ringSize) {
return this.mRingSizeAdjust[ringSize];
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:46 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
