(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "SlidingWindowDistHist");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['lenFilHalf'],'O',['arrFilter','double[]','arrTmp','byte[]']]]

Clazz.newMeth(C$, 'c$$DA',  function (arrFilter) {
;C$.$init$.apply(this);
this.arrFilter=arrFilter;
if (arrFilter.length % 2 == 0) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Odd number of filter values needed!"]);
}this.lenFilHalf=(arrFilter.length/2|0);
var n=64;
var maxNumDistHist=(((n * n) - n)/2|0);
this.arrTmp=Clazz.array(Byte.TYPE, [80 * maxNumDistHist]);
}, 1);

Clazz.newMeth(C$, 'apply$com_actelion_research_chem_descriptor_flexophore_DistHist',  function (distHist) {
var nNodes=distHist.getNumPPNodes$();
var n=80;
var end=n - this.lenFilHalf;
for (var i=0; i < nNodes; i++) {
for (var j=i + 1; j < nNodes; j++) {
var indexStart=distHist.getIndexPosStartForDistHist$I$I(i, j);
for (var k=this.lenFilHalf; k < end; k++) {
var v=0;
for (var l=0; l < this.arrFilter.length; l++) {
var ind=k - this.lenFilHalf + l + indexStart;
v+=distHist.getValueAtAbsolutePosition$I(ind) * this.arrFilter[l];
}
this.arrTmp[indexStart + k]=((v + 0.5)|0);
}
}
}
System.arraycopy$O$I$O$I$I(this.arrTmp, 0, distHist.arrDistHists, 0, distHist.arrDistHists.length);
});

Clazz.newMeth(C$, 'getBlurred$BA',  function (hist) {
var histBlurred=Clazz.array(Byte.TYPE, [80]);
var n=80;
var end=n - this.lenFilHalf;
for (var k=this.lenFilHalf; k < end; k++) {
var v=0;
for (var l=0; l < this.arrFilter.length; l++) {
var ind=k - this.lenFilHalf + l;
v+=hist[ind] * this.arrFilter[l];
}
histBlurred[k]=((v + 0.5)|0);
}
return histBlurred;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:52 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
