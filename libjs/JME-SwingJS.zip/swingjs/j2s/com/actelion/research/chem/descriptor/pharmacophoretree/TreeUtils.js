(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.pharmacophoretree"),I$=[[0,'java.util.Arrays','java.util.HashMap','java.util.ArrayList']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "TreeUtils");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'binaryInsert$DA$IAA$D$IA',  function (arr, indexPairs, val, indexPair) {
var n=arr.length;
var index=$I$(1).binarySearch$DA$D(arr, val);
if (index < 0) index=-index - 1;
 else index=index + 1;
if (index < n) {
var currentVal=arr[index];
var currentIndexPair=indexPairs[index];
arr[index]=val;
indexPairs[index]=indexPair;
for (var i=index + 1; i < n; i++) {
var previousVal=arr[i];
var previousIndexPair=indexPairs[i];
arr[i]=currentVal;
indexPairs[i]=currentIndexPair;
currentVal=previousVal;
currentIndexPair=previousIndexPair;
}
}}, 1);

Clazz.newMeth(C$, 'retrieveHighestValuesFrom2DArray$DAA$DA$IAA',  function (arr, val, indeces) {
$I$(1).fill$DA$D(val, 1);
for (var indecesRow, $indecesRow = 0, $$indecesRow = indeces; $indecesRow<$$indecesRow.length&&((indecesRow=($$indecesRow[$indecesRow])),1);$indecesRow++) $I$(1).fill$IA$I(indecesRow, -1);

for (var i=0; i < arr.length; i++) {
for (var j=0; j < arr[0].length; j++) {
C$.binaryInsert$DA$IAA$D$IA(val, indeces, -arr[i][j], Clazz.array(Integer.TYPE, -1, [i, j]));
}
}
}, 1);

Clazz.newMeth(C$, 'getAdjacencyList$I$java_util_List',  function (n, edges) {
var adjacencyList=Clazz.new_($I$(2,1));
for (var i=0; i < n; i++) adjacencyList.putIfAbsent$O$O(Integer.valueOf$I(i), Clazz.new_($I$(3,1)));

for (var edge, $edge = edges.iterator$(); $edge.hasNext$()&&((edge=($edge.next$())),1);) {
var n1=edge[0];
var n2=edge[1];
adjacencyList.get$O(Integer.valueOf$I(n1)).add$O(Integer.valueOf$I(n2));
adjacencyList.get$O(Integer.valueOf$I(n2)).add$O(Integer.valueOf$I(n1));
}
return adjacencyList;
}, 1);

Clazz.newMeth(C$, 'getAdjacencyListWithBondOrders$I$java_util_List',  function (n, edges) {
var adjacencyList=Clazz.new_($I$(2,1));
for (var i=0; i < n; i++) adjacencyList.putIfAbsent$O$O(Integer.valueOf$I(i), Clazz.new_($I$(2,1)));

for (var edge, $edge = edges.iterator$(); $edge.hasNext$()&&((edge=($edge.next$())),1);) {
var n1=edge.edge[0];
var n2=edge.edge[1];
adjacencyList.get$O(Integer.valueOf$I(n1)).put$O$O(Integer.valueOf$I(n2), Integer.valueOf$I(edge.order));
adjacencyList.get$O(Integer.valueOf$I(n2)).put$O$O(Integer.valueOf$I(n1), Integer.valueOf$I(edge.order));
}
return adjacencyList;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:05 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
