(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),p$1={},I$=[[0,'com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.SSSearcherWithIndex','com.actelion.research.chem.IDCodeParser','java.util.ArrayList','StringBuilder']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "NastyFunctionDetector");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['Z',['sInitialized'],'O',['cNastyFunctionsUnknown','String[]','sNastyFunction','String[][]','sFragmentList','com.actelion.research.chem.StereoMolecule[]','sIndexList','long[][]']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
{
if (!C$.sInitialized) {
try {
C$.sFragmentList=Clazz.array($I$(1), [C$.sNastyFunction.length]);
C$.sIndexList=Clazz.array(Long.TYPE, [C$.sNastyFunction.length, null]);
var sss=Clazz.new_($I$(2,1).c$$I,[1]);
for (var i=0; i < C$.sNastyFunction.length; i++) {
C$.sFragmentList[i]=Clazz.new_($I$(3,1).c$$Z,[false]).getCompactMolecule$S(C$.sNastyFunction[i][0]);
C$.sIndexList[i]=sss.createLongIndex$com_actelion_research_chem_StereoMolecule(C$.sFragmentList[i]);
}
C$.sInitialized=true;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.out.println$S("Unable to initialize NastyFunctionDetector");
} else {
throw e;
}
}
}}}, 1);

Clazz.newMeth(C$, 'getNastyFunctionList$com_actelion_research_chem_StereoMolecule$JA',  function (mol, index) {
if (!C$.sInitialized) return C$.cNastyFunctionsUnknown;
var nastyFunctionList=Clazz.new_($I$(4,1));
var sss=Clazz.new_($I$(2,1).c$$I,[1]);
sss.setMolecule$com_actelion_research_chem_StereoMolecule$JA(mol, index);
for (var i=0; i < C$.sNastyFunction.length; i++) {
sss.setFragment$com_actelion_research_chem_StereoMolecule$JA(C$.sFragmentList[i], C$.sIndexList[i]);
if (sss.isFragmentInMolecule$()) nastyFunctionList.add$O(C$.sNastyFunction[i][1]);
}
p$1.addPolyHaloAromaticRings$com_actelion_research_chem_StereoMolecule$java_util_ArrayList.apply(this, [mol, nastyFunctionList]);
return nastyFunctionList.toArray$OA(Clazz.array(String, [0]));
});

Clazz.newMeth(C$, 'getNastyFunctionString$com_actelion_research_chem_StereoMolecule$JA',  function (mol, index) {
var nfl=this.getNastyFunctionList$com_actelion_research_chem_StereoMolecule$JA(mol, index);
if (nfl == null ) return "initialization error";
if (nfl.length == 0) return "";
var sb=Clazz.new_($I$(5,1).c$$S,[nfl[0]]);
for (var i=1; i < nfl.length; i++) sb.append$S("; " + nfl[i]);

return sb.toString();
});

Clazz.newMeth(C$, 'addPolyHaloAromaticRings$com_actelion_research_chem_StereoMolecule$java_util_ArrayList',  function (mol, nastyFunctionList) {
var ringSet=mol.getRingSet$();
for (var ring=0; ring < ringSet.getSize$(); ring++) {
if (ringSet.isAromatic$I(ring)) {
var halogenes=0;
var ringAtom=ringSet.getRingAtoms$I(ring);
for (var i=0; i < ringAtom.length; i++) {
for (var j=0; j < mol.getConnAtoms$I(ringAtom[i]); j++) {
var connAtom=mol.getConnAtom$I$I(ringAtom[i], j);
if (!mol.isRingAtom$I(connAtom) && (mol.getAtomicNo$I(connAtom) == 9 || mol.getAtomicNo$I(connAtom) == 17  || mol.getAtomicNo$I(connAtom) == 35  || mol.getAtomicNo$I(connAtom) == 53 ) ) ++halogenes;
}
}
if (halogenes > 2) {
nastyFunctionList.add$O("polyhalo aromatic ring");
}}}
}, p$1);

C$.$static$=function(){C$.$static$=0;
C$.cNastyFunctionsUnknown=null;
C$.sNastyFunction=Clazz.array(String, -2, [Clazz.array(String, -1, ["gGP@LdbKT`]RMdmGJFCPpWN@PBJpd@", "polar activated DB"]), Clazz.array(String, -1, ["gGP@DjVePNlFJXhypB@Q\\xA@HjlPd@", "twice activated DB"]), Clazz.array(String, -1, ["eM@HvCjFtQ[N@PBDiBHqJrlD@", "acyl-halogenide type"]), Clazz.array(String, -1, ["eFBJHcAbc\\@axABIVVQFIV@", "Cl,Br,I on N,O,P,S,Se,I"]), Clazz.array(String, -1, ["gC`HADIKRAuHubL", "allyl/benzyl chloride"]), Clazz.array(String, -1, ["eM@HzCBKUFTqJp", "prim. alkyl-bromide/iodide"]), Clazz.array(String, -1, ["gC`@H}PFrbcLfIV@", "sec./tert. alkyl-bromide/iodide"]), Clazz.array(String, -1, ["gC`hH`DIVtAuL`", "alkyl sulfonate/sulfate type"]), Clazz.array(String, -1, ["gJQ`@bdjt`P", "anhydride"]), Clazz.array(String, -1, ["gJXA@IczhB", "quart. ammonium"]), Clazz.array(String, -1, ["gChA@Icm@P", "tert. immonium"]), Clazz.array(String, -1, ["fHT`P", "carbenium"]), Clazz.array(String, -1, ["gCh`hEIWILtAuM@", "aromatic nitro"]), Clazz.array(String, -1, ["gCd@Adeb@p`}M@", "1,2-diamino-aryl"]), Clazz.array(String, -1, ["gJT@@TeXHCA@`", "1,3-diamino-aryl"]), Clazz.array(String, -1, ["gGT@ATeV@`LDJ", "1,4-diamino-aryl"]), Clazz.array(String, -1, ["gCd@ADiZDEsA@", "azo"]), Clazz.array(String, -1, ["gJU@h`NdiLsPdh", "azoxy"]), Clazz.array(String, -1, ["eMPRIncTH", "diazo"]), Clazz.array(String, -1, ["eMPRI^cxH", "diazo"]), Clazz.array(String, -1, ["gJT@@Te^lB", "1,1-dinitrile"]), Clazz.array(String, -1, ["eMHAIhLDhsW@H^@Pb@", "formaldehyde aduct"]), Clazz.array(String, -1, ["eO@HyjCYJLipB@", "oxiran/aziridine"]), Clazz.array(String, -1, ["eMPBchLDkR", "hydrazine"]), Clazz.array(String, -1, ["eM`AITLYs`D@`", "isocyanate type"]), Clazz.array(String, -1, ["fH@MjM~@p\\@aHZA`x^@QDYAQbU`", "unwanted atom"]), Clazz.array(String, -1, ["fHw`dB", "phosphonium"]), Clazz.array(String, -1, ["gCi@hAteIi`H", "nitrone"]), Clazz.array(String, -1, ["eMhHRVCZP", "nitroso"]), Clazz.array(String, -1, ["gCa`@lduPD", "orthoester/acid"]), Clazz.array(String, -1, ["eFDBcA@", "peroxo"]), Clazz.array(String, -1, ["gGY@HDiViPMdmEGN@PBKg@HA@", "N-acyloxy-amide"]), Clazz.array(String, -1, ["gC`@H{PFJVQFIV[HcDk@", "1,1-dihalo-alkene"]), Clazz.array(String, -1, ["gC`@DiZDEbedQbUfrHqJp", "1,2-dihalo-alkene"]), Clazz.array(String, -1, ["fIRPNj@", "pyrylium"]), Clazz.array(String, -1, ["gCaHHGAIZPMXb@", "silylenol-ether"]), Clazz.array(String, -1, ["gCd@ADie@y``", "dimethylene-hydrazine"]), Clazz.array(String, -1, ["eMPARZCJg}T@", "methanediamine"]), Clazz.array(String, -1, ["daFD`Bs`BLdTTIUSRpA@", "limit! methylene-thiazolidine-2,4-dione"]), Clazz.array(String, -1, ["gOtHLPDISOkSM@XP`", "limit! thiazol-2-ylamine"]), Clazz.array(String, -1, ["gGU@DPdsmRAeDx", "acyl-hydrazone"]), Clazz.array(String, -1, ["gCh@@eKP`lIIROFIFC`@", "imine/hydrazone of aldehyde"]), Clazz.array(String, -1, ["deUD@BxIrJJKPlKTmL@ZqP`", "2,3-diamino-quinone"]), Clazz.array(String, -1, ["difL@DBarJIPhfZif@LHh", "limit! 4-acyl-3-azoline-2-one-3-ol"]), Clazz.array(String, -1, ["gGT`EPTfyi`H", "limit! oxal-diamide"]), Clazz.array(String, -1, ["daED@DpFRYUJfjV@H", "limit! 5-methylene-imidazolidine-2,4-dione"]), Clazz.array(String, -1, ["gJQ@@dls@XpyDXeX", "2-halo-enone"]), Clazz.array(String, -1, ["gJQ@@djsBJqarHqJp", "3-halo-enone"]), Clazz.array(String, -1, ["gCd`i`iJyIf`H", "N-nitro"]), Clazz.array(String, -1, ["gChHD@aIf`LYdXN@", "thio-amide/urea"])]);
};
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:00 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
