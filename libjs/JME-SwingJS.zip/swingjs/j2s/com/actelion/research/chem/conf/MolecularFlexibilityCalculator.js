(function(){var P$=Clazz.newPackage("com.actelion.research.chem.conf"),p$1={},I$=[[0,'com.actelion.research.chem.conf.TorsionDB','com.actelion.research.chem.conf.TorsionRelevanceHelper','com.actelion.research.chem.conf.TorsionPrediction']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MolecularFlexibilityCalculator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
$I$(1).initialize$I(1);
}, 1);

Clazz.newMeth(C$, 'calculateMolecularFlexibility$com_actelion_research_chem_StereoMolecule',  function (mol) {
mol.ensureHelperArrays$I(7);
if (mol.getAllAtoms$() == 0) return 0.0;
var isRotatableBond=Clazz.array(Boolean.TYPE, [mol.getBonds$()]);
var rotatableBondCount=$I$(1).findRotatableBonds$com_actelion_research_chem_StereoMolecule$Z$ZA(mol, false, isRotatableBond);
if (rotatableBondCount == 0) return 0.0;
var bondFlexibility=this.calculateBondFlexibilities$com_actelion_research_chem_StereoMolecule$ZA(mol, isRotatableBond);
var bondImportance=$I$(2).getRelevance$com_actelion_research_chem_StereoMolecule$ZA(mol, null);
return p$1.calculateMoleculeFlexibility$FA$FA.apply(this, [bondFlexibility, bondImportance]);
});

Clazz.newMeth(C$, 'calculateBondFlexibilities$com_actelion_research_chem_StereoMolecule$ZA',  function (mol, isRotatableBond) {
var bondFlexibility=Clazz.array(Float.TYPE, [mol.getBonds$()]);
for (var bond=0; bond < mol.getBonds$(); bond++) {
if (isRotatableBond[bond]) {
var torsionAtom=Clazz.array(Integer.TYPE, [4]);
var torsionID=$I$(1).getTorsionID$com_actelion_research_chem_StereoMolecule$I$IA$com_actelion_research_chem_conf_TorsionDetail(mol, bond, torsionAtom, null);
var torsion=$I$(1).getTorsions$S(torsionID);
var frequency=null;
var range=null;
if (torsion != null ) {
frequency=$I$(1).getTorsionFrequencies$S(torsionID);
range=$I$(1).getTorsionRanges$S(torsionID);
} else {
var prediction=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_StereoMolecule$IA,[mol, torsionAtom]);
torsion=prediction.getTorsions$();
frequency=prediction.getTorsionFrequencies$();
range=prediction.getTorsionRanges$();
}if (!mol.isAromaticBond$I(bond)) {
bondFlexibility[bond]=(torsion == null ) ? 1.0 : p$1.calculateBondFlexibility$HA$HA$HAA.apply(this, [torsion, frequency, range]);
if (mol.isRingBond$I(bond)) bondFlexibility[bond]*=0.5 * (1.0 - 3.0 / mol.getBondRingSize$I(bond));
}}}
return bondFlexibility;
});

Clazz.newMeth(C$, 'calculateBondFlexibility$HA$HA$HAA',  function (torsion, frequency, range) {
var count=torsion.length;
var maxFrequency=0.0;
var maxFrequencyIndex=-1;
var maxEmptySpace=-1.0;
var maxEmptySpaceIndex=-1;
for (var i=0; i < count; i++) {
if (maxFrequency < frequency[i] ) {
maxFrequency=frequency[i];
maxFrequencyIndex=i;
}var r=p$1.rightEmptySpace$I$I$HAA.apply(this, [i, count, range]);
if (maxEmptySpace < r ) {
maxEmptySpace=r;
maxEmptySpaceIndex=i;
}}
var emptyRangeSum=maxEmptySpace;
var factor=1.0;
var ti=maxEmptySpaceIndex;
while (p$1.right$I$I.apply(this, [ti, count]) != maxFrequencyIndex){
ti=p$1.right$I$I.apply(this, [ti, count]);
factor*=(1.0 - Math.pow(frequency[ti] / maxFrequency, 0.3));
emptyRangeSum+=factor * (p$1.rightEmptySpace$I$I$HAA.apply(this, [ti, count, range]) + range[ti][1] - range[ti][0]);
}
factor=1.0;
ti=maxEmptySpaceIndex;
while (ti != maxFrequencyIndex){
var oi=ti;
ti=p$1.left$I$I.apply(this, [ti, count]);
factor*=(1.0 - Math.sqrt(frequency[oi] / maxFrequency));
emptyRangeSum+=factor * (p$1.rightEmptySpace$I$I$HAA.apply(this, [ti, count, range]) + range[oi][1] - range[oi][0]);
}
return 0.5 + 0.5 * Math.cos(emptyRangeSum * 3.141592653589793 / 360);
}, p$1);

Clazz.newMeth(C$, 'left$I$I',  function (i, count) {
return (i == 0) ? count - 1 : i - 1;
}, p$1);

Clazz.newMeth(C$, 'right$I$I',  function (i, count) {
return (i == count - 1) ? 0 : i + 1;
}, p$1);

Clazz.newMeth(C$, 'rightEmptySpace$I$I$HAA',  function (i, count, range) {
return (i == count - 1) ? 360 + range[0][0] - range[i][1] : range[i + 1][0] - range[i][1];
}, p$1);

Clazz.newMeth(C$, 'calculateMoleculeFlexibility$FA$FA',  function (bondFlexibility, bondWeight) {
var CORRECTION_FACTOR=0.7;
var meanFlexibility=0.0;
var weightSum=0.0;
for (var i=0; i < bondFlexibility.length; i++) {
meanFlexibility+=bondWeight[i] * bondFlexibility[i];
weightSum+=bondWeight[i];
}
var rawFlexibility=(weightSum == 0.0 ) ? 0.0 : meanFlexibility / weightSum;
return (1.0 - Math.pow(1 - Math.pow(rawFlexibility, 0.7), 1.4285714528998554));
}, p$1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:02 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
