(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore"),I$=[[0,['com.actelion.research.chem.descriptor.flexophore.DistHistHelper','.RangeStatistics'],'com.actelion.research.util.datamodel.IntArray','com.actelion.research.calc.ArrayUtilsCalc']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DistHistHelper", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['RangeStatistics',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getSpread$BA',  function (a) {
var start=0;
for (var i=0; i < a.length; i++) {
if (a[i] > 0) {
start=i;
break;
}}
var end=0;
for (var i=a.length - 1; i >= 0; i--) {
if (a[i] > 0) {
end=i;
break;
}}
return end - start + 1;
}, 1);

Clazz.newMeth(C$, 'getMaxIndexNotZero$BA',  function (a) {
var end=0;
for (var i=a.length - 1; i >= 0; i--) {
if (a[i] > 0) {
end=i;
break;
}}
return end;
}, 1);

Clazz.newMeth(C$, 'getMedianBin$BA',  function (a) {
var medianBin=-1;
var sum=0;
for (var b, $b = 0, $$b = a; $b<$$b.length&&((b=($$b[$b])),1);$b++) {
sum+=b;
}
sum=(sum/(2)|0);
var s2=0;
for (var i=0; i < a.length; i++) {
s2+=a[i];
if (s2 >= sum) {
medianBin=i;
break;
}}
return medianBin;
}, 1);

Clazz.newMeth(C$, 'getRangeStatistics$com_actelion_research_chem_descriptor_flexophore_MolDistHist',  function (mdh) {
var rangeStatisticsTotal=Clazz.new_($I$(1,1));
var n=mdh.getNumPPNodes$();
var nn=(((n * n) - n)/2|0);
var iaMaxRange=Clazz.new_($I$(2,1).c$$I,[nn]);
var iaMedianRange=Clazz.new_($I$(2,1).c$$I,[nn]);
for (var i=0; i < n; i++) {
for (var j=i + 1; j < n; j++) {
var arr=mdh.getDistHist$I$I(i, j);
var indexMax=-1;
for (var k=arr.length - 1; k >= 0; k--) {
if (arr[k] > 0) {
indexMax=k;
break;
}}
iaMaxRange.add$I(indexMax);
var indexMin=-1;
for (var k=0; k < arr.length; k++) {
if (arr[k] > 0) {
indexMin=k;
break;
}}
var sum=0;
for (var k=indexMin; k < indexMax + 1; k++) {
sum+=arr[k];
}
var half=(sum/2|0);
sum=0;
var indexMedian1=-1;
for (var k=indexMin; k < indexMax + 1; k++) {
sum+=arr[k];
if (sum >= half) {
indexMedian1=k;
break;
}}
sum=0;
var indexMedian2=-1;
for (var k=indexMax; k >= indexMin; k--) {
sum+=arr[k];
if (sum >= half) {
indexMedian2=k;
break;
}}
var medianRange=(((indexMedian1 + indexMedian2) / 2.0 + 0.5)|0);
iaMedianRange.add$I(medianRange);
}
}
var mmi=$I$(3,"getMedian$IA",[iaMedianRange.get$()]);
rangeStatisticsTotal.maxRange=iaMaxRange.max$();
rangeStatisticsTotal.medianRange=mmi.median;
return rangeStatisticsTotal;
}, 1);

Clazz.newMeth(C$, 'count$BA',  function (a) {
var c=0;
for (var i=0; i < a.length; i++) {
c+=a[i];
}
return c;
}, 1);

Clazz.newMeth(C$, 'normalize$DA',  function (arrHistRaw) {
var countValuesInHistogram=0;
for (var i=0; i < arrHistRaw.length; i++) {
countValuesInHistogram=(countValuesInHistogram+(arrHistRaw[i])|0);
}
var arrHistPercent=Clazz.array(Byte.TYPE, [arrHistRaw.length]);
for (var i=0; i < arrHistRaw.length; i++) {
arrHistPercent[i]=((((arrHistRaw[i] / countValuesInHistogram) * 100.0) + 0.5)|0);
}
return arrHistPercent;
}, 1);

Clazz.newMeth(C$, 'normalize$BA',  function (arrHistRaw) {
var countValuesInHistogram=0;
for (var i=0; i < arrHistRaw.length; i++) {
countValuesInHistogram+=arrHistRaw[i];
}
var arrHistPercent=Clazz.array(Byte.TYPE, [arrHistRaw.length]);
for (var i=0; i < arrHistRaw.length; i++) {
var v=((arrHistRaw[i] / countValuesInHistogram) * 100.0) + 0.5;
arrHistPercent[i]=(v|0);
}
return arrHistPercent;
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.DistHistHelper, "RangeStatistics", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['maxRange','medianRange']]]

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:04 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
