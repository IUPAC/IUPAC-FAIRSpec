(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "CanonizerParity", null, null, 'Comparable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['atom','group','rank']]]

Clazz.newMeth(C$, 'c$$I$I$I$I',  function (atom, group, type, rank) {
;C$.$init$.apply(this);
this.atom=atom;
this.group=group + (type << 8);
this.rank=rank;
}, 1);

Clazz.newMeth(C$, ['compareTo$com_actelion_research_chem_CanonizerParity','compareTo$O'],  function (p) {
if (this.group != p.group) return this.group < p.group ? -1 : 1;
if (this.rank != p.rank) return this.rank > p.rank ? -1 : 1;
return 0;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:47 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
