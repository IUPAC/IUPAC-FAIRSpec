(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor"),I$=[[0,'com.actelion.research.chem.descriptor.DescriptorConstants','com.actelion.research.chem.descriptor.AbstractDescriptorHandlerLongFP','com.actelion.research.chem.StereoMolecule','java.util.Arrays','com.actelion.research.chem.Canonizer','com.actelion.research.util.BurtleHasher']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DescriptorHandlerReactionFP", null, 'com.actelion.research.chem.descriptor.AbstractDescriptorHandlerLongFP');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['sDefaultInstance','com.actelion.research.chem.descriptor.DescriptorHandlerReactionFP']]]

Clazz.newMeth(C$, 'getDefaultInstance$',  function () {
if (C$.sDefaultInstance == null ) {
{
C$.sDefaultInstance=Clazz.new_(C$);
}}return C$.sDefaultInstance;
}, 1);

Clazz.newMeth(C$, 'getInfo$',  function () {
return $I$(1).DESCRIPTOR_ReactionFP;
});

Clazz.newMeth(C$, 'getVersion$',  function () {
return $I$(1).DESCRIPTOR_ReactionFP.version;
});

Clazz.newMeth(C$, ['createDescriptor$com_actelion_research_chem_reaction_Reaction','createDescriptor$O'],  function (rxn) {
if (rxn == null ) return null;
var isReactionCenterMapNo=rxn.getReactionCenterMapNos$();
if (isReactionCenterMapNo == null ) return $I$(2).FAILED_OBJECT;
var len=16;
var data=Clazz.array(Long.TYPE, [16]);
for (var m=0; m < rxn.getMolecules$(); m++) {
var mol=rxn.getMolecule$I(m);
mol.ensureHelperArrays$I(7);
var isReactionCenterAtom=Clazz.array(Boolean.TYPE, [mol.getAllAtoms$()]);
var reactionCenterAtomCount=rxn.getReactionCenterAtoms$I$ZA$ZA$IA(m, isReactionCenterMapNo, isReactionCenterAtom, null);
var fragment=Clazz.new_([mol.getAllAtoms$(), mol.getAllBonds$()],$I$(3,1).c$$I$I);
var atomList=Clazz.array(Integer.TYPE, [mol.getAllAtoms$()]);
var atomMask=Clazz.array(Boolean.TYPE, [mol.getAllAtoms$()]);
for (var rootAtom=0; rootAtom < mol.getAtoms$(); rootAtom++) {
if (rootAtom != 0) $I$(4).fill$ZA$Z(atomMask, false);
var min=0;
var max=0;
for (var sphere=0; sphere < 5 && max < mol.getAtoms$() ; sphere++) {
if (max == 0) {
atomList[0]=rootAtom;
atomMask[rootAtom]=true;
max=1;
} else {
var newMax=max;
for (var i=min; i < max; i++) {
var atom=atomList[i];
for (var j=0; j < mol.getConnAtoms$I(atom); j++) {
var connAtom=mol.getConnAtom$I$I(atom, j);
if (!atomMask[connAtom] && (isReactionCenterAtom[rootAtom] || !isReactionCenterAtom[connAtom] ) ) {
atomMask[connAtom]=true;
atomList[newMax++]=connAtom;
}}
}
if (max == newMax) break;
min=max;
max=newMax;
}mol.copyMoleculeByAtoms$com_actelion_research_chem_ExtendedMolecule$ZA$Z$IA(fragment, atomMask, true, null);
var idcode=Clazz.new_($I$(5,1).c$$com_actelion_research_chem_StereoMolecule,[fragment]).getIDCode$();
if (m >= rxn.getReactants$()) idcode=idcode.concat$S("P");
var weight=isReactionCenterAtom[rootAtom] ? 5 - sphere : 1;
for (var i=0; i < weight; i++) {
var h=$I$(6,"hashlittle$S$J",[idcode.concat$S(Integer.toString$I(i)), 13]);
h=(h & $I$(6).hashmask$I(9));
if (isReactionCenterAtom[rootAtom]) h+=(512);
var index=16 - (h/64|0) - 1;
(data[$k$=index]=Long.$or(data[$k$],((Long.$sl(1,(h % 64))))));
}
}
}
}
return data;
});

Clazz.newMeth(C$, ['getSimilarity$JA$JA','getSimilarity$O$O'],  function (o1, o2) {
if (o1 == null  || o2 == null   || o1.length == 0  || o2.length == 0 ) return 0.0;
var reactionCenterSimilarity=C$.getSimilarityTanimoto$JA$JA$I$I(o1, o2, 0, 8);
var nonReactionCenterSimilarity=C$.getSimilarityTanimoto$JA$JA$I$I(o1, o2, 8, o1.length);
return 0.8 * reactionCenterSimilarity + 0.19999999 * nonReactionCenterSimilarity;
});

Clazz.newMeth(C$, 'getReactionCenterSimilarity$JA$JA',  function (o1, o2) {
if (o1 == null  || o2 == null   || o1.length == 0  || o2.length == 0 ) return 0.0;
return C$.getSimilarityTanimoto$JA$JA$I$I(o1, o2, 0, 8);
});

Clazz.newMeth(C$, 'getPeripherySimilarity$JA$JA',  function (o1, o2) {
if (o1 == null  || o2 == null   || o1.length == 0  || o2.length == 0 ) return 0.0;
return C$.getSimilarityTanimoto$JA$JA$I$I(o1, o2, 8, o1.length);
});

Clazz.newMeth(C$, 'getSimilarityTanimoto$JA$JA$I$I',  function (index1, index2, i1, i2) {
var sharedKeys=0;
var allKeys=0;
for (var i=i1; i < i2; i++) {
sharedKeys+=Long.bitCount$J(Long.$and(index1[i],index2[i]));
allKeys+=Long.bitCount$J(Long.$or(index1[i],index2[i]));
}
return allKeys == 0 ? 1.0 : sharedKeys / allKeys;
}, 1);

Clazz.newMeth(C$, 'getThreadSafeCopy$',  function () {
return this;
});
var $k$;

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:51 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
