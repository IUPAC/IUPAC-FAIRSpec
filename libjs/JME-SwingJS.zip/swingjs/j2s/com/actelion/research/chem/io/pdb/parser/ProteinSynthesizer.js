(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io.pdb.parser"),I$=[[0,'com.actelion.research.chem.io.pdb.parser.Residue']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ProteinSynthesizer");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.mTerminalC=-1;
},1);

C$.$fields$=[['I',['mTerminalC'],'O',['mProtein','com.actelion.research.chem.Molecule3D']]]

Clazz.newMeth(C$, 'addResidue$com_actelion_research_chem_Molecule3D',  function (residue) {
var coupled=false;
var toDelete=-1;
var newTerminalN=-1;
var newTerminalC=-1;
for (var atom=0; atom < residue.getAtoms$(); atom++) {
if (residue.getAtomicNo$I(atom) == 7 && residue.getAtomCustomLabel$I(atom) == null  ) newTerminalN=atom;
if (residue.getAtomicNo$I(atom) == 6 && residue.getAtomCustomLabel$I(atom) == null  ) newTerminalC=atom;
}
if (this.mProtein == null ) {
this.mProtein=residue;
this.mTerminalC=newTerminalC;
coupled=true;
} else if (newTerminalN > -1 && this.mTerminalC > -1 ) {
var coordsC=this.mProtein.getCoordinates$I(this.mTerminalC);
var coordsN=residue.getCoordinates$I(newTerminalN);
if (coordsC.distanceSquared$com_actelion_research_chem_Coordinates(coordsN) < $I$(1).BOND_CUTOFF_SQ ) {
var notFound=true;
for (var i=0; i < this.mProtein.getConnAtoms$I(this.mTerminalC) && notFound ; i++) {
var a=this.mProtein.getConnAtom$I$I(this.mTerminalC, i);
var b=this.mProtein.getBond$I$I(this.mTerminalC, a);
if (this.mProtein.getAtomicNo$I(a) == 8 && this.mProtein.getBondOrder$I(b) == 1 ) {
notFound=false;
toDelete=this.mProtein.getConnAtom$I$I(this.mTerminalC, i);
}}
if (toDelete >= 0) {
this.mProtein.deleteAtom$I(toDelete);
var atomMap=this.mProtein.addMolecule$com_actelion_research_chem_Molecule(residue);
this.mProtein.addBond$I$I$I(this.mTerminalC, atomMap[newTerminalN], 1);
this.mTerminalC=this.mProtein.getAllAtoms$() - (residue.getAllAtoms$() - newTerminalC);
coupled=true;
}}}this.mProtein.ensureHelperArrays$I(1);
return coupled;
});

Clazz.newMeth(C$, 'getProtein$',  function () {
return this.mProtein;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:55 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
