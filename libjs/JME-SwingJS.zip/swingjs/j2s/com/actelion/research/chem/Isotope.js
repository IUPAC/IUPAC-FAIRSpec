(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Isotope");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['absoluteMass','percentage'],'I',['neutrones']]]

Clazz.newMeth(C$, 'c$$I$D$D',  function (neutrones, absoluteMass, percentage) {
;C$.$init$.apply(this);
this.neutrones=neutrones;
this.absoluteMass=absoluteMass;
this.percentage=percentage;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:48 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
