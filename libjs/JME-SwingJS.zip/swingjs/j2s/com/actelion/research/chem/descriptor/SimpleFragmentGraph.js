(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor"),p$1={},I$=[[0,'java.util.Arrays','com.actelion.research.util.BurtleHasher']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SimpleFragmentGraph");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['mAtoms','mBonds'],'O',['mConnAtoms','int[]','+mFragmentAtomFromOrig','+mCanRank','+mGraphAtom','+mGraphIndex','mConnAtom','int[][]','+mConnBond','+mConnRank','mAtomDescriptor','byte[]','+mBondDescriptor','+mBuffer']]]

Clazz.newMeth(C$, 'c$$I',  function (maxFragmentBonds) {
;C$.$init$.apply(this);
p$1.init$I$I.apply(this, [maxFragmentBonds, 256]);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$IA$I',  function (mol, bondMember, bondCount) {
;C$.$init$.apply(this);
mol.ensureHelperArrays$I(1);
p$1.init$I$I.apply(this, [bondCount, mol.getAtoms$()]);
p$1.setMolecule$com_actelion_research_chem_StereoMolecule$IA$I.apply(this, [mol, bondMember, bondCount]);
}, 1);

Clazz.newMeth(C$, 'init$I$I',  function (maxFragmentBonds, atomCount) {
var maxFragmentAtoms=maxFragmentBonds + 1;
this.mAtomDescriptor=Clazz.array(Byte.TYPE, [maxFragmentAtoms]);
this.mBondDescriptor=Clazz.array(Byte.TYPE, [maxFragmentBonds]);
this.mConnAtoms=Clazz.array(Integer.TYPE, [maxFragmentAtoms]);
this.mCanRank=Clazz.array(Integer.TYPE, [maxFragmentAtoms]);
this.mGraphAtom=Clazz.array(Integer.TYPE, [maxFragmentAtoms]);
this.mGraphIndex=Clazz.array(Integer.TYPE, [maxFragmentAtoms]);
this.mFragmentAtomFromOrig=Clazz.array(Integer.TYPE, [atomCount]);
this.mConnAtom=Clazz.array(Integer.TYPE, [maxFragmentAtoms, 8]);
this.mConnBond=Clazz.array(Integer.TYPE, [maxFragmentAtoms, 8]);
this.mConnRank=Clazz.array(Integer.TYPE, [9, null]);
for (var i=1; i <= 8; i++) this.mConnRank[i]=Clazz.array(Integer.TYPE, [i]);

this.mBuffer=Clazz.array(Byte.TYPE, [3 * maxFragmentBonds]);
}, p$1);

Clazz.newMeth(C$, 'set$com_actelion_research_chem_StereoMolecule$IA$I',  function (mol, bondMember, bondCount) {
this.mAtoms=0;
this.mBonds=0;
var maxAtomCount=this.mFragmentAtomFromOrig.length;
if (maxAtomCount < mol.getAtoms$()) {
do {
maxAtomCount*=2;
} while (maxAtomCount < mol.getAtoms$());
this.mFragmentAtomFromOrig=Clazz.array(Integer.TYPE, [maxAtomCount]);
}mol.ensureHelperArrays$I(1);
p$1.setMolecule$com_actelion_research_chem_StereoMolecule$IA$I.apply(this, [mol, bondMember, bondCount]);
});

Clazz.newMeth(C$, 'setMolecule$com_actelion_research_chem_StereoMolecule$IA$I',  function (mol, bondMember, bondCount) {
var includeAtom=Clazz.array(Boolean.TYPE, [mol.getAtoms$()]);
$I$(1).fill$IA$I(this.mConnAtoms, 0);
for (var i=0; i < bondCount; i++) {
var bond=bondMember[i];
for (var j=0; j < 2; j++) {
var atom=mol.getBondAtom$I$I(j, bond);
if (!includeAtom[atom]) {
includeAtom[atom]=true;
this.mFragmentAtomFromOrig[atom]=this.mAtoms;
this.mAtomDescriptor[this.mAtoms++]=p$1.createAtomDescriptor$com_actelion_research_chem_StereoMolecule$I.apply(this, [mol, atom]);
}}
for (var j=0; j < 2; j++) {
var atom=mol.getBondAtom$I$I(j, bond);
var fragmentAtom=this.mFragmentAtomFromOrig[atom];
this.mConnAtom[fragmentAtom][this.mConnAtoms[fragmentAtom]]=this.mFragmentAtomFromOrig[mol.getBondAtom$I$I(1 - j, bond)];
this.mConnBond[fragmentAtom][this.mConnAtoms[fragmentAtom]]=this.mBonds;
++this.mConnAtoms[fragmentAtom];
}
this.mBondDescriptor[this.mBonds++]=p$1.createBondDescriptor$com_actelion_research_chem_StereoMolecule$I.apply(this, [mol, bond]);
}
}, p$1);

Clazz.newMeth(C$, 'createHashValue$I',  function (hashBits) {
var baseValue=Clazz.array(Long.TYPE, [this.mAtoms]);
for (var i=0; i < this.mAtoms; i++) baseValue[i]=(this.mAtomDescriptor[i] << 4) + i;

$I$(1).sort$JA(baseValue);
var startRanks=1;
for (var atom=0; atom < this.mAtoms; atom++) {
if (atom != 0 && Long.$ne((Long.$and((Long.$xor(baseValue[atom],baseValue[atom - 1])),(Long.$not(15)))),0 ) ) ++startRanks;
this.mCanRank[Long.$ival((Long.$and(baseValue[atom],15)))]=startRanks;
}
while (true){
for (var atom=0; atom < this.mAtoms; atom++) {
var connRank=this.mConnRank[this.mConnAtoms[atom]];
for (var i=0; i < this.mConnAtoms[atom]; i++) connRank[i]=(this.mBondDescriptor[this.mConnBond[atom][i]] << 4) | this.mCanRank[this.mConnAtom[atom][i]];

$I$(1).sort$IA(connRank);
baseValue[atom]=this.mCanRank[atom];
for (var i=0; i < this.mConnAtoms[atom]; i++) {
baseValue[atom]=Long.$or((Long.$sl(baseValue[atom],(6))),connRank[i]);
}
baseValue[atom]=Long.$or((Long.$sl(baseValue[atom],4)),atom);
}
$I$(1).sort$JA(baseValue);
var ranks=1;
for (var atom=0; atom < this.mAtoms; atom++) {
if (atom != 0 && Long.$ne((Long.$and((Long.$xor(baseValue[atom],baseValue[atom - 1])),(Long.$not(15)))),0 ) ) ++ranks;
this.mCanRank[Long.$ival((Long.$and(baseValue[atom],15)))]=ranks;
}
if (ranks == startRanks) break;
startRanks=ranks;
}
var maxRank=-1;
var maxAtom=-1;
for (var atom=0; atom < this.mAtoms; atom++) {
if (maxRank < this.mCanRank[atom]) {
maxRank=this.mCanRank[atom];
maxAtom=atom;
}}
var isUsedAtom=Clazz.array(Boolean.TYPE, [this.mAtoms]);
var isUsedBond=Clazz.array(Boolean.TYPE, [this.mBonds]);
this.mGraphAtom[0]=maxAtom;
this.mGraphIndex[maxAtom]=0;
isUsedAtom[maxAtom]=true;
var closureBonds=this.mBonds - this.mAtoms + 1;
var bufferAtomIndex=1;
var bufferBondIndex=this.mAtoms;
var bufferClosureIndex=this.mAtoms + this.mBonds - closureBonds;
this.mBuffer[0]=(((this.mAtomDescriptor[maxAtom] << 4) | closureBonds)|0);
var maxBond=-1;
var current=0;
var highest=0;
while (current <= highest){
var parent=this.mGraphAtom[current];
maxRank=-1;
maxAtom=-1;
for (var i=0; i < this.mConnAtoms[parent]; i++) {
var bond=this.mConnBond[parent][i];
if (!isUsedBond[bond]) {
var atom=this.mConnAtom[parent][i];
if (maxRank < this.mCanRank[atom]) {
maxRank=this.mCanRank[atom];
maxAtom=atom;
maxBond=bond;
}}}
if (maxRank != -1) {
if (isUsedAtom[maxAtom]) {
this.mBuffer[bufferClosureIndex++]=(((this.mGraphIndex[parent] << 4) | this.mGraphIndex[maxAtom])|0);
this.mBuffer[bufferClosureIndex++]=this.mBondDescriptor[maxBond];
} else {
this.mGraphIndex[maxAtom]=++highest;
this.mGraphAtom[highest]=maxAtom;
isUsedAtom[maxAtom]=true;
this.mBuffer[bufferAtomIndex++]=this.mAtomDescriptor[maxAtom];
this.mBuffer[bufferBondIndex++]=(((this.mGraphIndex[parent] << 2) | this.mBondDescriptor[maxBond])|0);
}isUsedBond[maxBond]=true;
continue;
}++current;
}
var hash=$I$(2,"hashlittle$BA$J$I",[this.mBuffer, 13, this.mAtoms + this.mBonds + (this.mBonds - this.mAtoms + 1) ]);
return (hash & $I$(2).hashmask$I(hashBits));
});

Clazz.newMeth(C$, 'createAtomDescriptor$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
return ($b$[0] = mol.getAtomicNo$I(atom), $b$[0]);
}, p$1);

Clazz.newMeth(C$, 'createBondDescriptor$com_actelion_research_chem_StereoMolecule$I',  function (mol, bond) {
if (mol.isDelocalizedBond$I(bond)) return $b$[0] = 0, $b$[0];
var order=Math.min(3, mol.getBondOrder$I(bond));
return ($b$[0] = (order == 0 ? 3 : order), $b$[0]);
}, p$1);
var $b$ = new Int8Array(1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:51 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
