(function(){var P$=Clazz.newPackage("com.actelion.research.chem.alignment3d.transformation"),I$=[[0,'com.actelion.research.chem.alignment3d.transformation.Rotation','com.actelion.research.chem.alignment3d.transformation.Translation','com.actelion.research.chem.alignment3d.transformation.Scaling','com.actelion.research.chem.alignment3d.transformation.TransformationSequence']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*i*/var C$=Clazz.newInterface(P$, "Transformation");

Clazz.newMeth(C$, 'decode$S',  function (s) {
if (s.startsWith$S("r")) {
return $I$(1).decode$S(s);
} else if (s.startsWith$S("t")) {
return $I$(2).decode$S(s);
} else if (s.startsWith$S("s")) {
return $I$(3).decode$S(s);
} else if (s.startsWith$S(String.valueOf$C("{"))) {
return $I$(4).decode$S(s);
} else return null;
}, 1);
C$.$defaults$ = function(C$){

Clazz.newMeth(C$, 'apply$com_actelion_research_chem_StereoMolecule',  function (mol) {
for (var a=0; a < mol.getAllAtoms$(); a++) {
this.apply$com_actelion_research_chem_Coordinates(mol.getCoordinates$I(a));
}
});

Clazz.newMeth(C$, 'apply$com_actelion_research_chem_conf_Conformer',  function (conf) {
for (var a=0; a < conf.getMolecule$().getAllAtoms$(); a++) {
this.apply$com_actelion_research_chem_Coordinates(conf.getCoordinates$I(a));
}
});
};})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:01 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
