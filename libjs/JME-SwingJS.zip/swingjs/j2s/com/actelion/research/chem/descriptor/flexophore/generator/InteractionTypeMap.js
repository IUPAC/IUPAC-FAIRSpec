(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore.generator"),I$=[[0,'com.actelion.research.chem.interactionstatistics.InteractionSimilarityTable','com.actelion.research.chem.interactionstatistics.InteractionDistanceStatistics','java.util.HashMap','java.util.ArrayList','com.actelion.research.util.datamodel.IntegerDouble','java.util.Collections']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InteractionTypeMap");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['threshSimilarity'],'O',['hmAtomType_ListSimilars','java.util.HashMap','interactionSimilarityTable','com.actelion.research.chem.interactionstatistics.InteractionSimilarityTable','liAtomTypes','java.util.List']]]

Clazz.newMeth(C$, 'c$$D',  function (threshSimilarity) {
;C$.$init$.apply(this);
this.threshSimilarity=threshSimilarity;
this.interactionSimilarityTable=$I$(1).getInstance$();
var interactionDistanceStatistics=$I$(2).getInstance$();
this.liAtomTypes=interactionDistanceStatistics.getAtomTypes$();
this.hmAtomType_ListSimilars=Clazz.new_($I$(3,1));
}, 1);

Clazz.newMeth(C$, 'getSimilars$I',  function (interactionTypeQuery) {
var li=this.hmAtomType_ListSimilars.get$O(Integer.valueOf$I(interactionTypeQuery));
if (li == null ) {
{
var liInteractionType_Similarity=Clazz.new_([this.liAtomTypes.size$()],$I$(4,1).c$$I);
for (var interactionTypeBase, $interactionTypeBase = this.liAtomTypes.iterator$(); $interactionTypeBase.hasNext$()&&((interactionTypeBase=($interactionTypeBase.next$()).intValue$()),1);) {
var similarity=1.0 - this.interactionSimilarityTable.getDistance$I$I(interactionTypeQuery, interactionTypeBase);
if (similarity >= this.threshSimilarity ) {
liInteractionType_Similarity.add$O(Clazz.new_($I$(5,1).c$$I$D,[interactionTypeBase, similarity]));
}}
$I$(6,"sort$java_util_List$java_util_Comparator",[liInteractionType_Similarity, $I$(5).getComparatorDouble$()]);
$I$(6).reverse$java_util_List(liInteractionType_Similarity);
this.hmAtomType_ListSimilars.put$O$O(Integer.valueOf$I(interactionTypeQuery), liInteractionType_Similarity);
li=liInteractionType_Similarity;
}}return li;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:52 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
