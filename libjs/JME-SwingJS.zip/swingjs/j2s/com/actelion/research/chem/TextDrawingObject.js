(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),p$1={},I$=[[0,'com.actelion.research.gui.generic.GenericPoint','StringBuilder','com.actelion.research.gui.generic.GenericRectangle','java.util.ArrayList','StringBuffer']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "TextDrawingObject", null, 'com.actelion.research.chem.AbstractDrawingObject');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['mHilite'],'D',['mSize','mZoomReferenceSize'],'I',['mStyle'],'S',['mText'],'O',['mLastBounds','com.actelion.research.gui.generic.GenericRectangle']]]

Clazz.newMeth(C$, 'c$',  function () {
C$.c$$S$com_actelion_research_gui_generic_GenericPoint$D$I.apply(this, ["", Clazz.new_($I$(1,1)), 9.0, 0]);
}, 1);

Clazz.newMeth(C$, 'c$$S$D$D',  function (text, x, y) {
C$.c$$S$D$D$D$I.apply(this, [text, x, y, 9.0, 0]);
}, 1);

Clazz.newMeth(C$, 'c$$S$D$D$D$I',  function (text, x, y, size, style) {
C$.c$$S$com_actelion_research_gui_generic_GenericPoint$D$I.apply(this, [text, Clazz.new_($I$(1,1).c$$D$D,[x, y]), size, style]);
}, 1);

Clazz.newMeth(C$, 'c$$S',  function (descriptorDetail) {
C$.c$.apply(this, []);
var index1=0;
while (index1 != -1){
var index2=descriptorDetail.indexOf$S$I("=\"", index1);
if (index2 == -1) break;
var key=descriptorDetail.substring$I$I(index1 + 1, index2);
index1=descriptorDetail.indexOf$S$I("\"", index2 + 2);
var value=(index1 == -1) ? descriptorDetail.substring$I(index2 + 1) : descriptorDetail.substring$I$I(index2 + 1, index1);
if (key.equals$O("text")) this.setText$S(value);
 else if (key.equals$O("x")) this.setX$S(value);
 else if (key.equals$O("y")) this.setY$S(value);
 else if (key.equals$O("size")) this.setSize$S(value);
 else if (key.equals$O("style")) this.setStyle$S(value);
}
}, 1);

Clazz.newMeth(C$, 'setText$S',  function (value) {
this.mText=p$1.decodeText$S.apply(this, [value]);
});

Clazz.newMeth(C$, 'setX$S',  function (value) {
try {
this.mPoint[0].x=Float.parseFloat$S(value);
} catch (nfe) {
if (Clazz.exceptionOf(nfe,"NumberFormatException")){
} else {
throw nfe;
}
}
});

Clazz.newMeth(C$, 'setY$S',  function (value) {
try {
this.mPoint[0].y=Float.parseFloat$S(value);
} catch (nfe) {
if (Clazz.exceptionOf(nfe,"NumberFormatException")){
} else {
throw nfe;
}
}
});

Clazz.newMeth(C$, 'setSize$S',  function (value) {
try {
this.mSize=Float.parseFloat$S(value);
} catch (nfe) {
if (Clazz.exceptionOf(nfe,"NumberFormatException")){
} else {
throw nfe;
}
}
});

Clazz.newMeth(C$, 'setStyle$S',  function (value) {
try {
this.mStyle=Integer.parseInt$S(value);
} catch (nfe) {
if (Clazz.exceptionOf(nfe,"NumberFormatException")){
} else {
throw nfe;
}
}
});

Clazz.newMeth(C$, 'c$$S$com_actelion_research_gui_generic_GenericPoint$D$I',  function (text, pt, size, style) {
Clazz.super_(C$, this);
this.mText=text;
this.mSize=size;
this.mStyle=style;
this.mPoint=Clazz.array($I$(1), [1]);
this.mPoint[0]=pt;
}, 1);

Clazz.newMeth(C$, 'getTypeString$',  function () {
return "text";
});

Clazz.newMeth(C$, 'getDescriptorDetail$',  function () {
var detail=Clazz.new_($I$(2,1));
detail.append$S(" text=\"" + p$1.encodeText$S.apply(this, [this.mText]) + "\"" );
detail.append$S(" x=\"" + new Double(this.mPoint[0].x).toString() + "\"" );
detail.append$S(" y=\"" + new Double(this.mPoint[0].y).toString() + "\"" );
if (this.mSize != 9.0 ) detail.append$S(String.format$S$OA(" size=\"%.4f\"", Clazz.array(java.lang.Object, -1, [ new Double(this.mSize)])));
if (this.mStyle != 0) detail.append$S(" style=\"" + this.mStyle + "\"" );
return detail.toString();
});

Clazz.newMeth(C$, 'clone$',  function () {
var duplicate=Clazz.new_(C$);
duplicate.setValues$S$D$I(this.mText, this.mSize, this.mStyle);
duplicate.setCoordinates$D$D(this.mPoint[0].x, this.mPoint[0].y);
duplicate.mIsSelected=this.mIsSelected;
return duplicate;
});

Clazz.newMeth(C$, 'setCoordinates$D$D',  function (x, y) {
this.mPoint[0].x=x;
this.mPoint[0].y=y;
});

Clazz.newMeth(C$, 'scale$D',  function (f) {
C$.superclazz.prototype.scale$D.apply(this, [f]);
this.mSize*=f;
});

Clazz.newMeth(C$, 'zoomAndRotateInit$D$D',  function (x, y) {
C$.superclazz.prototype.zoomAndRotateInit$D$D.apply(this, [x, y]);
this.mZoomReferenceSize=this.mSize;
});

Clazz.newMeth(C$, 'zoomAndRotate$D$D',  function (zoom, angle) {
C$.superclazz.prototype.zoomAndRotate$D$D.apply(this, [zoom, angle]);
this.mSize=this.mZoomReferenceSize * zoom;
});

Clazz.newMeth(C$, 'draw$com_actelion_research_gui_generic_GenericDrawContext$com_actelion_research_chem_DepictorTransformation',  function (context, t) {
var size=((t == null ) ? this.mSize : t.getScaling$() * this.mSize);
context.setFont$I$Z$Z(Math.round(size), (this.mStyle & 1) != 0, (this.mStyle & 2) != 0);
context.setRGB$I(this.mIsSelected ? -65536 : context.isDarkBackground$() ? -1 : -16777216);
var textList=p$1.getTextLineList.apply(this, []);
this.mLastBounds=p$1.calculateBoundingRect$com_actelion_research_gui_generic_GenericDrawContext$java_util_ArrayList.apply(this, [context, textList]);
if (t != null ) t.applyTo$com_actelion_research_gui_generic_GenericRectangle(this.mLastBounds);
for (var i=0; i < textList.size$(); i++) context.drawString$D$D$S(this.mLastBounds.x, this.mLastBounds.y + 1 + size * 5 / 6  + size * 1.4 * i , textList.get$I(i));

});

Clazz.newMeth(C$, 'calculateBoundingRect$com_actelion_research_gui_generic_GenericDrawContext$java_util_ArrayList',  function (context, textList) {
var maxWidth=0;
for (var text, $text = textList.iterator$(); $text.hasNext$()&&((text=($text.next$())),1);) {
if (text.length$() != 0) {
var width=context.getBounds$S(text).getWidth$();
if (maxWidth < width ) maxWidth=width;
}}
var height=this.mSize * 1.4 * (textList.size$() - 1)  + this.mSize;
return Clazz.new_($I$(3,1).c$$D$D$D$D,[this.mPoint[0].x, this.mPoint[0].y - this.mSize / 2, maxWidth, height]);
}, p$1);

Clazz.newMeth(C$, 'getBoundingRect$com_actelion_research_gui_generic_GenericDrawContext',  function (context) {
var textList=p$1.getTextLineList.apply(this, []);
return p$1.calculateBoundingRect$com_actelion_research_gui_generic_GenericDrawContext$java_util_ArrayList.apply(this, [context, textList]);
});

Clazz.newMeth(C$, 'getTextLineList',  function () {
var textList=Clazz.new_($I$(4,1));
var lineBreak=this.mText.indexOf$I("\n");
if (lineBreak == -1) {
textList.add$O(this.mText);
} else {
var textStart=0;
while (lineBreak != -1){
textList.add$O(this.mText.substring$I$I(textStart, lineBreak));
textStart=lineBreak + 1;
lineBreak=this.mText.indexOf$I$I("\n", textStart);
}
textList.add$O(this.mText.substring$I(textStart));
}return textList;
}, p$1);

Clazz.newMeth(C$, 'hilite$com_actelion_research_gui_generic_GenericDrawContext',  function (context) {
var bounds=this.getBoundingRect$com_actelion_research_gui_generic_GenericDrawContext(context);
context.setRGB$I(context.getSelectionBackgroundRGB$());
context.fillRectangle$D$D$D$D(bounds.x, bounds.y, bounds.width, bounds.height);
});

Clazz.newMeth(C$, 'checkHiliting$D$D',  function (x, y) {
this.mHilite=this.contains$D$D(x, y);
return this.mHilite;
});

Clazz.newMeth(C$, 'contains$D$D',  function (x, y) {
return (this.mLastBounds != null  && this.mLastBounds.contains$D$D(x, y) );
});

Clazz.newMeth(C$, 'clearHiliting$',  function () {
this.mHilite=false;
});

Clazz.newMeth(C$, 'setValues$S$D$I',  function (text, size, style) {
this.mText=text;
this.mSize=size;
this.mStyle=style;
});

Clazz.newMeth(C$, 'getText$',  function () {
return this.mText;
});

Clazz.newMeth(C$, 'getSize$',  function () {
return this.mSize;
});

Clazz.newMeth(C$, 'getStyle$',  function () {
return this.mStyle;
});

Clazz.newMeth(C$, 'encodeText$S',  function (source) {
var text=Clazz.new_($I$(5,1));
for (var i=0; i < source.length$(); i++) {
switch ((source.charCodeAt$I(i))) {
case 38:
text.append$S("&&");
break;
case 9:
text.append$S("&09");
break;
case 10:
text.append$S("&0A");
break;
case 32:
text.append$S("&20");
break;
default:
text.append$C(source.charAt$I(i));
break;
}
}
return text.toString();
}, p$1);

Clazz.newMeth(C$, 'decodeText$S',  function (source) {
var index=source.indexOf$I("&");
if (index == -1) return source;
var startIndex=0;
var text=Clazz.new_($I$(5,1));
while (index != -1){
text.append$S(source.substring$I$I(startIndex, index));
if (source.charAt$I(index + 1) == "&") {
text.append$C("&");
startIndex=index + 2;
} else {
var h=source.charAt$I(index + 1).$c();
h=h - (((h < 65 ) ? "0" : (h < 97 ) ? "A" : "a").$c());
var l=source.charAt$I(index + 2).$c();
l=l - (((l < 65 ) ? "0" : (l < 97 ) ? "A" : "a").$c());
text.append$C(String.fromCharCode((16 * h + l)));
startIndex=index + 3;
}index=source.indexOf$I$I("&", startIndex);
}
text.append$S(source.substring$I(startIndex));
return text.toString();
}, p$1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:01 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
