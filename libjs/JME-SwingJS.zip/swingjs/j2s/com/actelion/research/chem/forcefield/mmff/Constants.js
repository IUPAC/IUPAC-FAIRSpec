(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Constants");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:06 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
