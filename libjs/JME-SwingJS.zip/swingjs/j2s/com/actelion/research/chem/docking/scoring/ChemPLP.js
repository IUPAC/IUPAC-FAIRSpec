(function(){var P$=Clazz.newPackage("com.actelion.research.chem.docking.scoring"),p$1={},I$=[[0,'java.util.HashSet','java.util.Arrays','java.util.HashMap','com.actelion.research.chem.forcefield.mmff.ForceFieldMMFF94','com.actelion.research.chem.StereoMolecule','java.util.ArrayList','java.util.stream.IntStream','com.actelion.research.chem.docking.scoring.chemscore.HBTerm','com.actelion.research.chem.docking.scoring.plp.PLPTerm','com.actelion.research.chem.docking.scoring.plp.REPTerm','com.actelion.research.chem.docking.scoring.chemscore.SimpleMetalTerm','com.actelion.research.chem.docking.scoring.chemscore.MetalTerm','com.actelion.research.chem.Coordinates','com.actelion.research.chem.alignment3d.KabschAlignment','java.util.stream.Collectors','com.actelion.research.calc.combinatorics.CombinationGenerator','com.actelion.research.chem.phesa.pharmacophore.PharmacophoreCalculator','com.actelion.research.chem.phesa.pharmacophore.ChargedGroupDetector']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ChemPLP", null, 'com.actelion.research.chem.docking.scoring.AbstractScoringEngine');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['e0'],'O',['+receptorAcceptors','+receptorDonorHs','+receptorDonors','receptorDonorHPos','java.util.Map','+receptorAcceptorNeg','receptorMetals','java.util.Set','+ligandAcceptors','+ligandDonorHs','+ligandDonors','ligandDonorHPos','java.util.Map','+ligandAcceptorNeg','plp','java.util.List','+chemscoreHbond','+chemscoreMetal','ff','com.actelion.research.chem.forcefield.mmff.ForceFieldMMFF94','metalInteractionSites','java.util.Map']]
,['O',['SIMPLE_METAL_ATOMS','java.util.Set']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_Molecule3D$java_util_Set$com_actelion_research_chem_io_pdb_converter_MoleculeGrid',  function (receptor, bindingSiteAtoms, grid) {
;C$.superclazz.c$$com_actelion_research_chem_StereoMolecule$java_util_Set$com_actelion_research_chem_io_pdb_converter_MoleculeGrid.apply(this,[receptor, bindingSiteAtoms, grid]);C$.$init$.apply(this);
this.receptorAcceptors=Clazz.new_($I$(1,1));
this.receptorDonorHs=Clazz.new_($I$(1,1));
this.receptorDonorHPos=Clazz.new_($I$(3,1));
this.receptorAcceptorNeg=Clazz.new_($I$(3,1));
this.receptorMetals=Clazz.new_($I$(1,1));
this.receptorDonors=Clazz.new_($I$(1,1));
C$.identifyHBondFunctionality$com_actelion_research_chem_StereoMolecule$java_util_Set$java_util_Set$java_util_Set$java_util_Set$java_util_Map$java_util_Map(receptor, this.receptorAcceptors, this.receptorDonorHs, this.receptorDonors, this.receptorMetals, this.receptorAcceptorNeg, this.receptorDonorHPos);
this.metalInteractionSites=Clazz.new_($I$(3,1));
for (var met, $met = this.receptorMetals.iterator$(); $met.hasNext$()&&((met=($met.next$()).intValue$()),1);) this.metalInteractionSites.put$O$O(Integer.valueOf$I(met), C$.processMetalCoordination$com_actelion_research_chem_conf_Conformer$I$java_util_Set(this.receptorConf, met, this.receptorAcceptors));

}, 1);

Clazz.newMeth(C$, 'getFGValue$DA',  function (grad) {
var energy=this.getBumpTerm$();
for (var term, $term = this.chemscoreHbond.iterator$(); $term.hasNext$()&&((term=($term.next$())),1);) energy+=term.getFGValue$DA(grad);

for (var term, $term = p$1.getMetalTerm$java_util_List.apply(this, [this.chemscoreMetal]).iterator$(); $term.hasNext$()&&((term=($term.next$())),1);) energy+=term.getFGValue$DA(grad);

for (var term, $term = this.plp.iterator$(); $term.hasNext$()&&((term=($term.next$())),1);) energy+=term.getFGValue$DA(grad);

this.ff.setState$DA(this.candidatePose.getCartState$());
var ffEnergy=this.ff.getTotalEnergy$();
if ((ffEnergy - this.e0) > 10.0 ) {
energy+=ffEnergy - this.e0;
this.ff.addGradient$DA(grad);
}for (var term, $term = this.constraints.iterator$(); $term.hasNext$()&&((term=($term.next$())),1);) energy+=term.getFGValue$DA(grad);

return energy;
});

Clazz.newMeth(C$, 'updateState$',  function () {
this.ff.setState$DA(this.candidatePose.getCartState$());
});

Clazz.newMeth(C$, 'getScore$',  function () {
var grad=Clazz.array(Double.TYPE, [3 * this.candidatePose.getLigConf$().getMolecule$().getAllAtoms$()]);
var energy=this.getBumpTerm$();
for (var term, $term = this.chemscoreHbond.iterator$(); $term.hasNext$()&&((term=($term.next$())),1);) energy+=term.getFGValue$DA(grad);

for (var term, $term = p$1.getMetalTerm$java_util_List.apply(this, [this.chemscoreMetal]).iterator$(); $term.hasNext$()&&((term=($term.next$())),1);) energy+=term.getFGValue$DA(grad);

for (var term, $term = this.plp.iterator$(); $term.hasNext$()&&((term=($term.next$())),1);) energy+=term.getFGValue$DA(grad);

var ffOptions=Clazz.new_($I$(3,1));
ffOptions.put$O$O("dielectric constant", Double.valueOf$D(80.0));
$I$(4).initialize$S("MMFF94s+");
var toOptimize=Clazz.new_([this.candidatePose.getLigConf$().getMolecule$()],$I$(5,1).c$$com_actelion_research_chem_Molecule);
toOptimize.ensureHelperArrays$I(31);
var ff=Clazz.new_($I$(4,1).c$$com_actelion_research_chem_StereoMolecule$S$java_util_Map,[toOptimize, "MMFF94s+", ffOptions]);
var e=ff.getTotalEnergy$();
ff.minimise$();
var e0=ff.getTotalEnergy$();
var deltaE=e - e0;
if (deltaE > 10.0 ) {
energy+=deltaE - 10.0;
}return energy;
});

Clazz.newMeth(C$, 'init$com_actelion_research_chem_docking_LigandPose$D',  function (candidatePose, e0) {
this.e0=e0;
this.candidatePose=candidatePose;
this.plp=Clazz.new_($I$(6,1));
this.chemscoreHbond=Clazz.new_($I$(6,1));
this.chemscoreMetal=Clazz.new_($I$(6,1));
this.ligandAcceptors=Clazz.new_($I$(1,1));
this.ligandDonorHs=Clazz.new_($I$(1,1));
this.ligandDonors=Clazz.new_($I$(1,1));
this.ligandDonorHPos=Clazz.new_($I$(3,1));
this.ligandAcceptorNeg=Clazz.new_($I$(3,1));
this.constraints=Clazz.new_($I$(6,1));
var ligand=candidatePose.getLigConf$().getMolecule$();
var ffOptions=Clazz.new_($I$(3,1));
ffOptions.put$O$O("dielectric constant", Double.valueOf$D(80.0));
$I$(4).initialize$S("MMFF94s+");
this.ff=Clazz.new_($I$(4,1).c$$com_actelion_research_chem_StereoMolecule$S$java_util_Map,[ligand, "MMFF94s+", ffOptions]);
var receptor=this.receptorConf.getMolecule$();
C$.identifyHBondFunctionality$com_actelion_research_chem_StereoMolecule$java_util_Set$java_util_Set$java_util_Set$java_util_Set$java_util_Map$java_util_Map(ligand, this.ligandAcceptors, this.ligandDonorHs, this.ligandDonors, Clazz.new_($I$(1,1)), this.ligandAcceptorNeg, this.ligandDonorHPos);
for (var p, $p = this.bindingSiteAtoms.iterator$(); $p.hasNext$()&&((p=($p.next$()).intValue$()),1);) {
if (receptor.getAtomicNo$I(p) == 1) {
if (this.receptorDonorHs.contains$O(Integer.valueOf$I(p))) {
var d=receptor.getConnAtom$I$I(p, 0);
var chargedP=this.receptorDonorHPos.keySet$().contains$O(Integer.valueOf$I(p));
for (var l=0; l < ligand.getAtoms$(); l++) {
if (this.ligandAcceptors.contains$O(Integer.valueOf$I(l))) {
var li=l;
var acceptorNeighbours=$I$(7,"range$I$I",[0, ligand.getConnAtoms$I(li)]).map$java_util_function_IntUnaryOperator(((P$.ChemPLP$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "ChemPLP$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntUnaryOperator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsInt$I','applyAsInt$O'],  function (i) { return (this.$finals$.ligand.getConnAtom$I$I.apply(this.$finals$.ligand, [this.$finals$.li, i]));});
})()
), Clazz.new_(P$.ChemPLP$lambda1.$init$,[this, {ligand:ligand,li:li}]))).toArray$();
var chargedL=this.ligandAcceptorNeg.keySet$().contains$O(Integer.valueOf$I(l));
var scale=1.0;
if (chargedP && chargedL ) {
scale+=((this.ligandAcceptorNeg.get$O(Integer.valueOf$I(l))).$c() * (this.receptorDonorHPos.get$O(Integer.valueOf$I(p))).$c());
}var hbTerm=$I$(8,"create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$I$Z$Z$IA$D",[this.receptorConf, candidatePose.getLigConf$(), l, d, p, true, false, acceptorNeighbours, scale]);
this.chemscoreHbond.add$O(hbTerm);
}}
}} else {
if (this.receptorDonors.contains$O(Integer.valueOf$I(p))) {
for (var l=0; l < ligand.getAtoms$(); l++) {
if (this.ligandAcceptors.contains$O(Integer.valueOf$I(l))) {
var plpTerm=$I$(9,"create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$java_util_Map",[this.receptorConf, candidatePose.getLigConf$(), p, l, $I$(9).HBOND_TERM]);
this.plp.add$O(plpTerm);
} else if (this.ligandDonors.contains$O(Integer.valueOf$I(l))) {
var repTerm=$I$(10,"create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I",[this.receptorConf, candidatePose.getLigConf$(), p, l]);
this.plp.add$O(repTerm);
} else {
var plpTerm=$I$(9,"create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$java_util_Map",[this.receptorConf, candidatePose.getLigConf$(), p, l, $I$(9).BURIED_TERM]);
this.plp.add$O(plpTerm);
}}
} else if (this.receptorAcceptors.contains$O(Integer.valueOf$I(p))) {
var acceptorNeighbours=$I$(7,"range$I$I",[0, receptor.getConnAtoms$I(p)]).map$java_util_function_IntUnaryOperator(((P$.ChemPLP$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "ChemPLP$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntUnaryOperator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsInt$I','applyAsInt$O'],  function (i) { return (this.$finals$.receptor.getConnAtom$I$I.apply(this.$finals$.receptor, [this.$finals$.p, i]));});
})()
), Clazz.new_(P$.ChemPLP$lambda2.$init$,[this, {receptor:receptor,p:p}]))).toArray$();
var chargedP=this.receptorAcceptorNeg.keySet$().contains$O(Integer.valueOf$I(p));
for (var l=0; l < ligand.getAllAtoms$(); l++) {
if (ligand.getAtomicNo$I(l) == 1) {
if (this.ligandDonorHs.contains$O(Integer.valueOf$I(l))) {
var chargedL=this.ligandDonorHPos.keySet$().contains$O(Integer.valueOf$I(l));
var d=ligand.getConnAtom$I$I(l, 0);
var scale=1.0;
if (chargedP && chargedL ) scale+=((this.receptorAcceptorNeg.get$O(Integer.valueOf$I(p))).$c() * (this.ligandDonorHPos.get$O(Integer.valueOf$I(l))).$c());
var hbTerm=$I$(8,"create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$I$Z$Z$IA$D",[this.receptorConf, candidatePose.getLigConf$(), p, d, l, false, true, acceptorNeighbours, scale]);
this.chemscoreHbond.add$O(hbTerm);
}} else {
if (this.ligandDonors.contains$O(Integer.valueOf$I(l))) {
var plpTerm=$I$(9,"create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$java_util_Map",[this.receptorConf, candidatePose.getLigConf$(), p, l, $I$(9).HBOND_TERM]);
this.plp.add$O(plpTerm);
} else if (this.ligandAcceptors.contains$O(Integer.valueOf$I(l))) {
var repTerm=$I$(10,"create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I",[this.receptorConf, candidatePose.getLigConf$(), p, l]);
this.plp.add$O(repTerm);
} else {
var plpTerm=$I$(9,"create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$java_util_Map",[this.receptorConf, candidatePose.getLigConf$(), p, l, $I$(9).BURIED_TERM]);
this.plp.add$O(plpTerm);
}}}
} else if (this.receptorMetals.contains$O(Integer.valueOf$I(p))) {
for (var l=0; l < ligand.getAtoms$(); l++) {
if (this.ligandDonors.contains$O(Integer.valueOf$I(l))) {
var repTerm=$I$(10,"create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I",[this.receptorConf, candidatePose.getLigConf$(), p, l]);
this.plp.add$O(repTerm);
} else if (this.ligandAcceptors.contains$O(Integer.valueOf$I(l))) {
var plpTerm=$I$(9,"create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$java_util_Map",[this.receptorConf, candidatePose.getLigConf$(), p, l, $I$(9).METAL_TERM]);
this.plp.add$O(plpTerm);
} else {
var plpTerm=$I$(9,"create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$java_util_Map",[this.receptorConf, candidatePose.getLigConf$(), p, l, $I$(9).BURIED_TERM]);
this.plp.add$O(plpTerm);
}}
if (C$.SIMPLE_METAL_ATOMS.contains$O(Integer.valueOf$I(receptor.getAtomicNo$I(p)))) {
for (var l, $l = this.ligandAcceptors.iterator$(); $l.hasNext$()&&((l=($l.next$()).intValue$()),1);) {
var scale=1.0;
if (this.ligandAcceptorNeg.keySet$().contains$O(Integer.valueOf$I(l))) scale+=(this.ligandAcceptorNeg.get$O(Integer.valueOf$I(l))).$c();
var acceptorNeighbours=$I$(7,"range$I$I",[0, ligand.getConnAtoms$I(l)]).map$java_util_function_IntUnaryOperator(((P$.ChemPLP$lambda3||
(function(){/*m*/var C$=Clazz.newClass(P$, "ChemPLP$lambda3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntUnaryOperator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsInt$I','applyAsInt$O'],  function (i) { return (this.$finals$.ligand.getConnAtom$I$I.apply(this.$finals$.ligand, [this.$finals$.l, i]));});
})()
), Clazz.new_(P$.ChemPLP$lambda3.$init$,[this, {ligand:ligand,l:l}]))).toArray$();
var metTerm=$I$(11,"create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$IA$D",[this.receptorConf, candidatePose.getLigConf$(), l, p, acceptorNeighbours, scale]);
this.chemscoreMetal.add$O(metTerm);
}
} else {
var interactionSites=this.metalInteractionSites.get$O(Integer.valueOf$I(p));
for (var l, $l = this.ligandAcceptors.iterator$(); $l.hasNext$()&&((l=($l.next$()).intValue$()),1);) {
var scale=1.0;
if (this.ligandAcceptorNeg.keySet$().contains$O(Integer.valueOf$I(l))) scale+=(this.ligandAcceptorNeg.get$O(Integer.valueOf$I(l))).$c();
var acceptorNeighbours=$I$(7,"range$I$I",[0, ligand.getConnAtoms$I(l)]).map$java_util_function_IntUnaryOperator(((P$.ChemPLP$lambda4||
(function(){/*m*/var C$=Clazz.newClass(P$, "ChemPLP$lambda4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntUnaryOperator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsInt$I','applyAsInt$O'],  function (i) { return (this.$finals$.ligand.getConnAtom$I$I.apply(this.$finals$.ligand, [this.$finals$.l, i]));});
})()
), Clazz.new_(P$.ChemPLP$lambda4.$init$,[this, {ligand:ligand,l:l}]))).toArray$();
for (var site, $site = interactionSites.iterator$(); $site.hasNext$()&&((site=($site.next$())),1);) {
var metTerm=$I$(12,"create$com_actelion_research_chem_conf_Conformer$I$com_actelion_research_chem_conf_Conformer$I$IA$com_actelion_research_chem_Coordinates$D",[candidatePose.getLigConf$(), l, this.receptorConf, p, acceptorNeighbours, site, scale]);
this.chemscoreMetal.add$O(metTerm);
}
}
}} else {
for (var l=0; l < ligand.getAtoms$(); l++) {
if (this.ligandDonors.contains$O(Integer.valueOf$I(l))) {
var plpTerm=$I$(9,"create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$java_util_Map",[this.receptorConf, candidatePose.getLigConf$(), p, l, $I$(9).BURIED_TERM]);
this.plp.add$O(plpTerm);
} else if (this.ligandAcceptors.contains$O(Integer.valueOf$I(l))) {
var plpTerm=$I$(9,"create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$java_util_Map",[this.receptorConf, candidatePose.getLigConf$(), p, l, $I$(9).BURIED_TERM]);
this.plp.add$O(plpTerm);
} else {
var plpTerm=$I$(9,"create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$java_util_Map",[this.receptorConf, candidatePose.getLigConf$(), p, l, $I$(9).NONPOLAR_TERM]);
this.plp.add$O(plpTerm);
}}
}}}
});

Clazz.newMeth(C$, 'processMetalCoordination$com_actelion_research_chem_conf_Conformer$I$java_util_Set',  function (receptor, metalAtom, receptorAcceptors) {
var interactionPoints=Clazz.new_($I$(6,1));
var metalCoordinates=receptor.getCoordinates$I(metalAtom);
var interactionSites=Clazz.new_($I$(6,1));
interactionSites.add$O(Clazz.new_($I$(13,1).c$$com_actelion_research_chem_Coordinates,[metalCoordinates]));
for (var acceptor, $acceptor = receptorAcceptors.iterator$(); $acceptor.hasNext$()&&((acceptor=($acceptor.next$()).intValue$()),1);) {
var acceptorCoords=receptor.getCoordinates$I(acceptor);
if (acceptorCoords.distance$com_actelion_research_chem_Coordinates(metalCoordinates) < 2.6 ) interactionSites.add$O(acceptorCoords);
}
var occupiedSites=interactionSites.toArray$OA(Clazz.array($I$(13), [interactionSites.size$()]));
var overallMinimalRMSD=1.7976931348623157E308;
var fittedGeometry=null;
;var finalMapping=null;
if (occupiedSites.length < 5) {
var idealGeom=C$.getTetrahedron$();
var bestMapping=Clazz.array(Integer.TYPE, [occupiedSites.length, 2]);
overallMinimalRMSD=C$.getBestMetalFit$com_actelion_research_chem_CoordinatesA$com_actelion_research_chem_CoordinatesA$IAA$I(idealGeom, occupiedSites, bestMapping, 4);
fittedGeometry=idealGeom;
finalMapping=bestMapping;
}if (occupiedSites.length < 6) {
var idealGeom3=C$.getTrigonalBipyramidal$();
var bestMapping3=Clazz.array(Integer.TYPE, [occupiedSites.length, 2]);
if (C$.getBestMetalFit$com_actelion_research_chem_CoordinatesA$com_actelion_research_chem_CoordinatesA$IAA$I(idealGeom3, occupiedSites, bestMapping3, 5) < overallMinimalRMSD ) {
fittedGeometry=idealGeom3;
finalMapping=bestMapping3;
}}if (occupiedSites.length < 7) {
var idealGeom2=C$.getOctahedron$();
var bestMapping2=Clazz.array(Integer.TYPE, [occupiedSites.length, 2]);
if (C$.getBestMetalFit$com_actelion_research_chem_CoordinatesA$com_actelion_research_chem_CoordinatesA$IAA$I(idealGeom2, occupiedSites, bestMapping2, 6) < overallMinimalRMSD ) {
fittedGeometry=idealGeom2;
finalMapping=bestMapping2;
}}if (fittedGeometry != null ) {
var alignment=Clazz.new_($I$(14,1).c$$com_actelion_research_chem_CoordinatesA$com_actelion_research_chem_CoordinatesA$IAA,[occupiedSites, fittedGeometry, finalMapping]);
alignment.align$();
var mappedPoints=$I$(2).stream$OA(finalMapping).map$java_util_function_Function((P$.ChemPLP$lambda5$||(P$.ChemPLP$lambda5$=(((P$.ChemPLP$lambda5||
(function(){/*m*/var C$=Clazz.newClass(P$, "ChemPLP$lambda5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$IA','apply$O'],  function (e) { return (Integer.valueOf$I(e[1]));});
})()
), Clazz.new_(P$.ChemPLP$lambda5.$init$,[this, null])))))).collect$java_util_stream_Collector($I$(15).toList$());
for (var i=0; i < fittedGeometry.length; i++) {
if (!mappedPoints.contains$O(Integer.valueOf$I(i))) interactionPoints.add$O(fittedGeometry[i]);
}
}for (var point, $point = interactionPoints.iterator$(); $point.hasNext$()&&((point=($point.next$())),1);) {
var v=point.subC$com_actelion_research_chem_Coordinates(metalCoordinates);
v.unit$();
v.scale$D(2.2);
var newPoint=metalCoordinates.addC$com_actelion_research_chem_Coordinates(v);
point.x=newPoint.x;
point.y=newPoint.y;
point.z=newPoint.z;
}
return interactionPoints;
}, 1);

Clazz.newMeth(C$, 'getMetalTerm$java_util_List',  function (metalTerms) {
var grad=Clazz.array(Double.TYPE, [3 * this.candidatePose.getLigConf$().getMolecule$().getAllAtoms$()]);
var interactionPt2Term=Clazz.new_($I$(3,1));
var curatedTerms=Clazz.new_($I$(6,1));
for (var term, $term = metalTerms.iterator$(); $term.hasNext$()&&((term=($term.next$())),1);) {
if (!(Clazz.instanceOf(term, "com.actelion.research.chem.docking.scoring.chemscore.MetalTerm"))) {
curatedTerms.add$O(term);
} else {
var metalTerm=term;
interactionPt2Term.putIfAbsent$O$O(metalTerm.getFitPoint$(), Clazz.new_($I$(6,1)));
interactionPt2Term.get$O(metalTerm.getFitPoint$()).add$O(metalTerm);
}}
for (var key, $key = interactionPt2Term.keySet$().iterator$(); $key.hasNext$()&&((key=($key.next$())),1);) {
var bestTerm=interactionPt2Term.get$O(key).stream$().sorted$java_util_Comparator(((P$.ChemPLP$lambda6||
(function(){/*m*/var C$=Clazz.newClass(P$, "ChemPLP$lambda6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['compare$com_actelion_research_chem_potentialenergy_PotentialEnergyTerm$com_actelion_research_chem_potentialenergy_PotentialEnergyTerm','compare$O$O'],  function (e1, e2) /*block*/{
return Double.compare$D$D(e1.getFGValue$DA.apply(e1, [this.$finals$.grad]), e2.getFGValue$DA.apply(e2, [this.$finals$.grad]));
});
})()
), Clazz.new_(P$.ChemPLP$lambda6.$init$,[this, {grad:grad}]))).collect$java_util_stream_Collector($I$(15).toList$()).get$I(0);
curatedTerms.add$O(bestTerm);
}
return curatedTerms;
}, p$1);

Clazz.newMeth(C$, 'getBestMetalFit$com_actelion_research_chem_CoordinatesA$com_actelion_research_chem_CoordinatesA$IAA$I',  function (idealGeom, occupiedSites, bestMapping, coordinationNumber) {
var overallMinimalRMSD=1.7976931348623157E308;
if ((occupiedSites.length - 1) < coordinationNumber) {
var assignments=C$.enumerateMetalPosAssignments$I$I(coordinationNumber, occupiedSites.length - 1);
for (var ass, $ass = assignments.iterator$(); $ass.hasNext$()&&((ass=($ass.next$())),1);) {
var mapping=Clazz.array(Integer.TYPE, [occupiedSites.length, 2]);
var counter=0;
mapping[0][0]=0;
mapping[0][1]=0;
for (var i=1; i < occupiedSites.length; i++) {
var m=Clazz.array(Integer.TYPE, -1, [counter, ass[counter]]);
for (var j=0; j < m.length; j++) {
m[j]=m[j] + 1;
}
mapping[i]=m;
++counter;
}
var idealGeomCopy=$I$(2).stream$OA(idealGeom).map$java_util_function_Function((P$.ChemPLP$lambda7$||(P$.ChemPLP$lambda7$=(((P$.ChemPLP$lambda7||
(function(){/*m*/var C$=Clazz.newClass(P$, "ChemPLP$lambda7", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$com_actelion_research_chem_Coordinates','apply$O'],  function (e) { return (Clazz.new_($I$(13,1).c$$com_actelion_research_chem_Coordinates,[e]));});
})()
), Clazz.new_(P$.ChemPLP$lambda7.$init$,[this, null])))))).toArray$java_util_function_IntFunction(((P$.ChemPLP$lambda8||
(function(){/*m*/var C$=Clazz.newClass(P$, "ChemPLP$lambda8", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_C*/
Clazz.newMeth(C$, 'apply$I',  function (t) { return Clazz.array($I$(13), [t.intValue()])});
})()
), Clazz.new_(P$.ChemPLP$lambda8.$init$,[this, null])));
var alignment=Clazz.new_($I$(14,1).c$$com_actelion_research_chem_CoordinatesA$com_actelion_research_chem_CoordinatesA$IAA,[occupiedSites, idealGeomCopy, mapping]);
alignment.align$();
var rmsd=C$.getRMSD$com_actelion_research_chem_CoordinatesA$com_actelion_research_chem_CoordinatesA$IAA(occupiedSites, idealGeomCopy, mapping);
if (rmsd < overallMinimalRMSD ) {
overallMinimalRMSD=rmsd;
for (var i=0; i < mapping.length; i++) {
for (var j=0; j < mapping[i].length; j++) {
bestMapping[i][j]=mapping[i][j];
}
}
}}
}return overallMinimalRMSD;
}, 1);

Clazz.newMeth(C$, 'getRMSD$com_actelion_research_chem_CoordinatesA$com_actelion_research_chem_CoordinatesA$IAA',  function (c1, c2, mapping) {
var rmsd=0.0;
for (var m, $m = 0, $$m = mapping; $m<$$m.length&&((m=($$m[$m])),1);$m++) {
var coor1=c1[m[0]];
var coor2=c2[m[1]];
var dx=coor1.x - coor2.x;
var dy=coor1.y - coor2.y;
var dz=coor1.z - coor2.z;
rmsd+=dx * dx + dy * dy + dz * dz;
}
rmsd/=mapping.length;
return Math.sqrt(rmsd);
}, 1);

Clazz.newMeth(C$, 'enumerateMetalPosAssignments$I$I',  function (coordinationNumber, occupiedSites) {
var allAssignments=Clazz.new_($I$(6,1));
if (occupiedSites != 0) {
if (occupiedSites == 1) {
var assignment=Clazz.array(Integer.TYPE, -1, [0, 0]);
allAssignments.add$O(assignment);
} else {
var liComb=$I$(16).getAllOutOf$I$I(coordinationNumber - 1, occupiedSites - 1);
for (var r, $r = liComb.iterator$(); $r.hasNext$()&&((r=($r.next$())),1);) {
var permutations=$I$(16).getPermutations$IA$I(r, r.length);
for (var per, $per = permutations.iterator$(); $per.hasNext$()&&((per=($per.next$())),1);) {
var arr=Clazz.array(Integer.TYPE, [per.length + 1]);
arr[0]=0;
$I$(7).range$I$I(0, per.length).forEach$java_util_function_IntConsumer(((P$.ChemPLP$lambda9||
(function(){/*m*/var C$=Clazz.newClass(P$, "ChemPLP$lambda9", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$I','accept$O'],  function (e) /*block*/{
this.$finals$.arr[e + 1]=this.$finals$.per[e] + 1;
});
})()
), Clazz.new_(P$.ChemPLP$lambda9.$init$,[this, {arr:arr,per:per}])));
allAssignments.add$O(arr);
}
}
}}return allAssignments;
}, 1);

Clazz.newMeth(C$, 'identifyHBondFunctionality$com_actelion_research_chem_StereoMolecule$java_util_Set$java_util_Set$java_util_Set$java_util_Set$java_util_Map$java_util_Map',  function (mol, acceptors, donorHs, donors, metals, chargedAcceptors, chargedDonorHs) {
for (var a=0; a < mol.getAllAtoms$(); a++) {
if (mol.getAtomicNo$I(a) == 7 || mol.getAtomicNo$I(a) == 8 ) {
if ($I$(17).isAcceptor$com_actelion_research_chem_StereoMolecule$I(mol, a)) acceptors.add$O(Integer.valueOf$I(a));
} else if ($I$(17).isDonorHydrogen$com_actelion_research_chem_StereoMolecule$I(mol, a)) {
donorHs.add$O(Integer.valueOf$I(a));
donors.add$O(Integer.valueOf$I(mol.getConnAtom$I$I(a, 0)));
} else if (mol.isMetalAtom$I(a)) metals.add$O(Integer.valueOf$I(a));
}
var detector=Clazz.new_($I$(18,1).c$$com_actelion_research_chem_StereoMolecule,[mol]);
detector.detect$();
var chargedGroups=detector.getChargedGroups$();
for (var a, $a = acceptors.iterator$(); $a.hasNext$()&&((a=($a.next$()).intValue$()),1);) {
for (var chargedGroup, $chargedGroup = chargedGroups.iterator$(); $chargedGroup.hasNext$()&&((chargedGroup=($chargedGroup.next$())),1);) {
var invScale=chargedGroup.stream$().mapToInt$java_util_function_ToIntFunction(((P$.ChemPLP$lambda10||
(function(){/*m*/var C$=Clazz.newClass(P$, "ChemPLP$lambda10", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.ToIntFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsInt$Integer','applyAsInt$O'],  function (e) /*block*/{
if (this.$finals$.mol.getAtomicNo$I.apply(this.$finals$.mol, [(e).$c()]) != 6 && this.$finals$.mol.getAtomicNo$I.apply(this.$finals$.mol, [(e).$c()]) != 15  && this.$finals$.mol.getAtomicNo$I.apply(this.$finals$.mol, [(e).$c()]) != 16 ) return 1;
 else return 0;
});
})()
), Clazz.new_(P$.ChemPLP$lambda10.$init$,[this, {mol:mol}]))).sum$();
var scale=1.0 / invScale;
if (chargedGroup.contains$O(Integer.valueOf$I(a))) {
chargedAcceptors.put$O$O(Integer.valueOf$I(a), Double.valueOf$D(scale));
}}
}
for (var h, $h = donorHs.iterator$(); $h.hasNext$()&&((h=($h.next$()).intValue$()),1);) {
for (var chargedGroup, $chargedGroup = chargedGroups.iterator$(); $chargedGroup.hasNext$()&&((chargedGroup=($chargedGroup.next$())),1);) {
var invScale=chargedGroup.stream$().mapToInt$java_util_function_ToIntFunction(((P$.ChemPLP$lambda11||
(function(){/*m*/var C$=Clazz.newClass(P$, "ChemPLP$lambda11", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.ToIntFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsInt$Integer','applyAsInt$O'],  function (e) /*block*/{
if (this.$finals$.mol.getAtomicNo$I.apply(this.$finals$.mol, [(e).$c()]) != 6 && this.$finals$.mol.getAtomicNo$I.apply(this.$finals$.mol, [(e).$c()]) != 15  && this.$finals$.mol.getAtomicNo$I.apply(this.$finals$.mol, [(e).$c()]) != 16 ) return 1;
 else return 0;
});
})()
), Clazz.new_(P$.ChemPLP$lambda11.$init$,[this, {mol:mol}]))).sum$();
var scale=1.0 / invScale;
;var d=mol.getConnAtom$I$I(h, 0);
if (chargedGroup.contains$O(Integer.valueOf$I(d))) {
chargedDonorHs.put$O$O(Integer.valueOf$I(h), Double.valueOf$D(scale));
}}
}
}, 1);

Clazz.newMeth(C$, 'getTetrahedron$',  function () {
return Clazz.array($I$(13), -1, [Clazz.new_($I$(13,1).c$$D$D$D,[0.0, 0.0, 0.0]), Clazz.new_($I$(13,1).c$$D$D$D,[2.074, 0, -0.733]), Clazz.new_($I$(13,1).c$$D$D$D,[-1.037, 1.796, -0.733]), Clazz.new_($I$(13,1).c$$D$D$D,[-1.037, -1.796, -0.733]), Clazz.new_($I$(13,1).c$$D$D$D,[0.0, 0.0, 2.2])]);
}, 1);

Clazz.newMeth(C$, 'getOctahedron$',  function () {
return Clazz.array($I$(13), -1, [Clazz.new_($I$(13,1).c$$D$D$D,[0.0, 0.0, 0.0]), Clazz.new_($I$(13,1).c$$D$D$D,[0, 0, 2.2]), Clazz.new_($I$(13,1).c$$D$D$D,[0, 0, -2.2]), Clazz.new_($I$(13,1).c$$D$D$D,[1.555, 1.555, 0.0]), Clazz.new_($I$(13,1).c$$D$D$D,[1.555, -1.555, 0.0]), Clazz.new_($I$(13,1).c$$D$D$D,[-1.555, 1.555, 0.0]), Clazz.new_($I$(13,1).c$$D$D$D,[-1.555, -1.555, 0.0])]);
}, 1);

Clazz.newMeth(C$, 'getTrigonalBipyramidal$',  function () {
return Clazz.array($I$(13), -1, [Clazz.new_($I$(13,1).c$$D$D$D,[0.0, 0.0, 0.0]), Clazz.new_($I$(13,1).c$$D$D$D,[0, 0, 2.2]), Clazz.new_($I$(13,1).c$$D$D$D,[0, 0, -2.2]), Clazz.new_($I$(13,1).c$$D$D$D,[-1.1, 1.905, 0.0]), Clazz.new_($I$(13,1).c$$D$D$D,[-1.1, -1.905, 0.0]), Clazz.new_($I$(13,1).c$$D$D$D,[2.2, 0.0, 0.0])]);
}, 1);

Clazz.newMeth(C$, 'getContributions$',  function () {
var contributions=Clazz.new_($I$(3,1));
var grad=Clazz.array(Double.TYPE, [3 * this.candidatePose.getLigConf$().getMolecule$().getAllAtoms$()]);
var hbond=0.0;
for (var term, $term = this.chemscoreHbond.iterator$(); $term.hasNext$()&&((term=($term.next$())),1);) hbond+=term.getFGValue$DA(grad);

contributions.put$O$O("HBOND", Double.valueOf$D(hbond));
var metal=0.0;
for (var term, $term = p$1.getMetalTerm$java_util_List.apply(this, [this.chemscoreMetal]).iterator$(); $term.hasNext$()&&((term=($term.next$())),1);) {
metal+=term.getFGValue$DA(grad);
}
contributions.put$O$O("METAL", Double.valueOf$D(metal));
var plpContr=0.0;
for (var term, $term = this.plp.iterator$(); $term.hasNext$()&&((term=($term.next$())),1);) plpContr+=term.getFGValue$DA(grad);

contributions.put$O$O("PLP", Double.valueOf$D(plpContr));
var strain=0.0;
var ffOptions=Clazz.new_($I$(3,1));
ffOptions.put$O$O("dielectric constant", Double.valueOf$D(80.0));
$I$(4).initialize$S("MMFF94s+");
var toOptimize=Clazz.new_([this.candidatePose.getLigConf$().getMolecule$()],$I$(5,1).c$$com_actelion_research_chem_Molecule);
toOptimize.ensureHelperArrays$I(31);
var ff=Clazz.new_($I$(4,1).c$$com_actelion_research_chem_StereoMolecule$S$java_util_Map,[toOptimize, "MMFF94s+", ffOptions]);
var e=ff.getTotalEnergy$();
ff.minimise$();
var e0=ff.getTotalEnergy$();
var deltaE=e - e0;
if (deltaE > 10.0 ) {
strain+=deltaE - 10.0;
}contributions.put$O$O("STRAIN", Double.valueOf$D(strain));
return contributions;
});

C$.$static$=function(){C$.$static$=0;
C$.SIMPLE_METAL_ATOMS=Clazz.new_([$I$(2,"asList$OA",[Clazz.array(Integer, -1, [Integer.valueOf$I(12), Integer.valueOf$I(20)])])],$I$(1,1).c$$java_util_Collection);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:05 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
