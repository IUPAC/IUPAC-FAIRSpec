(function(){var P$=Clazz.newPackage("com.actelion.research.chem.docking"),p$1={},I$=[[0,'java.util.Base64','StringBuilder','com.actelion.research.chem.Canonizer','com.actelion.research.chem.phesa.EncodeFunctions','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.IDCodeParserWithoutCoordinateInvention','com.actelion.research.chem.IDCodeParser','java.nio.charset.StandardCharsets','java.util.HashMap','com.actelion.research.chem.Molecule3D','com.actelion.research.chem.phesa.MolecularVolume','com.actelion.research.chem.Coordinates','com.actelion.research.chem.conf.Conformer','com.actelion.research.chem.alignment3d.transformation.TransformationSequence','com.actelion.research.chem.docking.receptorpharmacophore.NegativeReceptorImageCreator','com.actelion.research.chem.docking.shape.ShapeDocking','com.actelion.research.chem.io.pdb.converter.MoleculeGrid','java.util.HashSet',['com.actelion.research.chem.docking.DockingEngine','.ScoringFunction'],'com.actelion.research.chem.docking.scoring.ChemPLP','com.actelion.research.chem.docking.scoring.IdoScore','java.util.Random','com.actelion.research.chem.docking.LigandPose','com.actelion.research.chem.conf.ConformerSet','com.actelion.research.chem.forcefield.mmff.ForceFieldMMFF94','com.actelion.research.chem.forcefield.mmff.MMFFPositionConstraint','com.actelion.research.chem.mcs.MCS','com.actelion.research.chem.SSSearcher','java.util.ArrayList','com.actelion.research.chem.conf.ConformerSetGenerator','com.actelion.research.calc.Matrix','com.actelion.research.chem.alignment3d.KabschAlignment',['java.util.Map','.Entry'],'java.util.stream.Collectors','java.util.LinkedHashMap','com.actelion.research.chem.potentialenergy.PositionConstraint','com.actelion.research.chem.alignment3d.transformation.Translation',['com.actelion.research.chem.docking.DockingEngine','.DockingResult'],'com.actelion.research.chem.optimization.OptimizerLBFGS','com.actelion.research.chem.interactionstatistics.InteractionAtomTypeCalculator','com.actelion.research.chem.phesa.PheSAAlignment']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DockingEngine", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['ScoringFunction',25],['DockingResult',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['gridDimension'],'I',['mcSteps','startPositions'],'O',['rotation','com.actelion.research.chem.alignment3d.transformation.Rotation','origCOM','com.actelion.research.chem.Coordinates','random','java.util.Random','engine','com.actelion.research.chem.docking.scoring.AbstractScoringEngine','nativeLigand','com.actelion.research.chem.StereoMolecule','shapeDocking','com.actelion.research.chem.docking.shape.ShapeDocking','threadMaster','com.actelion.research.calc.ThreadMaster','mcsRef','com.actelion.research.chem.StereoMolecule','mcsConstrainedBonds','java.util.List','+mcsConstrainedAtoms']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$I$I$D$com_actelion_research_chem_docking_DockingEngine_ScoringFunction',  function (rec, nativeLig, mcSteps, startPositions, gridDimension, scoringFunction) {
;C$.$init$.apply(this);
for (var ra=0; ra < rec.getAtoms$(); ra++) {
if (rec.getImplicitHydrogens$I(ra) > 0) throw Clazz.new_(Clazz.load('com.actelion.research.chem.docking.DockingFailedException').c$$S,["please add hydrogen atoms to receptor structure!"]);
}
this.nativeLigand=Clazz.new_($I$(10,1).c$$com_actelion_research_chem_StereoMolecule,[nativeLig]);
this.nativeLigand.ensureHelperArrays$I(31);
var receptor=Clazz.new_($I$(10,1).c$$com_actelion_research_chem_StereoMolecule,[rec]);
receptor.ensureHelperArrays$I(31);
var molVol=Clazz.new_($I$(11,1).c$$com_actelion_research_chem_StereoMolecule,[this.nativeLigand]);
this.origCOM=Clazz.new_([molVol.getCOM$()],$I$(12,1).c$$com_actelion_research_chem_Coordinates);
var conf=Clazz.new_($I$(13,1).c$$com_actelion_research_chem_StereoMolecule,[this.nativeLigand]);
this.rotation=molVol.preProcess$com_actelion_research_chem_conf_Conformer(conf);
this.startPositions=startPositions;
p$1.preprocess$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule.apply(this, [receptor, this.nativeLigand]);
var transform=Clazz.new_($I$(14,1));
var bsVolume=$I$(15).create$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_alignment3d_transformation_TransformationSequence(this.nativeLigand, receptor, transform);
this.shapeDocking=Clazz.new_($I$(16,1).c$$com_actelion_research_chem_phesa_ShapeVolume$com_actelion_research_chem_alignment3d_transformation_Transformation,[bsVolume, transform]);
var grid=Clazz.new_([this.nativeLigand, 0.5, Clazz.new_($I$(12,1).c$$D$D$D,[gridDimension, gridDimension, gridDimension])],$I$(17,1).c$$com_actelion_research_chem_StereoMolecule$D$com_actelion_research_chem_Coordinates);
var bindingSiteAtoms=Clazz.new_($I$(18,1));
if (scoringFunction === $I$(19).CHEMPLP ) {
C$.getBindingSiteAtoms$com_actelion_research_chem_StereoMolecule$java_util_Set$com_actelion_research_chem_io_pdb_converter_MoleculeGrid$Z(receptor, bindingSiteAtoms, grid, true);
this.engine=Clazz.new_($I$(20,1).c$$com_actelion_research_chem_Molecule3D$java_util_Set$com_actelion_research_chem_io_pdb_converter_MoleculeGrid,[receptor, bindingSiteAtoms, grid]);
} else if (scoringFunction === $I$(19).IDOSCORE ) {
C$.getBindingSiteAtoms$com_actelion_research_chem_StereoMolecule$java_util_Set$com_actelion_research_chem_io_pdb_converter_MoleculeGrid$Z(receptor, bindingSiteAtoms, grid, false);
this.engine=Clazz.new_([receptor, bindingSiteAtoms, C$.getReceptorAtomTypes$com_actelion_research_chem_StereoMolecule(receptor), grid],$I$(21,1).c$$com_actelion_research_chem_StereoMolecule$java_util_Set$IA$com_actelion_research_chem_io_pdb_converter_MoleculeGrid);
}this.mcSteps=mcSteps;
this.random=Clazz.new_([$I$(23).SEED],$I$(22,1).c$$J);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$D',  function (receptor, nativeLigand, gridDimension) {
C$.c$$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$I$I$D$com_actelion_research_chem_docking_DockingEngine_ScoringFunction.apply(this, [receptor, nativeLigand, 50, 10, gridDimension, $I$(19).CHEMPLP]);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule',  function (receptor, nativeLigand) {
C$.c$$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$I$I$D$com_actelion_research_chem_docking_DockingEngine_ScoringFunction.apply(this, [receptor, nativeLigand, 50, 10, 6.0, $I$(19).CHEMPLP]);
}, 1);

Clazz.newMeth(C$, 'setThreadMaster$com_actelion_research_calc_ThreadMaster',  function (tm) {
this.threadMaster=tm;
this.shapeDocking.setThreadMaster$com_actelion_research_calc_ThreadMaster(tm);
});

Clazz.newMeth(C$, 'getStartingPositions$com_actelion_research_chem_StereoMolecule$java_util_List',  function (mol, initialPos) {
var eMin=1.7976931348623157E308;
var ffOptions=Clazz.new_($I$(9,1));
ffOptions.put$O$O("dielectric constant", Double.valueOf$D(80.0));
var confSet=Clazz.new_($I$(24,1));
var alignedMol=this.shapeDocking.dock$com_actelion_research_chem_StereoMolecule(mol);
alignedMol.stream$().forEach$java_util_function_Consumer(((P$.DockingEngine$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "DockingEngine$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$com_actelion_research_chem_StereoMolecule','accept$O'],  function (e) { return (this.$finals$.confSet.add$O.apply(this.$finals$.confSet, [Clazz.new_($I$(13,1).c$$com_actelion_research_chem_StereoMolecule,[e])]));});
})()
), Clazz.new_(P$.DockingEngine$lambda1.$init$,[this, {confSet:confSet}])));
for (var c, $c = confSet.iterator$(); $c.hasNext$()&&((c=($c.next$())),1);) {
if (c != null ) {
var conf=c.toMolecule$();
conf.ensureHelperArrays$I(15);
var mmff;
try {
mmff=Clazz.new_($I$(25,1).c$$com_actelion_research_chem_StereoMolecule$S$java_util_Map,[conf, "MMFF94s+", ffOptions]);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
throw Clazz.new_(Clazz.load('com.actelion.research.chem.docking.DockingFailedException').c$$S,["could not assess atom types"]);
} else {
throw e;
}
}
var constraint=Clazz.new_($I$(26,1).c$$com_actelion_research_chem_StereoMolecule$D$D,[conf, 50, 0.5]);
mmff.addEnergyTerm$com_actelion_research_chem_forcefield_mmff_EnergyTerm(constraint);
mmff.minimise$();
var ligConf=Clazz.new_($I$(13,1).c$$com_actelion_research_chem_StereoMolecule,[conf]);
initialPos.add$O(ligConf);
if (initialPos.size$() >= this.startPositions) break;
var e=mmff.getTotalEnergy$();
if (e < eMin ) eMin=e;
if (this.threadMaster != null  && this.threadMaster.threadMustDie$() ) break;
}}
return eMin;
}, p$1);

Clazz.newMeth(C$, 'getStartingPositionsMCS$com_actelion_research_chem_StereoMolecule$java_util_List',  function (mol, initialPos) {
var eMin=1.7976931348623157E308;
var rotBondsMol=mol.getRotatableBondCount$();
var rotBondsRef=this.nativeLigand.getRotatableBondCount$();
var mcs=Clazz.new_($I$(27,1));
var bondMCSMol=null;
var bondMCSFrag=null;
var isNativeLigFrag;
if (rotBondsMol > rotBondsRef) {
mcs.set$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule(mol, this.nativeLigand);
bondMCSMol=Clazz.array(Boolean.TYPE, [mol.getAllBonds$()]);
bondMCSFrag=Clazz.array(Boolean.TYPE, [this.nativeLigand.getAllBonds$()]);
isNativeLigFrag=true;
} else {
mcs.set$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule(mol, this.nativeLigand);
bondMCSMol=Clazz.array(Boolean.TYPE, [mol.getAllBonds$()]);
bondMCSFrag=Clazz.array(Boolean.TYPE, [this.nativeLigand.getAllBonds$()]);
isNativeLigFrag=false;
}var mcsMol=mcs.getMCS$();
var sss=Clazz.new_($I$(28,1));
sss.setFragment$com_actelion_research_chem_StereoMolecule(mcsMol);
sss.setMolecule$com_actelion_research_chem_StereoMolecule(this.nativeLigand);
sss.findFragmentInMolecule$I$I(4, 4);
var map1=sss.getMatchList$().get$I(0);
sss.setMolecule$com_actelion_research_chem_StereoMolecule(mol);
sss.findFragmentInMolecule$I$I(4, 4);
var map2=sss.getMatchList$().get$I(0);
this.mcsConstrainedAtoms=Clazz.new_($I$(29,1));
for (var a, $a = 0, $$a = map2; $a<$$a.length&&((a=($$a[$a])),1);$a++) {
this.mcsConstrainedAtoms.add$O(Integer.valueOf$I(a));
}
var map=Clazz.new_($I$(9,1));
for (var i=0; i < map1.length; i++) {
map.put$O$O(Integer.valueOf$I(map1[i]), Integer.valueOf$I(map2[i]));
}
mcs.getMCSBondArray$ZA$ZA(bondMCSMol, bondMCSFrag);
this.mcsConstrainedBonds=Clazz.new_($I$(29,1));
var bondArray=null;
if (isNativeLigFrag) bondArray=bondMCSMol;
 else bondArray=bondMCSFrag;
for (var b=0; b < bondArray.length; b++) {
if (bondArray[b]) this.mcsConstrainedBonds.add$O(Integer.valueOf$I(b));
}
$I$(25).initialize$S("MMFF94s+");
var ffOptions=Clazz.new_($I$(9,1));
ffOptions.put$O$O("dielectric constant", Double.valueOf$D(80.0));
var csGen=Clazz.new_($I$(30,1));
var confSet=csGen.generateConformerSet$com_actelion_research_chem_StereoMolecule(mol);
var confsWithRMSDs=Clazz.new_($I$(9,1));
for (var conf, $conf = confSet.iterator$(); $conf.hasNext$()&&((conf=($conf.next$())),1);) {
var coords1=Clazz.array($I$(12), [map1.length]);
var coords2=Clazz.array($I$(12), [map1.length]);
var counter=0;
for (var key, $key = map.keySet$().iterator$(); $key.hasNext$()&&((key=($key.next$()).intValue$()),1);) {
coords1[counter]=Clazz.new_([this.nativeLigand.getCoordinates$I(key)],$I$(12,1).c$$com_actelion_research_chem_Coordinates);
coords2[counter]=Clazz.new_([conf.getCoordinates$I((map.get$O(Integer.valueOf$I(key))).$c())],$I$(12,1).c$$com_actelion_research_chem_Coordinates);
++counter;
}
var mapping=Clazz.array(Integer.TYPE, [coords1.length, 2]);
counter=0;
for (var m, $m = 0, $$m = mapping; $m<$$m.length&&((m=($$m[$m])),1);$m++) {
m[0]=counter;
m[1]=counter;
++counter;
}
var trans1=Clazz.new_($I$(12,1));
var rot=Clazz.new_($I$(31,1).c$$I$I,[3, 3]);
var trans2=Clazz.new_($I$(12,1));
var alignment=Clazz.new_($I$(32,1).c$$com_actelion_research_chem_CoordinatesA$com_actelion_research_chem_CoordinatesA$IAA,[coords1, coords2, mapping]);
alignment.align$com_actelion_research_chem_Coordinates$com_actelion_research_calc_Matrix$com_actelion_research_chem_Coordinates(trans1, rot, trans2);
var rmsd=C$.getCoreRMSD$com_actelion_research_chem_CoordinatesA$com_actelion_research_chem_CoordinatesA(coords1, coords2);
for (var coord, $coord = 0, $$coord = conf.getCoordinates$(); $coord<$$coord.length&&((coord=($$coord[$coord])),1);$coord++) {
coord.add$com_actelion_research_chem_Coordinates(trans1);
coord.rotate$DAA(rot.getArray$());
coord.add$com_actelion_research_chem_Coordinates(trans2);
}
confsWithRMSDs.put$O$O(conf, Double.valueOf$D(rmsd));
}
var sortedConfs=confsWithRMSDs.entrySet$().stream$().sorted$java_util_Comparator($I$(33).comparingByValue$()).collect$java_util_stream_Collector($I$(34,"toMap$java_util_function_Function$java_util_function_Function$java_util_function_BinaryOperator$java_util_function_Supplier",[(function($$){((
(function(){/*m*/var C$=Clazz.newClass(P$, "DockingEngine$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_M*/
Clazz.newMeth(C$, 'apply$O',  function (t) { return t.getKey$.apply(t,[])});
})()
)); return Clazz.new_(P$.DockingEngine$lambda2.$init$,[this, null])})($I$(33)), (function($$){((
(function(){/*m*/var C$=Clazz.newClass(P$, "DockingEngine$lambda3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_M*/
Clazz.newMeth(C$, 'apply$O',  function (t) { return t.getValue$.apply(t,[])});
})()
)); return Clazz.new_(P$.DockingEngine$lambda3.$init$,[this, null])})($I$(33)), (P$.DockingEngine$lambda4$||(P$.DockingEngine$lambda4$=(((P$.DockingEngine$lambda4||
(function(){/*m*/var C$=Clazz.newClass(P$, "DockingEngine$lambda4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.BinaryOperator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$Double$Double','apply$O$O'],  function (e1, e2) { return (e1);});
})()
), Clazz.new_(P$.DockingEngine$lambda4.$init$,[this, null]))))), ((P$.DockingEngine$lambda5||
(function(){/*m*/var C$=Clazz.newClass(P$, "DockingEngine$lambda5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Supplier', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_C*/
Clazz.newMeth(C$, 'get$',  function () { return Clazz.new_($I$(35,1),[])});
})()
), Clazz.new_(P$.DockingEngine$lambda5.$init$,[this, null]))]));
var iterator=sortedConfs.entrySet$().iterator$();
var done=false;
var entry;
var c=0;
while (!done && c < this.startPositions * 3 ){
++c;
try {
entry=iterator.next$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
done=true;
continue;
} else {
throw e;
}
}
var conf=entry.getKey$();
var aligned=Clazz.new_($I$(5,1));
aligned=conf.toMolecule$com_actelion_research_chem_StereoMolecule(null);
aligned.ensureHelperArrays$I(15);
var mmff;
var constraint=Clazz.new_($I$(26,1).c$$com_actelion_research_chem_StereoMolecule$D$D,[aligned, 50, 0.2]);
mmff=Clazz.new_($I$(25,1).c$$com_actelion_research_chem_StereoMolecule$S$java_util_Map,[aligned, "MMFF94s+", ffOptions]);
mmff.addEnergyTerm$com_actelion_research_chem_forcefield_mmff_EnergyTerm(constraint);
mmff.minimise$();
var e=mmff.getTotalEnergy$();
for (var a=0; a < aligned.getAllAtoms$(); a++) {
conf.setCoordinates$I$com_actelion_research_chem_Coordinates(a, Clazz.new_([aligned.getCoordinates$I(a)],$I$(12,1).c$$com_actelion_research_chem_Coordinates));
}
initialPos.add$O(conf);
if (e < eMin ) eMin=e;
}
return eMin;
}, p$1);

Clazz.newMeth(C$, 'dockMolecule$com_actelion_research_chem_StereoMolecule',  function (mol) {
var bestPose=null;
var bestEnergy=1.7976931348623157E308;
if ($I$(25).table$S("MMFF94s+") == null ) $I$(25).initialize$S("MMFF94s+");
var startPoints=Clazz.new_($I$(29,1));
var eMin=0.0;
var steps=this.mcSteps;
if (this.mcsRef != null ) {
eMin=p$1.getStartingPositionsMCS$com_actelion_research_chem_StereoMolecule$java_util_List.apply(this, [mol, startPoints]);
steps=(steps/3|0);
} else {
eMin=p$1.getStartingPositions$com_actelion_research_chem_StereoMolecule$java_util_List.apply(this, [mol, startPoints]);
}var contributions=null;
for (var ligConf, $ligConf = startPoints.iterator$(); $ligConf.hasNext$()&&((ligConf=($ligConf.next$())),1);) {
var newLigConf=Clazz.new_($I$(13,1).c$$com_actelion_research_chem_conf_Conformer,[ligConf]);
var pose=p$1.initiate$com_actelion_research_chem_conf_Conformer$D.apply(this, [newLigConf, eMin]);
if (this.mcsRef != null ) {
pose.setMCSBondConstraints$java_util_List(this.mcsConstrainedBonds);
for (var a, $a = this.mcsConstrainedAtoms.iterator$(); $a.hasNext$()&&((a=($a.next$()).intValue$()),1);) {
var constr=Clazz.new_($I$(36,1).c$$com_actelion_research_chem_conf_Conformer$I$D$D,[newLigConf, a, 50, 1.0]);
pose.addConstraint$com_actelion_research_chem_potentialenergy_PositionConstraint(constr);
}
}var energy=p$1.mcSearch$com_actelion_research_chem_docking_LigandPose$I.apply(this, [pose, steps]);
if (energy < bestEnergy ) {
bestEnergy=pose.getScore$();
bestPose=pose.getLigConf$();
contributions=pose.getContributions$();
}if (this.threadMaster != null  && this.threadMaster.threadMustDie$() ) break;
}
if (bestPose != null ) {
var best=bestPose.toMolecule$();
var rot=this.rotation.getInvert$();
var translate=Clazz.new_([Clazz.array(Double.TYPE, -1, [this.origCOM.x, this.origCOM.y, this.origCOM.z])],$I$(37,1).c$$DA);
rot.apply$com_actelion_research_chem_StereoMolecule(best);
translate.apply$com_actelion_research_chem_StereoMolecule(best);
return Clazz.new_($I$(38,1).c$$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$D$java_util_Map,[mol, best, bestEnergy, contributions]);
} else {
throw Clazz.new_(Clazz.load('com.actelion.research.chem.docking.DockingFailedException').c$$S,["docking failed"]);
}});

Clazz.newMeth(C$, 'mcSearch$com_actelion_research_chem_docking_LigandPose$I',  function (pose, steps) {
var bestState=Clazz.array(Double.TYPE, [pose.getState$().length]);
var oldState=Clazz.array(Double.TYPE, [pose.getState$().length]);
var state=Clazz.array(Double.TYPE, [pose.getState$().length]);
var bestEnergy=-3.4028235E38;
var oldEnergy=-3.4028235E38;
var energy=-3.4028235E38;
var optimizer=Clazz.new_($I$(39,1).c$$I$D,[200, 0.001]);
oldState=optimizer.optimize$com_actelion_research_chem_optimization_Evaluable(pose);
bestState=oldState;
oldEnergy=pose.getFGValue$DA(Clazz.array(Double.TYPE, [bestState.length]));
bestEnergy=oldEnergy;
for (var i=0; i < steps; i++) {
pose.randomPerturbation$();
var energyMC=pose.getFGValue$DA(Clazz.array(Double.TYPE, [bestState.length]));
if (energyMC < 100.0 ) {
state=optimizer.optimize$com_actelion_research_chem_optimization_Evaluable(pose);
energy=pose.getFGValue$DA(Clazz.array(Double.TYPE, [bestState.length]));
} else {
state=pose.getState$();
energy=energyMC;
}if (energy < oldEnergy ) {
oldEnergy=energy;
oldState=state;
if (energy < bestEnergy ) {
bestEnergy=energy;
bestState=state;
}} else {
var dE=energy - oldEnergy;
var randNr=this.random.nextDouble$();
var probability=Math.exp(-dE / 1.2);
if (randNr < probability ) {
oldEnergy=energy;
oldState=state;
} else {
pose.setState$DA(oldState);
}}}
pose.setState$DA(bestState);
pose.removeConstraints$();
bestEnergy=pose.getScore$();
return bestEnergy;
}, p$1);

Clazz.newMeth(C$, 'initiate$com_actelion_research_chem_conf_Conformer$D',  function (ligConf, e0) {
var pose=Clazz.new_($I$(23,1).c$$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_docking_scoring_AbstractScoringEngine$D,[ligConf, this.engine, e0]);
return pose;
}, p$1);

Clazz.newMeth(C$, 'setMCSReference$com_actelion_research_chem_StereoMolecule',  function (referencePose) {
this.mcsRef=referencePose;
});

Clazz.newMeth(C$, 'getBindingSiteAtoms$com_actelion_research_chem_StereoMolecule$java_util_Set$com_actelion_research_chem_io_pdb_converter_MoleculeGrid$Z',  function (receptor, bindingSiteAtoms, grid, includeHydrogens) {
var gridSize=grid.getGridSize$();
var atoms=receptor.getAtoms$();
if (includeHydrogens) atoms=receptor.getAllAtoms$();
for (var i=0; i < atoms; i++) {
var gridC=grid.getGridCoordinates$com_actelion_research_chem_Coordinates(receptor.getCoordinates$I(i));
var x=gridC[0];
var y=gridC[1];
var z=gridC[2];
if (x > 0 && x < gridSize[0] ) {
if (y > 0 && y < gridSize[1] ) {
if (z > 0 && z < gridSize[2] ) {
bindingSiteAtoms.add$O(Integer.valueOf$I(i));
}}}}
}, 1);

Clazz.newMeth(C$, 'getReceptorAtomTypes$com_actelion_research_chem_StereoMolecule',  function (receptor) {
var receptorAtomTypes=Clazz.array(Integer.TYPE, [receptor.getAtoms$()]);
for (var i=0; i < receptor.getAtoms$(); i++) {
receptorAtomTypes[i]=$I$(40).getAtomType$com_actelion_research_chem_StereoMolecule$I(receptor, i);
}
return receptorAtomTypes;
}, 1);

Clazz.newMeth(C$, 'preprocess$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule',  function (receptor, ligand) {
var translate=Clazz.new_([Clazz.array(Double.TYPE, -1, [-this.origCOM.x, -this.origCOM.y, -this.origCOM.z])],$I$(37,1).c$$DA);
translate.apply$com_actelion_research_chem_StereoMolecule(ligand);
this.rotation.apply$com_actelion_research_chem_StereoMolecule(ligand);
translate.apply$com_actelion_research_chem_StereoMolecule(receptor);
this.rotation.apply$com_actelion_research_chem_StereoMolecule(receptor);
}, p$1);

Clazz.newMeth(C$, 'refineNativePose$D$DA',  function (d, coords) {
var ffOptions=Clazz.new_($I$(9,1));
ffOptions.put$O$O("dielectric constant", Double.valueOf$D(80.0));
if ($I$(25).table$S("MMFF94s+") == null ) $I$(25).initialize$S("MMFF94s+");
var nativePose=Clazz.new_($I$(10,1).c$$com_actelion_research_chem_StereoMolecule,[this.nativeLigand]);
Clazz.new_($I$(3,1).c$$com_actelion_research_chem_StereoMolecule,[nativePose]);
var mmff=Clazz.new_($I$(25,1).c$$com_actelion_research_chem_StereoMolecule$S$java_util_Map,[nativePose, "MMFF94s+", ffOptions]);
var constraint=Clazz.new_($I$(26,1).c$$com_actelion_research_chem_StereoMolecule$D$D,[nativePose, 50, 0.2]);
mmff.addEnergyTerm$com_actelion_research_chem_forcefield_mmff_EnergyTerm(constraint);
mmff.minimise$();
var confSetGen=Clazz.new_([100, 3, false, $I$(23).SEED],$I$(30,1).c$$I$I$Z$J);
var confSet=confSetGen.generateConformerSet$com_actelion_research_chem_StereoMolecule(nativePose);
var eMin=1.7976931348623157E308;
var initialPos=Clazz.new_($I$(24,1));
for (var conformer, $conformer = confSet.iterator$(); $conformer.hasNext$()&&((conformer=($conformer.next$())),1);) {
if (conformer != null ) {
var conf=conformer.toMolecule$();
conf.ensureHelperArrays$I(15);
mmff=Clazz.new_($I$(25,1).c$$com_actelion_research_chem_StereoMolecule$S$java_util_Map,[conf, "MMFF94s+", ffOptions]);
constraint=Clazz.new_($I$(26,1).c$$com_actelion_research_chem_StereoMolecule$D$D,[conf, 50, 0.5]);
mmff.addEnergyTerm$com_actelion_research_chem_forcefield_mmff_EnergyTerm(constraint);
mmff.minimise$();
var ligConf=Clazz.new_($I$(13,1).c$$com_actelion_research_chem_StereoMolecule,[conf]);
initialPos.add$O(ligConf);
if (initialPos.size$() >= this.startPositions) break;
var e=mmff.getTotalEnergy$();
if (e < eMin ) eMin=e;
}}
var pose=Clazz.new_([Clazz.new_($I$(13,1).c$$com_actelion_research_chem_StereoMolecule,[nativePose]), this.engine, eMin],$I$(23,1).c$$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_docking_scoring_AbstractScoringEngine$D);
pose.addPositionalConstraints$D(d);
var optimizer=Clazz.new_($I$(39,1).c$$I$D,[200, 0.001]);
optimizer.optimize$com_actelion_research_chem_optimization_Evaluable(pose);
var energy=pose.getFGValue$DA(Clazz.array(Double.TYPE, [pose.getState$().length]));
var best=pose.getLigConf$().toMolecule$();
var rot=this.rotation.getInvert$().getRotation$();
$I$(41).rotateMol$com_actelion_research_chem_StereoMolecule$DAA(best, rot);
$I$(41,"translateMol$com_actelion_research_chem_StereoMolecule$DA",[best, Clazz.array(Double.TYPE, -1, [this.origCOM.x, this.origCOM.y, this.origCOM.z])]);
for (var a=0; a < best.getAllAtoms$(); a++) {
coords[3 * a]=best.getAtomX$I(a);
coords[3 * a + 1]=best.getAtomY$I(a);
coords[3 * a + 2]=best.getAtomZ$I(a);
}
return energy;
});

Clazz.newMeth(C$, 'getCoreRMSD$com_actelion_research_chem_CoordinatesA$com_actelion_research_chem_CoordinatesA',  function (coords1, coords2) {
var rmsd=0.0;
for (var i=0; i < coords1.length; i++) {
var c1=coords1[i];
var c2=coords2[i];
rmsd+=c1.distanceSquared$com_actelion_research_chem_Coordinates(c2);
}
rmsd/=coords1.length;
rmsd=Math.sqrt(rmsd);
return rmsd;
}, 1);
;
(function(){/*e*/var C$=Clazz.newClass(P$.DockingEngine, "ScoringFunction", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "CHEMPLP", 0, []);
Clazz.newEnumConst($vals, C$.c$, "IDOSCORE", 1, []);
};

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.DockingEngine, "DockingResult", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, 'Comparable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['score'],'O',['input','com.actelion.research.chem.StereoMolecule','+pose','contributions','java.util.Map']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$D$java_util_Map',  function (input, pose, score, contributions) {
;C$.$init$.apply(this);
this.score=score;
this.pose=pose;
this.contributions=contributions;
this.input=input;
}, 1);

Clazz.newMeth(C$, 'setInput$com_actelion_research_chem_StereoMolecule',  function (input) {
this.input=input;
});

Clazz.newMeth(C$, 'getInput$',  function () {
return this.input;
});

Clazz.newMeth(C$, 'getScore$',  function () {
return this.score;
});

Clazz.newMeth(C$, 'getPose$',  function () {
return this.pose;
});

Clazz.newMeth(C$, 'getContributions$',  function () {
return this.contributions;
});

Clazz.newMeth(C$, 'encode$',  function () {
var encoder=$I$(1).getEncoder$();
var sb=Clazz.new_($I$(2,1));
var can=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_StereoMolecule$I,[this.pose, 64]);
var idcoords=can.getEncodedCoordinates$Z(true);
var idcode=can.getIDCode$();
sb.append$S(idcode);
sb.append$S(";");
sb.append$S(idcoords);
sb.append$S(";");
sb.append$S(this.input.getIDCode$());
sb.append$S(";");
sb.append$S(encoder.encodeToString$BA($I$(4).doubleToByteArray$D(this.score)));
sb.append$S(";");
if (this.contributions == null  || this.contributions.keySet$().size$() == 0 ) sb.append$S("#");
 else {
for (var name, $name = this.contributions.keySet$().iterator$(); $name.hasNext$()&&((name=($name.next$())),1);) {
sb.append$S(name);
sb.append$S("%");
sb.append$S(encoder.encodeToString$BA($I$(4,"doubleToByteArray$D",[(this.contributions.get$O(name)).valueOf()])));
sb.append$S(":");
}
sb.setLength$I(sb.length$() - 1);
}return sb.toString();
});

Clazz.newMeth(C$, 'decode$S',  function (resultString) {
var decoder=$I$(1).getDecoder$();
var s=resultString.split$S(";");
var idcode=s[0];
var idcoords=s[1];
var pose=Clazz.new_($I$(5,1));
var parser=Clazz.new_($I$(6,1));
parser.parse$com_actelion_research_chem_StereoMolecule$S$S(pose, idcode, idcoords);
pose.ensureHelperArrays$I(31);
var idcodeInput=s[2];
var input=Clazz.new_($I$(5,1));
Clazz.new_($I$(7,1)).parse$com_actelion_research_chem_StereoMolecule$S(input, idcodeInput);
var score=$I$(4,"byteArrayToDouble$BA",[decoder.decode$BA(s[3].getBytes$java_nio_charset_Charset($I$(8).UTF_8))]);
var contributions=null;
if (!s[4].equals$O("#")) {
contributions=Clazz.new_($I$(9,1));
var splitted=s[4].split$S(":");
for (var contr, $contr = 0, $$contr = splitted; $contr<$$contr.length&&((contr=($$contr[$contr])),1);$contr++) {
var splitted2=contr.split$S("%");
var name=splitted2[0];
var value=$I$(4,"byteArrayToDouble$BA",[decoder.decode$BA(splitted2[1].getBytes$java_nio_charset_Charset($I$(8).UTF_8))]);
contributions.put$O$O(name, Double.valueOf$D(value));
}
}var dockingResult=Clazz.new_(C$.c$$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$D$java_util_Map,[input, pose, score, contributions]);
return dockingResult;
}, 1);

Clazz.newMeth(C$, ['compareTo$com_actelion_research_chem_docking_DockingEngine_DockingResult','compareTo$O'],  function (o) {
if (Double.isNaN$D(this.score) && Double.isNaN$D(o.score) ) {
return 0;
}if (Double.isNaN$D(this.score)) {
return -1;
}if (Double.isNaN$D(o.score)) {
return 1;
}return Double.compare$D$D(this.score, o.score);
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:53 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
