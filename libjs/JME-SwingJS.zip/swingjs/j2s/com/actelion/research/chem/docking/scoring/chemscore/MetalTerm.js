(function(){var P$=Clazz.newPackage("com.actelion.research.chem.docking.scoring.chemscore"),p$1={},I$=[[0,'com.actelion.research.chem.Coordinates','java.util.ArrayList']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MetalTerm", null, null, 'com.actelion.research.chem.potentialenergy.PotentialEnergyTerm');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['scale'],'I',['acceptor','metal'],'O',['ligand','com.actelion.research.chem.conf.Conformer','fitPoint','com.actelion.research.chem.Coordinates','acceptorNeighbours','int[]','receptor','com.actelion.research.chem.conf.Conformer']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_conf_Conformer$I$com_actelion_research_chem_conf_Conformer$I$IA$com_actelion_research_chem_Coordinates$D',  function (ligand, acceptor, receptor, metal, acceptorNeighbours, fitPoint, scale) {
;C$.$init$.apply(this);
this.ligand=ligand;
this.acceptor=acceptor;
this.acceptor=acceptor;
this.acceptorNeighbours=acceptorNeighbours;
this.fitPoint=fitPoint;
this.scale=scale;
this.metal=metal;
this.receptor=receptor;
}, 1);

Clazz.newMeth(C$, 'getFitPoint$',  function () {
return this.fitPoint;
});

Clazz.newMeth(C$, 'setFitPoint$com_actelion_research_chem_Coordinates',  function (fitPoint) {
this.fitPoint=fitPoint;
});

Clazz.newMeth(C$, 'create$com_actelion_research_chem_conf_Conformer$I$com_actelion_research_chem_conf_Conformer$I$IA$com_actelion_research_chem_Coordinates$D',  function (ligand, acceptor, receptor, metal, acceptorNeighbours, fitPoint, scale) {
return Clazz.new_(C$.c$$com_actelion_research_chem_conf_Conformer$I$com_actelion_research_chem_conf_Conformer$I$IA$com_actelion_research_chem_Coordinates$D,[ligand, acceptor, receptor, metal, acceptorNeighbours, fitPoint, scale]);
}, 1);

Clazz.newMeth(C$, 'getDistTerm$DA',  function (gradient) {
var a;
var grad=Clazz.new_($I$(1,1));
var energy=0.0;
a=this.ligand.getCoordinates$I(this.acceptor);
var r=a.subC$com_actelion_research_chem_Coordinates(this.fitPoint);
var rSq=r.distSq$();
if (rSq < 0.64 ) {
var d=Math.sqrt(rSq);
if (d < 0.6 ) {
energy=1.0;
} else if (d > 0.8 ) {
energy=0.0;
} else {
var prefactor=-4.999999999999998 * (1.0 / d);
grad=r.scaleC$D(prefactor);
gradient[3 * this.acceptor]+=grad.x;
gradient[3 * this.acceptor + 1]+=grad.y;
gradient[3 * this.acceptor + 2]+=grad.z;
energy=(0.8 - d) / (0.20000000000000007);
}}return energy;
}, p$1);

Clazz.newMeth(C$, 'getAngleTerm$DA$I$I$D$D$D',  function (gradient, a1, a2, x0, x1, x2) {
var energy=0.0;
var c1;
var c2;
var c3;
c1=this.ligand.getCoordinates$I(a1);
c2=this.ligand.getCoordinates$I(a2);
c3=this.receptor.getCoordinates$I(this.metal);
var r0=c1.subC$com_actelion_research_chem_Coordinates(c2).unit$();
var r1=c3.subC$com_actelion_research_chem_Coordinates(c2).unit$();
var dist0=c2.distance$com_actelion_research_chem_Coordinates(c1);
var dist1=c3.distance$com_actelion_research_chem_Coordinates(c2);
var cosTheta=r0.cosAngle$com_actelion_research_chem_Coordinates(r1);
var angleTerm=Math.acos(cosTheta) - x0;
var invert=false;
if (angleTerm < 0 ) {
angleTerm=-angleTerm;
invert=true;
}if (angleTerm < x1 ) energy=1.0;
 else if (angleTerm > x2 ) energy=0.0;
 else {
var prefactor=-1.0 / (x2 - x1);
if (invert) {
prefactor=-prefactor;
}energy=(x2 - angleTerm) / (x2 - x1);
var sinThetaSq=1.0 - cosTheta * cosTheta;
var sinTheta=1.0E-8;
if (sinThetaSq > 0.0 ) sinTheta=Math.sqrt(sinThetaSq);
var dCos_dS=Clazz.array(Double.TYPE, -1, [1.0 / dist0 * (r1.x - cosTheta * r0.x), 1.0 / dist0 * (r1.y - cosTheta * r0.y), 1.0 / dist0 * (r1.z - cosTheta * r0.z), 1.0 / dist1 * (r0.x - cosTheta * r1.x), 1.0 / dist1 * (r0.y - cosTheta * r1.y), 1.0 / dist1 * (r0.z - cosTheta * r1.z)]);
gradient[3 * a1]+=prefactor * dCos_dS[0] / (-sinTheta);
gradient[3 * a1 + 1]+=prefactor * dCos_dS[1] / (-sinTheta);
gradient[3 * a1 + 2]+=prefactor * dCos_dS[2] / (-sinTheta);
gradient[3 * a2]+=prefactor * (-dCos_dS[0] - dCos_dS[3]) / (-sinTheta);
gradient[3 * a2 + 1]+=prefactor * (-dCos_dS[1] - dCos_dS[4]) / (-sinTheta);
gradient[3 * a2 + 2]+=prefactor * (-dCos_dS[2] - dCos_dS[5]) / (-sinTheta);
}return energy;
}, p$1);

Clazz.newMeth(C$, 'getFGValue$DA',  function (gradient) {
var energies=Clazz.new_($I$(2,1));
var gradients=Clazz.new_($I$(2,1));
var energy=0.0;
var grad=Clazz.array(Double.TYPE, [gradient.length]);
energy=p$1.getDistTerm$DA.apply(this, [grad]);
var totEnergy=0.0;
if (energy != 0.0 ) {
energies.add$O(Double.valueOf$D(energy));
gradients.add$O(grad);
for (var aa, $aa = 0, $$aa = this.acceptorNeighbours; $aa<$$aa.length&&((aa=($$aa[$aa])),1);$aa++) {
grad=Clazz.array(Double.TYPE, [gradient.length]);
energy=p$1.getAngleTerm$DA$I$I$D$D$D.apply(this, [gradient, aa, this.acceptor, 3.141592653589793, 1.3962634015954636, 1.5707963267948966]);
energies.add$O(Double.valueOf$D(energy));
gradients.add$O(grad);
}
var totGrad=Clazz.array(Double.TYPE, [gradient.length]);
totEnergy=this.scale * -6.0;
for (var eng, $eng = energies.iterator$(); $eng.hasNext$()&&((eng=($eng.next$()).objectValue$()),1);) totEnergy*=eng;

for (var i=0; i < gradients.size$(); i++) {
var g=gradients.get$I(i);
for (var j=0; j < gradients.size$(); j++) {
if (i == j) continue;
var e=(energies.get$I(j)).valueOf();
var w=e * this.scale * -6.0 ;
for (var k=0; k < g.length; k++) g[k]*=w;

}
for (var l=0; l < totGrad.length; l++) {
totGrad[l]+=g[l];
}
}
for (var i=0; i < totGrad.length; i++) {
gradient[i]+=totGrad[i];
}
}return totEnergy;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:06 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
