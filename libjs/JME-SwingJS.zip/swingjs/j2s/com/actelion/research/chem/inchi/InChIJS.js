(function(){var P$=Clazz.newPackage("com.actelion.research.chem.inchi"),p$1={},I$=[[0,'com.actelion.research.chem.MolfileCreator','org.iupac.InchiUtils']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InChIJS", null, 'com.actelion.research.chem.inchi.InChIOCL', 'org.iupac.InChIStructureProvider');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['atoms','java.util.List','+bonds','+stereo','thisAtom','java.util.Map','+thisBond','+thisStereo']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'initAndRun$Runnable',  function (r) {

if (!J2S) { alert("J2S has not been installed");
System.exit(0);
} var t = [];
t[0] = setInterval( function(){ if (J2S.inchiWasmLoaded && J2S.inchiWasmLoaded()) { clearInterval(t[0]);
r.run$();
} }, 50);
});

Clazz.newMeth(C$, 'implementsMolDataOnlyToInChI$',  function () {
return true;
});

Clazz.newMeth(C$, 'getInchiImpl$com_actelion_research_chem_StereoMolecule$S$S',  function (mol, molFileDataOrInChI, options) {
if (options.equals$O("version")) {
{
return (J2S.modelFromInchi ? J2S.modelFromInchi('').ver : "");
}
}options=options.replace$C$C("-", " ").replaceAll$S$S("\\s+", " ").trim$().replaceAll$S$S(" ", " -").toLowerCase$();
if (options.length$() > 0) options="-" + options;
if (mol != null ) molFileDataOrInChI=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_ExtendedMolecule,[mol]).getMolfile$();
var isLoaded=(p$1.execute$S$S$S$S.apply(this, ["inchiFromInchi", null, null, null]) != null );
if (!isLoaded) return "";
var inchi=(this.isInputInChI ? molFileDataOrInChI : p$1.execute$S$S$S$S.apply(this, ["inchiFromMolfile", molFileDataOrInChI, options, (this.getAuxInfo ? "auxinfo" : "inchi")]));
return (this.getInchiModel ? p$1.execute$S$S$S$S.apply(this, ["modelFromInchi", inchi, options, "model"]) : this.getKey ? p$1.execute$S$S$S$S.apply(this, ["inchikeyFromInchi", inchi, options, "inchikey"]) : this.isInputInChI ? p$1.execute$S$S$S$S.apply(this, ["inchiFromInchi", inchi, options, "inchi"]) : inchi);
});

Clazz.newMeth(C$, 'execute$S$S$S$S',  function (method, data, options, key) {
{
return(key == null ? J2S[method] : J2S[method](data, options)[key] || null);
}
}, p$1);

Clazz.newMeth(C$, 'initializeInchiModel$S',  function (inchi) {

var json = JSON.parse(J2S.modelFromInchi(inchi).model); this.atoms = json.atoms; this.bonds = json.bonds; this.stereo = (json.stereo || []);
});

Clazz.newMeth(C$, 'getNumAtoms$',  function () {
{
return this.atoms.length;
}
});

Clazz.newMeth(C$, 'setAtom$I',  function (i) {
{
this.thisAtom = this.atoms[i];
}
return this;
});

Clazz.newMeth(C$, 'getElementType$',  function () {
return p$1.getString$java_util_Map$S$S.apply(this, [this.thisAtom, "elname", ""]);
});

Clazz.newMeth(C$, 'getX$',  function () {
return p$1.getDouble$java_util_Map$S$D.apply(this, [this.thisAtom, "x", 0]);
});

Clazz.newMeth(C$, 'getY$',  function () {
return p$1.getDouble$java_util_Map$S$D.apply(this, [this.thisAtom, "y", 0]);
});

Clazz.newMeth(C$, 'getZ$',  function () {
return p$1.getDouble$java_util_Map$S$D.apply(this, [this.thisAtom, "z", 0]);
});

Clazz.newMeth(C$, 'getCharge$',  function () {
return p$1.getInt$java_util_Map$S$I.apply(this, [this.thisAtom, "charge", 0]);
});

Clazz.newMeth(C$, 'getImplicitH$',  function () {
return p$1.getInt$java_util_Map$S$I.apply(this, [this.thisAtom, "implicitH", 0]);
});

Clazz.newMeth(C$, 'getIsotopicMass$',  function () {
var sym=this.getElementType$();
var mass=0;
{
mass = this.thisAtom["isotopicMass"] || 0;
}
return $I$(2).getActualMass$S$I(sym, mass);
});

Clazz.newMeth(C$, 'getNumBonds$',  function () {
{
return this.bonds.length;
}
});

Clazz.newMeth(C$, 'setBond$I',  function (i) {
{
this.thisBond = this.bonds[i];
}
return this;
});

Clazz.newMeth(C$, 'getIndexOriginAtom$',  function () {
return p$1.getInt$java_util_Map$S$I.apply(this, [this.thisBond, "originAtom", 0]);
});

Clazz.newMeth(C$, 'getIndexTargetAtom$',  function () {
return p$1.getInt$java_util_Map$S$I.apply(this, [this.thisBond, "targetAtom", 0]);
});

Clazz.newMeth(C$, 'getInchiBondType$',  function () {
return p$1.getString$java_util_Map$S$S.apply(this, [this.thisBond, "type", "SINGLE"]);
});

Clazz.newMeth(C$, 'getNumStereo0D$',  function () {
{
return this.stereo.length;
}
});

Clazz.newMeth(C$, 'setStereo0D$I',  function (i) {
{
this.thisStereo = this.stereo[i];
}
return this;
});

Clazz.newMeth(C$, 'getParity$',  function () {
return p$1.getString$java_util_Map$S$S.apply(this, [this.thisStereo, "parity", ""]);
});

Clazz.newMeth(C$, 'getStereoType$',  function () {
return p$1.getString$java_util_Map$S$S.apply(this, [this.thisStereo, "type", ""]);
});

Clazz.newMeth(C$, 'getCenterAtom$',  function () {
return p$1.getInt$java_util_Map$S$I.apply(this, [this.thisStereo, "centralAtom", -1]);
});

Clazz.newMeth(C$, 'getNeighbors$',  function () {
{
return this.thisStereo.neighbors;
}
});

Clazz.newMeth(C$, 'getInt$java_util_Map$S$I',  function (map, name, defaultValue) {
{
var val = map[name]; if (val || val == 0) return val;
}
return defaultValue;
}, p$1);

Clazz.newMeth(C$, 'getDouble$java_util_Map$S$D',  function (map, name, defaultValue) {
{
var val = map[name]; if (val || val == 0) return val;
}
return defaultValue;
}, p$1);

Clazz.newMeth(C$, 'getString$java_util_Map$S$S',  function (map, name, defaultValue) {
{
var val = map[name]; if (val || val == "") return val;
}
return defaultValue;
}, p$1);

C$.$static$=function(){C$.$static$=0;
{
try {
{
var j2sPath = J2S._applets.master._j2sFullPath;
J2S.inchiPath = J2S._applets.master._j2sFullPath + "/_ES6";
$.getScript(J2S.inchiPath +   "/inchi-web-SwingJS.js");
}
} catch (t) {
}
};
};
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-21 17:35:28 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
