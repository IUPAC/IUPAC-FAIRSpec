(function(){var P$=Clazz.newPackage("com.actelion.research.calc"),I$=[[0,'java.util.ArrayList','java.util.Collections','java.util.Arrays','java.awt.Point','com.actelion.research.util.datamodel.ScorePoint','com.actelion.research.util.convert.String2DoubleArray','com.actelion.research.calc.LUDecomposition','com.actelion.research.util.DoubleVec','com.actelion.research.util.datamodel.IntegerDouble','StringBuilder','java.text.DecimalFormat','java.text.DecimalFormatSymbols','java.util.Locale','java.io.File','java.io.FileOutputStream','java.io.ByteArrayOutputStream','java.util.Base64','java.io.ObjectOutputStream','java.io.FileInputStream','java.io.ObjectInputStream','java.io.BufferedWriter','java.io.FileWriter','StringBuffer']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Matrix");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['identifier'],'O',['data','double[][]']]
,['D',['TINY16'],'S',['OUT_SEPARATOR_COL','OUT_SEPARATOR_ROW']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.data=Clazz.array(Double.TYPE, [1, 1]);
}, 1);

Clazz.newMeth(C$, 'c$$I$I',  function (rows, cols) {
;C$.$init$.apply(this);
this.data=Clazz.array(Double.TYPE, [rows, cols]);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_calc_Matrix',  function (ma) {
C$.c$$DAA.apply(this, [ma.getArray$()]);
}, 1);

Clazz.newMeth(C$, 'c$$Z$DA',  function (row, arr) {
;C$.$init$.apply(this);
if (row) {
this.data=Clazz.array(Double.TYPE, [1, null]);
this.data[0]=arr;
} else {
this.data=Clazz.array(Double.TYPE, [arr.length, 1]);
for (var i=0; i < this.getRowDim$(); i++) {
this.data[i][0]=arr[i];
}
}}, 1);

Clazz.newMeth(C$, 'c$$Z$BA',  function (row, arr) {
;C$.$init$.apply(this);
if (row) {
this.data=Clazz.array(Double.TYPE, [1, arr.length]);
for (var i=0; i < arr.length; i++) {
this.data[0][i]=arr[i];
}
} else {
this.data=Clazz.array(Double.TYPE, [arr.length, 1]);
for (var i=0; i < this.getRowDim$(); i++) {
this.data[i][0]=arr[i];
}
}}, 1);

Clazz.newMeth(C$, 'c$$Z$IA',  function (row, dArray) {
;C$.$init$.apply(this);
if (row) {
this.data=Clazz.array(Double.TYPE, [1, dArray.length]);
for (var jj=0; jj < this.getColDim$(); jj++) {
this.data[0][jj]=dArray[jj];
}
} else {
this.data=Clazz.array(Double.TYPE, [dArray.length, 1]);
for (var ii=0; ii < this.getRowDim$(); ii++) {
this.data[ii][0]=dArray[ii];
}
}}, 1);

Clazz.newMeth(C$, 'c$$DAA',  function (arrArr) {
;C$.$init$.apply(this);
this.data=Clazz.array(Double.TYPE, [arrArr.length, null]);
var rows=arrArr.length;
var cols=arrArr[0].length;
for (var i=0; i < rows; i++) {
var arr=Clazz.array(Double.TYPE, [cols]);
System.arraycopy$O$I$O$I$I(arrArr[i], 0, arr, 0, cols);
this.data[i]=arr;
}
}, 1);

Clazz.newMeth(C$, 'c$$DAA$Z',  function (arrArr, flat) {
;C$.$init$.apply(this);
if (!flat) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Only flat constructor!"]);
}this.data=arrArr;
}, 1);

Clazz.newMeth(C$, 'c$$FAA',  function (arrArr) {
;C$.$init$.apply(this);
this.data=Clazz.array(Double.TYPE, [arrArr.length, arrArr[0].length]);
var rows=arrArr.length;
var cols=arrArr[0].length;
for (var i=0; i < rows; i++) {
var arr=Clazz.array(Double.TYPE, [cols]);
for (var j=0; j < arr.length; j++) {
this.data[i][j]=arrArr[i][j];
}
}
}, 1);

Clazz.newMeth(C$, 'c$$IAA',  function (arrArr) {
;C$.$init$.apply(this);
this.data=Clazz.array(Double.TYPE, [arrArr.length, null]);
var rows=arrArr.length;
var cols=arrArr[0].length;
for (var i=0; i < rows; i++) {
var arr=Clazz.array(Double.TYPE, [cols]);
for (var j=0; j < cols; j++) {
arr[j]=arrArr[i][j];
}
this.data[i]=arr;
}
}, 1);

Clazz.newMeth(C$, 'c$$BAA',  function (arrArr) {
;C$.$init$.apply(this);
this.data=Clazz.array(Double.TYPE, [arrArr.length, null]);
var rows=arrArr.length;
var cols=arrArr[0].length;
for (var i=0; i < rows; i++) {
var arr=Clazz.array(Double.TYPE, [cols]);
System.arraycopy$O$I$O$I$I(arrArr[i], 0, arr, 0, cols);
this.data[i]=arr;
}
}, 1);

Clazz.newMeth(C$, 'c$$java_util_List',  function (vecDoubleVec) {
;C$.$init$.apply(this);
var dv=vecDoubleVec.get$I(0);
this.data=Clazz.array(Double.TYPE, [vecDoubleVec.size$(), dv.size$()]);
for (var ii=0; ii < this.getRowDim$(); ii++) {
dv=vecDoubleVec.get$I(ii);
for (var jj=0; jj < this.getColDim$(); jj++) {
this.data[ii][jj]=dv.get$I(jj);
}
}
}, 1);

Clazz.newMeth(C$, 'c$$Z$java_util_List',  function (bRow, liDoubles) {
;C$.$init$.apply(this);
if (bRow) {
this.data=Clazz.array(Double.TYPE, [1, liDoubles.size$()]);
for (var i=0; i < this.getColDim$(); i++) {
this.data[0][i]=(liDoubles.get$I(i)).valueOf();
}
} else {
this.data=Clazz.array(Double.TYPE, [liDoubles.size$(), 1]);
for (var i=0; i < this.getRowDim$(); i++) {
this.data[i][0]=(liDoubles.get$I(i)).valueOf();
}
}}, 1);

Clazz.newMeth(C$, 'add$D',  function (v) {
var r=this.rows$();
var c=this.cols$();
var A=Clazz.new_(C$.c$$I$I,[r, c]);
for (var i=0; i < r; i++) {
for (var j=0; j < c; j++) {
var s=this.get$I$I(i, j) + v;
A.set$I$I$D(i, j, s);
}
}
return A;
});

Clazz.newMeth(C$, 'addRow$DA',  function (arr) {
if (this.getColDim$() != arr.length) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Matrices have wrong dimensions."]);
}this.resize$I$I(this.getRowDim$() + 1, this.getColDim$());
for (var ii=0; ii < arr.length; ii++) this.data[this.getRowDim$() - 1][ii]=arr[ii];

});

Clazz.newMeth(C$, 'addRow$IA',  function (arr) {
if (this.getColDim$() != arr.length) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Matrices have wrong dimensions."]);
}this.resize$I$I(this.getRowDim$() + 1, this.getColDim$());
for (var ii=0; ii < arr.length; ii++) this.data[this.getRowDim$() - 1][ii]=arr[ii];

});

Clazz.newMeth(C$, 'add2Row$I$com_actelion_research_calc_Matrix$I',  function (row, ma2, row2) {
for (var ii=0; ii < this.getColDim$(); ii++) this.data[row][ii]+=ma2.data[row2][ii];

});

Clazz.newMeth(C$, 'addToElement$I$I$D',  function (i, j, value) {
this.data[i][j]+=value;
});

Clazz.newMeth(C$, 'add2CompleteCol$com_actelion_research_calc_Matrix',  function (maRow) {
var m=Clazz.new_(C$.c$$com_actelion_research_calc_Matrix,[this]);
for (var ii=0; ii < this.getRowDim$(); ii++) for (var jj=0; jj < this.getColDim$(); jj++) m.data[ii][jj]+=maRow.data[0][jj];


return m;
});

Clazz.newMeth(C$, 'assignCol$I$com_actelion_research_calc_Matrix',  function (iCol, ma) {
if (this.getRowDim$() != ma.getRowDim$()) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Matrices have wrong dimensions."]);
}for (var ii=0; ii < this.data.length; ii++) {
this.data[ii][iCol]=ma.data[ii][0];
}
});

Clazz.newMeth(C$, 'assignCol$I$com_actelion_research_calc_Matrix$I',  function (iCol, ma, iColMa) {
if (this.getRowDim$() != ma.getRowDim$()) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Matrices have wrong dimensions."]);
}for (var ii=0; ii < this.data.length; ii++) {
this.data[ii][iCol]=ma.data[ii][iColMa];
}
});

Clazz.newMeth(C$, 'assignRow$I$java_util_Vector',  function (iRow, vecRow) {
if (this.getColDim$() != vecRow.size$()) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Matrix and Vector have wrong dimensions."]);
}for (var jj=0; jj < this.data[0].length; jj++) {
this.data[iRow][jj]=(vecRow.get$I(jj)).valueOf();
}
});

Clazz.newMeth(C$, 'assignRow$I$DA',  function (iRow, arr) {
if (this.getColDim$() != arr.length) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Matrix and Vector have wrong dimensions."]);
}for (var jj=0; jj < arr.length; jj++) {
this.data[iRow][jj]=arr[jj];
}
});

Clazz.newMeth(C$, 'assignRow$I$IA',  function (iRow, arr) {
if (this.getColDim$() != arr.length) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Matrix and Vector have wrong dimensions."]);
}for (var jj=0; jj < arr.length; jj++) {
this.data[iRow][jj]=arr[jj];
}
});

Clazz.newMeth(C$, 'assignRow$I$com_actelion_research_util_DoubleVec',  function (iRow, dv) {
if (this.getColDim$() != dv.size$()) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Matrix and Vector have wrong dimensions."]);
}for (var jj=0; jj < dv.size$(); jj++) {
this.data[iRow][jj]=dv.get$I(jj);
}
});

Clazz.newMeth(C$, 'containsRow$com_actelion_research_util_DoubleVec',  function (dv) {
var bOK=false;
var iRows=this.getRowDim$();
var iCols=this.getColDim$();
for (var ii=0; ii < iRows; ii++) {
bOK=true;
for (var jj=0; jj < iCols; jj++) if (this.data[ii][jj] != dv.get$I(jj) ) {
bOK=false;
break;
}
if (bOK) break;
}
return bOK;
});

Clazz.newMeth(C$, 'copy$com_actelion_research_calc_Matrix',  function (maSource) {
var rows=maSource.rows$();
var cols=maSource.cols$();
if (this.rows$() == rows && this.cols$() == cols ) {
for (var i=0; i < rows; i++) {
System.arraycopy$O$I$O$I$I(maSource.data[i], 0, this.data[i], 0, cols);
}
} else {
this.data=Clazz.array(Double.TYPE, [rows, null]);
for (var i=0; i < rows; i++) {
var a=Clazz.array(Double.TYPE, [cols]);
System.arraycopy$O$I$O$I$I(maSource.data[i], 0, a, 0, cols);
this.data[i]=a;
}
}});

Clazz.newMeth(C$, 'copy$I$com_actelion_research_calc_Matrix',  function (offsetRows, maSource) {
if (this.cols$() != maSource.cols$()) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Matrix col dimension error. Number of cols differ!"]);
}var cols=this.cols$();
var r=maSource.rows$();
for (var i=0; i < r; i++) {
System.arraycopy$O$I$O$I$I(maSource.data[i], 0, this.data[offsetRows + i], 0, cols);
}
});

Clazz.newMeth(C$, 'copyColumn$com_actelion_research_calc_Matrix$I$I',  function (maSource, colSource, colDestination) {
var rows=maSource.rows$();
for (var i=0; i < rows; i++) {
this.data[i][colDestination]=maSource.get$I$I(i, colSource);
}
});

Clazz.newMeth(C$, 'get$I$I',  function (row, col) {
return this.data[row][col];
});

Clazz.newMeth(C$, 'getAbs$',  function () {
var ma=Clazz.new_(C$.c$$I$I,[this.getRowDim$(), this.getColDim$()]);
for (var ii=0; ii < this.getRowDim$(); ii++) {
for (var jj=0; jj < this.getColDim$(); jj++) {
ma.data[ii][jj]=Math.abs(this.data[ii][jj]);
}
}
return ma;
});

Clazz.newMeth(C$, 'getArray$',  function () {
return this.data;
});

Clazz.newMeth(C$, 'getArrayAsInt$',  function () {
var arr=Clazz.array(Integer.TYPE, [this.data.length, this.data[0].length]);
for (var ii=0; ii < this.getRowDim$(); ii++) {
for (var jj=0; jj < this.getColDim$(); jj++) {
if (this.data[ii][jj] > 2147483647  || this.data[ii][jj] < -2147483648  ) {
var err="Double value instead of int " + new Double(this.data[ii][jj]).toString() + "." ;
throw Clazz.new_(Clazz.load('NumberFormatException').c$$S,[err]);
}arr[ii][jj]=(this.data[ii][jj]|0);
}
}
return arr;
});

Clazz.newMeth(C$, 'getArrayCopy$',  function () {
var arr=Clazz.array(Double.TYPE, [this.data.length, this.data[0].length]);
for (var ii=0; ii < this.getRowDim$(); ii++) {
for (var jj=0; jj < this.getColDim$(); jj++) {
arr[ii][jj]=this.data[ii][jj];
}
}
return arr;
});

Clazz.newMeth(C$, 'getCenteredMatrix$',  function () {
var cols=this.cols$();
var rows=this.rows$();
var arr=Clazz.array(Double.TYPE, [rows, null]);
var maMean=this.getMeanCols$();
var arrMean=maMean.getRow$I(0);
for (var i=0; i < rows; i++) {
var arrRowSrc=this.getRow$I(i);
var arrRow=Clazz.array(Double.TYPE, [cols]);
System.arraycopy$O$I$O$I$I(arrRowSrc, 0, arrRow, 0, arrRowSrc.length);
for (var j=0; j < cols; j++) {
arrRow[j]=arrRow[j] - arrMean[j];
}
arr[i]=arrRow;
}
var ma=Clazz.new_(C$);
ma.setFlat$DAA(arr);
return ma;
});

Clazz.newMeth(C$, 'getCenteredMatrix$com_actelion_research_calc_Matrix',  function (maMean) {
var ma=Clazz.new_(C$.c$$I$I,[this.getRowDim$(), this.getColDim$()]);
for (var i=0; i < this.rows$(); i++) {
for (var j=0; j < this.cols$(); j++) {
ma.data[i][j]=this.data[i][j] - maMean.data[0][j];
}
}
return ma;
});

Clazz.newMeth(C$, 'getCol$I',  function (col) {
var ma=Clazz.new_(C$.c$$I$I,[this.rows$(), 1]);
var iRows=this.getRowDim$();
for (var i=0; i < iRows; i++) {
ma.data[i][0]=this.data[i][col];
}
return ma;
});

Clazz.newMeth(C$, 'removeCol$I',  function (col2Remove) {
var r=this.rows$();
var c=this.cols$();
var ma=Clazz.new_(C$.c$$I$I,[r, c - 1]);
for (var i=0; i < r; i++) {
var ccColNew=0;
for (var j=0; j < c; j++) {
if (j != col2Remove) {
ma.data[i][ccColNew++]=this.data[i][j];
}}
}
return ma;
});

Clazz.newMeth(C$, 'getColAsDouble$I',  function (col) {
var arr=Clazz.array(Double.TYPE, [this.rows$()]);
for (var i=0; i < this.rows$(); i++) {
arr[i]=this.data[i][col];
}
return arr;
});

Clazz.newMeth(C$, 'getColAsList$I',  function (col) {
var li=Clazz.new_([this.rows$()],$I$(1,1).c$$I);
for (var i=0; i < this.rows$(); i++) {
li.add$O(Double.valueOf$D(this.data[i][col]));
}
return li;
});

Clazz.newMeth(C$, 'getColAsFloat$I',  function (iCol) {
var arr=Clazz.array(Float.TYPE, [this.rows$()]);
for (var i=0; i < this.rows$(); i++) {
arr[i]=this.data[i][iCol];
}
return arr;
});

Clazz.newMeth(C$, 'getColAsInt$I',  function (iCol) {
var arr=Clazz.array(Integer.TYPE, [this.rows$()]);
for (var i=0; i < this.rows$(); i++) {
arr[i]=((this.data[i][iCol] + 0.5)|0);
}
return arr;
});

Clazz.newMeth(C$, 'getColumns$java_util_Vector',  function (vecIndices) {
var maReduced=Clazz.new_(C$.c$$I$I,[this.getRowDim$(), vecIndices.size$()]);
for (var i=0; i < vecIndices.size$(); i++) {
var col=(vecIndices.get$I(i)).$c();
maReduced.assignCol$I$com_actelion_research_calc_Matrix$I(i, this, col);
}
return maReduced;
});

Clazz.newMeth(C$, 'getColumns$java_util_List',  function (liIndex) {
var maReduced=Clazz.new_(C$.c$$I$I,[this.getRowDim$(), liIndex.size$()]);
for (var i=0; i < liIndex.size$(); i++) {
var col=(liIndex.get$I(i)).$c();
maReduced.assignCol$I$com_actelion_research_calc_Matrix$I(i, this, col);
}
return maReduced;
});

Clazz.newMeth(C$, 'getColumns$IA',  function (arrIndex) {
var maReduced=Clazz.new_(C$.c$$I$I,[this.getRowDim$(), arrIndex.length]);
for (var i=0; i < arrIndex.length; i++) {
var col=arrIndex[i];
maReduced.assignCol$I$com_actelion_research_calc_Matrix$I(i, this, col);
}
return maReduced;
});

Clazz.newMeth(C$, 'getColDim$',  function () {
return this.data[0].length;
});

Clazz.newMeth(C$, 'cols$',  function () {
return this.data[0].length;
});

Clazz.newMeth(C$, 'getDeleteColsZeroVar$java_util_List',  function (vecIndices) {
vecIndices.clear$();
var maReduced=Clazz.new_(C$.c$$I$I,[0, 0]);
var maVar=this.getVarianceCols$();
vecIndices.clear$();
for (var ii=0; ii < maVar.getColDim$(); ii++) {
if (maVar.get$I$I(0, ii) > 0 ) {
vecIndices.add$O( new Integer(ii));
}}
maReduced=this.getColumns$java_util_List(vecIndices);
return maReduced;
});

Clazz.newMeth(C$, 'covariance$',  function () {
var n=this.getColDim$();
var m=this.getRowDim$();
var X=Clazz.new_(C$.c$$I$I,[n, n]);
var degrees=(m - 1);
var c;
var s1;
var s2;
for (var i=0; i < n; i++) {
for (var j=0; j < n; j++) {
c=0;
s1=0;
s2=0;
for (var k=0; k < m; k++) {
s1+=this.get$I$I(k, i);
s2+=this.get$I$I(k, j);
}
s1=s1 / m;
s2=s2 / m;
for (var k=0; k < m; k++) {
c+=(this.get$I$I(k, i) - s1) * (this.get$I$I(k, j) - s2);
}
X.set$I$I$D(i, j, c / degrees);
}
}
return X;
});

Clazz.newMeth(C$, 'correlation$',  function () {
var n=this.getColDim$();
var m=this.getRowDim$();
var X=Clazz.new_(C$.c$$I$I,[n, n]);
var degrees=(m - 1);
var V=Clazz.new_(C$.c$$I$I,[n, n]);
var c;
var s1;
var s2;
for (var i=0; i < n; i++) {
for (var j=0; j < n; j++) {
c=0;
s1=0;
s2=0;
for (var k=0; k < m; k++) {
s1+=this.get$I$I(k, i);
s2+=this.get$I$I(k, j);
}
s1=s1 / m;
s2=s2 / m;
for (var k=0; k < m; k++) {
c+=(this.get$I$I(k, i) - s1) * (this.get$I$I(k, j) - s2);
}
V.set$I$I$D(i, j, c / degrees);
}
}
for (var i=0; i < n; i++) {
for (var j=0; j < n; j++) {
X.set$I$I$D(i, j, V.get$I$I(i, j) / Math.sqrt(V.get$I$I(i, i) * V.get$I$I(j, j)));
}
}
return X;
});

Clazz.newMeth(C$, 'getDiagonal$',  function () {
var n=Math.min(this.getRowDim$(), this.getColDim$());
var ma=Clazz.new_(C$.c$$I$I,[n, 1]);
for (var i=0; i < n; i++) {
ma.set$I$I$D(i, 0, this.data[i][i]);
}
return ma;
});

Clazz.newMeth(C$, 'getLinedCol$',  function () {
var ma=Clazz.new_(C$.c$$I$I,[this.getNumElements$(), 1]);
var ind=0;
for (var i=0; i < this.getRowDim$(); i++) {
for (var j=0; j < this.getColDim$(); j++) {
ma.data[ind][0]=this.data[i][j];
++ind;
}
}
return ma;
});

Clazz.newMeth(C$, 'getList$',  function () {
var li=Clazz.new_([this.getRowDim$() * this.getColDim$()],$I$(1,1).c$$I);
for (var i=0; i < this.getRowDim$(); i++) {
for (var j=0; j < this.getColDim$(); j++) {
li.add$O(Double.valueOf$D(this.data[i][j]));
}
}
return li;
});

Clazz.newMeth(C$, 'getMatrix$I$I$I$I',  function (i0, i1, j0, j1) {
var X=Clazz.new_(C$.c$$I$I,[i1 - i0 + 1, j1 - j0 + 1]);
var B=X.getArray$();
try {
for (var i=i0; i <= i1; i++) {
for (var j=j0; j <= j1; j++) {
B[i - i0][j - j0]=this.data[i][j];
}
}
} catch (e) {
if (Clazz.exceptionOf(e,"ArrayIndexOutOfBoundsException")){
throw Clazz.new_(Clazz.load('ArrayIndexOutOfBoundsException').c$$S,["Submatrix indices"]);
} else {
throw e;
}
}
return X;
});

Clazz.newMeth(C$, 'getMatrix$IA$IA',  function (r, c) {
var X=Clazz.new_(C$.c$$I$I,[r.length, c.length]);
var B=X.getArray$();
try {
for (var i=0; i < r.length; i++) {
for (var j=0; j < c.length; j++) {
B[i][j]=this.data[r[i]][c[j]];
}
}
} catch (e) {
if (Clazz.exceptionOf(e,"ArrayIndexOutOfBoundsException")){
throw Clazz.new_(Clazz.load('ArrayIndexOutOfBoundsException').c$$S,["Submatrix indices"]);
} else {
throw e;
}
}
return X;
});

Clazz.newMeth(C$, 'getMatrix$I$I$IA',  function (i0, i1, c) {
var X=Clazz.new_(C$.c$$I$I,[i1 - i0 + 1, c.length]);
var B=X.getArray$();
try {
for (var i=i0; i <= i1; i++) {
for (var j=0; j < c.length; j++) {
B[i - i0][j]=this.data[i][c[j]];
}
}
} catch (e) {
if (Clazz.exceptionOf(e,"ArrayIndexOutOfBoundsException")){
throw Clazz.new_(Clazz.load('ArrayIndexOutOfBoundsException').c$$S,["Submatrix indices"]);
} else {
throw e;
}
}
return X;
});

Clazz.newMeth(C$, 'getMatrix$IA$I$I',  function (r, j0, j1) {
var X=Clazz.new_(C$.c$$I$I,[r.length, j1 - j0 + 1]);
var B=X.getArray$();
try {
for (var i=0; i < r.length; i++) {
for (var j=j0; j <= j1; j++) {
B[i][j - j0]=this.data[r[i]][j];
}
}
} catch (e) {
if (Clazz.exceptionOf(e,"ArrayIndexOutOfBoundsException")){
throw Clazz.new_(Clazz.load('ArrayIndexOutOfBoundsException').c$$S,["Submatrix indices"]);
} else {
throw e;
}
}
return X;
});

Clazz.newMeth(C$, 'getNumElements$',  function () {
return this.cols$() * this.rows$();
});

Clazz.newMeth(C$, 'getNumElementsLarger$D',  function (val2Compare) {
var ind=0;
for (var i=0; i < this.rows$(); i++) {
for (var j=0; j < this.cols$(); j++) {
if (this.data[i][j] > val2Compare ) ++ind;
}
}
return ind;
});

Clazz.newMeth(C$, 'getNumElementsEqual$D',  function (val2Compare) {
var ind=0;
for (var i=0; i < this.rows$(); i++) {
for (var j=0; j < this.cols$(); j++) {
if (this.data[i][j] == val2Compare ) ++ind;
}
}
return ind;
});

Clazz.newMeth(C$, 'log$',  function () {
var maResult=Clazz.new_(C$.c$$I$I,[this.getRowDim$(), this.getColDim$()]);
for (var i=0; i < this.rows$(); i++) {
for (var j=0; j < this.cols$(); j++) {
if (this.data[i][j] > 0 ) {
maResult.data[i][j]=Math.log(this.data[i][j]);
} else {
maResult.data[i][j]=0.0;
}}
}
return maResult;
});

Clazz.newMeth(C$, 'diagonalize$',  function () {
var maResult=Clazz.new_(C$);
if ((this.getRowDim$() > 1) && (this.cols$() == 1) ) {
maResult.resize$I$I(this.rows$(), this.rows$());
for (var i=0; i < maResult.rows$(); i++) {
maResult.data[i][i]=this.data[i][0];
}
} else if ((this.cols$() > 1) && (this.rows$() == 1) ) {
maResult.resize$I$I(this.cols$(), this.cols$());
for (var i=0; i < maResult.cols$(); i++) {
maResult.data[i][i]=this.data[0][i];
}
}return maResult;
});

Clazz.newMeth(C$, 'devide$D',  function (dDivisor) {
var maResult=Clazz.new_(C$.c$$I$I,[this.getRowDim$(), this.getColDim$()]);
for (var i=0; i < this.getRowDim$(); i++) {
for (var j=0; j < this.getColDim$(); j++) {
maResult.data[i][j]=this.data[i][j] / dDivisor;
}
}
return maResult;
});

Clazz.newMeth(C$, 'devide$com_actelion_research_calc_Matrix',  function (maDivisor) {
var maResult=Clazz.new_(C$.c$$I$I,[this.getRowDim$(), this.getColDim$()]);
for (var i=0; i < this.getRowDim$(); i++) {
for (var j=0; j < this.getColDim$(); j++) {
maResult.data[i][j]=this.data[i][j] / maDivisor.data[i][j];
}
}
return maResult;
});

Clazz.newMeth(C$, 'devideDivisorBigger$com_actelion_research_calc_Matrix',  function (maDivisor) {
var maResult=Clazz.new_(C$.c$$I$I,[this.getRowDim$(), this.getColDim$()]);
for (var i=0; i < this.getRowDim$(); i++) {
for (var j=0; j < this.getColDim$(); j++) {
if (this.data[i][j] < maDivisor.data[i][j] ) {
maResult.data[i][j]=this.data[i][j] / maDivisor.data[i][j];
} else {
maResult.data[i][j]=maDivisor.data[i][j] / this.data[i][j];
}}
}
return maResult;
});

Clazz.newMeth(C$, 'devideCols$com_actelion_research_calc_Matrix',  function (maDivisor) {
var maResult=Clazz.new_(C$.c$$I$I,[this.getRowDim$(), this.getColDim$()]);
for (var i=0; i < this.getRowDim$(); i++) {
for (var j=0; j < this.getColDim$(); j++) {
maResult.data[i][j]=this.data[i][j] / maDivisor.get$I$I(0, j);
}
}
return maResult;
});

Clazz.newMeth(C$, 'devideRow$I$D',  function (row, denominator) {
for (var j=0; j < this.getColDim$(); j++) {
this.data[row][j]/=denominator;
}
});

Clazz.newMeth(C$, 'getEigenvector$com_actelion_research_calc_Matrix$I$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix',  function (A, n, D, E) {
var l;
var k;
var j;
var i;
var scale;
var hh;
var h;
var g;
var f;
var a=A.toArray$();
var d=Clazz.array(Double.TYPE, [n]);
var e=Clazz.array(Double.TYPE, [n]);
var cols=n;
for (i=n - 1; i >= 1; i--) {
l=i;
h=scale=0.0;
if (l > 0) {
for (k=0; k < l; k++) scale+=Math.abs(a[i * cols + k]);

if (scale == 0.0 ) e[i]=a[i * cols + l - 1];
 else {
for (k=0; k < l; k++) {
a[i * cols + k]/=scale;
h+=a[i * cols + k] * a[i * cols + k];
}
f=a[i * cols + l - 1];
g=(f >= 0.0  ? -Math.sqrt(h) : Math.sqrt(h));
e[i]=scale * g;
h-=f * g;
a[i * cols + l - 1]=f - g;
f=0.0;
for (j=0; j < l; j++) {
a[j * cols + i]=a[i * cols + j] / h;
g=0.0;
for (k=0; k < j + 1; k++) g+=a[j * cols + k] * a[i * cols + k];

for (k=j + 1; k < l; k++) g+=a[k * cols + j] * a[i * cols + k];

e[j]=g / h;
f+=e[j] * a[i * cols + j];
}
hh=f / (h + h);
for (j=0; j < l; j++) {
f=a[i * cols + j];
e[j]=g=e[j] - hh * f;
for (k=0; k < j + 1; k++) a[j * cols + k]-=(f * e[k] + g * a[i * cols + k]);

}
}} else e[i]=a[i * cols + l - 1];
d[i]=h;
}
d[0]=0.0;
e[0]=0.0;
for (i=0; i < n; i++) {
l=i;
if (d[i] != 0 ) {
for (j=0; j < l; j++) {
g=0.0;
for (k=0; k < l; k++) g+=a[i * cols + k] * a[k * cols + j];

for (k=0; k < l; k++) a[k * cols + j]-=g * a[k * cols + i];

}
}d[i]=a[i * cols + i];
a[i * cols + i]=1.0;
for (j=0; j < l; j++) a[j * cols + i]=a[i * cols + j]=0.0;

}
var m;
var iter;
var s;
var r;
var p;
var dd;
var c;
var b;
for (i=1; i < n; i++) e[i - 1]=e[i];

e[n - 1]=0.0;
for (l=0; l < n; l++) {
iter=0;
do {
for (m=l; m <= n - 2; m++) {
dd=Math.abs(d[m]) + Math.abs(d[m + 1]);
if ((Math.abs(e[m]) + dd) == dd ) break;
}
if (m != l) {
if (iter++ == 30) System.err.println$S("Too many iterations in tqli");
g=(d[l + 1] - d[l]) / (2.0 * e[l]);
r=C$.getPythag$D$D(g, 1.0);
g=d[m] - d[l] + e[l] / (g + C$.Sign$D$D(r, g));
s=c=1.0;
p=0.0;
for (i=m - 1; i >= l; i--) {
f=s * e[i];
b=c * e[i];
e[i + 1]=(r=C$.getPythag$D$D(f, g));
if (r == 0.0 ) {
d[i + 1]-=p;
e[m]=0.0;
break;
}s=f / r;
c=g / r;
g=d[i + 1] - p;
r=(d[i] - g) * s + 2.0 * c * b ;
d[i + 1]=g + (p=s * r);
g=c * r - b;
for (k=0; k < n; k++) {
f=a[k * cols + i + 1];
a[k * cols + i + 1]=s * a[k * cols + i] + c * f;
a[k * cols + i]=c * a[k * cols + i] - s * f;
}
}
if (r == 0.0  && i >= l ) continue;
d[l]-=p;
e[l]=g;
e[m]=0.0;
}} while (m != l);
}
for (var o=0; o < A.rows$(); o++) {
for (var q=0; q < A.cols$(); q++) {
A.set$I$I$D(o, q, a[o * n + q]);
}
}
D.resize$I$I(n, 1);
D.setCol$I$DA(0, d);
E.resize$I$I(n, 1);
E.setCol$I$DA(0, e);
return;
}, 1);

Clazz.newMeth(C$, 'getMinRow$I',  function (row) {
var val=1.7976931348623157E308;
for (var i=0; i < this.getColDim$(); i++) {
if (this.data[row][i] < val ) {
val=this.data[row][i];
}}
return val;
});

Clazz.newMeth(C$, 'getMinRowIndex$I',  function (row) {
var index=0;
var min=1.7976931348623157E308;
for (var i=0; i < this.getColDim$(); i++) {
if (this.data[row][i] < min ) {
min=this.data[row][i];
index=i;
}}
return index;
});

Clazz.newMeth(C$, 'getMinRowIndexRND$I',  function (row) {
var indexMin=0;
var list=Clazz.new_($I$(1,1));
for (var i=0; i < this.getColDim$(); i++) {
list.add$O( new Integer(i));
}
$I$(2).shuffle$java_util_List(list);
var arrIndex=Clazz.array(Integer.TYPE, [this.getColDim$()]);
for (var i=0; i < arrIndex.length; i++) {
arrIndex[i]=(list.get$I(i)).intValue$();
}
var min=1.7976931348623157E308;
for (var i=0; i < this.getColDim$(); i++) {
var ind=arrIndex[i];
if (this.data[row][ind] < min ) {
min=this.data[row][ind];
indexMin=ind;
}}
return indexMin;
});

Clazz.newMeth(C$, 'getID$',  function () {
return this.identifier;
});

Clazz.newMeth(C$, 'getEuclideanDistanceFastRows$I$com_actelion_research_calc_Matrix$I',  function (iRow, A, iRowA) {
var distance=0;
var cols=this.cols$();
for (var i=0; i < cols; i++) {
distance+=(this.data[iRow][i] - A.data[iRowA][i]) * (this.data[iRow][i] - A.data[iRowA][i]);
}
return distance;
});

Clazz.newMeth(C$, 'getEuclideanDistanceFastRows$I$I',  function (row1, row2) {
var distance=0;
var cols=this.cols$();
for (var i=0; i < cols; i++) {
distance+=(this.data[row1][i] - this.data[row2][i]) * (this.data[row1][i] - this.data[row2][i]);
}
return distance;
});

Clazz.newMeth(C$, 'getMaximumValue$',  function () {
var max=4.9E-324;
for (var i=0; i < this.data.length; i++) {
for (var j=0; j < this.data[0].length; j++) {
if (max < this.data[i][j] ) max=this.data[i][j];
}
}
return max;
});

Clazz.newMeth(C$, 'getMean$',  function () {
var cols=this.getColDim$();
var rows=this.getRowDim$();
var mean=this.getSum$() / (cols * rows);
return mean;
});

Clazz.newMeth(C$, 'getMeanCols$',  function () {
var cols=this.cols$();
var rows=this.rows$();
var a=Clazz.array(Double.TYPE, [cols]);
for (var i=0; i < rows; i++) {
var arrRow=this.data[i];
for (var j=0; j < arrRow.length; j++) {
a[j]+=arrRow[j];
}
}
for (var i=0; i < cols; i++) {
a[i]/=rows;
}
return Clazz.new_(C$.c$$Z$DA,[true, a]);
});

Clazz.newMeth(C$, 'getMeanCols$IA',  function (rowIndex) {
var ma=Clazz.new_(C$.c$$I$I,[1, this.getColDim$()]);
var cols=this.getColDim$();
for (var j=0; j < cols; j++) {
ma.data[0][j]=this.getMeanCol$I$IA(j, rowIndex);
}
return ma;
});

Clazz.newMeth(C$, 'getMeanCol$I',  function (col) {
var rows=this.rows$();
var sum=0;
for (var i=0; i < rows; i++) {
sum+=this.data[i][col];
}
return sum / rows;
});

Clazz.newMeth(C$, 'getMeanRow$I',  function (row) {
var iCols=this.getColDim$();
var dMean=0;
for (var i=0; i < iCols; i++) {
dMean+=this.data[row][i];
}
return dMean / iCols;
});

Clazz.newMeth(C$, 'getMeanRows$',  function () {
var ma=Clazz.new_(C$.c$$I$I,[1, this.getRowDim$()]);
var iRows=this.getRowDim$();
for (var i=0; i < iRows; i++) {
ma.set$I$I$D(0, i, this.getMeanRow$I(i));
}
return ma;
});

Clazz.newMeth(C$, 'getMeanCol$I$IA',  function (iColIndex, rowIndex) {
var iRows=this.getRowDim$();
var dMean=0;
for (var ii=0; ii < rowIndex.length; ii++) {
dMean+=this.data[rowIndex[ii]][iColIndex];
}
return dMean / iRows;
});

Clazz.newMeth(C$, 'getMedian$I',  function (row) {
var arr=this.getRowCopy$I(row);
$I$(3).sort$DA(arr);
var median=0;
var len=arr.length;
if (len % 2 != 0) {
median=arr[(len/2|0)];
} else {
var ind=(((len / 2.0) + 0.5)|0);
median=(arr[ind] + arr[ind - 1]) / 2.0;
}return median;
});

Clazz.newMeth(C$, 'getMedian$',  function () {
var nRows=this.rows$();
var nCols=this.cols$();
var arr=Clazz.array(Double.TYPE, [nRows * nCols]);
var k=0;
for (var i=0; i < nRows; i++) {
for (var j=0; j < nCols; j++) {
arr[k++]=this.get$I$I(i, j);
}
}
$I$(3).sort$DA(arr);
var median=0;
var len=arr.length;
if (len % 2 != 0) {
median=arr[(len/2|0)];
} else {
var ind=(((len / 2.0) + 0.5)|0);
median=(arr[ind] + arr[ind - 1]) / 2.0;
}return median;
});

Clazz.newMeth(C$, 'getMedianCols$',  function () {
var maMedian=Clazz.new_(C$.c$$I$I,[1, this.cols$()]);
var rows=this.rows$();
var cols=this.cols$();
var arr=Clazz.array(Double.TYPE, [rows]);
for (var i=0; i < cols; i++) {
for (var j=0; j < rows; j++) {
arr[j]=this.get$I$I(j, i);
}
$I$(3).sort$DA(arr);
var median=0;
var len=arr.length;
if (len % 2 != 0) {
median=arr[(len/2|0)];
} else {
var ind=(((len / 2.0) + 0.5)|0);
median=(arr[ind] + arr[ind - 1]) / 2.0;
}maMedian.set$I$I$D(0, i, median);
}
return maMedian;
});

Clazz.newMeth(C$, 'getMergeRows$com_actelion_research_calc_Matrix',  function (ma) {
var maMerge=Clazz.new_(C$.c$$I$I,[this.getRowDim$() + ma.getRowDim$(), this.getColDim$()]);
for (var i=0; i < this.getRowDim$(); i++) {
for (var j=0; j < this.getColDim$(); j++) {
maMerge.data[i][j]=this.data[i][j];
}
}
var iRow=this.getRowDim$();
for (var ii=0; ii < ma.getRowDim$(); ii++) {
for (var jj=0; jj < this.getColDim$(); jj++) {
maMerge.data[iRow + ii][jj]=ma.data[ii][jj];
}
}
return maMerge;
});

Clazz.newMeth(C$, 'getMaxMin$',  function () {
var maMaxMin=Clazz.new_(C$.c$$I$I,[2, this.getColDim$()]);
var cols=this.getColDim$();
for (var i=0; i < cols; i++) {
maMaxMin.set$I$I$D(1, i, this.getMin$I(i));
maMaxMin.set$I$I$D(0, i, this.getMax$I(i));
}
return maMaxMin;
});

Clazz.newMeth(C$, 'getMax$',  function () {
var rows=this.getRowDim$();
var cols=this.getColDim$();
var dMax=-1.7976931348623157E308;
for (var i=0; i < rows; i++) for (var j=0; j < cols; j++) if (this.data[i][j] > dMax ) dMax=this.data[i][j];


return dMax;
});

Clazz.newMeth(C$, 'getMax$I',  function (col) {
var iRows=this.getRowDim$();
var max=-1.7976931348623157E308;
for (var i=0; i < iRows; i++) {
if (this.data[i][col] > max ) max=this.data[i][col];
}
return max;
});

Clazz.newMeth(C$, 'getMaxIndex$',  function () {
var p=Clazz.new_($I$(4,1).c$$I$I,[0, 0]);
var rows=this.rows$();
var cols=this.cols$();
var max=this.data[0][0];
for (var i=0; i < rows; i++) {
for (var j=0; j < cols; j++) {
if (this.data[i][j] > max ) {
max=this.data[i][j];
p.y=i;
p.x=j;
}}
}
return p;
});

Clazz.newMeth(C$, 'getMaxRow$I',  function (row) {
var max=-1.7976931348623157E308;
for (var i=0; i < this.getColDim$(); i++) {
if (this.data[row][i] > max ) max=this.data[row][i];
}
return max;
});

Clazz.newMeth(C$, 'getMaxRowIndexRND$I',  function (row) {
var indexMax=0;
var list=Clazz.new_($I$(1,1));
for (var i=0; i < this.cols$(); i++) {
list.add$O(Integer.valueOf$I(i));
}
$I$(2).shuffle$java_util_List(list);
var arrIndex=Clazz.array(Integer.TYPE, [this.getColDim$()]);
for (var i=0; i < arrIndex.length; i++) {
arrIndex[i]=(list.get$I(i)).intValue$();
}
var max=-1.7976931348623157E308;
for (var i=0; i < this.getColDim$(); i++) {
var ind=arrIndex[i];
if (this.data[row][ind] > max ) {
max=this.data[row][ind];
indexMax=ind;
}}
return indexMax;
});

Clazz.newMeth(C$, 'getMaxRowIndex$I',  function (col) {
var row=-1;
var max=-1.7976931348623157E308;
for (var i=0; i < this.rows$(); i++) {
if (this.data[i][col] > max ) {
max=this.data[i][col];
row=i;
}}
return row;
});

Clazz.newMeth(C$, 'getMin$',  function () {
var rows=this.getRowDim$();
var cols=this.getColDim$();
var min=1.7976931348623157E308;
for (var i=0; i < rows; i++) for (var j=0; j < cols; j++) if (this.data[i][j] < min ) min=this.data[i][j];


return min;
});

Clazz.newMeth(C$, 'getMinPos$',  function () {
var rows=this.getRowDim$();
var cols=this.getColDim$();
var td=Clazz.new_($I$(5,1));
td.setScore$D(1.7976931348623157E308);
for (var i=0; i < rows; i++) for (var j=0; j < cols; j++) if (this.data[i][j] < td.getScore$() ) {
td.y=i;
td.x=j;
td.setScore$D(this.data[i][j]);
}

return td;
});

Clazz.newMeth(C$, 'getMinRows$',  function () {
var rows=this.getRowDim$();
var cols=this.getColDim$();
var ma=Clazz.new_(C$.c$$I$I,[rows, 1]);
for (var i=0; i < rows; i++) {
var dMin=1.7976931348623157E308;
for (var j=0; j < cols; j++) if (this.data[i][j] < dMin ) dMin=this.data[i][j];

ma.set$I$I$D(i, 0, dMin);
}
return ma;
});

Clazz.newMeth(C$, 'getMinRowsPosCol$',  function () {
var rows=this.getRowDim$();
var cols=this.getColDim$();
var ma=Clazz.new_(C$.c$$I$I,[rows, 2]);
for (var i=0; i < rows; i++) {
var dMin=1.7976931348623157E308;
for (var j=0; j < cols; j++) if (this.data[i][j] < dMin ) {
ma.set$I$I$D(i, 0, j);
ma.set$I$I$D(i, 1, this.data[i][j]);
}
}
return ma;
});

Clazz.newMeth(C$, 'getMin$I',  function (col) {
var rows=this.getRowDim$();
var min=1.7976931348623157E308;
for (var i=0; i < rows; i++) {
if (this.data[i][col] < min ) min=this.data[i][col];
}
return min;
});

Clazz.newMeth(C$, 'getMinColIndex$I',  function (row) {
var cols=this.getColDim$();
var min=1.7976931348623157E308;
var ind=-1;
for (var i=0; i < cols; i++) {
if (this.data[row][i] < min ) {
min=this.data[row][i];
ind=i;
}}
return ind;
});

Clazz.newMeth(C$, 'getColIndexContainingMaxVal$I',  function (row) {
var cols=this.getColDim$();
var max=-1.7976931348623157E308;
var col=-1;
for (var i=0; i < cols; i++) {
if (this.data[row][i] > max ) {
max=this.data[row][i];
col=i;
}}
return col;
});

Clazz.newMeth(C$, 'getColIndexContainingMaxVal$I$I',  function (rowEnd, colEnd) {
var cols=colEnd;
var rows=rowEnd;
var max=-1.7976931348623157E308;
var rowMax=-1;
var colMax=-1;
for (var i=0; i < cols; i++) {
var maxInCol=-1.7976931348623157E308;
var rowMaxInCol=-1;
for (var j=0; j < rows; j++) {
if (this.data[j][i] > maxInCol ) {
maxInCol=this.data[j][i];
rowMaxInCol=j;
}}
if (maxInCol > max ) {
max=maxInCol;
rowMax=rowMaxInCol;
colMax=i;
}}
var sc=Clazz.new_($I$(5,1).c$$I$I,[rowMax, colMax]);
sc.setScore$D(max);
return sc;
});

Clazz.newMeth(C$, 'getNormalizedMatrix$',  function () {
var iRows=this.getRowDim$();
var iCols=this.getColDim$();
var maNorm=Clazz.new_(C$.c$$I$I,[iRows, iCols]);
var maStandardDeviation=this.getStandardDeviationCols$();
for (var ii=0; ii < iRows; ii++) for (var jj=0; jj < iCols; jj++) {
var dStandardDeviation=maStandardDeviation.get$I$I(0, jj);
if (dStandardDeviation == 0 ) {
dStandardDeviation=1.4E-45;
}var dVal=this.get$I$I(ii, jj) / dStandardDeviation;
maNorm.set$I$I$D(ii, jj, dVal);
}

return maNorm;
});

Clazz.newMeth(C$, 'getNormalizedMatrix$com_actelion_research_calc_Matrix',  function (maStandardDeviation) {
var iRows=this.getRowDim$();
var iCols=this.getColDim$();
var maNorm=Clazz.new_(C$.c$$I$I,[iRows, iCols]);
for (var ii=0; ii < iRows; ii++) for (var jj=0; jj < iCols; jj++) {
var dStandardDeviation=maStandardDeviation.get$I$I(0, jj);
if (dStandardDeviation == 0 ) {
dStandardDeviation=1.4E-45;
}var dVal=this.get$I$I(ii, jj) / dStandardDeviation;
maNorm.set$I$I$D(ii, jj, dVal);
}

return maNorm;
});

Clazz.newMeth(C$, 'getUpperTriangle$',  function () {
var r=this.rows$();
var c=this.cols$();
if (r != c) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Not a quadratic matrix."]);
}var n=(((r * r) - r)/2|0);
var a=Clazz.array(Double.TYPE, [n]);
var cc=0;
for (var i=0; i < r; i++) {
for (var j=i + 1; j < r; j++) {
a[cc++]=this.get$I$I(i, j);
}
}
return a;
});

Clazz.newMeth(C$, 'getPythag$D$D',  function (a, b) {
var absa=Math.abs(a);
var absb=Math.abs(b);
if (absa > absb ) {
var dScale=(absb / absa) * (absb / absa);
return absa * Math.sqrt(1.0 + dScale);
} else if (absb == 0.0 ) return 0.0;
 else {
var dScale=(absa / absb) * (absa / absb);
return (absb * Math.sqrt(1.0 + dScale));
}}, 1);

Clazz.newMeth(C$, 'getPythag2$D$D',  function (a, b) {
return Math.sqrt((a * a) + (b * b));
}, 1);

Clazz.newMeth(C$, 'areRowsEqual$I$I',  function (row1, row2) {
var equal=true;
var cols=this.cols$();
for (var i=0; i < cols; i++) {
var diff=Math.abs(this.data[row1][i] - this.data[row2][i]);
if (diff > 1.0E-11 ) {
equal=false;
break;
}}
return equal;
});

Clazz.newMeth(C$, 'equal$com_actelion_research_calc_Matrix',  function (ma) {
var bEQ=true;
if (this.equalDimension$com_actelion_research_calc_Matrix(ma)) {
for (var i=0; i < this.getRowDim$(); i++) {
for (var j=0; j < this.getColDim$(); j++) {
if (this.data[i][j] != ma.data[i][j] ) {
bEQ=false;
break;
}}
}
} else {
bEQ=false;
}return bEQ;
});

Clazz.newMeth(C$, 'equal$com_actelion_research_calc_Matrix$D',  function (ma, dLimit) {
var bEQ=true;
if (this.equalDimension$com_actelion_research_calc_Matrix(ma)) {
for (var i=0; i < this.getRowDim$(); i++) {
for (var j=0; j < this.getColDim$(); j++) {
var dDiff=Math.abs(this.data[i][j] - ma.data[i][j]);
if (dDiff > dLimit ) {
bEQ=false;
break;
}}
}
} else {
bEQ=false;
}return bEQ;
});

Clazz.newMeth(C$, 'equalDimension$com_actelion_research_calc_Matrix',  function (ma) {
var bEqual=false;
if ((this.getColDim$() == ma.getColDim$()) && (this.getRowDim$() == ma.getRowDim$()) ) bEqual=true;
return bEqual;
});

Clazz.newMeth(C$, 'hasOnlyFinite$',  function () {
var finite=true;
var r=this.rows$();
var c=this.cols$();
 ma : for (var i=0; i < r; i++) {
for (var j=0; j < c; j++) {
if (!Double.isFinite$D(this.data[i][j])) {
finite=false;
break ma;
}}
}
return finite;
});

Clazz.newMeth(C$, 'multiplyValByVal$com_actelion_research_calc_Matrix',  function (ma) {
var maProd=Clazz.new_(C$.c$$I$I,[this.rows$(), this.cols$()]);
for (var i=0; i < this.rows$(); i++) {
for (var j=0; j < this.cols$(); j++) {
maProd.set$I$I$D(i, j, this.get$I$I(i, j) * ma.get$I$I(i, j));
}
}
return maProd;
});

Clazz.newMeth(C$, 'multCols$com_actelion_research_calc_Matrix',  function (maMuiltiplicant) {
var maResult=Clazz.new_(C$.c$$I$I,[this.getRowDim$(), this.getColDim$()]);
for (var i=0; i < this.getRowDim$(); i++) {
for (var j=0; j < this.getColDim$(); j++) {
maResult.data[i][j]=this.data[i][j] * maMuiltiplicant.get$I$I(0, j);
}
}
return maResult;
});

Clazz.newMeth(C$, 'multiply$D',  function (dScalar) {
var maResult=Clazz.new_(C$.c$$I$I,[this.getRowDim$(), this.getColDim$()]);
for (var i=0; i < this.getRowDim$(); i++) {
for (var j=0; j < this.getColDim$(); j++) {
maResult.data[i][j]=this.data[i][j] * dScalar;
}
}
return maResult;
});

Clazz.newMeth(C$, 'multiply$com_actelion_research_calc_Matrix',  function (ma) {
return this.multiply$Z$Z$com_actelion_research_calc_Matrix(false, false, ma);
});

Clazz.newMeth(C$, 'multiply$I$com_actelion_research_calc_Matrix$I',  function (row1, ma2, row2) {
var sum=0;
for (var ii=0; ii < this.getColDim$(); ii++) {
sum+=this.data[row1][ii] * ma2.data[row2][ii];
}
return sum;
});

Clazz.newMeth(C$, 'multiply$Z$Z$com_actelion_research_calc_Matrix',  function (transA, transB, ma) {
var maResult=null;
if (!transA && !transB ) {
var n=this.cols$();
var m=this.rows$();
var maCols=ma.cols$();
if (n != ma.rows$()) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Error in Routine Matrix.multiply(...). Attempt to calculate the product of two incompatible matrices. Do nothing and return."]);
}maResult=Clazz.new_(C$.c$$I$I,[this.rows$(), ma.cols$()]);
var C=maResult.getArray$();
var Btrans=ma.getTranspose$();
var bTrans=Btrans.getArray$();
var Bcolj=null;
var Arowi=null;
var c4=(n/4|0) * 4;
for (var j=0; j < maCols; j++) {
Bcolj=bTrans[j];
for (var i=0; i < m; i++) {
Arowi=this.data[i];
var s=0;
for (var k=0; k < c4; k+=4) {
var s1=Arowi[k] * Bcolj[k];
var s2=Arowi[k + 1] * Bcolj[k + 1];
var s3=Arowi[k + 2] * Bcolj[k + 2];
var s4=Arowi[k + 3] * Bcolj[k + 3];
s+=s1 + s2 + s3 + s4 ;
}
for (var k=c4; k < n; k++) {
s+=Arowi[k] * Bcolj[k];
}
C[i][j]=s;
}
}
}if (transA && !transB ) {
var n=this.rows$();
var m=this.cols$();
var maCols=ma.cols$();
if (n != ma.rows$()) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Error in Routine SMatrix::Mult(). Attempt to calculate the product of two incompatible matrices. Do nothing and return."]);
}maResult=Clazz.new_(C$.c$$I$I,[this.cols$(), ma.cols$()]);
var C=maResult.getArray$();
var Bcolj=null;
var c4=(n/4|0) * 4;
var Atrans=this.getTranspose$();
var aTrans=Atrans.getArray$();
var Btrans=ma.getTranspose$();
var bTrans=Btrans.getArray$();
var Arowi=null;
for (var j=0; j < maCols; j++) {
Bcolj=bTrans[j];
for (var i=0; i < m; i++) {
Arowi=aTrans[i];
var s=0;
for (var k=0; k < c4; k+=4) {
var s1=Arowi[k] * Bcolj[k];
var s2=Arowi[k + 1] * Bcolj[k + 1];
var s3=Arowi[k + 2] * Bcolj[k + 2];
var s4=Arowi[k + 3] * Bcolj[k + 3];
s+=s1 + s2 + s3 + s4 ;
}
for (var k=c4; k < n; k++) {
s+=Arowi[k] * Bcolj[k];
}
C[i][j]=s;
}
}
}if (!transA && transB ) {
var n=this.cols$();
var m=this.rows$();
var maRows=ma.rows$();
if (n != ma.cols$()) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Error in Routine SMatrix::Mult(). Attempt to calculate the product of two incompatible matrices. Do nothing and return."]);
}maResult=Clazz.new_(C$.c$$I$I,[this.rows$(), maRows]);
var C=maResult.getArray$();
var Bcolj=null;
var c4=(n/4|0) * 4;
var Arowi=null;
for (var j=0; j < maRows; j++) {
Bcolj=ma.data[j];
for (var i=0; i < m; i++) {
Arowi=this.data[i];
var s=0;
for (var k=0; k < c4; k+=4) {
var s1=Arowi[k] * Bcolj[k];
var s2=Arowi[k + 1] * Bcolj[k + 1];
var s3=Arowi[k + 2] * Bcolj[k + 2];
var s4=Arowi[k + 3] * Bcolj[k + 3];
s+=s1 + s2 + s3 + s4 ;
}
for (var k=c4; k < n; k++) {
s+=Arowi[k] * Bcolj[k];
}
C[i][j]=s;
}
}
}if (transA && transB ) {
var n=this.rows$();
var m=this.cols$();
var maRows=ma.rows$();
if (n != ma.cols$()) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Error in Routine SMatrix::Mult(). Attempt to calculate the product of two incompatible matrices. Do nothing and return."]);
}maResult=Clazz.new_(C$.c$$I$I,[this.cols$(), maRows]);
var C=maResult.getArray$();
var Bcolj=null;
var c4=(n/4|0) * 4;
var Atrans=this.getTranspose$();
var aTrans=Atrans.getArray$();
var Arowi=null;
for (var j=0; j < maRows; j++) {
Bcolj=ma.data[j];
for (var i=0; i < m; i++) {
Arowi=aTrans[i];
var s=0;
for (var k=0; k < c4; k+=4) {
var s1=Arowi[k] * Bcolj[k];
var s2=Arowi[k + 1] * Bcolj[k + 1];
var s3=Arowi[k + 2] * Bcolj[k + 2];
var s4=Arowi[k + 3] * Bcolj[k + 3];
s+=s1 + s2 + s3 + s4 ;
}
for (var k=c4; k < n; k++) {
s+=Arowi[k] * Bcolj[k];
}
C[i][j]=s;
}
}
}return maResult;
});

Clazz.newMeth(C$, 'getParsed$java_util_Vector',  function (vecStringMatrix) {
var ma=Clazz.new_(C$);
var sRow=vecStringMatrix.get$I(0);
var iLen=0;
var dArr=$I$(6).convert$S(sRow);
iLen=dArr.length;
ma.resize$I$I(vecStringMatrix.size$(), dArr.length);
for (var ii=0; ii < dArr.length; ii++) {
ma.set$I$I$D(0, ii, dArr[ii]);
}
for (var ii=1; ii < vecStringMatrix.size$(); ii++) {
sRow=vecStringMatrix.get$I(ii);
dArr=$I$(6).convert$S(sRow);
if (iLen != dArr.length) {
System.err.println$S("Vectors for matrix generation differ in length");
(Clazz.new_(Clazz.load('RuntimeException'))).printStackTrace$();
break;
}for (var jj=0; jj < dArr.length; jj++) {
ma.set$I$I$D(ii, jj, dArr[jj]);
}
}
return ma;
}, 1);

Clazz.newMeth(C$, 'plus$com_actelion_research_calc_Matrix',  function (ma) {
var maResult=Clazz.new_(C$.c$$I$I,[this.getRowDim$(), this.getColDim$()]);
if (!this.equalDimension$com_actelion_research_calc_Matrix(ma)) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Matrices have wrong dimensions."]);
}for (var ii=0; ii < this.getRowDim$(); ii++) {
for (var jj=0; jj < this.getColDim$(); jj++) {
maResult.data[ii][jj]=this.data[ii][jj] + ma.data[ii][jj];
}
}
return maResult;
});

Clazz.newMeth(C$, 'pow$D',  function (exp) {
var ma=Clazz.new_(C$.c$$I$I,[this.getRowDim$(), this.getColDim$()]);
for (var i=0; i < this.getRowDim$(); i++) {
for (var j=0; j < this.getColDim$(); j++) {
ma.data[i][j]=Math.pow(this.data[i][j], exp);
}
}
return ma;
});

Clazz.newMeth(C$, 'det$',  function () {
return Clazz.new_($I$(7,1).c$$com_actelion_research_calc_Matrix,[this]).det$();
});

Clazz.newMeth(C$, 'resize$I$I',  function (rowsNew, colsNew) {
var arrTmp=Clazz.array(Double.TYPE, [rowsNew, null]);
var rowsMin=Math.min(this.rows$(), rowsNew);
var colsMin=Math.min(this.cols$(), colsNew);
for (var i=0; i < rowsMin; i++) {
var a=Clazz.array(Double.TYPE, [colsNew]);
System.arraycopy$O$I$O$I$I(this.data[i], 0, a, 0, colsMin);
arrTmp[i]=a;
}
for (var i=rowsMin; i < rowsNew; i++) {
var a=Clazz.array(Double.TYPE, [colsNew]);
arrTmp[i]=a;
}
this.data=arrTmp;
});

Clazz.newMeth(C$, 'getRow$I',  function (row) {
return this.data[row];
});

Clazz.newMeth(C$, 'getRowCopy$I',  function (row) {
var arr=Clazz.array(Double.TYPE, [this.data[0].length]);
for (var i=0; i < arr.length; i++) {
arr[i]=this.data[row][i];
}
return arr;
});

Clazz.newMeth(C$, 'getRowAsList$I',  function (row) {
var list=Clazz.new_($I$(1,1));
for (var ii=0; ii < this.data[0].length; ii++) {
list.add$O(Double.valueOf$D(this.data[row][ii]));
}
return list;
});

Clazz.newMeth(C$, 'getRowAsFloat$I',  function (row) {
var arr=Clazz.array(Float.TYPE, [this.data[0].length]);
for (var i=0; i < this.data[0].length; i++) {
arr[i]=this.data[row][i];
}
return arr;
});

Clazz.newMeth(C$, 'getRowDim$',  function () {
return this.data.length;
});

Clazz.newMeth(C$, 'rows$',  function () {
return this.data.length;
});

Clazz.newMeth(C$, 'getSorted$',  function () {
var ma=Clazz.new_(C$.c$$I$I,[this.getRowDim$(), this.getColDim$()]);
var list=Clazz.new_($I$(1,1));
for (var i=0; i < this.data.length; i++) {
list.add$O(Clazz.new_($I$(8,1).c$$DA,[this.data[i]]));
}
$I$(2).sort$java_util_List(list);
for (var i=0; i < this.data.length; i++) {
ma.assignRow$I$com_actelion_research_util_DoubleVec(i, list.get$I(i));
}
return ma;
});

Clazz.newMeth(C$, 'getSQRT$',  function () {
var ma=Clazz.new_(C$.c$$I$I,[this.getRowDim$(), this.getColDim$()]);
for (var i=0; i < this.data.length; i++) {
for (var j=0; j < this.data[0].length; j++) {
ma.data[i][j]=Math.sqrt(this.data[i][j]);
}
}
return ma;
});

Clazz.newMeth(C$, 'getSquaredSum$',  function () {
var s=0;
for (var i=0; i < this.data.length; i++) {
for (var j=0; j < this.data[0].length; j++) {
s+=this.data[i][j] * this.data[i][j];
}
}
return s;
});

Clazz.newMeth(C$, 'getStandardDeviationCols$',  function () {
var maMean=this.getMeanCols$();
var arrMeanCols=maMean.getRow$I(0);
var cols=this.cols$();
var rows=this.rows$();
var arrStdvCols=Clazz.array(Double.TYPE, [cols]);
for (var i=0; i < rows; i++) {
var arrRow=this.data[i];
for (var j=0; j < cols; j++) {
arrStdvCols[j]+=(arrRow[j] - arrMeanCols[j]) * (arrRow[j] - arrMeanCols[j]);
}
}
for (var i=0; i < cols; i++) {
var sdv=Math.sqrt(arrStdvCols[i] / (rows - 1));
arrStdvCols[i]=sdv;
}
return Clazz.new_(C$.c$$Z$DA,[true, arrStdvCols]);
});

Clazz.newMeth(C$, 'getStandardDeviation$',  function () {
var sdv=0;
var n=this.rows$() * this.cols$();
var mean=this.getMean$();
var sum=0;
for (var i=0; i < this.data.length; i++) {
for (var j=0; j < this.data[0].length; j++) {
sum+=(this.data[i][j] - mean) * (this.data[i][j] - mean);
}
}
sdv=Math.sqrt(sum / (n - 1));
return sdv;
});

Clazz.newMeth(C$, 'getVariance$',  function () {
var $var=0;
var mean=this.getMean$();
var sum=0;
for (var j=0; j < this.data[0].length; j++) {
for (var i=0; i < this.data.length; i++) {
sum+=(this.data[i][j] - mean) * (this.data[i][j] - mean);
}
}
$var=sum / (this.getNumElements$() - 1);
return $var;
});

Clazz.newMeth(C$, 'getCoefficientVariation$',  function () {
var mean=this.getMean$();
var sum=0;
for (var j=0; j < this.data[0].length; j++) {
for (var i=0; i < this.data.length; i++) {
sum+=(this.data[i][j] - mean) * (this.data[i][j] - mean);
}
}
var $var=sum / (this.getNumElements$() - 1);
var sdv=Math.sqrt($var);
var varCoeff=sdv / mean;
return varCoeff;
});

Clazz.newMeth(C$, 'getVarianceCol$I',  function (col) {
var $var=0;
var mean=this.getMeanCol$I(col);
var dSum=0;
for (var i=0; i < this.data.length; i++) {
dSum+=(this.data[i][col] - mean) * (this.data[i][col] - mean);
}
$var=dSum / (this.data.length - 1.0);
return $var;
});

Clazz.newMeth(C$, 'getVarianceRow$I',  function (row) {
var $var=0;
var cols=this.cols$();
var mean=this.getMeanRow$I(row);
var dSum=0;
for (var i=0; i < cols; i++) {
dSum+=(this.data[row][i] - mean) * (this.data[row][i] - mean);
}
$var=dSum / (cols - 1.0);
return $var;
});

Clazz.newMeth(C$, 'getVarianceCentered$',  function () {
var $var=0;
var sum=0;
for (var j=0; j < this.data[0].length; j++) {
for (var i=0; i < this.data.length; i++) {
sum+=(this.data[i][j]) * (this.data[i][j]);
}
}
$var=sum / (this.getNumElements$() - 1);
return $var;
});

Clazz.newMeth(C$, 'getVarianceCols$',  function () {
var ma=Clazz.new_(C$.c$$I$I,[1, this.getColDim$()]);
var maMean=this.getMeanCols$();
for (var j=0; j < this.data[0].length; j++) {
var sum=0;
for (var i=0; i < this.data.length; i++) {
sum+=(this.data[i][j] - maMean.data[0][j]) * (this.data[i][j] - maMean.data[0][j]);
}
var dVariance=sum / (this.getRowDim$() - 1);
ma.data[0][j]=dVariance;
}
return ma;
});

Clazz.newMeth(C$, 'increase$I$I$D',  function (row, col, v) {
this.data[row][col]+=v;
});

Clazz.newMeth(C$, 'set$I$I$D',  function (row, col, v) {
this.data[row][col]=v;
});

Clazz.newMeth(C$, 'set$com_actelion_research_calc_Matrix',  function (ma) {
this.resize$I$I(ma.getRowDim$(), ma.getColDim$());
for (var ii=0; ii < this.data.length; ii++) {
for (var jj=0; jj < this.data[0].length; jj++) {
this.data[ii][jj]=ma.data[ii][jj];
}
}
});

Clazz.newMeth(C$, 'set$DAA',  function (arr) {
this.resize$I$I(arr.length, arr[0].length);
for (var ii=0; ii < this.data.length; ii++) {
for (var jj=0; jj < this.data[0].length; jj++) {
this.data[ii][jj]=arr[ii][jj];
}
}
});

Clazz.newMeth(C$, 'setFlat$DAA',  function (arr) {
this.data=arr;
});

Clazz.newMeth(C$, 'set$D',  function (v) {
for (var i=0; i < this.data.length; i++) {
for (var j=0; j < this.data[0].length; j++) {
this.data[i][j]=v;
}
}
});

Clazz.newMeth(C$, 'setID$I',  function (id) {
this.identifier=id;
});

Clazz.newMeth(C$, 'setCol$I$D',  function (col, v) {
for (var i=0; i < this.data.length; i++) this.data[i][col]=v;

});

Clazz.newMeth(C$, 'setCol$I$DA',  function (col, arr) {
for (var i=0; i < this.data.length; i++) this.data[i][col]=arr[i];

});

Clazz.newMeth(C$, 'setRow$I$D',  function (iRow, v) {
for (var i=0; i < this.data[0].length; i++) this.data[iRow][i]=v;

});

Clazz.newMeth(C$, 'setRow$I$DA',  function (iRow, arr) {
for (var i=0; i < this.data[0].length; i++) this.data[iRow][i]=arr[i];

});

Clazz.newMeth(C$, 'setRow$I$IA',  function (iRow, arr) {
for (var i=0; i < this.data[0].length; i++) this.data[iRow][i]=arr[i];

});

Clazz.newMeth(C$, 'setSeparatorCol$S',  function (s) {
C$.OUT_SEPARATOR_COL=s;
}, 1);

Clazz.newMeth(C$, 'setSeparatorRow$S',  function (s) {
C$.OUT_SEPARATOR_ROW=s;
}, 1);

Clazz.newMeth(C$, 'shuffleRows$',  function () {
var r=this.rows$();
var li=Clazz.new_($I$(1,1).c$$I,[r]);
for (var i=0; i < r; i++) {
li.add$O(Integer.valueOf$I(i));
}
$I$(2).shuffle$java_util_List(li);
for (var i=0; i < li.size$(); i++) {
this.swapRows$I$I(i, (li.get$I(i)).$c());
}
});

Clazz.newMeth(C$, 'swapRows$I$I',  function (a, b) {
var t=this.data[a];
this.data[a]=this.data[b];
this.data[b]=t;
});

Clazz.newMeth(C$, 'sortRows$I',  function (col) {
var r=this.rows$();
var li=Clazz.new_($I$(1,1).c$$I,[r]);
for (var i=0; i < r; i++) {
li.add$O(Clazz.new_([i, this.get$I$I(i, col)],$I$(9,1).c$$I$D));
}
$I$(2,"sort$java_util_List$java_util_Comparator",[li, $I$(9).getComparatorDouble$()]);
var dataSorted=Clazz.array(Double.TYPE, [r, null]);
for (var i=0; i < r; i++) {
dataSorted[i]=this.data[li.get$I(i).getInt$()];
}
this.data=dataSorted;
});

Clazz.newMeth(C$, 'getStandardized$',  function () {
var ma=Clazz.new_(C$.c$$I$I,[this.getRowDim$(), this.getColDim$()]);
var maStandardDeviation=this.getStandardDeviationCols$();
var Xc=this.getCenteredMatrix$();
for (var i=0; i < this.data.length; i++) {
for (var j=0; j < this.data[0].length; j++) {
ma.data[i][j]=Xc.data[i][j] / maStandardDeviation.data[0][j];
}
}
return ma;
});

Clazz.newMeth(C$, 'getSubMatrix$I$I$I$I',  function (indexRowStart, indexRowEnd, indexColStart, indexColEnd) {
var rows=indexRowEnd - indexRowStart + 1;
var cols=indexColEnd - indexColStart + 1;
var ma=Clazz.new_(C$);
var arr=Clazz.array(Double.TYPE, [rows, cols]);
for (var i=0; i < rows; i++) {
System.arraycopy$O$I$O$I$I(this.data[indexRowStart + i], indexColStart, arr[i], 0, cols);
}
ma.data=arr;
return ma;
});

Clazz.newMeth(C$, 'getSubMatrix$java_util_List',  function (liIndexRow) {
var cols=this.cols$();
var ma=Clazz.new_(C$);
var arr=Clazz.array(Double.TYPE, [liIndexRow.size$(), cols]);
var row=0;
for (var i=0; i < liIndexRow.size$(); i++) {
System.arraycopy$O$I$O$I$I(this.data[(liIndexRow.get$I(i)).$c()], 0, arr[row], 0, cols);
++row;
}
ma.data=arr;
return ma;
});

Clazz.newMeth(C$, 'getSum$',  function () {
var sum=0;
for (var i=0; i < this.getRowDim$(); i++) {
for (var j=0; j < this.getColDim$(); j++) {
sum+=this.data[i][j];
}
}
return sum;
});

Clazz.newMeth(C$, 'getSumUpperTriangle$',  function () {
if (this.rows$() != this.cols$()) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Not a quadratic matrix."]);
}var rows=this.cols$();
var sum=0;
for (var i=0; i < rows; i++) {
for (var j=i + 1; j < rows; j++) {
if (!Double.isNaN$D(this.get$I$I(i, j))) {
sum+=this.get$I$I(i, j);
}}
}
return sum;
});

Clazz.newMeth(C$, 'getSumCols$',  function () {
var ma=Clazz.new_(C$.c$$I$I,[1, this.getColDim$()]);
for (var i=0; i < this.getRowDim$(); i++) {
for (var j=0; j < this.getColDim$(); j++) {
ma.data[0][j]+=this.data[i][j];
}
}
return ma;
});

Clazz.newMeth(C$, 'getSumRows$',  function () {
var ma=Clazz.new_(C$.c$$I$I,[1, this.getRowDim$()]);
for (var i=0; i < this.getRowDim$(); i++) {
ma.set$I$I$D(0, i, this.getSumRow$I(i));
}
return ma;
});

Clazz.newMeth(C$, 'getSumCol$I',  function (col) {
var sum=0;
for (var i=0; i < this.getRowDim$(); i++) {
sum+=this.data[i][col];
}
return sum;
});

Clazz.newMeth(C$, 'getSumRow$I',  function (row) {
var sum=0;
for (var i=0; i < this.getColDim$(); i++) {
sum+=this.data[row][i];
}
return sum;
});

Clazz.newMeth(C$, 'getSumSquared$',  function () {
var sum=0;
for (var i=0; i < this.getRowDim$(); i++) {
for (var j=0; j < this.getColDim$(); j++) {
sum+=(this.data[i][j] * this.data[i][j]);
}
}
return sum;
});

Clazz.newMeth(C$, 'getNext4NeighboursTorus$I$I',  function (row, col) {
var arr=Clazz.array(Double.TYPE, [4]);
arr[0]=this.getTorus$I$I(row - 1, col);
arr[1]=this.getTorus$I$I(row, col - 1);
arr[2]=this.getTorus$I$I(row, col + 1);
arr[3]=this.getTorus$I$I(row + 1, col);
return arr;
});

Clazz.newMeth(C$, 'getNext8NeighboursTorus$I$I',  function (row, col) {
var arr=Clazz.array(Double.TYPE, [8]);
var cc=0;
for (var i=-1; i < 2; i++) {
for (var j=-1; j < 2; j++) {
if (i != 0 || j != 0 ) {
arr[cc]=this.getTorus$I$I(row + i, col + j);
++cc;
}}
}
return arr;
});

Clazz.newMeth(C$, 'row2Matrix$I$I',  function (row, len) {
var m=Clazz.new_(C$.c$$I$I,[(this.getColDim$()/len|0), len]);
var r=0;
var c=0;
for (var i=0; i < this.getColDim$(); i++) {
if ((i % len == 0) && (i > 0) ) {
++r;
c=0;
}m.set$I$I$D(r, c, this.get$I$I(0, i));
++c;
}
return m;
});

Clazz.newMeth(C$, 'getTorus$I$I',  function (row, col) {
var torRow=row;
var torCol=col;
while (torRow < 0){
torRow+=this.getRowDim$();
}
while (torRow >= this.getRowDim$()){
torRow-=this.getRowDim$();
}
while (torCol < 0){
torCol+=this.getColDim$();
}
while (torCol >= this.getColDim$()){
torCol-=this.getColDim$();
}
return this.get$I$I(torRow, torCol);
});

Clazz.newMeth(C$, 'getTrace$',  function () {
var t=0;
var m=this.getRowDim$();
var n=this.getColDim$();
for (var ii=0; ii < Math.min(m, n); ii++) {
t=t + this.get$I$I(ii, ii);
}
return t;
});

Clazz.newMeth(C$, 'getTranspose$',  function () {
var rows=this.getRowDim$();
var cols=this.getColDim$();
var ma=Clazz.new_(C$.c$$I$I,[cols, rows]);
for (var ii=0; ii < rows; ii++) {
for (var jj=0; jj < cols; jj++) {
ma.data[jj][ii]=this.data[ii][jj];
}
}
return ma;
});

Clazz.newMeth(C$, 'getFlipped$',  function () {
var rows=this.getRowDim$();
var cols=this.getColDim$();
var ma=Clazz.new_(C$.c$$I$I,[cols, rows]);
for (var ii=0; ii < rows; ii++) {
for (var jj=0; jj < cols; jj++) {
ma.data[cols - jj - 1 ][ii]=this.data[ii][jj];
}
}
return ma;
});

Clazz.newMeth(C$, 'toRow$',  function () {
var m=Clazz.new_(C$.c$$I$I,[1, this.getRowDim$() * this.getColDim$()]);
for (var i=0; i < this.getRowDim$(); i++) {
for (var j=0; j < this.getColDim$(); j++) {
m.set$I$I$D(0, i * this.getColDim$() + j, this.get$I$I(i, j));
}
}
return m;
});

Clazz.newMeth(C$, 'toArray$',  function () {
var rows=this.rows$();
var cols=this.cols$();
var a=Clazz.array(Double.TYPE, [rows * cols]);
for (var i=0; i < rows; i++) {
for (var j=0; j < cols; j++) {
a[i * cols + j]=this.get$I$I(i, j);
}
}
return a;
});

Clazz.newMeth(C$, 'toString',  function () {
var iRequireDigits=20;
var len=this.getRowDim$() * this.getColDim$() * iRequireDigits ;
var sb=Clazz.new_($I$(10,1).c$$I,[len]);
for (var i=0; i < this.data.length; i++) {
for (var j=0; j < this.data[0].length - 1; j++) {
sb.append$S(new Double(this.data[i][j]).toString() + C$.OUT_SEPARATOR_COL);
}
sb.append$D(this.data[i][this.data[0].length - 1]);
if (i < this.data.length - 1) sb.append$S(C$.OUT_SEPARATOR_ROW);
}
return sb.toString();
});

Clazz.newMeth(C$, 'toStringBinary$',  function () {
var len=this.getRowDim$() * this.getColDim$();
var sb=Clazz.new_($I$(10,1).c$$I,[len]);
for (var i=0; i < this.data.length; i++) {
for (var j=0; j < this.data[0].length; j++) {
if (this.data[i][j] == 0 ) sb.append$I(0);
 else sb.append$I(1);
}
if (i < this.data.length - 1) sb.append$S(C$.OUT_SEPARATOR_ROW);
}
return sb.toString();
});

Clazz.newMeth(C$, 'toString$I',  function (digits) {
return this.toString$I$I$I$I(this.rows$(), this.cols$(), digits, 0);
});

Clazz.newMeth(C$, 'toString$I$I',  function (digits, width) {
return this.toString$I$I$I$I(this.rows$(), this.cols$(), digits, width);
});

Clazz.newMeth(C$, 'toString$I$I$I$I',  function (rowEnd, colEnd, digits, width) {
var iRequireDigits=20;
var sFormat="";
sFormat+="0";
var iCounter=0;
if (digits > 0) sFormat+=".";
while (iCounter < digits){
sFormat+="0";
++iCounter;
}
var nf=Clazz.new_([sFormat, Clazz.new_([$I$(13).US],$I$(12,1).c$$java_util_Locale)],$I$(11,1).c$$S$java_text_DecimalFormatSymbols);
var len=this.getRowDim$() * this.getColDim$() * iRequireDigits ;
var sb=Clazz.new_($I$(10,1).c$$I,[len]);
for (var i=0; i < rowEnd; i++) {
for (var j=0; j < colEnd; j++) {
var sVal=nf.format$D(this.data[i][j]);
if (this.data[i][j] == 1.7976931348623157E308 ) sVal="Max";
var sbVal=Clazz.new_($I$(10,1).c$$S,[sVal]);
while (sbVal.length$() < width){
sbVal.insert$I$S(0, " ");
}
sb.append$S(sbVal.toString());
if (j < this.data[0].length - 1) sb.append$S(C$.OUT_SEPARATOR_COL);
}
if (i < this.data.length - 1) sb.append$S(C$.OUT_SEPARATOR_ROW);
}
return sb.toString();
});

Clazz.newMeth(C$, 'toStringRow$I$I',  function (row, iDigits) {
var iRequireDigits=20;
var sFormat="";
sFormat+="0";
var iCounter=0;
if (iDigits > 0) sFormat+=".";
while (iCounter < iDigits){
sFormat+="0";
++iCounter;
}
var nf=Clazz.new_($I$(11,1).c$$S,[sFormat]);
var len=this.getRowDim$() * this.getColDim$() * iRequireDigits ;
var sb=Clazz.new_($I$(10,1).c$$I,[len]);
for (var j=0; j < this.data[0].length; j++) {
var sVal=nf.format$D(this.data[row][j]);
if (this.data[row][j] == 1.7976931348623157E308 ) sVal="Max";
sb.append$S(sVal);
if (j < this.data[0].length - 1) sb.append$S(C$.OUT_SEPARATOR_COL);
}
return sb.toString();
});

Clazz.newMeth(C$, 'toStringRowNumber$I$S',  function (iDigits, sSeparatorCol) {
var iRequireDigits=20;
var sFormat="##,";
var iCounter=0;
while (iCounter < iDigits){
sFormat+="#";
++iCounter;
}
sFormat+="0.";
iCounter=0;
while (iCounter < iDigits){
sFormat+="0";
++iCounter;
}
var nf=Clazz.new_($I$(11,1).c$$S,[sFormat]);
var len=this.getRowDim$() * this.getColDim$() * iRequireDigits ;
var sb=Clazz.new_($I$(10,1).c$$I,[len]);
for (var i=0; i < this.data.length; i++) {
sb.append$S(i + sSeparatorCol);
for (var j=0; j < this.data[0].length - 1; j++) {
sb.append$S(nf.format$D(this.data[i][j]) + sSeparatorCol);
}
sb.append$S(nf.format$D(this.data[i][this.data[0].length - 1]));
if (i < this.data.length - 1) sb.append$S(C$.OUT_SEPARATOR_ROW);
}
return sb.toString();
});

Clazz.newMeth(C$, 'subtract$com_actelion_research_calc_Matrix',  function (ma) {
var maResult=Clazz.new_(C$.c$$I$I,[this.getRowDim$(), this.getColDim$()]);
if (!this.equalDimension$com_actelion_research_calc_Matrix(ma)) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Matrices have wrong dimensions."]);
}for (var ii=0; ii < this.getRowDim$(); ii++) {
for (var jj=0; jj < this.getColDim$(); jj++) {
maResult.data[ii][jj]=this.data[ii][jj] - ma.data[ii][jj];
}
}
return maResult;
});

Clazz.newMeth(C$, 'subtract$D',  function (val) {
var maResult=Clazz.new_(C$.c$$I$I,[this.getRowDim$(), this.getColDim$()]);
for (var ii=0; ii < this.getRowDim$(); ii++) {
for (var jj=0; jj < this.getColDim$(); jj++) {
maResult.data[ii][jj]=this.data[ii][jj] - val;
}
}
return maResult;
});

Clazz.newMeth(C$, 'subtractFromCols$com_actelion_research_calc_Matrix',  function (maDivisor) {
var maResult=Clazz.new_(C$.c$$I$I,[this.getRowDim$(), this.getColDim$()]);
for (var ii=0; ii < this.getRowDim$(); ii++) {
for (var jj=0; jj < this.getColDim$(); jj++) {
maResult.data[ii][jj]=this.data[ii][jj] - maDivisor.get$I$I(0, jj);
}
}
return maResult;
});

Clazz.newMeth(C$, 'Sign$D$D',  function (a, b) {
if (b >= 0.0 ) return Math.abs(a);
 else return -Math.abs(a);
}, 1);

Clazz.newMeth(C$, 'getRND$I$I',  function (rows, cols) {
var ma=Clazz.new_(C$.c$$I$I,[rows, cols]);
for (var i=0; i < rows; i++) for (var j=0; j < cols; j++) ma.set$I$I$D(i, j, Math.random());


return ma;
}, 1);

Clazz.newMeth(C$, 'write$S$Z',  function (sFile, apppend) {
var df=Clazz.new_($I$(11,1).c$$S,["0.############"]);
this.write$java_io_File$java_text_DecimalFormat$Z(Clazz.new_($I$(14,1).c$$S,[sFile]), df, apppend);
});

Clazz.newMeth(C$, 'write$S',  function (sFile) {
var df=Clazz.new_($I$(11,1).c$$S,["0.############"]);
this.write$java_io_File$java_text_DecimalFormat$Z(Clazz.new_($I$(14,1).c$$S,[sFile]), df, false);
});

Clazz.newMeth(C$, 'write$java_io_File',  function (fiMa) {
var df=Clazz.new_($I$(11,1).c$$S,["0.############"]);
this.write$java_io_File$java_text_DecimalFormat$Z(fiMa, df, false);
});

Clazz.newMeth(C$, 'write$java_io_File$Z$I',  function (fiMa, apppend, digits) {
var sFormat="##,";
var iCounter=0;
while (iCounter < digits){
sFormat+="#";
++iCounter;
}
sFormat+="0.";
iCounter=0;
while (iCounter < digits){
sFormat+="0";
++iCounter;
}
var nf=Clazz.new_($I$(11,1).c$$S,[sFormat]);
this.write$java_io_File$java_text_DecimalFormat$Z(fiMa, nf, apppend);
});

Clazz.newMeth(C$, 'write$S$Z$I',  function (sFiMa, apppend, digits) {
this.write$java_io_File$Z$I(Clazz.new_($I$(14,1).c$$S,[sFiMa]), apppend, digits);
});

Clazz.newMeth(C$, 'write$java_io_File$java_text_DecimalFormat$Z',  function (fiMa, nf, apppend) {
try {
var os=Clazz.new_($I$(15,1).c$$java_io_File$Z,[fiMa, apppend]);
this.write$java_io_OutputStream$java_text_NumberFormat(os, nf);
os.close$();
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
throw Clazz.new_(Clazz.load('RuntimeException').c$$Throwable,[e]);
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'write$java_io_OutputStream',  function (os) {
var nf=Clazz.new_($I$(11,1).c$$S,["#.###############"]);
this.write$java_io_OutputStream$java_text_NumberFormat(os, nf);
});

Clazz.newMeth(C$, 'writeAsLineBase64Encoded$',  function () {
var nf=Clazz.new_($I$(11,1).c$$S,["#.###############"]);
var baos=Clazz.new_($I$(16,1));
this.write$java_io_OutputStream$java_text_NumberFormat(baos, nf);
var encoder=$I$(17).getEncoder$();
var arr64=encoder.encode$BA(baos.toByteArray$());
return  String.instantialize(arr64);
});

Clazz.newMeth(C$, 'write$java_io_OutputStream$java_text_NumberFormat',  function (os, nf) {
try {
for (var i=0; i < this.data.length; i++) {
var sb=Clazz.new_($I$(10,1));
for (var j=0; j < this.data[0].length; j++) {
sb.append$S(nf.format$D(this.data[i][j]));
if (j < this.data[0].length - 1) {
sb.append$S(C$.OUT_SEPARATOR_COL);
}}
os.write$BA(sb.toString().getBytes$());
if (i < this.data.length - 1) {
os.write$BA(C$.OUT_SEPARATOR_ROW.getBytes$());
}}
os.flush$();
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
throw Clazz.new_(Clazz.load('RuntimeException').c$$Throwable,[e]);
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'toStringWithColTags$java_util_List$java_text_DecimalFormat$S',  function (liColTags, nf, separator) {
if (this.cols$() != liColTags.size$()) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Number of cols and col tags differ."]);
}var arrWidth=Clazz.array(Integer.TYPE, [this.cols$()]);
for (var i=0; i < arrWidth.length; i++) {
arrWidth[i]=liColTags.get$I(i).length$();
}
for (var i=0; i < arrWidth.length; i++) {
for (var j=0; j < this.rows$(); j++) {
arrWidth[i]=Math.max(arrWidth[i], nf.format$D(this.get$I$I(j, i)).length$());
}
}
var sbAll=Clazz.new_($I$(10,1));
for (var i=0; i < arrWidth.length; i++) {
var w=arrWidth[i];
var sb=Clazz.new_([liColTags.get$I(i)],$I$(10,1).c$$S);
var l=w - sb.length$();
for (var j=0; j < l; j++) {
sb.append$S(" ");
}
sbAll.append$S(sb.toString());
sbAll.append$S(" ");
}
sbAll.append$S("\n");
for (var i=0; i < this.rows$(); i++) {
for (var j=0; j < arrWidth.length; j++) {
var w=arrWidth[j];
var sb=Clazz.new_([nf.format$D(this.get$I$I(i, j))],$I$(10,1).c$$S);
var l=w - sb.length$();
for (var k=0; k < l; k++) {
sb.append$S(" ");
}
sbAll.append$S(sb.toString());
sbAll.append$S(" ");
}
sbAll.append$S("\n");
}
return sbAll.toString();
});

Clazz.newMeth(C$, 'toStringWithRowTags$java_util_List$java_text_DecimalFormat$S',  function (liRowTags, nf, separator) {
if (this.rows$() != liRowTags.size$()) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Number of rows and row tags differ."]);
}var arrWidth=Clazz.array(Integer.TYPE, [this.cols$() + 1]);
for (var i=0; i < liRowTags.size$(); i++) {
arrWidth[0]=Math.max(arrWidth[0], liRowTags.get$I(i).length$());
}
for (var i=0; i < this.cols$(); i++) {
for (var j=0; j < this.rows$(); j++) {
arrWidth[i + 1]=Math.max(arrWidth[i + 1], nf.format$D(this.get$I$I(j, i)).length$());
}
}
var sbAll=Clazz.new_($I$(10,1));
for (var i=0; i < arrWidth.length; i++) {
var w=arrWidth[i];
var sb=Clazz.new_([liRowTags.get$I(i)],$I$(10,1).c$$S);
var l=w - sb.length$();
for (var j=0; j < l; j++) {
sb.append$S(" ");
}
sbAll.append$S(sb.toString());
sbAll.append$S(" ");
}
sbAll.append$S("\n");
for (var i=0; i < this.rows$(); i++) {
for (var j=0; j < arrWidth.length; j++) {
var w=arrWidth[j];
var sb=Clazz.new_([nf.format$D(this.get$I$I(i, j))],$I$(10,1).c$$S);
var l=w - sb.length$();
for (var k=0; k < l; k++) {
sb.append$S(" ");
}
sbAll.append$S(sb.toString());
sbAll.append$S(" ");
}
sbAll.append$S("\n");
}
return sbAll.toString();
});

Clazz.newMeth(C$, 'writeSerialized$java_io_File',  function (fiOut) {
var fos=Clazz.new_($I$(15,1).c$$java_io_File,[fiOut]);
var oos=Clazz.new_($I$(18,1).c$$java_io_OutputStream,[fos]);
oos.writeObject$O(this.data);
oos.close$();
});

Clazz.newMeth(C$, 'readSerialized$java_io_File',  function (fiIn) {
var ma=null;
var fos=Clazz.new_($I$(19,1).c$$java_io_File,[fiIn]);
var ois=Clazz.new_($I$(20,1).c$$java_io_InputStream,[fos]);
var data=ois.readObject$();
ma=Clazz.new_(C$.c$$DAA,[data]);
ois.close$();
return ma;
}, 1);

Clazz.newMeth(C$, 'format$I',  function (digits) {
var sFormat="##,###";
if (digits > 0) {
sFormat+=".";
var iCounter=0;
while (iCounter < digits){
sFormat+="0";
++iCounter;
}
}return Clazz.new_([sFormat, Clazz.new_([$I$(13).US],$I$(12,1).c$$java_util_Locale)],$I$(11,1).c$$S$java_text_DecimalFormatSymbols);
}, 1);

Clazz.newMeth(C$, 'write$S$Z$I$I',  function (sFile, bApppend, digits, totalWidth) {
try {
var nf=C$.format$I(digits);
var writer=Clazz.new_([Clazz.new_([Clazz.new_($I$(14,1).c$$S,[sFile]), bApppend],$I$(22,1).c$$java_io_File$Z)],$I$(21,1).c$$java_io_Writer);
var sVal;
for (var ii=0; ii < this.data.length; ii++) {
sVal=Clazz.new_($I$(23,1));
for (var jj=0; jj < this.data[0].length; jj++) {
sVal.append$S(C$.format$D$java_text_DecimalFormat$I(this.data[ii][jj], nf, totalWidth) + C$.OUT_SEPARATOR_COL);
}
writer.write$S(sVal.toString());
if (ii < this.data.length - 1) {
writer.write$S(C$.OUT_SEPARATOR_ROW);
}}
writer.flush$();
writer.close$();
} catch (ex) {
if (Clazz.exceptionOf(ex,"java.io.IOException")){
ex.printStackTrace$();
} else {
throw ex;
}
}
});

Clazz.newMeth(C$, 'format$D$java_text_DecimalFormat$I',  function (val, nf, totalWidth) {
var str="";
str=nf.format$D(val);
while (str.length$() < totalWidth){
str=" " + str;
}
return str;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.TINY16=Math.pow(10, -16);
C$.OUT_SEPARATOR_COL="\t";
C$.OUT_SEPARATOR_ROW="\n";
};
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:45 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
