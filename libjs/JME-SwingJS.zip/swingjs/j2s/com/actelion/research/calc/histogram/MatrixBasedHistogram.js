(function(){var P$=Clazz.newPackage("com.actelion.research.calc.histogram"),I$=[[0,'com.actelion.research.calc.histogram.Histogram','com.actelion.research.calc.Matrix','java.io.BufferedWriter','java.io.FileWriter','java.io.File','java.text.DecimalFormat','StringBuilder']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MatrixBasedHistogram");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['Z',['VERBOSE']]]

Clazz.newMeth(C$, 'getFromQuadraticMatrix$com_actelion_research_calc_Matrix$D$D$I',  function (ma, min, max, bins) {
var r=ma.rows$();
var n=(((r * r) - r)/2|0);
var a=Clazz.array(Double.TYPE, [n]);
var c=0;
for (var i=0; i < r; i++) {
for (var j=i + 1; j < r; j++) {
a[c++]=ma.get$I$I(i, j);
}
}
return Clazz.new_($I$(1,1).c$$DA$D$D$I,[a, min, max, bins]);
}, 1);

Clazz.newMeth(C$, 'getHistogram$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix',  function (ma, maHistogramBins) {
var maHistogram=Clazz.new_($I$(2,1).c$$com_actelion_research_calc_Matrix,[maHistogramBins]);
maHistogram.resize$I$I(3, maHistogramBins.getColDim$());
for (var i=0; i < ma.getRowDim$(); i++) {
for (var j=0; j < ma.getColDim$(); j++) {
var v=ma.get$I$I(i, j);
C$.placeValueInHistogramBin$D$com_actelion_research_calc_Matrix(v, maHistogram);
}
}
return maHistogram;
}, 1);

Clazz.newMeth(C$, 'getHistogram$DA$com_actelion_research_calc_Matrix',  function (arrValues, maHistogramBins) {
var maHistogram=Clazz.new_($I$(2,1).c$$com_actelion_research_calc_Matrix,[maHistogramBins]);
maHistogram.resize$I$I(3, maHistogramBins.getColDim$());
for (var i=0; i < arrValues.length; i++) {
C$.placeValueInHistogramBin$D$com_actelion_research_calc_Matrix(arrValues[i], maHistogram);
}
return maHistogram;
}, 1);

Clazz.newMeth(C$, 'placeValueInHistogramBin$D$com_actelion_research_calc_Matrix',  function (v, maHist) {
if (Double.isNaN$D(v)) {
if (C$.VERBOSE) System.err.println$S("Warning NaN in placeValueInHistogramBin(...).");
return;
}if (v < maHist.get$I$I(0, 0)  || v > maHist.get$I$I(1, maHist.cols$() - 1)  ) return;
var maxloops=maHist.cols$();
var bEnd=false;
var pos=(maHist.cols$()/2|0);
var posLow=0;
var posUp=maHist.cols$() - 1;
var cc=0;
while (!bEnd){
if (v >= maHist.get$I$I(0, pos)  && v < maHist.get$I$I(1, pos)  ) {
maHist.increase$I$I$D(2, pos, 1);
bEnd=true;
} else if (v < maHist.get$I$I(0, pos) ) {
posUp=pos;
pos=posLow + ((pos - posLow)/2|0);
} else if (v >= maHist.get$I$I(1, pos) ) {
posLow=pos;
pos=pos + (((posUp - pos) / 2 + 0.5)|0);
}if (cc == maxloops) {
var msg="Fitting bin for value " + new Double(v).toString() + " not found!\n" + C$.histogram2String$com_actelion_research_calc_Matrix$I$I(maHist, 2, 8) ;
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Fitting bin for value " + new Double(v).toString() + " not found" ]);
}++cc;
}
}, 1);

Clazz.newMeth(C$, 'getHistogram$com_actelion_research_calc_Matrix',  function (maHistogramBins) {
var maHistogram=Clazz.new_($I$(2,1).c$$com_actelion_research_calc_Matrix,[maHistogramBins]);
maHistogram.resize$I$I(3, maHistogramBins.getColDim$());
return maHistogram;
}, 1);

Clazz.newMeth(C$, 'getBordersMostFreqOccBin$com_actelion_research_calc_Matrix$I',  function (maHistogram, radius) {
var arr=Clazz.array(Double.TYPE, [2]);
var maxFreq=0;
var index=-1;
for (var i=radius; i < maHistogram.cols$() - radius; i++) {
var sumFreq=0;
for (var j=-radius; j < radius + 1; j++) {
sumFreq=(sumFreq+(maHistogram.get$I$I(2, i + j))|0);
}
if (sumFreq > maxFreq ) {
maxFreq=sumFreq;
index=i;
}}
var indexLower=Math.max(0, index - radius);
var indexUpper=Math.min(maHistogram.cols$() - 1, index + radius);
arr[0]=maHistogram.get$I$I(0, indexLower);
arr[1]=maHistogram.get$I$I(1, indexUpper);
return arr;
}, 1);

Clazz.newMeth(C$, 'getHistogram$FA$com_actelion_research_calc_Matrix',  function (ma, maHistogramBins) {
var maHistogram=Clazz.new_($I$(2,1).c$$com_actelion_research_calc_Matrix,[maHistogramBins]);
maHistogram.resize$I$I(3, maHistogramBins.getColDim$());
for (var ii=0; ii < ma.length; ii++) {
for (var kk=0; kk < maHistogramBins.getColDim$(); kk++) {
if (ma[ii] >= maHistogram.get$I$I(0, kk)  && ma[ii] < maHistogram.get$I$I(1, kk)  ) {
var iCounter=(maHistogram.get$I$I(2, kk)|0);
++iCounter;
maHistogram.set$I$I$D(2, kk, iCounter);
}}
}
return maHistogram;
}, 1);

Clazz.newMeth(C$, 'getHistogram$FAA$I$com_actelion_research_calc_Matrix',  function (ma, col, maHistogramBins) {
var maHistogram=Clazz.new_($I$(2,1).c$$com_actelion_research_calc_Matrix,[maHistogramBins]);
maHistogram.resize$I$I(3, maHistogramBins.getColDim$());
for (var ii=0; ii < ma.length; ii++) {
for (var kk=0; kk < maHistogramBins.getColDim$(); kk++) {
if (ma[ii][col] >= maHistogram.get$I$I(0, kk)  && ma[ii][col] < maHistogram.get$I$I(1, kk)  ) {
var iCounter=(maHistogram.get$I$I(2, kk)|0);
++iCounter;
maHistogram.set$I$I$D(2, kk, iCounter);
}}
}
return maHistogram;
}, 1);

Clazz.newMeth(C$, 'getHistogram$com_actelion_research_calc_Matrix$I',  function (ma, numBins) {
var min=ma.getMin$() - ma.getMin$() * 1.0E-6;
var max=ma.getMax$() + ma.getMax$() * 1.0E-6;
var maBins=C$.getHistogramBins$D$D$I(min, max, numBins);
var maHist=C$.getHistogram$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix(ma, maBins);
return maHist;
}, 1);

Clazz.newMeth(C$, 'getMinOccBin$com_actelion_research_calc_Matrix',  function (maHist) {
var min=0;
for (var i=0; i < maHist.getColDim$(); i++) {
if (maHist.get$I$I(2, i) > 0 ) {
min=maHist.get$I$I(0, i);
break;
}}
return min;
}, 1);

Clazz.newMeth(C$, 'getMaxOccBin$com_actelion_research_calc_Matrix',  function (maHist) {
var max=0;
for (var i=maHist.getColDim$() - 1; i >= 0; i--) {
if (maHist.get$I$I(2, i) > 0 ) {
max=maHist.get$I$I(1, i);
break;
}}
return max;
}, 1);

Clazz.newMeth(C$, 'getHistogramBins$D$D$I',  function (dMin, dMax, iNumBins) {
var maHistogramBins=Clazz.new_($I$(2,1).c$$I$I,[2, iNumBins]);
var dDelta=dMax - dMin;
var dBinWidth=dDelta / iNumBins;
var dIncrementLast=dBinWidth * 1.0E-4;
var dLow=dMin;
var iCols=maHistogramBins.getColDim$();
for (var ii=0; ii < iCols; ii++) {
maHistogramBins.set$I$I$D(0, ii, dLow);
var dUp=dLow + dBinWidth;
if (ii == (iCols - 1)) dUp+=dIncrementLast;
maHistogramBins.set$I$I$D(1, ii, dUp);
dLow=dUp;
}
return maHistogramBins;
}, 1);

Clazz.newMeth(C$, 'writeHistogram$S$com_actelion_research_calc_Matrix$Z$I$I',  function (sFile, hist, bApppend, digits, totalWidth) {
var writer=Clazz.new_([Clazz.new_([Clazz.new_($I$(5,1).c$$S,[sFile]), bApppend],$I$(4,1).c$$java_io_File$Z)],$I$(3,1).c$$java_io_Writer);
var dfBins=$I$(2).format$I(digits);
var sVal="";
for (var ii=0; ii < 2; ii++) {
sVal="";
for (var jj=0; jj < hist.getColDim$(); jj++) {
sVal+=$I$(2,"format$D$java_text_DecimalFormat$I",[hist.get$I$I(ii, jj), dfBins, totalWidth]) + $I$(2).OUT_SEPARATOR_COL;
}
sVal+=$I$(2).OUT_SEPARATOR_ROW;
writer.write$S(sVal);
}
var dfFreq=Clazz.new_($I$(6,1));
sVal="";
for (var jj=0; jj < hist.getColDim$(); jj++) {
sVal+=$I$(2,"format$D$java_text_DecimalFormat$I",[hist.get$I$I(2, jj), dfFreq, totalWidth]) + $I$(2).OUT_SEPARATOR_COL;
}
writer.write$S(sVal + "\n");
writer.flush$();
writer.close$();
}, 1);

Clazz.newMeth(C$, 'histogram2String$com_actelion_research_calc_Matrix$I$I',  function (hist, digits, totalWidth) {
var sb=Clazz.new_($I$(7,1));
var dfBins=$I$(2).format$I(digits);
for (var i=0; i < 2; i++) {
for (var j=0; j < hist.getColDim$(); j++) {
sb.append$S($I$(2,"format$D$java_text_DecimalFormat$I",[hist.get$I$I(i, j), dfBins, totalWidth]) + $I$(2).OUT_SEPARATOR_COL);
}
sb.append$S($I$(2).OUT_SEPARATOR_ROW);
}
var dfFreq=Clazz.new_($I$(6,1));
for (var i=0; i < hist.getColDim$(); i++) {
sb.append$S($I$(2,"format$D$java_text_DecimalFormat$I",[hist.get$I$I(2, i), dfFreq, totalWidth]) + $I$(2).OUT_SEPARATOR_COL);
}
sb.append$S("\n");
return sb.toString();
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.VERBOSE=false;
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:05:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
