(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.linear.pls"),I$=[[0,'java.text.DecimalFormat','com.actelion.research.util.datamodel.ModelXYCrossValidation','com.actelion.research.util.datamodel.ModelXY','java.util.ArrayList','com.actelion.research.calc.regression.linear.pls.PLSRegressionModelCalculator','com.actelion.research.util.datamodel.ModelXYIndex','com.actelion.research.calc.regression.ModelError','com.actelion.research.calc.statistics.median.MedianStatisticFunctions']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SimPLSLMOValidation");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['centerData'],'I',['nRepetitions','nFactors'],'O',['liModelErrorTest','java.util.List','+liModelErrorTrain','modelXYCrossValidation','com.actelion.research.util.datamodel.ModelXYCrossValidation']]
,['O',['NF','java.text.DecimalFormat']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix',  function (X, Y) {
;C$.$init$.apply(this);
this.modelXYCrossValidation=Clazz.new_([Clazz.new_($I$(3,1).c$$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix,[X, Y])],$I$(2,1).c$$com_actelion_research_util_datamodel_ModelXY);
}, 1);

Clazz.newMeth(C$, 'setFractionLeaveOut$D',  function (fracOut) {
this.modelXYCrossValidation.setFractionLeaveOut$D(fracOut);
});

Clazz.newMeth(C$, 'setNumRepetitions$I',  function (nRepetitions) {
this.nRepetitions=nRepetitions;
});

Clazz.newMeth(C$, 'setNumFactors$I',  function (nFactors) {
this.nFactors=nFactors;
});

Clazz.newMeth(C$, 'setCenterData$Z',  function (centerData) {
this.centerData=centerData;
});

Clazz.newMeth(C$, 'calculateMedianTestError$',  function () {
this.liModelErrorTest=Clazz.new_($I$(4,1));
this.liModelErrorTrain=Clazz.new_($I$(4,1));
var rmc=Clazz.new_($I$(5,1));
rmc.setCenterData$Z(this.centerData);
for (var i=0; i < this.nRepetitions; i++) {
this.modelXYCrossValidation.next$();
var modelXYIndex=Clazz.new_($I$(6,1));
modelXYIndex.X=this.modelXYCrossValidation.getXtrain$();
modelXYIndex.Y=this.modelXYCrossValidation.getYtrain$();
var yHat=rmc.createModel$com_actelion_research_util_datamodel_ModelXYIndex(modelXYIndex);
var modelErrorTrain=$I$(7).calculateError$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix(modelXYIndex.Y, yHat);
var modelErrorTest=rmc.calculateModelErrorTest$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix(this.modelXYCrossValidation.getXtest$(), this.modelXYCrossValidation.getYtest$());
this.liModelErrorTrain.add$O(modelErrorTrain);
this.liModelErrorTest.add$O(modelErrorTest);
}
var liErrorTest=$I$(7).getError$java_util_List(this.liModelErrorTest);
var modelMedian=$I$(8).getMedianForDouble$java_util_Collection(liErrorTest);
return modelMedian.median;
});

C$.$static$=function(){C$.$static$=0;
C$.NF=Clazz.new_($I$(1,1).c$$S,["0.000"]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:46 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
