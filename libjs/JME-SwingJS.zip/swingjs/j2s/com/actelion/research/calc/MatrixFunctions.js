(function(){var P$=Clazz.newPackage("com.actelion.research.calc"),I$=[[0,'com.actelion.research.calc.Matrix','com.actelion.research.chem.descriptor.SimilarityCalculatorDoubleArray','java.util.ArrayList','com.actelion.research.util.DoubleVec','com.actelion.research.util.datamodel.IntegerDouble','java.util.Collections','com.actelion.research.util.Formatter','java.awt.Point','java.util.Random','com.actelion.research.calc.ArrayUtilsCalc','com.actelion.research.util.datamodel.DoubleArray','com.actelion.research.calc.CorrelationCalculator','com.actelion.research.util.datamodel.IntVec','java.util.Vector','java.io.BufferedReader','java.io.FileReader','java.io.FileInputStream','java.io.ByteArrayInputStream','java.util.Base64','java.util.Scanner','java.io.BufferedWriter','java.io.FileWriter','StringBuilder','com.actelion.research.util.datamodel.IdentifiedObject']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MatrixFunctions");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'convert2Binary$com_actelion_research_calc_Matrix$D',  function (A, thresh) {
var rows=A.rows$();
var cols=A.cols$();
var B=Clazz.new_($I$(1,1).c$$I$I,[rows, cols]);
for (var i=0; i < rows; i++) {
for (var j=0; j < cols; j++) {
if (A.get$I$I(i, j) > thresh ) {
B.set$I$I$D(i, j, 1);
}}
}
return B;
}, 1);

Clazz.newMeth(C$, 'split$com_actelion_research_calc_Matrix$I',  function (A, row) {
var rows=A.rows$();
var cols=A.cols$();
var rowsC=rows - row;
var B=Clazz.new_($I$(1,1).c$$I$I,[row, cols]);
var C=Clazz.new_($I$(1,1).c$$I$I,[rowsC, cols]);
for (var i=0; i < row; i++) {
for (var j=0; j < cols; j++) {
B.set$I$I$D(i, j, A.get$I$I(i, j));
}
}
for (var i=0; i < rowsC; i++) {
for (var j=0; j < cols; j++) {
C.set$I$I$D(i, j, A.get$I$I(i + row, j));
}
}
var arr=Clazz.array($I$(1), [2]);
arr[0]=B;
arr[1]=C;
return arr;
}, 1);

Clazz.newMeth(C$, 'splitCol$com_actelion_research_calc_Matrix$I',  function (A, col) {
var rows=A.rows$();
var cols=A.cols$();
var colsC=cols - col;
var B=Clazz.new_($I$(1,1).c$$I$I,[rows, col]);
var C=Clazz.new_($I$(1,1).c$$I$I,[rows, colsC]);
for (var i=0; i < rows; i++) {
for (var j=0; j < col; j++) {
B.set$I$I$D(i, j, A.get$I$I(i, j));
}
}
for (var i=0; i < rows; i++) {
for (var j=0; j < colsC; j++) {
C.set$I$I$D(i, j, A.get$I$I(i, j + col));
}
}
var arr=Clazz.array($I$(1), [2]);
arr[0]=B;
arr[1]=C;
return arr;
}, 1);

Clazz.newMeth(C$, 'isEqualCol$com_actelion_research_calc_Matrix$I$com_actelion_research_calc_Matrix$I$D',  function (A, colA, B, colB, thresh) {
var equal=true;
var r=A.rows$();
if (r != B.rows$()) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Row number differs!"]);
}for (var i=0; i < r; i++) {
var abs=Math.abs(A.get$I$I(i, colA) - B.get$I$I(i, colB));
if (abs > thresh ) {
equal=false;
break;
}}
return equal;
}, 1);

Clazz.newMeth(C$, 'equals$D$D',  function (d1, d2) {
return (Math.abs(d1 - d2) < 1.0E-7 ) ? true : false;
}, 1);

Clazz.newMeth(C$, 'id$I',  function (n) {
var A=Clazz.array(Double.TYPE, [n, n]);
for (var i=0; i < n; i++) for (var j=0; j < n; j++) {
if (i == j) A[i][j]=1.0;
 else A[i][j]=0.0;
}

return A;
}, 1);

Clazz.newMeth(C$, 'inv$com_actelion_research_calc_Matrix',  function (A) {
var n=A.rows$();
var invertedA=Clazz.array(Double.TYPE, [n, n]);
var R=Clazz.array(Double.TYPE, [n, n]);
var basis=C$.id$I(n);
for (var i=0; i < n; i++) {
for (var j=0; j < n; j++) {
R[i][j]=A.get$I$I(i, j);
}
}
for (var i=0; i < n - 1; i++) {
var a=Math.abs(R[i][i]);
for (var j=i + 1; j < n; j++) {
if (Math.abs(R[j][i]) > a ) {
a=Math.abs(R[j][i]);
var tempLine=R[j];
R[j]=R[i];
R[i]=tempLine;
tempLine=basis[j];
basis[j]=basis[i];
basis[i]=tempLine;
}}
for (var j=i + 1; j < n; j++) {
var l=R[j][i] / R[i][i];
for (var k=i; k < n; k++) {
R[j][k]=R[j][k] - l * R[i][k];
}
for (var k=0; k < n; k++) {
basis[j][k]=basis[j][k] - l * basis[i][k];
}
}
}
for (var k=0; k < basis.length; k++) {
for (var i=n - 1; i > -1; i--) {
var sum=0.0;
for (var j=i + 1; j < n; j++) sum+=R[i][j] * invertedA[j][k];

invertedA[i][k]=(basis[i][k] - sum) / R[i][i];
}
}
return Clazz.new_($I$(1,1).c$$DAA,[invertedA]);
}, 1);

Clazz.newMeth(C$, 'isSymmetric$com_actelion_research_calc_Matrix',  function (A) {
var rows=A.rows$();
for (var i=0; i < rows; i++) {
for (var j=0; j < i; j++) {
if (A.get$I$I(i, j) != A.get$I$I(j, i) ) return false;
}
}
return true;
}, 1);

Clazz.newMeth(C$, 'isSquare$com_actelion_research_calc_Matrix',  function (A) {
var rows=A.rows$();
var cols=A.cols$();
return (rows == cols) ? true : false;
}, 1);

Clazz.newMeth(C$, 'cholesky$com_actelion_research_calc_Matrix',  function (A) {
if (!C$.isSquare$com_actelion_research_calc_Matrix(A)) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Matrix is not square"]);
}if (!C$.isSymmetric$com_actelion_research_calc_Matrix(A)) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Matrix is not symmetric"]);
}var rows=A.rows$();
var L=Clazz.array(Double.TYPE, [rows, rows]);
for (var i=0; i < rows; i++) {
for (var j=0; j <= i; j++) {
var sum=0.0;
for (var k=0; k < j; k++) {
sum+=L[i][k] * L[j][k];
}
if (i == j) L[i][i]=Math.sqrt(A.get$I$I(i, i) - sum);
 else L[i][j]=1.0 / L[j][j] * (A.get$I$I(i, j) - sum);
}
if (L[i][i] <= 0 ) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Matrix not positive definite"]);
}}
return Clazz.new_($I$(1,1).c$$DAA,[L]);
}, 1);

Clazz.newMeth(C$, 'calculateSimilarityMatrixRowWise$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix',  function (X1, X2) {
var similarityCalculatorDoubleArray=Clazz.new_($I$(2,1));
var r1=X1.rows$();
var r2=X2.rows$();
var maSim=Clazz.new_($I$(1,1).c$$I$I,[r1, r2]);
for (var i=0; i < r1; i++) {
var x1=X1.getRow$I(i);
for (var j=0; j < r2; j++) {
var x2=X2.getRow$I(j);
var v=similarityCalculatorDoubleArray.getSimilarity$DA$DA(x1, x2);
maSim.set$I$I$D(i, j, v);
}
}
return maSim;
}, 1);

Clazz.newMeth(C$, 'calculateMaxSimilarity$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix',  function (XTrain, Xtest) {
var arrSim=Clazz.array(Double.TYPE, [Xtest.rows$()]);
var r=Xtest.rows$();
for (var i=0; i < r; i++) {
var arrDescriptor=Xtest.getRow$I(i);
var maxSim=C$.calculateMaxSimilarity$com_actelion_research_calc_Matrix$DA(XTrain, arrDescriptor);
arrSim[i]=maxSim.getDouble$();
}
return arrSim;
}, 1);

Clazz.newMeth(C$, 'calculateMaxSimilarity$com_actelion_research_calc_Matrix$DA$I',  function (X, arr, nMostSimilar) {
var li=Clazz.new_($I$(3,1));
var rows=X.rows$();
for (var i=0; i < rows; i++) {
var similarity=$I$(4,"getTanimotoSimilarity$DA$DA",[X.getRow$I(i), arr]);
li.add$O(Clazz.new_($I$(5,1).c$$I$D,[i, similarity]));
}
$I$(6,"sort$java_util_List$java_util_Comparator",[li, $I$(5).getComparatorDouble$()]);
$I$(6).reverse$java_util_List(li);
var n=Math.min(li.size$(), nMostSimilar);
var arrMax=Clazz.array($I$(5), [n]);
for (var i=0; i < n; i++) {
arrMax[i]=li.get$I(i);
}
return arrMax;
}, 1);

Clazz.newMeth(C$, 'calculateMaxSimilarity$com_actelion_research_calc_Matrix$DA',  function (X, arr) {
var rows=X.rows$();
var maxSim=Clazz.new_($I$(5,1).c$$I$D,[-1, 0]);
for (var i=0; i < rows; i++) {
var similarity=$I$(4,"getTanimotoSimilarity$DA$DA",[X.getRow$I(i), arr]);
if (similarity > maxSim.getDouble$() ) {
maxSim.setInteger$I(i);
maxSim.setDouble$D(similarity);
}}
return maxSim;
}, 1);

Clazz.newMeth(C$, 'upperTriangle$com_actelion_research_calc_Matrix',  function (maQuadratic) {
var r=maQuadratic.rows$();
var n=(((r * r) - r)/2|0);
var arr=Clazz.array(Double.TYPE, [n]);
var cc=0;
for (var i=0; i < r; i++) {
for (var j=i + 1; j < r; j++) {
arr[cc++]=maQuadratic.get$I$I(i, j);
}
}
return arr;
}, 1);

Clazz.newMeth(C$, 'appendRows$java_util_List',  function (liMatrix) {
if (liMatrix == null  || liMatrix.size$() == 0 ) {
return null;
}var cols=liMatrix.get$I(0).cols$();
var rows=0;
for (var m, $m = liMatrix.iterator$(); $m.hasNext$()&&((m=($m.next$())),1);) {
rows+=m.rows$();
}
var mAll=Clazz.new_($I$(1,1).c$$I$I,[rows, cols]);
var offsetRow=0;
for (var m, $m = liMatrix.iterator$(); $m.hasNext$()&&((m=($m.next$())),1);) {
mAll.copy$I$com_actelion_research_calc_Matrix(offsetRow, m);
offsetRow+=m.rows$();
}
return mAll;
}, 1);

Clazz.newMeth(C$, 'appendRows$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix',  function (ma0, ma1) {
var ma=Clazz.new_([ma0.rows$() + ma1.rows$(), ma0.cols$()],$I$(1,1).c$$I$I);
for (var i=0; i < ma0.rows$(); i++) {
for (var j=0; j < ma0.cols$(); j++) {
ma.set$I$I$D(i, j, ma0.get$I$I(i, j));
}
}
var offsetRows=ma0.rows$();
for (var i=0; i < ma1.rows$(); i++) {
for (var j=0; j < ma1.cols$(); j++) {
ma.set$I$I$D(i + offsetRows, j, ma1.get$I$I(i, j));
}
}
return ma;
}, 1);

Clazz.newMeth(C$, 'appendCols$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix',  function (ma0, ma1) {
if (ma0.rows$() != ma1.rows$()) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Number rows differ!"]);
}var ma=Clazz.new_([ma0.rows$(), ma0.cols$() + ma1.cols$()],$I$(1,1).c$$I$I);
for (var i=0; i < ma0.rows$(); i++) {
for (var j=0; j < ma0.cols$(); j++) {
ma.set$I$I$D(i, j, ma0.get$I$I(i, j));
}
}
var offsetCols=ma0.cols$();
for (var i=0; i < ma1.rows$(); i++) {
for (var j=0; j < ma1.cols$(); j++) {
ma.set$I$I$D(i, j + offsetCols, ma1.get$I$I(i, j));
}
}
return ma;
}, 1);

Clazz.newMeth(C$, 'create$java_util_List',  function (li) {
var a=Clazz.array(Double.TYPE, [li.size$(), null]);
for (var i=0; i < li.size$(); i++) {
a[i]=li.get$I(i);
}
return Clazz.new_($I$(1,1).c$$DAA,[a]);
}, 1);

Clazz.newMeth(C$, 'countFieldsBiggerThan$com_actelion_research_calc_Matrix$I$D',  function (ma, row, thresh) {
var cc=0;
for (var i=0; i < ma.getColDim$(); i++) {
if (ma.get$I$I(row, i) > thresh ) {
++cc;
}}
return cc;
}, 1);

Clazz.newMeth(C$, 'countFieldsBiggerThanThreshColWise$com_actelion_research_calc_Matrix$I$D',  function (ma, col, thresh) {
var cc=0;
for (var i=0; i < ma.rows$(); i++) {
if (ma.get$I$I(i, col) > thresh ) {
++cc;
}}
return cc;
}, 1);

Clazz.newMeth(C$, 'countFieldsBiggerThanThreshColWise$com_actelion_research_calc_Matrix$D',  function (ma, thresh) {
var maCounts=Clazz.new_([1, ma.cols$()],$I$(1,1).c$$I$I);
for (var i=0; i < ma.cols$(); i++) {
var cc=C$.countFieldsBiggerThanThreshColWise$com_actelion_research_calc_Matrix$I$D(ma, i, thresh);
maCounts.set$I$I$D(0, i, cc);
}
return maCounts;
}, 1);

Clazz.newMeth(C$, 'getDistanceMatrixTanimotoInv$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix',  function (ma1, ma2) {
var maDist=Clazz.new_([ma1.getRowDim$(), ma2.getRowDim$()],$I$(1,1).c$$I$I);
for (var i=0; i < ma1.getRowDim$(); i++) {
for (var j=0; j < ma2.getRowDim$(); j++) {
var dist=C$.getDistanceTanimotoInv$com_actelion_research_calc_Matrix$I$com_actelion_research_calc_Matrix$I(ma1, i, ma2, j);
maDist.set$I$I$D(i, j, dist);
}
}
return maDist;
}, 1);

Clazz.newMeth(C$, 'getDistanceMatrix$java_util_List',  function (li) {
var maDist=Clazz.new_([li.size$(), li.size$()],$I$(1,1).c$$I$I);
for (var i=0; i < li.size$(); i++) {
for (var j=0; j < li.size$(); j++) {
var dist=li.get$I(i).distance$java_awt_geom_Point2D(li.get$I(j));
maDist.set$I$I$D(i, j, dist);
}
}
return maDist;
}, 1);

Clazz.newMeth(C$, 'getDistTanimotoInvReduced$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix',  function (ma1, ma2) {
var maDist=Clazz.new_([ma1.getRowDim$(), ma2.getRowDim$()],$I$(1,1).c$$I$I);
for (var i=0; i < ma1.getRowDim$(); i++) {
for (var j=0; j < ma2.getRowDim$(); j++) {
var dist=C$.getDistTanimotoInvReduced$com_actelion_research_calc_Matrix$I$com_actelion_research_calc_Matrix$I(ma1, i, ma2, j);
maDist.set$I$I$D(i, j, dist);
}
}
return maDist;
}, 1);

Clazz.newMeth(C$, 'getDistanceTanimotoInv$com_actelion_research_calc_Matrix$I$com_actelion_research_calc_Matrix$I',  function (ma1, row1, ma2, row2) {
var dist=0;
var dAtB=ma1.multiply$I$com_actelion_research_calc_Matrix$I(row1, ma2, row2);
var dAtA=ma1.multiply$I$com_actelion_research_calc_Matrix$I(row1, ma1, row1);
var dBtB=ma2.multiply$I$com_actelion_research_calc_Matrix$I(row2, ma2, row2);
dist=dAtB / (dAtA + dBtB - dAtB);
return 1 - dist;
}, 1);

Clazz.newMeth(C$, 'getSumSquaredDiff$com_actelion_research_calc_Matrix$I$com_actelion_research_calc_Matrix$I',  function (ma1, row1, ma2, row2) {
var sum=0;
for (var i=0; i < ma1.cols$(); i++) {
var diff=ma1.get$I$I(row1, i) - ma2.get$I$I(row2, i);
sum+=diff * diff;
}
return sum;
}, 1);

Clazz.newMeth(C$, 'getTotalSumSquaredDiffRowWise$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix',  function (ma1, ma2) {
var rows=ma1.rows$();
var sum=0;
for (var i=0; i < rows; i++) {
var dist=C$.getSumSquaredDiff$com_actelion_research_calc_Matrix$I$com_actelion_research_calc_Matrix$I(ma1, i, ma2, i);
sum+=dist;
System.out.println$S($I$(7,"format1$Double",[Double.valueOf$D(dist)]));
}
return sum;
}, 1);

Clazz.newMeth(C$, 'getDistTanimotoInvReduced$com_actelion_research_calc_Matrix$I$com_actelion_research_calc_Matrix$I',  function (ma1, row1, ma2, row2) {
var dist=0;
var li1=Clazz.new_($I$(3,1));
var li2=Clazz.new_($I$(3,1));
for (var ii=0; ii < ma1.getColDim$(); ii++) {
if ((ma1.get$I$I(row1, ii) != 0 ) || (ma2.get$I$I(row2, ii) != 0 ) ) {
li1.add$O( new Double(ma1.get$I$I(row1, ii)));
li2.add$O( new Double(ma2.get$I$I(row2, ii)));
}}
var maRow1=Clazz.new_($I$(1,1).c$$Z$java_util_List,[true, li1]);
var maRow2=Clazz.new_($I$(1,1).c$$Z$java_util_List,[true, li2]);
var dAtB=maRow1.multiply$I$com_actelion_research_calc_Matrix$I(0, maRow2, 0);
var dAtA=maRow1.multiply$I$com_actelion_research_calc_Matrix$I(0, maRow1, 0);
var dBtB=maRow2.multiply$I$com_actelion_research_calc_Matrix$I(0, maRow2, 0);
dist=dAtB / (dAtA + dBtB - dAtB);
return 1 - dist;
}, 1);

Clazz.newMeth(C$, 'getMooreNeighborhood$java_awt_Point$com_actelion_research_calc_Matrix',  function (p, ma) {
var li=Clazz.new_($I$(3,1));
var startX=Math.max(0, p.x - 1);
var endX=Math.min(ma.cols$(), p.x + 2);
var startY=Math.max(0, p.y - 1);
var endY=Math.min(ma.rows$(), p.y + 2);
for (var i=startY; i < endY; i++) {
for (var j=startX; j < endX; j++) {
if (i != p.y || j != p.x ) {
if (ma.get$I$I(i, j) > 0 ) {
li.add$O(Clazz.new_($I$(8,1).c$$I$I,[j, i]));
}}}
}
return li;
}, 1);

Clazz.newMeth(C$, 'getMooreNeighborhood$java_awt_Point$I$com_actelion_research_calc_Matrix',  function (p, r, ma) {
var li=Clazz.new_($I$(3,1));
var startX=Math.max(0, p.x - r);
var endX=Math.min(ma.cols$(), p.x + r + 1 );
var startY=Math.max(0, p.y - r);
var endY=Math.min(ma.rows$(), p.y + r + 1 );
for (var i=startY; i < endY; i++) {
for (var j=startX; j < endX; j++) {
if (i != p.y || j != p.x ) {
if (ma.get$I$I(i, j) > 0 ) {
li.add$O(Clazz.new_($I$(8,1).c$$I$I,[j, i]));
}}}
}
return li;
}, 1);

Clazz.newMeth(C$, 'getRowMinUnique$com_actelion_research_calc_Matrix',  function (ma) {
var maTmp=Clazz.new_($I$(1,1).c$$com_actelion_research_calc_Matrix,[ma]);
var maMin=Clazz.new_([maTmp.getRowDim$(), 1],$I$(1,1).c$$I$I);
for (var i=0; i < maTmp.getRowDim$(); i++) {
var td=maTmp.getMinPos$();
maMin.set$I$I$D(td.y, 0, td.getScore$());
maTmp.setRow$I$D(td.y, 1.7976931348623157E308);
maTmp.setCol$I$D(td.x, 1.7976931348623157E308);
}
return maMin;
}, 1);

Clazz.newMeth(C$, 'getPoints$com_actelion_research_calc_Matrix',  function (ma) {
var li=Clazz.new_($I$(3,1));
for (var i=0; i < ma.rows$(); i++) {
for (var j=0; j < ma.cols$(); j++) {
if (ma.get$I$I(i, j) > 0 ) {
li.add$O(Clazz.new_($I$(8,1).c$$I$I,[j, i]));
}}
}
return li;
}, 1);

Clazz.newMeth(C$, 'getIndicesUniqueMaxRowWise$com_actelion_research_calc_Matrix',  function (maIn) {
var li=Clazz.new_($I$(3,1));
var ma=Clazz.new_($I$(1,1).c$$com_actelion_research_calc_Matrix,[maIn]);
for (var i=0; i < ma.rows$(); i++) {
var p=ma.getMaxIndex$();
li.add$O(p);
var row=p.y;
for (var j=0; j < ma.cols$(); j++) {
ma.set$I$I$D(row, j, -1.7976931348623157E308);
}
}
return li;
}, 1);

Clazz.newMeth(C$, 'getIndicesUniqueMaxColumnWise$com_actelion_research_calc_Matrix',  function (maIn) {
var li=Clazz.new_($I$(3,1));
var ma=Clazz.new_($I$(1,1).c$$com_actelion_research_calc_Matrix,[maIn]);
for (var col=0; col < ma.cols$(); col++) {
var p=ma.getMaxIndex$();
li.add$O(p);
var colMax=p.x;
for (var row=0; row < ma.rows$(); row++) {
ma.set$I$I$D(row, colMax, -1.7976931348623157E308);
}
}
return li;
}, 1);

Clazz.newMeth(C$, 'getScaledByFactor$com_actelion_research_calc_Matrix$D',  function (ma, fac) {
var cols=((ma.cols$() * fac + 0.5)|0);
var rows=((ma.rows$() * fac + 0.5)|0);
var maSc=Clazz.new_($I$(1,1).c$$I$I,[rows, cols]);
for (var i=0; i < rows; i++) {
for (var j=0; j < cols; j++) {
var v=ma.get$I$I(((i / fac)|0), ((j / fac)|0));
maSc.set$I$I$D(i, j, v);
}
}
return maSc;
}, 1);

Clazz.newMeth(C$, 'getScaled$com_actelion_research_calc_Matrix',  function (ma) {
var maCentered=ma.getCenteredMatrix$();
var maSD=ma.getStandardDeviationCols$();
var rows=ma.rows$();
var cols=ma.cols$();
var maScale=Clazz.new_($I$(1,1).c$$I$I,[rows, cols]);
for (var i=0; i < cols; i++) {
var sdv=maSD.get$I$I(0, i);
for (var j=0; j < rows; j++) {
maScale.set$I$I$D(j, i, maCentered.get$I$I(j, i) / sdv);
}
}
return maScale;
}, 1);

Clazz.newMeth(C$, 'getKMeanClusters$com_actelion_research_calc_Matrix$I',  function (ma, k) {
var maCenters=Clazz.new_([k, ma.getColDim$()],$I$(1,1).c$$I$I);
var iMaxIterations=100;
var arrIndex=Clazz.array(Integer.TYPE, [ma.getRowDim$()]);
var rnd=Clazz.new_($I$(9,1));
for (var ii=0; ii < k; ii++) {
var rndIndex=rnd.nextInt$I(ma.getRowDim$());
maCenters.assignRow$I$DA(ii, ma.getRow$I(rndIndex));
}
maCenters=maCenters.getSorted$();
var maCenters2=Clazz.new_($I$(1,1).c$$com_actelion_research_calc_Matrix,[maCenters]);
var counter=0;
do {
maCenters=Clazz.new_($I$(1,1).c$$com_actelion_research_calc_Matrix,[maCenters2]);
for (var ii=0; ii < arrIndex.length; ii++) arrIndex[ii]=-1;

var maDist=C$.getDistTanimotoInvReduced$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix(ma, maCenters);
for (var ii=0; ii < maDist.getRowDim$(); ii++) {
var index=maDist.getMinRowIndexRND$I(ii);
arrIndex[ii]=index;
}
var arrNumObjects=Clazz.array(Double.TYPE, [k]);
maCenters2.set$D(0.0);
for (var ii=0; ii < ma.getRowDim$(); ii++) {
var index=arrIndex[ii];
maCenters2.add2Row$I$com_actelion_research_calc_Matrix$I(index, ma, ii);
++arrNumObjects[index];
}
for (var ii=0; ii < maCenters2.getRowDim$(); ii++) {
if (arrNumObjects[ii] > 0 ) maCenters2.devideRow$I$D(ii, arrNumObjects[ii]);
 else {
maCenters2.assignRow$I$DA(ii, maCenters.getRow$I(ii));
}}
maCenters2=maCenters2.getSorted$();
++counter;
if (counter > iMaxIterations) {
System.err.print$S("Max num iterations reached.\n");
break;
}} while (!maCenters.equal$com_actelion_research_calc_Matrix(maCenters2));
System.out.println$S("Number iterations: " + counter);
return maCenters;
}, 1);

Clazz.newMeth(C$, 'getCorrPearson$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix',  function (A, B) {
var a=A.toArray$();
var aCent=$I$(10).getCentered$DA(a);
var aCentNorm=$I$(10).getNormalized$DA(aCent);
var b=B.toArray$();
var bCent=$I$(10).getCentered$DA(b);
var bCentNorm=$I$(10).getNormalized$DA(bCent);
var val=$I$(10).getCorrPearsonStandardized$DA$DA(aCentNorm, bCentNorm);
return val;
}, 1);

Clazz.newMeth(C$, 'getCorrSpearman$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix',  function (A, B) {
var a=A.toArray$();
var b=B.toArray$();
var daA=Clazz.new_($I$(11,1).c$$DA,[a]);
var daB=Clazz.new_($I$(11,1).c$$DA,[b]);
var correlationCalculator=Clazz.new_($I$(12,1));
var c=correlationCalculator.calculateCorrelation$com_actelion_research_calc_INumericalDataColumn$com_actelion_research_calc_INumericalDataColumn$I(daA, daB, 1);
return c;
}, 1);

Clazz.newMeth(C$, 'getCorrPearson$com_actelion_research_calc_Matrix$I$I',  function (A, col1, col2) {
var val=0;
var Anorm=A.getCol$I(col1);
Anorm=Anorm.getCenteredMatrix$();
Anorm=Anorm.getNormalizedMatrix$();
var Bnorm=A.getCol$I(col2);
Bnorm=Bnorm.getCenteredMatrix$();
Bnorm=Bnorm.getNormalizedMatrix$();
val=C$.getCorrPearsonStandardized$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix(Anorm, Bnorm);
return val;
}, 1);

Clazz.newMeth(C$, 'getCorrPearsonStandardized$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix',  function (A, B) {
var val=0;
var covXY=C$.getCovarianceCentered$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix(A, B);
var varA=A.getVarianceCentered$();
var varB=B.getVarianceCentered$();
val=covXY / (varA * varB);
return val;
}, 1);

Clazz.newMeth(C$, 'getCovariance$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix',  function (A, B) {
var covXY=0;
var Amean=A.getMean$();
var Bmean=B.getMean$();
var sum=0;
for (var ii=0; ii < A.getRowDim$(); ii++) {
for (var jj=0; jj < A.getColDim$(); jj++) {
sum+=(A.get$I$I(ii, jj) - Amean) * (B.get$I$I(ii, jj) - Bmean);
}
}
covXY=sum / (A.getNumElements$() - 1);
return covXY;
}, 1);

Clazz.newMeth(C$, 'getCovarianceCentered$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix',  function (A, B) {
var covXY=0;
var sum=0;
var cols=A.cols$();
var rows=A.rows$();
for (var i=0; i < rows; i++) {
var a=A.getRow$I(i);
var b=B.getRow$I(i);
for (var j=0; j < cols; j++) {
sum+=(a[j] * b[j]);
}
}
covXY=sum / (A.getNumElements$() - 1);
return covXY;
}, 1);

Clazz.newMeth(C$, 'getRandomMatrix$I$I',  function (rows, cols) {
var ma=Clazz.new_($I$(1,1).c$$I$I,[rows, cols]);
var rnd=Clazz.new_($I$(9,1));
for (var i=0; i < ma.getRowDim$(); i++) {
for (var j=0; j < ma.getColDim$(); j++) {
ma.set$I$I$D(i, j, rnd.nextDouble$());
}
}
return ma;
}, 1);

Clazz.newMeth(C$, 'rnorm$I$D$D',  function (n, mean, sd) {
var x=Clazz.new_($I$(1,1).c$$I$I,[n, 1]);
var random=Clazz.new_($I$(9,1));
for (var i=0; i < n; i++) {
var v=random.nextGaussian$();
v=v * sd + mean;
x.set$I$I$D(i, 0, v);
}
return x;
}, 1);

Clazz.newMeth(C$, 'getNonZeroCols$com_actelion_research_calc_Matrix',  function (X) {
var s=(X.cols$()/32|0);
if (X.cols$() % 32 > 0) {
++s;
}var ivMask=Clazz.new_($I$(13,1).c$$I,[s]);
var r=X.rows$();
var c=X.cols$();
for (var i=0; i < c; i++) {
var zero=true;
for (var j=0; j < r; j++) {
if (Math.abs(X.get$I$I(j, i)) > $I$(1).TINY16 ) {
zero=false;
break;
}}
if (!zero) {
ivMask.setBit$I(i);
}}
return ivMask;
}, 1);

Clazz.newMeth(C$, 'vecvec2Matrix$java_util_Vector$com_actelion_research_calc_Matrix',  function (vecvec, ma) {
var it=vecvec.iterator$();
var iLenCol0=(it.next$()).size$();
for (; it.hasNext$(); ) {
var iLen=(it.next$()).size$();
if (iLen != iLenCol0) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["All vectors must have the same length."]);
}}
var iRows=vecvec.size$();
ma.resize$I$I(iRows, iLenCol0);
it=vecvec.iterator$();
var iRow=0;
for (; it.hasNext$(); ) {
var vec=Clazz.new_([(it.next$())],$I$(14,1).c$$java_util_Collection);
for (var ii=0; ii < vec.size$(); ii++) {
ma.set$I$I$D(iRow, ii, (vec.get$I(ii)).doubleValue$());
}
++iRow;
}
}, 1);

Clazz.newMeth(C$, 'readCSV$java_io_File',  function (fi) {
var li=Clazz.new_($I$(3,1));
var br=Clazz.new_([Clazz.new_($I$(16,1).c$$java_io_File,[fi])],$I$(15,1).c$$java_io_Reader);
var cols=-1;
var l=null;
while ((l=br.readLine$()) != null ){
var arr=l.split$S(",");
if (cols == -1) {
cols=arr.length;
} else {
if (arr.length != cols) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Number of columns differ!"]);
}}li.add$O(arr);
}
var ma=Clazz.new_([li.size$(), cols],$I$(1,1).c$$I$I);
for (var i=0; i < li.size$(); i++) {
var arr=li.get$I(i);
for (var j=0; j < arr.length; j++) {
var v=Double.parseDouble$S(arr[j]);
ma.set$I$I$D(i, j, v);
}
}
return ma;
}, 1);

Clazz.newMeth(C$, 'read$java_io_File',  function (fiMatrix) {
return C$.read$java_io_File$Z(fiMatrix, false);
}, 1);

Clazz.newMeth(C$, 'read$java_io_File$Z',  function (fiMatrix, skipFirstLine) {
var fis=Clazz.new_($I$(17,1).c$$java_io_File,[fiMatrix]);
var A=C$.read$java_io_InputStream$Z(fis, skipFirstLine);
fis.close$();
return A;
}, 1);

Clazz.newMeth(C$, 'read$S',  function (s) {
var is=Clazz.new_([s.getBytes$()],$I$(18,1).c$$BA);
var A=C$.read$java_io_InputStream$Z(is, false);
is.close$();
return A;
}, 1);

Clazz.newMeth(C$, 'readAsLineBase64Encoded$S',  function (s) {
var decoder=$I$(19).getDecoder$();
var b=decoder.decode$S(s);
var is=Clazz.new_($I$(18,1).c$$BA,[b]);
var A=C$.read$java_io_InputStream$Z(is, false);
is.close$();
return A;
}, 1);

Clazz.newMeth(C$, 'read$java_io_InputStream',  function (is) {
return C$.read$java_io_InputStream$Z(is, false);
}, 1);

Clazz.newMeth(C$, 'read$java_io_InputStream$Z',  function (is, skipFirstLine) {
var li=Clazz.new_($I$(3,1));
var scannerLine=Clazz.new_($I$(20,1).c$$java_io_InputStream,[is]);
if (skipFirstLine) {
scannerLine.nextLine$();
}var rows=0;
var cols=0;
while (scannerLine.hasNextLine$()){
++rows;
var scannerValue=Clazz.new_([scannerLine.nextLine$()],$I$(20,1).c$$S);
var arr=null;
if (cols == 0) {
arr=Clazz.new_($I$(11,1));
while (scannerValue.hasNextDouble$()){
var d=scannerValue.nextDouble$();
arr.add$D(d);
++cols;
}
} else {
arr=Clazz.new_($I$(11,1).c$$I,[cols]);
while (scannerValue.hasNextDouble$()){
var d=scannerValue.nextDouble$();
arr.add$D(d);
}
}li.add$O(arr);
}
scannerLine.close$();
var a=Clazz.array(Double.TYPE, [rows, cols]);
for (var i=0; i < li.size$(); i++) {
var arr=li.get$I(i);
for (var j=0; j < cols; j++) {
a[i][j]=arr.get$I(j);
}
}
return Clazz.new_($I$(1,1).c$$DAA,[a]);
}, 1);

Clazz.newMeth(C$, 'writeQuadraticSymmetricMatrixPairwise$com_actelion_research_calc_Matrix$java_io_File',  function (ma, fiTxt) {
if (ma.rows$() != ma.cols$()) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Not a quadratic matrix"]);
}var bw=Clazz.new_([Clazz.new_($I$(22,1).c$$java_io_File,[fiTxt])],$I$(21,1).c$$java_io_Writer);
var n=ma.rows$();
var rows2Write=(((n * n) - n)/2|0);
var cc=0;
for (var i=0; i < ma.rows$(); i++) {
for (var j=i + 1; j < ma.cols$(); j++) {
var v0=ma.get$I$I(i, j);
var v1=ma.get$I$I(j, i);
if (v0 != v1 ) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Matrix not symmetric"]);
}var sb=Clazz.new_($I$(23,1));
sb.append$I(i);
sb.append$S("\t");
sb.append$I(j);
sb.append$S("\t");
sb.append$D(v0);
if (cc < rows2Write - 1) {
sb.append$S("\n");
}++cc;
bw.write$S(sb.toString());
}
}
bw.close$();
}, 1);

Clazz.newMeth(C$, 'columnIntoDoubleArray$com_actelion_research_calc_Matrix$I$com_actelion_research_util_datamodel_DoubleArray',  function (A, col, da) {
da.clear$();
var r=A.rows$();
for (var i=0; i < r; i++) {
da.add$D(A.get$I$I(i, col));
}
}, 1);

Clazz.newMeth(C$, 'createIdentifiedObject$com_actelion_research_calc_Matrix',  function (A) {
var rows=A.rows$();
var liIdentifiedObject=Clazz.new_($I$(3,1).c$$I,[rows]);
for (var i=0; i < rows; i++) {
var a=A.getRow$I(i);
var io=Clazz.new_($I$(24,1).c$$O$J,[a, i]);
liIdentifiedObject.add$O(io);
}
return liIdentifiedObject;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:45 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
