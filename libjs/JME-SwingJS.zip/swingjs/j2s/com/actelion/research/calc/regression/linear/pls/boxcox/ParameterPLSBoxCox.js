(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.linear.pls.boxcox"),I$=[[0,'com.actelion.research.calc.MatrixFunctions','java.text.DecimalFormat','StringBuilder','com.actelion.research.calc.regression.ParameterRegressionMethod']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ParameterPLSBoxCox", null, 'com.actelion.research.calc.regression.linear.pls.ParameterPLS');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['lambda']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$$S$I.apply(this,["PLS Power", 3]);C$.$init$.apply(this);
this.setLambda$D(0.4);
}, 1);

Clazz.newMeth(C$, 'c$$I',  function (factors) {
;C$.superclazz.c$$S$I.apply(this,["PLS Power", factors]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_calc_regression_linear_pls_boxcox_ParameterPLSBoxCox',  function (orig) {
;C$.superclazz.c$$com_actelion_research_calc_regression_linear_pls_ParameterPLS.apply(this,[orig]);C$.$init$.apply(this);
this.copy$com_actelion_research_calc_regression_linear_pls_boxcox_ParameterPLSBoxCox(orig);
}, 1);

Clazz.newMeth(C$, 'copy$com_actelion_research_calc_regression_linear_pls_boxcox_ParameterPLSBoxCox',  function (orig) {
C$.superclazz.prototype.copy$com_actelion_research_calc_regression_linear_pls_ParameterPLS.apply(this, [orig]);
this.setLambda$D(orig.getLambda$());
});

Clazz.newMeth(C$, 'equals$O',  function (obj) {
if (!(Clazz.instanceOf(obj, "com.actelion.research.calc.regression.linear.pls.boxcox.ParameterPLSBoxCox"))) {
return false;
}var eq=C$.superclazz.prototype.equals$O.apply(this, [obj]);
var p=obj;
if (!$I$(1,"equals$D$D",[this.getLambda$(), p.getLambda$()])) {
eq=false;
}return eq;
});

Clazz.newMeth(C$, 'getLambda$',  function () {
return this.lambda;
});

Clazz.newMeth(C$, 'setLambda$D',  function (lambda) {
this.lambda=lambda;
this.properties.put$O$O("Lambda", Double.toString$D(lambda));
});

Clazz.newMeth(C$, ['compareTo$com_actelion_research_calc_regression_ParameterRegressionMethod','compareTo$O'],  function (o) {
var cmp=0;
var parameterPLSBoxCox=o;
if (this.getFactors$() > parameterPLSBoxCox.getFactors$()) {
cmp=1;
} else if (this.getFactors$() < parameterPLSBoxCox.getFactors$()) {
cmp=-1;
}if (cmp == 0) {
if (this.lambda > parameterPLSBoxCox.lambda ) {
cmp=1;
} else if (this.lambda < parameterPLSBoxCox.lambda ) {
cmp=-1;
}}return cmp;
});

Clazz.newMeth(C$, 'decodeProperties2Parameter$',  function () {
this.factors=Integer.parseInt$S(this.properties.getProperty$S("Factors"));
this.lambda=Double.parseDouble$S(this.properties.getProperty$S("Lambda"));
});

Clazz.newMeth(C$, 'toString',  function () {
var df=Clazz.new_($I$(2,1).c$$S,["0.0##"]);
var sb=Clazz.new_($I$(3,1).c$$S,["ParameterPLSBoxCox{"]);
sb.append$S("name=").append$S(this.getName$());
sb.append$S(", factors=").append$I(this.getFactors$());
sb.append$S(", lambda=").append$S(df.format$D(this.lambda));
sb.append$C("}");
return sb.toString();
});

Clazz.newMeth(C$, 'getHeader$',  function () {
var li=$I$(4).getHeader$();
li.add$O("Factors");
li.add$O("Lambda");
return li;
}, 1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:05:55 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
