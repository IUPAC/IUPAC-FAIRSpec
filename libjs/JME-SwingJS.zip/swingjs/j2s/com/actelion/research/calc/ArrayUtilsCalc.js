(function(){var P$=Clazz.newPackage("com.actelion.research.calc"),I$=[[0,'java.util.ArrayList','java.util.Arrays','com.actelion.research.calc.statistics.median.ModelMedianDouble','com.actelion.research.calc.statistics.median.ModelMedianInteger','java.util.TreeSet','java.util.StringTokenizer','StringBuilder','java.text.DecimalFormat']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ArrayUtilsCalc");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'cat$IA$IA',  function (a, b) {
var c=Clazz.array(Integer.TYPE, [a.length + b.length]);
for (var i=0; i < a.length; i++) {
c[i]=a[i];
}
for (var i=0; i < b.length; i++) {
c[a.length + i]=b[i];
}
return c;
}, 1);

Clazz.newMeth(C$, 'contains$IA$I',  function (a, b) {
var bFound=false;
for (var i=0; i < a.length; i++) {
if (a[i] == b) {
bFound=true;
break;
}}
return bFound;
}, 1);

Clazz.newMeth(C$, 'containsAll$IA$IA',  function (a, b) {
var bFound=true;
for (var i=0; i < b.length; i++) {
if (!C$.contains$IA$I(a, b[i])) {
bFound=false;
break;
}}
return bFound;
}, 1);

Clazz.newMeth(C$, 'copy$IA',  function (a) {
var b=Clazz.array(Integer.TYPE, [a.length]);
for (var i=0; i < b.length; i++) {
b[i]=a[i];
}
return b;
}, 1);

Clazz.newMeth(C$, 'copy$BA',  function (a) {
var b=Clazz.array(Byte.TYPE, [a.length]);
for (var i=0; i < b.length; i++) {
b[i]=a[i];
}
return b;
}, 1);

Clazz.newMeth(C$, 'copyIntArray$java_util_List',  function (li) {
var liC=Clazz.new_([li.size$()],$I$(1,1).c$$I);
for (var a, $a = li.iterator$(); $a.hasNext$()&&((a=($a.next$())),1);) {
var c=Clazz.array(Integer.TYPE, [a.length]);
System.arraycopy$O$I$O$I$I(a, 0, c, 0, a.length);
liC.add$O(c);
}
return liC;
}, 1);

Clazz.newMeth(C$, 'copy$OA',  function (a) {
var b=Clazz.array(java.lang.Object, [a.length]);
for (var ii=0; ii < a.length; ii++) {
b[ii]=a[ii];
}
return b;
}, 1);

Clazz.newMeth(C$, 'equals$IA$IA',  function (a, b) {
if (a.length != b.length) {
return false;
}for (var i=0; i < b.length; i++) {
if (a[i] != b[i]) {
return false;
}}
return true;
}, 1);

Clazz.newMeth(C$, 'extractCol$DAA$I',  function (a, col) {
var b=Clazz.array(Double.TYPE, [a.length]);
for (var ii=0; ii < a.length; ii++) {
b[ii]=a[ii][col];
}
return b;
}, 1);

Clazz.newMeth(C$, 'filter$IA$DA',  function (arrData, arrFilter) {
var arr=Clazz.array(Double.TYPE, [arrData.length]);
for (var i=0; i < arr.length; i++) {
var val=0;
for (var j=0; j < arrFilter.length; j++) {
var indexFilter=((-arrFilter.length/2|0)) + j;
var indexData=indexFilter + i;
if (indexData >= 0 && indexData < arr.length ) {
val+=arrData[indexData] * arrFilter[j];
}}
arr[i]=val;
}
return arr;
}, 1);

Clazz.newMeth(C$, 'filter$BA$DA',  function (arrData, arrFilter) {
var arr=Clazz.array(Double.TYPE, [arrData.length]);
for (var i=0; i < arr.length; i++) {
var val=0;
for (var j=0; j < arrFilter.length; j++) {
var indexFilter=((-arrFilter.length/2|0)) + j;
var indexData=indexFilter + i;
if (indexData >= 0 && indexData < arr.length ) {
val+=arrData[indexData] * arrFilter[j];
}}
arr[i]=val;
}
return arr;
}, 1);

Clazz.newMeth(C$, 'findIdentical$IA$IA',  function (a, b) {
var bFound=false;
for (var i=0; i < a.length; i++) {
for (var j=0; j < b.length; j++) {
if (a[i] == b[j]) {
bFound=true;
break;
}}
}
return bFound;
}, 1);

Clazz.newMeth(C$, 'getCorrPearson$java_util_List',  function (li) {
var a=Clazz.array(Double.TYPE, [li.size$()]);
var b=Clazz.array(Double.TYPE, [li.size$()]);
for (var i=0; i < li.size$(); i++) {
a[i]=li.get$I(i).x;
b[i]=li.get$I(i).y;
}
return C$.getCorrPearson$DA$DA(a, b);
}, 1);

Clazz.newMeth(C$, 'getCorrPearson$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix',  function (A, B) {
var a=A.toArray$();
var b=B.toArray$();
return C$.getCorrPearson$DA$DA(a, b);
}, 1);

Clazz.newMeth(C$, 'getCorrPearson$DA$DA',  function (a, b) {
var aCent=C$.getCentered$DA(a);
var aCentNorm=C$.getNormalized$DA(aCent);
var bCent=C$.getCentered$DA(b);
var bCentNorm=C$.getNormalized$DA(bCent);
var val=C$.getCorrPearsonStandardized$DA$DA(aCentNorm, bCentNorm);
return val;
}, 1);

Clazz.newMeth(C$, 'getCorrPearsonStandardized$DA$DA',  function (a, b) {
var covXY=C$.getCovarianceCentered$DA$DA(a, b);
var varA=C$.getVariance$DA(a);
var varB=C$.getVariance$DA(b);
var val=covXY / (varA * varB);
return val;
}, 1);

Clazz.newMeth(C$, 'getCentered$DA',  function (arr) {
var arrCent=Clazz.array(Double.TYPE, [arr.length]);
var mean=C$.getMean$DA(arr);
for (var i=0; i < arr.length; i++) {
arrCent[i]=arr[i] - mean;
}
return arrCent;
}, 1);

Clazz.newMeth(C$, 'getCovarianceCentered$DA$DA',  function (a, b) {
var sum=0;
for (var i=0; i < a.length; i++) {
sum+=a[i] * b[i];
}
var covXY=sum / (a.length - 1);
return covXY;
}, 1);

Clazz.newMeth(C$, 'getGiniCoefficient$DA',  function (a) {
var sum=0;
var sumDiff=0;
for (var i=0; i < a.length; i++) {
sum+=a[i];
for (var j=0; j < a.length; j++) {
sumDiff=Math.abs(a[i] - a[j]);
}
}
var gini=sumDiff / (2 * a.length * sum );
return gini;
}, 1);

Clazz.newMeth(C$, 'getNormalized$DA',  function (arr) {
var arrNorm=Clazz.array(Double.TYPE, [arr.length]);
var sdv=C$.getStandardDeviation$DA(arr);
for (var i=0; i < arr.length; i++) {
arrNorm[i]=arr[i] / sdv;
}
return arrNorm;
}, 1);

Clazz.newMeth(C$, 'getMean$DA',  function (arr) {
var sum=0;
for (var i=0; i < arr.length; i++) {
sum+=arr[i];
}
return sum / arr.length;
}, 1);

Clazz.newMeth(C$, 'getMean$IA',  function (arr) {
var sum=0;
for (var i=0; i < arr.length; i++) {
sum+=arr[i];
}
return sum / arr.length;
}, 1);

Clazz.newMeth(C$, 'getMedian$DA',  function (arr) {
$I$(2).sort$DA(arr);
var m=Clazz.new_($I$(3,1));
m.lowerQuartile=C$.getPercentileFromSorted$DA$D(arr, 0.25);
m.median=C$.getPercentileFromSorted$DA$D(arr, 0.5);
m.upperQuartile=C$.getPercentileFromSorted$DA$D(arr, 0.75);
m.size=arr.length;
return m;
}, 1);

Clazz.newMeth(C$, 'getMedian$IA',  function (arr) {
$I$(2).sort$IA(arr);
var m=Clazz.new_($I$(4,1));
m.lowerQuartile=C$.getPercentileFromSorted$IA$D(arr, 0.25);
m.median=C$.getPercentileFromSorted$IA$D(arr, 0.5);
m.upperQuartile=C$.getPercentileFromSorted$IA$D(arr, 0.75);
m.size=arr.length;
return m;
}, 1);

Clazz.newMeth(C$, 'getPercentileFromSorted$DA$D',  function (arr, fraction) {
if (arr.length == 1) {
return arr[0];
}var percentile=0;
var len=arr.length;
if ((((len * fraction)|0)) == (len * fraction) ) {
var index1=((len * fraction)|0) - 1;
var index2=index1 + 1;
if (index1 < 0) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Fraction to small."]);
}percentile=(arr[index1] + arr[index2]) / 2.0;
} else {
var index1=((len * fraction)|0);
percentile=arr[index1];
}return percentile;
}, 1);

Clazz.newMeth(C$, 'getPercentileFromSorted$IA$D',  function (arr, fraction) {
if (arr.length == 1) {
return arr[0];
}var percentile=0;
var len=arr.length;
if ((((len * fraction)|0)) == (len * fraction) ) {
var index1=((len * fraction)|0) - 1;
var index2=index1 + 1;
if (index1 < 0) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Fraction to small."]);
}percentile=(((arr[index1] + arr[index2]) / 2.0 + 0.5)|0);
} else {
var index1=((len * fraction)|0);
percentile=arr[index1];
}return percentile;
}, 1);

Clazz.newMeth(C$, 'getStandardDeviation$DA',  function (arr) {
var sum=0;
var mean=C$.getMean$DA(arr);
for (var i=0; i < arr.length; i++) {
sum+=(arr[i] - mean) * (arr[i] - mean);
}
var sdv=Math.sqrt(sum / (arr.length - 1));
return sdv;
}, 1);

Clazz.newMeth(C$, 'getVariance$DA',  function (arr) {
var sum=0;
var mean=C$.getMean$DA(arr);
for (var i=0; i < arr.length; i++) {
sum+=(arr[i] - mean) * (arr[i] - mean);
}
var $var=sum / (arr.length - 1);
return $var;
}, 1);

Clazz.newMeth(C$, 'getVariance$IA',  function (arr) {
var sum=0;
var mean=C$.getMean$IA(arr);
for (var i=0; i < arr.length; i++) {
sum+=(arr[i] - mean) * (arr[i] - mean);
}
var $var=sum / (arr.length - 1);
return $var;
}, 1);

Clazz.newMeth(C$, 'sum$IA',  function (a) {
var b=0;
for (var ii=0; ii < a.length; ii++) {
b+=a[ii];
}
return b;
}, 1);

Clazz.newMeth(C$, 'sum$JA',  function (a) {
var b=0;
for (var ii=0; ii < a.length; ii++) {
b=Long.$ival(Long.$add(b,(a[ii])));
}
return b;
}, 1);

Clazz.newMeth(C$, 'sum$BA',  function (a) {
var b=0;
for (var ii=0; ii < a.length; ii++) {
b+=a[ii];
}
return b;
}, 1);

Clazz.newMeth(C$, 'sum$DA',  function (a) {
var b=0;
for (var ii=0; ii < a.length; ii++) {
b+=a[ii];
}
return b;
}, 1);

Clazz.newMeth(C$, 'resize$SA$I',  function (arr, newSize) {
var tmp=Clazz.array(String, [newSize]);
var size=Math.min(arr.length, newSize);
System.arraycopy$O$I$O$I$I(arr, 0, tmp, 0, size);
return tmp;
}, 1);

Clazz.newMeth(C$, 'resize$IA$I',  function (arr, newSize) {
var tmp=Clazz.array(Integer.TYPE, [newSize]);
var size=Math.min(arr.length, newSize);
System.arraycopy$O$I$O$I$I(arr, 0, tmp, 0, size);
return tmp;
}, 1);

Clazz.newMeth(C$, 'resize$BA$I',  function (arr, newSize) {
var tmp=Clazz.array(Byte.TYPE, [newSize]);
var size=Math.min(arr.length, newSize);
System.arraycopy$O$I$O$I$I(arr, 0, tmp, 0, size);
return tmp;
}, 1);

Clazz.newMeth(C$, 'resize$ZA$I',  function (arr, newSize) {
var tmp=Clazz.array(Boolean.TYPE, [newSize]);
var size=Math.min(arr.length, newSize);
System.arraycopy$O$I$O$I$I(arr, 0, tmp, 0, size);
return tmp;
}, 1);

Clazz.newMeth(C$, 'resize$DA$I',  function (arr, newSize) {
var tmp=Clazz.array(Double.TYPE, [newSize]);
var size=Math.min(arr.length, newSize);
System.arraycopy$O$I$O$I$I(arr, 0, tmp, 0, size);
return tmp;
}, 1);

Clazz.newMeth(C$, 'removeDoubletsInt$java_util_List',  function (li) {
for (var i=0; i < li.size$(); i++) {
for (var j=li.size$() - 1; j > i; j--) {
var a1=li.get$I(i);
var a2=li.get$I(j);
var bEq=true;
if (a2.length != a1.length) {
bEq=false;
break;
}for (var k=0; k < a2.length; k++) {
if (a1[k] != a2[k]) {
bEq=false;
break;
}}
if (bEq) li.remove$I(j);
}
}
}, 1);

Clazz.newMeth(C$, 'removeDoubletsIntOrderIndepend$java_util_List',  function (li) {
for (var i=0; i < li.size$(); i++) {
for (var j=li.size$() - 1; j > i; j--) {
var a1=li.get$I(i);
var a2=li.get$I(j);
var bEq=true;
for (var k=0; k < a1.length; k++) {
var bFound=false;
for (var l=0; l < a2.length; l++) {
if (a1[k] == a2[l]) {
bFound=true;
break;
}}
if (!bFound) {
bEq=false;
break;
}}
if (bEq) li.remove$I(j);
}
}
}, 1);

Clazz.newMeth(C$, 'resize$DAA$I$I',  function (mData, iNumberRowsNew, iNumberColsNew) {
var dTmp=Clazz.array(Double.TYPE, [iNumberRowsNew, iNumberColsNew]);
var iRows=iNumberRowsNew;
var iCols=iNumberColsNew;
if (iNumberRowsNew > mData.length) iRows=mData.length;
if (iNumberColsNew > mData[0].length) iCols=mData[0].length;
for (var ii=0; ii < iRows; ii++) {
for (var jj=0; jj < iCols; jj++) {
dTmp[ii][jj]=mData[ii][jj];
}
}
return dTmp;
}, 1);

Clazz.newMeth(C$, 'resize$ZAA$I',  function (mData, rows) {
return C$.resize$ZAA$I$I(mData, rows, mData[0].length);
}, 1);

Clazz.newMeth(C$, 'resize$ZAA$I$I',  function (mData, iNumberRowsNew, iNumberColsNew) {
var dTmp=Clazz.array(Boolean.TYPE, [iNumberRowsNew, iNumberColsNew]);
var iRows=iNumberRowsNew;
var iCols=iNumberColsNew;
if (iNumberRowsNew > mData.length) iRows=mData.length;
if (iNumberColsNew > mData[0].length) iCols=mData[0].length;
for (var ii=0; ii < iRows; ii++) {
for (var jj=0; jj < iCols; jj++) {
dTmp[ii][jj]=mData[ii][jj];
}
}
return dTmp;
}, 1);

Clazz.newMeth(C$, 'reverse$IA',  function (arr) {
var res=Clazz.array(Integer.TYPE, [arr.length]);
for (var i=0; i < res.length; i++) {
res[res.length - i - 1 ]=arr[i];
}
return res;
}, 1);

Clazz.newMeth(C$, 'reverse$OA',  function (mArrResult) {
for (var i=0; i < (mArrResult.length/2|0); i++) {
var res=mArrResult[mArrResult.length - i - 1 ];
mArrResult[mArrResult.length - i - 1 ]=mArrResult[i];
mArrResult[i]=res;
}
}, 1);

Clazz.newMeth(C$, 'getOverlap$IA$IA',  function (a1, a2) {
var ts=Clazz.new_($I$(5,1));
for (var i=0; i < a1.length; i++) {
ts.add$O(Integer.valueOf$I(a1[i]));
}
var li=Clazz.new_($I$(1,1));
for (var i=0; i < a2.length; i++) {
if (!ts.add$O(Integer.valueOf$I(a2[i]))) {
li.add$O(Integer.valueOf$I(a2[i]));
}}
return li;
}, 1);

Clazz.newMeth(C$, 'getUnique$IA$IA',  function (a1, a2) {
var ts=Clazz.new_($I$(5,1));
for (var i=0; i < a1.length; i++) {
ts.add$O(Integer.valueOf$I(a1[i]));
}
for (var i=0; i < a2.length; i++) {
ts.add$O(Integer.valueOf$I(a2[i]));
}
var li=Clazz.new_($I$(1,1).c$$java_util_Collection,[ts]);
return li;
}, 1);

Clazz.newMeth(C$, 'getUnique$IA',  function (arr) {
var ts=Clazz.new_($I$(5,1));
for (var i=0; i < arr.length; i++) {
ts.add$O(Integer.valueOf$I(arr[i]));
}
var res=C$.toIntArray$java_util_Collection(ts);
return res;
}, 1);

Clazz.newMeth(C$, 'toIntArray$java_util_Collection',  function (list) {
var res=Clazz.array(Integer.TYPE, [list.size$()]);
var index=0;
var iter=list.iterator$();
while (iter.hasNext$()){
var i=iter.next$();
res[index++]=i.intValue$();
}
return res;
}, 1);

Clazz.newMeth(C$, 'toArray$java_util_List',  function (list) {
var res=Clazz.array(String, [list.size$()]);
for (var i=0; i < list.size$(); i++) {
res[i]=list.get$I(i);
}
return res;
}, 1);

Clazz.newMeth(C$, 'toArrayStrStr$java_util_List',  function (list) {
var res=Clazz.array(String, [list.size$(), list.get$I(0).size$()]);
for (var i=0; i < list.size$(); i++) {
for (var j=0; j < list.get$I(i).size$(); j++) {
res[i][j]=list.get$I(i).get$I(j);
}
}
return res;
}, 1);

Clazz.newMeth(C$, 'toDoubleArray$java_util_List',  function (list) {
var res=Clazz.array(Double.TYPE, [list.size$()]);
var index=0;
for (var d, $d = list.iterator$(); $d.hasNext$()&&((d=($d.next$()).objectValue$()),1);) {
res[index++]=d;
}
return res;
}, 1);

Clazz.newMeth(C$, 'toDoubleArray$IA',  function (a) {
var res=Clazz.array(Double.TYPE, [a.length]);
for (var i=0; i < a.length; i++) {
res[i]=a[i];
}
return res;
}, 1);

Clazz.newMeth(C$, 'toIntArray$DA',  function (a) {
var res=Clazz.array(Integer.TYPE, [a.length]);
for (var i=0; i < a.length; i++) {
res[i]=(a[i]|0);
}
return res;
}, 1);

Clazz.newMeth(C$, 'toList$IA',  function (a) {
if (a == null ) return null;
var li=Clazz.new_($I$(1,1).c$$I,[a.length]);
for (var i=0; i < a.length; i++) {
li.add$O(Integer.valueOf$I(a[i]));
}
return li;
}, 1);

Clazz.newMeth(C$, 'toList$SA',  function (a) {
if (a == null ) return null;
var li=Clazz.new_($I$(1,1).c$$I,[a.length]);
for (var i=0; i < a.length; i++) {
li.add$O(a[i]);
}
return li;
}, 1);

Clazz.newMeth(C$, 'indexOf$OA$O',  function (array, obj) {
for (var i=0; i < array.length; i++) {
if (array[i].equals$O(obj)) return i;
}
return -1;
}, 1);

Clazz.newMeth(C$, 'indexOf$IA$I',  function (array, obj) {
for (var i=0; i < array.length; i++) {
if (array[i] == obj) return i;
}
return -1;
}, 1);

Clazz.newMeth(C$, 'lastIndexOf$IA$I',  function (array, obj) {
for (var i=array.length - 1; i >= 0; i--) {
if (array[i] == obj) return i;
}
return -1;
}, 1);

Clazz.newMeth(C$, 'lastIndexOfNot$BA$I',  function (array, obj) {
for (var i=array.length - 1; i >= 0; i--) {
if (array[i] != obj) return i;
}
return -1;
}, 1);

Clazz.newMeth(C$, 'min$DA',  function (array) {
if (array.length == 0) return 0;
var res=array[0];
for (var i=1; i < array.length; i++) {
res=Math.min(res, array[i]);
}
return res;
}, 1);

Clazz.newMeth(C$, 'min$IA',  function (array) {
if (array.length == 0) return 0;
var res=array[0];
for (var i=1; i < array.length; i++) {
res=Math.min(res, array[i]);
}
return res;
}, 1);

Clazz.newMeth(C$, 'min$DAA$I',  function (array, col) {
if (array.length == 0) return 0;
var res=array[0][col];
for (var i=1; i < array.length; i++) {
res=Math.min(res, array[i][col]);
}
return res;
}, 1);

Clazz.newMeth(C$, 'min$FAA$I',  function (array, col) {
if (array.length == 0) return 0;
var res=array[0][col];
for (var i=1; i < array.length; i++) {
res=Math.min(res, array[i][col]);
}
return res;
}, 1);

Clazz.newMeth(C$, 'max$BA',  function (array) {
if (array.length == 0) return $b$[0] = 0, $b$[0];
var res=array[0];
for (var i=1; i < array.length; i++) {
res=($b$[0] = Math.max(res, array[i]), $b$[0]);
}
return res;
}, 1);

Clazz.newMeth(C$, 'max$DA',  function (array) {
if (array.length == 0) return 0;
var res=array[0];
for (var i=1; i < array.length; i++) {
res=Math.max(res, array[i]);
}
return res;
}, 1);

Clazz.newMeth(C$, 'maxDouble$java_util_List',  function (array) {
if (array.size$() == 0) return 0;
var res=(array.get$I(0)).valueOf();
for (var i=1; i < array.size$(); i++) {
res=Math.max(res, (array.get$I(i)).valueOf());
}
return res;
}, 1);

Clazz.newMeth(C$, 'maxInt$java_util_List',  function (array) {
if (array.size$() == 0) return 0;
var res=(array.get$I(0)).$c();
for (var i=1; i < array.size$(); i++) {
res=Math.max(res, (array.get$I(i)).$c());
}
return res;
}, 1);

Clazz.newMeth(C$, 'max$DAA$I',  function (array, col) {
if (array.length == 0) return 0;
var res=array[0][col];
for (var i=1; i < array.length; i++) {
res=Math.max(res, array[i][col]);
}
return res;
}, 1);

Clazz.newMeth(C$, 'max$FAA$I',  function (array, col) {
if (array.length == 0) return 0;
var res=array[0][col];
for (var i=1; i < array.length; i++) {
res=Math.max(res, array[i][col]);
}
return res;
}, 1);

Clazz.newMeth(C$, 'max$IA',  function (array) {
if (array.length == 0) return 0;
var res=array[0];
for (var i=1; i < array.length; i++) {
res=Math.max(res, array[i]);
}
return res;
}, 1);

Clazz.newMeth(C$, 'readIntArray$S',  function (s) {
return C$.readIntArray$S$S(s, ",");
}, 1);

Clazz.newMeth(C$, 'readIntArray$S$S',  function (s, seperator) {
s=s.replace$C$C("[", " ");
s=s.replace$C$C("]", " ");
s=s.trim$();
var st=Clazz.new_($I$(6,1).c$$S$S,[s, seperator]);
var li=Clazz.new_($I$(1,1));
while (st.hasMoreTokens$()){
li.add$O(Integer.valueOf$I(Integer.parseInt$S(st.nextToken$().trim$())));
}
return C$.toIntArray$java_util_Collection(li);
}, 1);

Clazz.newMeth(C$, 'readDoubleArray$S',  function (s) {
return C$.readDoubleArray$S$S(s, ",");
}, 1);

Clazz.newMeth(C$, 'readDoubleArray$S$S',  function (s, seperator) {
s=s.replace$C$C("[", " ");
s=s.replace$C$C("]", " ");
s=s.trim$();
var st=Clazz.new_($I$(6,1).c$$S$S,[s, seperator]);
var li=Clazz.new_($I$(1,1));
while (st.hasMoreTokens$()){
li.add$O(Double.valueOf$D(Double.parseDouble$S(st.nextToken$().trim$())));
}
return C$.toDoubleArray$java_util_List(li);
}, 1);

Clazz.newMeth(C$, 'set$IA$I',  function (array, val) {
for (var i=0; i < array.length; i++) {
array[i]=val;
}
}, 1);

Clazz.newMeth(C$, 'set$FA$F',  function (array, val) {
for (var i=0; i < array.length; i++) {
array[i]=val;
}
}, 1);

Clazz.newMeth(C$, 'set$DA$D',  function (array, val) {
for (var i=0; i < array.length; i++) {
array[i]=val;
}
}, 1);

Clazz.newMeth(C$, 'set$IAA$I',  function (array, val) {
for (var i=0; i < array.length; i++) for (var j=0; j < array[0].length; j++) array[i][j]=val;


}, 1);

Clazz.newMeth(C$, 'set$HAA$H',  function (array, val) {
for (var i=0; i < array.length; i++) for (var j=0; j < array[0].length; j++) array[i][j]=val;


}, 1);

Clazz.newMeth(C$, 'set$DAA$D',  function (array, val) {
for (var i=0; i < array.length; i++) for (var j=0; j < array[0].length; j++) array[i][j]=val;


}, 1);

Clazz.newMeth(C$, 'set$FAA$F',  function (array, val) {
for (var i=0; i < array.length; i++) for (var j=0; j < array[0].length; j++) array[i][j]=val;


}, 1);

Clazz.newMeth(C$, 'toStringBinary$IA',  function (v) {
var sb=Clazz.new_($I$(7,1));
sb.append$S("[");
for (var i=0; i < v.length; i++) {
sb.append$S(C$.toStringBinary$I(v[i]));
if (i < v.length - 1) {
sb.append$S(" ");
}}
sb.append$S("]");
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'toStringBinary$I',  function (v) {
var str="";
var len=32;
for (var ii=0; ii < len; ii++) {
if ((v & 1) == 1) {
str="1 " + str;
} else {
str="0 " + str;
}v=v >> 1;
}
return str.trim$();
}, 1);

Clazz.newMeth(C$, 'toString$IA',  function (v) {
var sb=Clazz.new_($I$(7,1));
sb.append$S("[");
for (var i=0; i < v.length; i++) {
sb.append$S((i > 0 ? "," : "") + v[i]);
}
sb.append$S("]");
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'toString$java_util_Collection',  function (li) {
var sb=Clazz.new_($I$(7,1));
sb.append$S("[");
var cc=0;
for (var i, $i = li.iterator$(); $i.hasNext$()&&((i=($i.next$()).intValue$()),1);) {
sb.append$S((cc > 0 ? "," : "") + i);
++cc;
}
sb.append$S("]");
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'toStringNoBrackets$java_util_Collection$S',  function (li, sep) {
var sb=Clazz.new_($I$(7,1));
var cc=0;
for (var i, $i = li.iterator$(); $i.hasNext$()&&((i=($i.next$()).intValue$()),1);) {
sb.append$S((cc > 0 ? sep : "") + i);
++cc;
}
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'toStringIntegerList$java_util_List$I',  function (li, step) {
var sb=Clazz.new_($I$(7,1));
sb=Clazz.new_($I$(7,1));
for (var i=0; i < li.size$(); i+=step) {
if (i + step > li.size$()) step=li.size$() - i;
for (var j=i; j < i + step; j++) {
sb.append$O(li.get$I(j));
if (j < i + step - 1) {
sb.append$S(" ");
}}
sb.append$S("\n");
}
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'toStringLongList$java_util_List$I',  function (li, step) {
var sb=Clazz.new_($I$(7,1));
sb=Clazz.new_($I$(7,1));
for (var i=0; i < li.size$(); i+=step) {
if (i + step > li.size$()) step=li.size$() - i;
for (var j=i; j < i + step; j++) {
sb.append$O(li.get$I(j));
if (j < i + step - 1) {
sb.append$S(" ");
}}
sb.append$S("\n");
}
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'toStringArray$java_util_List',  function (li) {
var a=Clazz.array(String, [li.size$()]);
for (var i=0; i < li.size$(); i++) {
a[i]=Integer.toString$I((li.get$I(i)).$c());
}
return a;
}, 1);

Clazz.newMeth(C$, 'toString$BA',  function (v) {
var sb=Clazz.new_($I$(7,1));
sb.append$S("[");
for (var i=0; i < v.length; i++) {
var val=v[i] & 255;
sb.append$S((i > 0 ? ", " : "") + val);
}
sb.append$S("]");
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'toStringPure$IA',  function (v) {
var sb=Clazz.new_($I$(7,1));
for (var i=0; i < v.length; i++) sb.append$S((i > 0 ? " " : "") + v[i]);

return sb.toString();
}, 1);

Clazz.newMeth(C$, 'toStringIntArrays$java_util_List',  function (li) {
var buff=Clazz.new_($I$(7,1));
for (var element, $element = li.iterator$(); $element.hasNext$()&&((element=($element.next$())),1);) {
buff.append$S(C$.toString$IA(element) + "\n");
}
return buff.toString();
}, 1);

Clazz.newMeth(C$, 'toString$IAA',  function (v) {
var sb=Clazz.new_($I$(7,1));
for (var i=0; i < v.length; i++) {
for (var j=0; j < v[0].length; j++) {
sb.append$S((j > 0 ? "," : "") + v[i][j]);
}
sb.append$S("\n");
}
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'toStringFormatted$IA$IA',  function (arrTop, arrBottom) {
var v=Clazz.array(Integer.TYPE, [2, null]);
v[0]=arrTop;
v[1]=arrBottom;
return C$.toStringFormatted$IAA(v);
}, 1);

Clazz.newMeth(C$, 'toStringFormatted$IAA',  function (v) {
var maxAbs=0;
for (var i=0; i < v.length; i++) {
for (var j=0; j < v[0].length; j++) {
if (Math.abs(v[i][j]) > maxAbs) {
maxAbs=Math.abs(v[i][j]);
}}
}
var len=Integer.toString$I(maxAbs).length$() + 1;
var sb=Clazz.new_($I$(7,1));
for (var i=0; i < v.length; i++) {
for (var j=0; j < v[0].length; j++) {
var sbVal=Clazz.new_([Integer.toString$I(v[i][j])],$I$(7,1).c$$S);
while (sbVal.length$() < len){
sbVal.insert$I$S(0, " ");
}
sb.append$CharSequence(sbVal);
if (j < v[0].length - 1) {
sb.append$S(" ");
}}
sb.append$S("\n");
}
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'toString$DA',  function (v) {
var sb=Clazz.new_($I$(7,1).c$$S,["["]);
for (var i=0; i < v.length; i++) {
sb.append$S((i > 0 ? "," : "") + new Double(v[i]).toString());
}
sb.append$S("]");
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'toStringPure$DA',  function (v) {
var sb=Clazz.new_($I$(7,1));
for (var i=0; i < v.length; i++) {
sb.append$S((i > 0 ? "\t" : "") + new Double(v[i]).toString());
}
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'toString$DA$java_text_NumberFormat',  function (v, nf) {
var sb=Clazz.new_($I$(7,1).c$$S,["["]);
for (var i=0; i < v.length; i++) {
sb.append$S((i > 0 ? "," : "") + nf.format$D(v[i]));
}
sb.append$S("]");
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'toString$DAA',  function (v) {
var res=Clazz.new_($I$(7,1));
for (var i=0; i < v.length; i++) {
for (var j=0; j < v[0].length; j++) {
res.append$S((j > 0 ? "," : "") + new Double(v[i][j]).toString());
}
res.append$S("\n");
}
return res.toString();
}, 1);

Clazz.newMeth(C$, 'toString$DA$I',  function (v, iDigits) {
var sFormat="";
sFormat+="0";
var iCounter=0;
if (iDigits > 0) sFormat+=".";
while (iCounter < iDigits){
sFormat+="0";
++iCounter;
}
var nf=Clazz.new_($I$(8,1).c$$S,[sFormat]);
var sb=Clazz.new_($I$(7,1));
for (var i=0; i < v.length; i++) {
sb.append$S((i > 0 ? "," : "") + nf.format$D(v[i]));
}
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'toString$FA$I',  function (v, iDigits) {
var sFormat="";
sFormat+="0";
var iCounter=0;
if (iDigits > 0) sFormat+=".";
while (iCounter < iDigits){
sFormat+="0";
++iCounter;
}
var nf=Clazz.new_($I$(8,1).c$$S,[sFormat]);
var sb=Clazz.new_($I$(7,1));
for (var i=0; i < v.length; i++) {
sb.append$S((i > 0 ? "," : "") + nf.format$D(v[i]));
}
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'toString$DAA$I',  function (v, iDigits) {
var sFormat="";
sFormat+="0";
var iCounter=0;
if (iDigits > 0) sFormat+=".";
while (iCounter < iDigits){
sFormat+="0";
++iCounter;
}
var nf=Clazz.new_($I$(8,1).c$$S,[sFormat]);
var res=Clazz.new_($I$(7,1));
for (var i=0; i < v.length; i++) {
for (var j=0; j < v[i].length; j++) {
res.append$S((j > 0 ? " " : "") + nf.format$D(v[i][j]));
}
res.append$S((i < v.length - 1 ? "\n" : ""));
}
return res.toString();
}, 1);

Clazz.newMeth(C$, 'toStringNoDigits$DA',  function (v) {
var nf=Clazz.new_($I$(8,1).c$$S,["0"]);
var res="";
for (var i=0; i < v.length; i++) {
res+=(i > 0 ? "," : "") + nf.format$D(v[i]);
}
return res + "";
}, 1);

Clazz.newMeth(C$, 'toString$OA',  function (v) {
var res="[";
for (var i=0; i < v.length; i++) {
res+=(i > 0 ? "," : "") + v[i];
}
return res + "]";
}, 1);

Clazz.newMeth(C$, 'shift$IA$I',  function (v, n) {
var copy=Clazz.array(Integer.TYPE, [v.length]);
for (var i=0; i < v.length; i++) copy[i]=v[(i + n + v.length ) % v.length];

System.arraycopy$O$I$O$I$I(copy, 0, v, 0, v.length);
}, 1);

Clazz.newMeth(C$, 'parseInteger$S$S',  function (s, sep) {
var st=Clazz.new_($I$(6,1).c$$S$S,[s, sep]);
var li=Clazz.new_($I$(1,1));
while (st.hasMoreTokens$()){
var v=Integer.parseInt$S(st.nextToken$());
li.add$O(Integer.valueOf$I(v));
}
return li;
}, 1);
var $b$ = new Int8Array(1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:45 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
