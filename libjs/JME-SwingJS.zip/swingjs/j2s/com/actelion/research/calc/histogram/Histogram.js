(function(){var P$=Clazz.newPackage("com.actelion.research.calc.histogram"),p$1={},I$=[[0,'com.actelion.research.calc.histogram.MatrixBasedHistogram','StringBuilder','java.text.DecimalFormat','java.text.DecimalFormatSymbols','java.util.Locale','java.util.Random']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Histogram");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['minimumX','maximumX','maximumY','sumY','binwidth'],'I',['digits'],'O',['arrBins','float[]','arrFrequencies','int[]','arrRaw','double[]']]]

Clazz.newMeth(C$, 'c$$DA$D$D$I',  function (arrRaw, min, max, bins) {
;C$.$init$.apply(this);
this.initialize$DA$D$D$I(arrRaw, min, max, bins);
}, 1);

Clazz.newMeth(C$, 'c$$java_util_Collection$D$D$I',  function (values, min, max, bins) {
;C$.$init$.apply(this);
var v=Clazz.array(Double.TYPE, [values.size$()]);
var c=0;
for (var value, $value = values.iterator$(); $value.hasNext$()&&((value=($value.next$())),1);) {
v[c++]=(value).valueOf();
}
this.initialize$DA$D$D$I(v, min, max, bins);
}, 1);

Clazz.newMeth(C$, 'c$$DA$I',  function (arrRaw, bins) {
;C$.$init$.apply(this);
var max=-1.7976931348623157E308;
var min=1.7976931348623157E308;
for (var v, $v = 0, $$v = arrRaw; $v<$$v.length&&((v=($$v[$v])),1);$v++) {
if (v > max ) {
max=v;
}if (v < min ) {
min=v;
}}
this.initialize$DA$D$D$I(arrRaw, min, max, bins);
}, 1);

Clazz.newMeth(C$, 'initialize$DA$D$D$I',  function (arrRaw, min, max, bins) {
if (bins == 0) throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Number of bins is 0."]);
this.arrRaw=arrRaw;
this.minimumX=min - min * 1.0E-6;
this.maximumX=max + max * 1.0E-6;
this.arrFrequencies=Clazz.array(Integer.TYPE, [bins]);
this.arrBins=Clazz.array(Float.TYPE, [bins]);
this.digits=-1;
p$1.calcBins.apply(this, []);
p$1.calcHistogram.apply(this, []);
});

Clazz.newMeth(C$, 'calcHistogram',  function () {
var bins=this.arrFrequencies.length;
this.binwidth=bins / (this.maximumX - this.minimumX);
this.maximumY=0;
for (var i=0; i < this.arrRaw.length; i++) {
if (this.arrRaw[i] >= this.minimumX  && this.arrRaw[i] < this.maximumX  ) {
var pos=(((this.arrRaw[i] - this.minimumX) * this.binwidth)|0);
++this.arrFrequencies[pos];
++this.sumY;
if (this.arrFrequencies[pos] > this.maximumY ) this.maximumY=this.arrFrequencies[pos];
}}
}, p$1);

Clazz.newMeth(C$, 'getBinIndex$D',  function (v) {
var pos=(((v - this.minimumX) * this.binwidth)|0);
return pos;
});

Clazz.newMeth(C$, 'calcBins',  function () {
var incr=(this.maximumX - this.minimumX) / this.arrBins.length;
this.arrBins[0]=this.minimumX;
for (var i=1; i < this.arrBins.length; i++) {
this.arrBins[i]=(this.arrBins[i - 1] + incr);
}
}, p$1);

Clazz.newMeth(C$, 'getFrequencies$',  function () {
return this.arrFrequencies;
});

Clazz.newMeth(C$, 'getFrequency$I',  function (index) {
return this.arrFrequencies[index];
});

Clazz.newMeth(C$, 'getBins$',  function () {
return this.arrBins;
});

Clazz.newMeth(C$, 'getBin$I',  function (index) {
return this.arrBins[index];
});

Clazz.newMeth(C$, 'getNumBins$',  function () {
return this.arrBins.length;
});

Clazz.newMeth(C$, 'getMaximumY$',  function () {
return this.maximumY;
});

Clazz.newMeth(C$, 'getSumY$',  function () {
return this.sumY;
});

Clazz.newMeth(C$, 'getSumFromRange$D$D',  function (low, up) {
var bins=this.arrFrequencies.length;
var devider=bins / (this.maximumX - this.minimumX);
var posStart=(Math.max(0, ((low - this.minimumX) * devider))|0);
var posEnd=(Math.min(bins - 1, ((up - this.minimumX) * devider))|0);
var sum=0;
for (var i=posStart; i < posEnd + 1; i++) {
sum+=this.arrFrequencies[i];
}
return sum;
});

Clazz.newMeth(C$, 'getHistogram$',  function () {
var maBins=$I$(1).getHistogramBins$D$D$I(this.minimumX, this.maximumX, this.arrFrequencies.length);
var maHist=$I$(1).getHistogram$DA$com_actelion_research_calc_Matrix(this.arrRaw, maBins);
return maHist;
});

Clazz.newMeth(C$, 'getMinimumX$',  function () {
return this.minimumX;
});

Clazz.newMeth(C$, 'getMaximumX$',  function () {
return this.maximumX;
});

Clazz.newMeth(C$, 'setDigits$I',  function (digits) {
this.digits=digits;
});

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_($I$(2,1));
var range=this.maximumX - this.minimumX;
var logRange=(Math.log10(range)|0);
var bins=this.arrFrequencies.length;
var logBins=(Math.log10(bins)|0);
if (this.digits < 0) this.digits=logBins - logRange + 1;
var sFormatDigits="";
for (var i=0; i < this.digits; i++) {
sFormatDigits+="0";
}
var sFormat="0";
if (sFormatDigits.length$() > 0) sFormat+="." + sFormatDigits;
var nfX=Clazz.new_([sFormat, Clazz.new_([$I$(5).US],$I$(4,1).c$$java_util_Locale)],$I$(3,1).c$$S$java_text_DecimalFormatSymbols);
var nfY=Clazz.new_(["0", Clazz.new_([$I$(5).US],$I$(4,1).c$$java_util_Locale)],$I$(3,1).c$$S$java_text_DecimalFormatSymbols);
var nfFractionCumulative=Clazz.new_(["0.00", Clazz.new_([$I$(5).US],$I$(4,1).c$$java_util_Locale)],$I$(3,1).c$$S$java_text_DecimalFormatSymbols);
var arrStrX=Clazz.array(String, [bins]);
var arrStrY=Clazz.array(String, [bins]);
var arrStrValCumulative=Clazz.array(String, [bins]);
var sumFreq=0;
for (var i=0; i < arrStrY.length; i++) {
var sX=nfX.format$D(this.arrBins[i]);
var sY=nfY.format$J(this.arrFrequencies[i]);
sumFreq+=this.arrFrequencies[i];
var fractionCumulative=sumFreq / this.arrRaw.length;
var sFractionCumulative=nfFractionCumulative.format$D(fractionCumulative);
var maxLen=sX.length$();
if (sY.length$() > maxLen) {
maxLen=sY.length$();
}if (sFractionCumulative.length$() > maxLen) {
maxLen=sFractionCumulative.length$();
}while (sX.length$() < maxLen){
sX=" " + sX;
}
while (sY.length$() < maxLen){
sY=" " + sY;
}
while (sFractionCumulative.length$() < maxLen){
sFractionCumulative=" " + sFractionCumulative;
}
arrStrX[i]=sX;
arrStrY[i]=sY;
arrStrValCumulative[i]=sFractionCumulative;
}
for (var i=0; i < arrStrX.length; i++) {
sb.append$S(arrStrX[i]);
if (i < arrStrX.length - 1) {
sb.append$S(" ");
}}
sb.append$S("\n");
for (var i=0; i < arrStrY.length; i++) {
sb.append$S(arrStrY[i]);
if (i < arrStrY.length - 1) {
sb.append$S(" ");
}}
sb.append$S("\n");
for (var i=0; i < arrStrValCumulative.length; i++) {
sb.append$S(arrStrValCumulative[i]);
if (i < arrStrValCumulative.length - 1) {
sb.append$S(" ");
}}
return sb.toString();
});

Clazz.newMeth(C$, 'toStringWithTabs$',  function () {
var s=this.toString();
var sTab=s.replaceAll$S$S("[ ]{1,}", "\t");
return sTab;
});

Clazz.newMeth(C$, 'getBinWidth$',  function () {
return this.binwidth;
});

Clazz.newMeth(C$, 'main$SA',  function (args) {
var n=1000;
var min=0;
var max=0.1;
var minBin=0;
var maxBin=1;
var bins=20;
var arr=Clazz.array(Double.TYPE, [n]);
var rnd=Clazz.new_($I$(6,1));
for (var i=0; i < n; i++) {
arr[i]=min + rnd.nextDouble$();
}
var h=Clazz.new_(C$.c$$DA$D$D$I,[arr, minBin, maxBin, bins]);
System.out.println$O(h);
System.out.println$S("sum " + new Double(h.getSumY$()).toString());
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:05:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
