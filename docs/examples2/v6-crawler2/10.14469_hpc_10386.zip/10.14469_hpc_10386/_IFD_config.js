// IFD.config.js

IFD.properties.baseDir = ".";
IFD.properties.haveLocalFiles = true; 
IFD.properties.imageDimensions = {width:40,height:40};
IFD.properties.MAX_IMAGE_DIMENSIONS = {width:200, height:200};


