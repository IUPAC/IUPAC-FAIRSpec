SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<13C>'; SpecInfo.Data.EXP='<C13CPD32>';SpecInfo.Data.SFO1=100.622829803;
SpecInfo.Data.O1=10061.277;SpecInfo.Data.F2=219.438350248103;SpecInfo.Data.SW=238.896695566946;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=93;
SpecInfo.Data.OFFSET=219.4603;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-a-team4/nmr/Jun15-2023/1203710/pdata/1/intrng, 6/15/2023 1:50:42 PM'
SpecInfo.Data.using='g:/data/chem-synthesis-a-team4/nmr/Jun15-2023/1203710/pdata/1/intgap_ole, 6/20/2023 9:27:16 AM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=32768
SpecInfo.Data.nint=7
SpecInfo.Data.realymin=-2184732
SpecInfo.Data.realymax=375397240
SpecInfo.Data.realyave=614159
SpecInfo.Data.realyint=5645129383
SpecInfo.Data.snr=614.795145882418
SpecInfo.Data.nbytes=1015
SpecInfo.Data.miny=-6
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=1.62655806035146
SpecInfo.Data.firstnz=7406
SpecInfo.Data.compressionratio=129.1/1
SpecInfo.Data.htratio=2.66384483807073E-06
SpecData=new Array([0,-1,32768,'g:/data/chem-synthesis-a-team4/nmr/Jun15-2023/1203710/pdata/1/1r']
,[1,7405,68,1,"7406a%kJTKJ%jTJ%jJT%jJT%%k%Jk%kJjT%KMjJk%TJMKTNJ6M9N2l9o1j7qkj","7457Dj%Tkj%KjT%kJ%T",""]
,[2,9425,57,1,"9426b%TJJTkK%TJjTJ%JT%%MLUOJ0J8J5Mj0j5TqonjkU%jJj%jTJJj%Jk%TjJ","9480@K",""]
,[3,11488,54,1,"11489a%jKJkJNkTJlK%JjJ%Kj%L%JMQJ8P1Tr1n8j7okJl%j%JjT%%UkK%kJKj","11541A",""]
,[4,12133,83,1,"12134B%LMjkLlmkKTkjKT%k%UJ%J%JTL%j%MLMOTJ4J8L1O9K06M89J27o35k07o9","12179G5k5j9rmTljTk%jkjk%Jj%J%Vj%JKjT%jT%jMT",""]
,[5,13099,92,1,"13100B%UJJj%JjT%jTJLJKnjK%jKLJkl%VJ%Tj%VJJKjJT%KTJJLOPJ3K2L5O5J99","13158C64L96K40n88k60p2l1j6rqml%TjkJ%jkU%J%JkjTkKjJ",""]
,[6,19447,150,1,"19448CjUJK%TklLKkJ%L%Tl%KJjL%K%LTJNTRJ3L0N5P8M4n2q5n2k7j5pljkl","19495HkjTKLJ%kmj%K%kj%jJUK%MNLKJNJ0K0L7O6Q0J4q1Tm0j8j1olk%jTmk","19542CjK%JjkJ%jJ%KkjJL%TMKLJLTJ0J3K5M6P6O0k8q8o3l0j7plTmkmkJTj%","19588B%j%UKjT",""]
,[7,22822,64,1,"22823akLjJ%Jj%JTj%JTj%Kj%TKjJTL%LjNPJ2K3O8O9O3Q9p4j79n2k0rlTjj","22868EjJkjk%jJkJT%Kj%TJ",""]
)
