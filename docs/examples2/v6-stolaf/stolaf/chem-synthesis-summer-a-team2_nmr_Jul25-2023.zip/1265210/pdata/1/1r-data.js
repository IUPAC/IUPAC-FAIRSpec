SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<1H>'; SpecInfo.Data.EXP='<PROTON>';SpecInfo.Data.SFO1=400.132470802;
SpecInfo.Data.O1=2470.802;SpecInfo.Data.F2=16.1876696570707;SpecInfo.Data.SW=20.0254193236558;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=93;
SpecInfo.Data.OFFSET=16.18777;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team2/nmr/Jul25-2023/1265210/pdata/1/intrng, 7/25/2023 12:19:36 PM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team2/nmr/Jul25-2023/1265210/pdata/1/intgap_ole, 7/25/2023 12:46:40 PM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=65536
SpecInfo.Data.nint=3
SpecInfo.Data.realymin=-153057
SpecInfo.Data.realymax=408704254
SpecInfo.Data.realyave=6819445
SpecInfo.Data.realyint=445529848612
SpecInfo.Data.snr=59.9546313519649
SpecInfo.Data.nbytes=1670
SpecInfo.Data.miny=0
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=16.6792786053421
SpecInfo.Data.firstnz=26330
SpecInfo.Data.compressionratio=156.9/1
SpecInfo.Data.htratio=2.44675701369137E-06
SpecData=new Array([0,-1,65536,'g:/data/chem-synthesis-summer-a-team2/nmr/Jul25-2023/1265210/pdata/1/1r']
,[1,25560,5185,770,"26330A%j%J%Yj%Z%SJj%S9J%S9j%WJ%Tj%ZJ%jJj%J%Yj%XJ%Tj%J%S6j%J%T83Jj","26741A%J%Yj%TJ%jJ%j%YJ%S08J%X8J%j%WJ%W6J%Tj%TJ%U9J%W2J%V9J%U5J%","27196Ij%J%T8J%T1J%T7J%T4J%S6J%T2J%S5J%S8J%S1J%S1J%S2J%S3J%S2J%","27443B2%YJ%YJ%XJ%YJ%XJ%YJ%XJ%WJ%WJ%VJ%WJ%XJ%WJ%WJ%WJ%UJ%VJ%UJ%","27558D0%TJ%UJ%UJ%J%UJ%TJ%J%TJ%TJ%TJ%TJ%UJ%UJ%UJ%UJ%TJ%TJ%UJ%J%","27621E9%J%TJ%TJ%J%TJ%J%J%J%J%J%JT%J%J%J%J%TJ%J%TJ%TJ%TJ%TJ%TJ%","27676H2%J%J%TJJ%J%J%JT%JU%JV%JTKJZKJS6%J%j%jkjklkTlklkTlkVjkTjj","27756H4kjU%j%j%Tj%UJ%TJ%JT%J%JT%J%JT%%J%TJ%Vj%kjkTlklmlTmlWklk","27818C6kUjkTjjkjX%jT%j%j%j%j%Tj%Uj%Vj%Yj%S1j%T7j%S89Jj%UJ%X2J%","28163E%Y2J%S16J%Wj%TJ%Uj%UJ%U5J%V4J%V3J%U7J%T7J%T0J%T1J%S8J%S5J%","28640A6%S8J%S4J%S4J%S3J%S3J%S0J%Z%SJ%S0J%ZJ%S0J%S0J%ZJ%YJ%XJ%%","28806C0%VJ%WJ%WJ%XJ%XJ%VJ%WJ%VJ%UJ%VJ%VJ%VJ%VJ%VJ%VJ%UJ%UJ%UJ%","28900D8%TJ%TJ%TJ%UJ%TJ%J%TJ%TJ%J%TJ%J%J%TJ%J%TJ%TJ%TJ%TJ%TJ%TJ%","28957F8%J%J%TJ%TJ%J%TJ%J%J%J%TJ%J%JT%J%JT%J%JT%J%J%J%JT%J%TJ%J","29012I5%J%J%J%J%J%J%J%J%JT%J%JT%JV%JZJSKJVKJTKJVKJUKJY%J%TjjVkk","29087A43kVlkZkSjkjkjW%j%j%Z%SJ%J%J%JT%J%J%J%J%Xj%jTkjkTjlkWlkk","29163G9kjkZlkVjkUjjkjX%jT%j%j%Tj%Vj%U2j%Uj%Tj%Uj%Vj%T3J%S0J%YJ%","29299B4%WJ%ZJ%Z%SJ%ZJ%WJ%WJ%WJ%UJ%UJ%UJ%UJ%UJ%UJ%WJ%S1j%Wj%Wj%","29406C5%S2J%VJ%VJ%UJ%S1j%j%j%jT%jV%jW%jT%jT%j%j%Tj%Tj%Wj%S7J%%","29505A7%WJ%XJ%S3j%Vj%Tj%Tj%Tj%Tj%Uj%Vj%Xj%WJ%S8j%Xj%Uj%Uj%Uj%%","29611Fj%Uj%Wj%S0j%V0jJ%Wj%J%S0j%T8J%Uj%Z%SJ%Tj%S19j%UJ%UjJ%S1j%","29882@%ZJ%Tj%UJ%j%VJ%Tj%S5J%Tj%YJj%WJ%j%S1J%WjJ%j%ZJ%S2j%UJ%Tj%","29995@%Z%SJ%S6jJ%Tj%VJ%S3j%VJ%Xj%J%Zj%S1J%Uj%Jj%J%W",""]
,[2,0,1,0,"0@",""]
,[3,0,1,0,"0@",""]
)
