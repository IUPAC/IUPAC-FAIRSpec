SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<13C>'; SpecInfo.Data.EXP='<C13CPD32>';SpecInfo.Data.SFO1=100.622829803;
SpecInfo.Data.O1=10061.277;SpecInfo.Data.F2=219.438350248103;SpecInfo.Data.SW=238.896695566946;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=91;
SpecInfo.Data.OFFSET=219.4603;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team2/nmr/Jul27-2023/1273910/pdata/1/intrng, 7/27/2023 11:33:16 AM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team2/nmr/Jul27-2023/1273910/pdata/1/intgap_ole, 8/1/2023 9:30:20 AM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=32768
SpecInfo.Data.nint=7
SpecInfo.Data.realymin=-9487353
SpecInfo.Data.realymax=346210011
SpecInfo.Data.realyave=2154820
SpecInfo.Data.realyint=11730839451
SpecInfo.Data.snr=165.070569235481
SpecInfo.Data.nbytes=1078
SpecInfo.Data.miny=-27
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=6.05801509397747
SpecInfo.Data.firstnz=10191
SpecInfo.Data.compressionratio=121.5/1
SpecInfo.Data.htratio=2.8884202311527E-06
SpecData=new Array([0,-1,32768,'g:/data/chem-synthesis-summer-a-team2/nmr/Jul27-2023/1273910/pdata/1/1r']
,[1,10190,48,1,"10191ejPJkMJnkKJT%JOMTOmPrkJ3MJ2M6N5L6kr5m1j5qoTj0jORoKMToqj0R","10237A",""]
,[2,11884,41,1,"11885FnPmj0NKNjnrQJMLJ0TL2M1L6L5j1q5l4qpj1rqnLJ2Ojmj5jONo",""]
,[3,12279,61,1,"12280AqkJRmoO%rRQpMQKMpOnLJ5QJ9K4M1J01K20j7k51r9k6j3rpqpjNKJML","12322A8L%pknoNlmLnRj2JTKk",""]
,[4,12431,76,1,"12432A0oJRJTj6K%MJ1qnjNKLkT%QJQNQK2K8L3R6J85Q3k41j22l9j9j7pMK3K5","12471I3K4M2Q2K00K54Q9k04l11j25n5k5onj1j6j2KL%qkNnTL%moKMJ3njj0J0","12506A0",""]
,[5,13458,48,1,"13459hnPkJNkLlMJ0NpoMRPTL4O9M6l8l0k1j7l2rj0m%j0kKUqjTllMOMqlMo","13505d",""]
,[6,19442,162,1,"19443ClrOJ3JqJJ1Kj2oOT%JTmQMmJMJpPMJMjJLrOJJ3kJ2J4J3J4J2K4L4P8J11","19488C56J79K52J87j04l14k36j23o7k9j5Tj1rMkmjMKrj6lMTnqJLRJ3%OMJ","19522E8PmJ1J7J8K1L5N1Q0J37K17K73P9k38l08j80r7m8m9k9rlJkmnjJj2R","19552B6NpmNLKQjoLJ7mNj0OJ5J1J7J8K1N0O8R3J72K54K14p1l02k51j50q4l0","19584I3j8k5j1jj7kj4JJ3j0jJjmlPlpl",""]
,[7,27109,56,1,"27110cQjMlj0JLJlKOROnTQKmqlLjnjNOLP%kJK7L9K4L3j3q3k9qnmkKj0QNm","27157AQpnjknO",""]
)
