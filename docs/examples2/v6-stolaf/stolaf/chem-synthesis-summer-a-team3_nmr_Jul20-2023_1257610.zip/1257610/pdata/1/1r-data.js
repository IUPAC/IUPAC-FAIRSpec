SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<1H>'; SpecInfo.Data.EXP='<PROTON>';SpecInfo.Data.SFO1=400.132470802;
SpecInfo.Data.O1=2470.802;SpecInfo.Data.F2=16.1876696570707;SpecInfo.Data.SW=20.0254193236558;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=97;
SpecInfo.Data.OFFSET=16.18777;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team3/nmr/Jul20-2023/1257610/pdata/1/intrng, 7/20/2023 1:27:02 PM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team3/nmr/Jul20-2023/1257610/pdata/1/intgap_ole, 7/22/2023 12:17:48 AM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=65536
SpecInfo.Data.nint=3
SpecInfo.Data.realymin=-19624
SpecInfo.Data.realymax=349844200
SpecInfo.Data.realyave=352828
SpecInfo.Data.realyint=22944989817
SpecInfo.Data.snr=991.598807350891
SpecInfo.Data.nbytes=1149
SpecInfo.Data.miny=0
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=1.00847237066728
SpecInfo.Data.firstnz=26545
SpecInfo.Data.compressionratio=228.1/1
SpecInfo.Data.htratio=2.85841526027872E-06
SpecData=new Array([0,-1,65536,'g:/data/chem-synthesis-summer-a-team3/nmr/Jul20-2023/1257610/pdata/1/1r']
,[1,25108,6682,1437,"26545A%U8j%Y79J%T4J%UJ%UJ%TJ%TJ%TJ%j%S0j%Tj%Tj%Tj%Vj%S1J%XJ%UJ%","27457D%UJ%TJ%J%TJ%Tj%Wj%Wj%j%j%Tj%Uj%X9j%Z3%S0J%VjJ%T67J%Y2J%%","28008C%U0J%S4J%Z%SJ%XJ%VJ%TJ%TJ%JT%KJUKJWKJTKJKTJJU%JKLOPQJ0TJ1J1","28118A08J0J1J0J1TJ2J3VJ2ROJmj0j2Uj3j3j5j4Tj0ronmVoopoTnnmnlmkj","28163B8jTJJTLKLMLMLTMMTOOPQRTJ0J0TQRPQPTOPTQRQPOMJlqj4j9k1Tj8j7","28212A29j6j5Tj3j1ronmlkjT%%WjkjkVjkTjjW%j%j%Tj%Yj%V2j%V89J%V0j%","28837@%T0J%T7J%ZJ%WJ%Vj%S0j%Wj%T5J%VJ%UJ%TJ%UJ%S0j%Vj%Uj%Tj%Uj%","28993A%T4J%XJ%VJ%Tj%S2j%Uj%Xj%W8J%XJ%J%J%TJ%TJ%J%J%J%Uj%jU%jT%j","29152B%j%Vj%S128J%S64J%S4j%T4J%VJ%UJ%TJ%J%J%S3j%Tj%j%j%Tj%Vj%%","30540A%S9J%WJ%UJ%TJ%J%TJ%Zj%Vj%Tj%j%Tj%Uj%S70J%W9J%XJ%WJ%TJ%S3j%","30866E%Uj%T4J%UJ%UJ%TJ%TJ%J%J%J%S1j%Uj%Z%SJ%TJJWKJUKJTKJKUJKTJJ","30966D2JTKKNOQJ0TJ2J1TJ2J1TJ2J2J3TJ4J3TJ1RMjoj0j3Uj4j5Uj3j1rpn","31006A09nmnToopTonUmmTkkj%TJKTLLTMLTMMTNOTPQRTJ0RUQPUOPVQPONK%","31064B40mrj5j8k0j8Tj6j6j4Tj2j0qonlTkjT%%VjjTkkTjkjkjkjT%jT%j%%","31111Dj%Uj%Xj%V5j%S84J%S9j%W1J%S7j%S89J%U9j%T6J%V6",""]
,[2,0,1,0,"0@",""]
,[3,0,1,0,"0@",""]
)
