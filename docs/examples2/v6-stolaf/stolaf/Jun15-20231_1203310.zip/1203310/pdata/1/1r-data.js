SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<1H>'; SpecInfo.Data.EXP='<PROTON>';SpecInfo.Data.SFO1=400.132470802;
SpecInfo.Data.O1=2470.802;SpecInfo.Data.F2=16.1876696570707;SpecInfo.Data.SW=20.0254193236558;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=98;
SpecInfo.Data.OFFSET=16.18777;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-a-team1/nmr/Jun15-2023/1203310/pdata/1/intrng, 6/15/2023 12:27:37 PM'
SpecInfo.Data.using='g:/data/chem-synthesis-a-team1/nmr/Jun15-2023/1203310/pdata/1/intgap_ole, 6/20/2023 9:19:05 AM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=65536
SpecInfo.Data.nint=5
SpecInfo.Data.realymin=-23849
SpecInfo.Data.realymax=379670941
SpecInfo.Data.realyave=225304
SpecInfo.Data.realyint=14668565708
SpecInfo.Data.snr=1685.25543265987
SpecInfo.Data.nbytes=844
SpecInfo.Data.miny=0
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=0.593381858097131
SpecInfo.Data.firstnz=20429
SpecInfo.Data.compressionratio=310.5/1
SpecInfo.Data.htratio=2.63385972433429E-06
SpecData=new Array([0,-1,65536,'g:/data/chem-synthesis-a-team1/nmr/Jun15-2023/1203310/pdata/1/1r']
,[1,19760,2574,669,"20429A%S3j%W37J%U8J%S3j%T0J%S7J%ZJ%VJ%TJ%J%J%JUKKTMMNOQRJ0J1J3J4","21111A01J5J4TJ3ROJmrj3j5j7Tj6j5j3j1qpomlTjkjV%j%Tj%Vj%Yj%U2j%%","21193@%ZJ%T1j%W87J%S3",""]
,[2,25576,3225,1433,"27009A%Z%Sj%W4J%Z%Sj%U54J%S18J%U0J%S1J%WJ%UJ%TJ%J%JT%JUKJTKJT%%","27631B1%TJ%JKTMNTPPQRJ0UJ1QOKlnqrj0TrqonmkTjjTkkmlmlVkjV%%j%TJ%","27689A2%UJJ%KJKULLVMLUKJKTMMOTQQRQPTNKlpj0j3Tj2j2j0rpomlkjU%%%","27745A8J%jVkjkjV%j%j%Tj%Vj%S0j%U4j%V91J%",""]
,[3,28801,3350,326,"29127A%VJ%TJ%J%J%J%UjjT%j%j%Uj%S247J%Zj%V7J%Uj%U63J%S19J%U2J%%","30983C%Z%SJ%WJ%UJ%J%JS4%JVKKLNTOPQRJ0TJ1RTOMJknpqrTqpTnnlZlSml","31064B6lkljkjV%%j%VJ%JWKKULLUMLUMLTMMTONPUOPMLJknqj0j1Uj0rpTmm","31128B5lkjU%j%TjjZjS%jT%j%Uj%Yj%T5",""]
,[4,0,1,0,"0@",""]
,[5,0,1,0,"0@",""]
)
