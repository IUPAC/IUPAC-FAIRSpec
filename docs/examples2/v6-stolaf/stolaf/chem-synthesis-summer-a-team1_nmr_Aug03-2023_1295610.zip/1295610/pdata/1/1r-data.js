SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<13C>'; SpecInfo.Data.EXP='<C13CPD32>';SpecInfo.Data.SFO1=100.622829803;
SpecInfo.Data.O1=10061.277;SpecInfo.Data.F2=219.438350248103;SpecInfo.Data.SW=238.896695566946;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=90;
SpecInfo.Data.OFFSET=219.4603;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team1/nmr/Aug03-2023/1295610/pdata/1/intrng, 8/3/2023 11:45:24 AM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team1/nmr/Aug03-2023/1295610/pdata/1/intgap_ole, 8/8/2023 8:37:58 AM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=32768
SpecInfo.Data.nint=4
SpecInfo.Data.realymin=-17059452
SpecInfo.Data.realymax=321489995
SpecInfo.Data.realyave=4100585
SpecInfo.Data.realyint=17403891597
SpecInfo.Data.snr=82.5612557720423
SpecInfo.Data.nbytes=942
SpecInfo.Data.miny=-53
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=12.1122188688732
SpecInfo.Data.firstnz=11817
SpecInfo.Data.compressionratio=139.1/1
SpecInfo.Data.htratio=3.11051670519327E-06
SpecData=new Array([0,-1,32768,'g:/data/chem-synthesis-summer-a-team1/nmr/Aug03-2023/1295610/pdata/1/1r']
,[1,11816,55,1,"11817b2K4OTjk3j0J2K1J2nj1kqJ9K6Ork2NprK0J4j6%K0K6N%QRL7N0qq9m4p","11854C3lrNjk5oKp%J0OJ2JmJ0J",""]
,[2,12029,65,1,"12030GLRTpOJj9J0j0%j2pRJ6J8MnJj7P%k1j4J0KMJ1J3K4J4jOk7QL4OTLM5L0","12070A76o2m7l6j1LJ3j4nJ4mj1qlj1J5LJj3mLN%M",""]
,[3,12464,108,1,"12465A3kNj1oK4J0k8j1J3%QqLJ0RJ1K6Oj6TrrlJ8PJ9MTnJ2J5Rnk%K8K3oo2","12504G8m0Lj1OMk5j0PmOPLmOKN%k0K6k3j0JkJ0J9j2jQpj5KQK4J2j3krk1J4","12543B2K9Oj6j4MK0j1RJ9pJ5mk7j4kj2j6LQj2J0J4j7RlNJ2n",""]
,[4,19439,174,1,"19440A6lMplj0J0QJNk3JMJ9K3J5jkOJ1J7qTJ7K4J5j4J5K7J5PoJ4J3kK2J0M","19477B36M2M9K2TOM1L7J5O7O0O3Q0O9R6R5kj81k81k02r8n8l6j2kPJ1nPTj4K8","19508A69LjJ0mM4ORojJNJ6K5J8J5L0M5J2L8L1O0M7N4O9TQ7P9O3o1k50k59j56","19540B67r1m5k8OKK6nNj3j1J2L9K6k1PrPJ3KK4J8rkK3K6K3J0L7L4J7L5N4M7","19573E26M1N3P0Q8J18P8%j75k83k00j09m4m8k0l5k6j9NTj3K3mj9%J2mj4o","19601@KOjmLj2KlL%L4",""]
)
