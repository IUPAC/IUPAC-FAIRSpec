SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<1H>'; SpecInfo.Data.EXP='<PROTON>';SpecInfo.Data.SFO1=400.132470802;
SpecInfo.Data.O1=2470.802;SpecInfo.Data.F2=16.1876696570707;SpecInfo.Data.SW=20.0254193236558;
SpecInfo.Data.INTSCL=1.13803995473631E-04;
SpecInfo.Data.NC_procplus100=95;
SpecInfo.Data.OFFSET=16.18777;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team3/nmr/Aug03-2023/1295310/pdata/1/intrng, 8/5/2023 6:55:25 PM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team3/nmr/Aug03-2023/1295310/pdata/1/intgap_ole, 8/5/2023 6:55:28 PM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=65536
SpecInfo.Data.nint=6
SpecInfo.Data.realymin=-73839
SpecInfo.Data.realymax=481242676
SpecInfo.Data.realyave=1093923
SpecInfo.Data.realyint=70975846067
SpecInfo.Data.snr=439.991219674511
SpecInfo.Data.nbytes=1001
SpecInfo.Data.miny=0
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=2.27277262655324
SpecInfo.Data.firstnz=28214
SpecInfo.Data.compressionratio=261.8/1
SpecInfo.Data.htratio=2.07795370167878E-06
SpecData=new Array([0,-1,65536,'g:/data/chem-synthesis-summer-a-team3/nmr/Aug03-2023/1295310/pdata/1/1r']
,[1,28213,114,1,"28214D9%J%JTKKTLKMLMNUOPQTRJ0TRJ0QRPTNNLTJJjVkj%TJ%TjkTmnoTppp","28270A62qpTonTmmkU%jJ%KUMLMNMTNNMONOUPNTMMLUKJT%jklTnmnmnoTp",""]
,[2,28336,132,1,"28337G5mkTjj%TJ%JV%JZKKUMNOQJ0J1J4J5UJ4J3TJ1RPMKknqj0j2j3j2j3j1","28390A76j1j0qpTonUonoVnnmlTkkjT%%TJKJKLMTNNTOONOWPOQPRTJ0J2VJ0Q","28448B52PNKjmoj0j3j5j8j9j8Tj7j4j3j0qp",""]
,[3,28730,114,1,"28731C2JZ%J%Vj%j%j%j%j%WJ%J%J%J%J%JTKJTKKVLLMLUMLTKLKLKUJKJKJK","28801A11KTLKLTKKUJ%TjjkTllZjkjU%%VJJKUL",""]
,[4,28858,80,1,"28859B47QPOLJ%klmoTqqTrj0rqUppTnomTlljTJKTLNTOOPUQQPQRQWJ0RJ0J1","28915B98J0RTPNLJjlorj1j4j5j6j7Tj5j3j2j1r",""]
,[5,30217,298,1,"30218F%S9J%S2J%ZJ%VJ%VJ%UJ%TJ%J%J%JV%KJTKJKTLKTLKLKTLKLKLUMNOP","30313I0RJ1J3J5J6VJ5J4J2J1QNKjmpj1j2j3j4j3Tj2j0TqpTonoTnopoUnnm","30356E4lkljU%%JUKKLMTNNTONOXPPTQRJ0TJ1J1TRQPML%lnrj1j3j6j7Uj6j4","30410A07j3j0qpomTllkZlkYjjW%jT%%j%Tj%Uj%Vj%Xj%S3j%U4",""]
,[6,0,1,0,"0@",""]
)
