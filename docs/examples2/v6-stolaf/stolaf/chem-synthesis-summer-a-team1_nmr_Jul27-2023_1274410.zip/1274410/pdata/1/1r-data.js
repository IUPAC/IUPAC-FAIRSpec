SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<1H>'; SpecInfo.Data.EXP='<PROTON>';SpecInfo.Data.SFO1=400.132470802;
SpecInfo.Data.O1=2470.802;SpecInfo.Data.F2=16.1876696570707;SpecInfo.Data.SW=20.0254193236558;
SpecInfo.Data.INTSCL=5.12927491443342E-04;
SpecInfo.Data.NC_procplus100=95;
SpecInfo.Data.OFFSET=16.18777;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team1/nmr/Jul27-2023/1274410/pdata/1/intrng, 8/8/2023 11:10:26 AM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team1/nmr/Jul27-2023/1274410/pdata/1/intgap_ole, 8/8/2023 11:10:27 AM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=65536
SpecInfo.Data.nint=6
SpecInfo.Data.realymin=-33676
SpecInfo.Data.realymax=396291287
SpecInfo.Data.realyave=812393
SpecInfo.Data.realyint=52943285661
SpecInfo.Data.snr=487.848815782509
SpecInfo.Data.nbytes=638
SpecInfo.Data.miny=0
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=2.04981536830422
SpecInfo.Data.firstnz=29040
SpecInfo.Data.compressionratio=410.8/1
SpecInfo.Data.htratio=2.52339638241908E-06
SpecData=new Array([0,-1,65536,'g:/data/chem-synthesis-summer-a-team1/nmr/Jul27-2023/1274410/pdata/1/1r']
,[1,29039,228,1,"29040A%WJ%T4J%ZJ%TJ%J%JT%JU%JT%%J%Tj%Tj%jT%jT%j%j%YJ%J%JKTLLML","29132B6MLTKLKJT%klmlkjT%%TJJX%%jVkkUlkVjkjU%j%j%Uj%S2J%UJJ%KJJ","29208A1KJKTJKTJKJ%Jj%j%kjkjkUjkjW%j%j%Tj%Wj%S5",""]
,[2,29281,407,1,"29282B%U9J%S4J%WJ%TJ%J%JT%JYKJUKJZ%J%J%j%Tj%jXkjTkjkjY%%j%VJ%%","29411IJ%JWKKVLKLTMLYKKTJJT%%jUkkUllZlSklkVjkjW%j%j%j%Uj%S6J%TJ%","29504FJ%JWKJTKJTKJY%J%Wj%jXkjVkjY%jT%%j%WJ%TJ%JU%JZ%JT%J%J%Xj%","29596B1jW%jZ%jU%j%j%Tj%Yj%W8",""]
,[3,0,1,0,"0@",""]
,[4,0,1,0,"0@",""]
,[5,0,1,0,"0@",""]
,[6,0,1,0,"0@",""]
)
