SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<13C>'; SpecInfo.Data.EXP='<C13CPD32>';SpecInfo.Data.SFO1=100.622829803;
SpecInfo.Data.O1=10061.277;SpecInfo.Data.F2=219.438350248103;SpecInfo.Data.SW=238.896695566946;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=91;
SpecInfo.Data.OFFSET=219.4603;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team3/nmr/Jul20-2023/1258010/pdata/1/intrng, 7/20/2023 1:47:54 PM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team3/nmr/Jul20-2023/1258010/pdata/1/intgap_ole, 7/22/2023 12:18:27 AM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=32768
SpecInfo.Data.nint=5
SpecInfo.Data.realymin=-9259503
SpecInfo.Data.realymax=394640983
SpecInfo.Data.realyave=2125330
SpecInfo.Data.realyint=8854813072
SpecInfo.Data.snr=190.041304644455
SpecInfo.Data.nbytes=912
SpecInfo.Data.miny=-23
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=5.26201397044122
SpecInfo.Data.firstnz=12607
SpecInfo.Data.compressionratio=143.7/1
SpecInfo.Data.htratio=2.53394868520282E-06
SpecData=new Array([0,-1,32768,'g:/data/chem-synthesis-summer-a-team3/nmr/Jul20-2023/1258010/pdata/1/1r']
,[1,12606,44,1,"12607CljlTOKk%mPkoNO%jJ%RJ1J8J9P2J07o6j21l1koqmJJ1nmlTLqlmK",""]
,[2,19453,156,1,"19454DLqLTJQOKj0JrjNJkJPJ%RJKlP%JJ4PTJ4K3K7M8P8J20K17L10J02k55l22","19494D23j91r7m4j9j5j0nkj2k%NRjomlrJOT%nKkNkLPJ1QJ1J0J7J2L6N1R0J60","19533D44K85K65p0l43k64j32o3l7k6j2j1onjNlrMlnROonKRTnnjKRkMJ1NJ0","19570F5J7J6K5L5O5J14K11L03J49k38l34j95r2m5k7j7j3qrjlokljpKTMNm","19601HqTKNRm%",""]
,[3,24525,51,1,"24526HqlN%Pjj0%NqL%QTjkL%jlNJOJ2NJ3K1M3J21L65J46m95j46n3k4rj7J","24564EkrkKPNj2MOpm",""]
,[4,25826,116,1,"25827akQoKLJomj%J0TMjponpKRJmToPn%mJQLmRkNJk%nj0RJ1%KlNqkN%mpJ","25880AkTllLJ1jJKklmMPTq%RJLj0oKpJLlPQ%QJ0TL0M5Q7K75L66m90k18p0k8","25922D1j5mlolpTJ2jmpMkMoNKmM",""]
,[5,27407,71,1,"27408bJ4Qj1TQonNOjpPJPLTkrolJQlJlJKJNMpqRNMOjJKJ7L2O5J46J21Q2k84","27454B06j38l9jj3kTJojl%jKRJkj4jPkMJk",""]
)
