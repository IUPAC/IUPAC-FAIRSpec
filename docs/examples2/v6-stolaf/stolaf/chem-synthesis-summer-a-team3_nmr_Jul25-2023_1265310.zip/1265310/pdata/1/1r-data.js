SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<13C>'; SpecInfo.Data.EXP='<C13CPD32>';SpecInfo.Data.SFO1=100.622829803;
SpecInfo.Data.O1=10061.277;SpecInfo.Data.F2=219.438350248103;SpecInfo.Data.SW=238.896695566946;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=92;
SpecInfo.Data.OFFSET=219.4603;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team3/nmr/Jul25-2023/1265310/pdata/1/intrng, 7/25/2023 12:30:44 PM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team3/nmr/Jul25-2023/1265310/pdata/1/intgap_ole, 7/25/2023 7:22:17 PM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=32768
SpecInfo.Data.nint=18
SpecInfo.Data.realymin=-4460239
SpecInfo.Data.realymax=270377229
SpecInfo.Data.realyave=1260514
SpecInfo.Data.realyint=12204202349
SpecInfo.Data.snr=218.036029746595
SpecInfo.Data.nbytes=2493
SpecInfo.Data.miny=-16
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=4.58639795066079
SpecInfo.Data.firstnz=11215
SpecInfo.Data.compressionratio=52.5/1
SpecInfo.Data.htratio=3.69853631423969E-06
SpecData=new Array([0,-1,32768,'g:/data/chem-synthesis-summer-a-team3/nmr/Jul25-2023/1265310/pdata/1/1r']
,[1,11214,114,1,"11215eOLo%JTO%oJlkOPklMKJ8J9j2mqkMqmj0kjLTkoM%Uk%Lk%jNlLJNJ2K1l","11267D1j5j4qno%JLk%MOkTjjkKP%jq%l%NM%lkNjTLKlO%jKjlM%JkTjn%mTMM","11321A%LTnjm",""]
,[2,12284,100,1,"12285fJMkpJQ%JNk%mkJ0%NJ0K4M8L0o0l8j5jlLKnoJlj%LJjNjOL%J7K7P3J52","12330B83J42j36j76n0k7j7kmoKlkTKKlK%J%kjTlJMKpJLjJjLMj%JKmlkJMn","12375BjJTKnjJM",""]
,[3,12479,58,1,"12480A%pjJNOklUJlLRL%LKkpjkUOkpJKPOjLmLK5M6M5n8m1j3pLopMTjkjpK","12532d%TJN",""]
,[4,12650,57,1,"12651aKTjLjpJ%KkJkJOMKMRjJ1K1N2J86K83l67j17l6j8j0pnpJOkKK1N0P3r4","12691F5l7j5pnOJmjMTljnjJ",""]
,[5,13142,82,1,"13143clNKjLjlKLm%KlPKljRjTnm%kjT%lTNJ%lJ%RMjlkKLJkmKJjKTmmkOjl","13199AMJT%RJ2M5O7n7n4j3j2jNlnlJOkK%JK",""]
,[6,19455,173,2,"19457AlNJlkKjo%MTL%TK%LT%J%J1LMKURQTJ7L3N1J02J68J82L6j82k02j08n7","19498A03k5j4j7j1pKpqMNLmomj%MTlJTjLjTPnLQJPJ3J4K3M2O4J24K01J49p2","19538E99k22j70p8l9k8j2j0pj0l%oJLmkoLPKLlmjKNJ%LKTJRMLJ4J8K8N5Q7","19578B47J62J88O5j62k03j26o2l2k3j5j2p%mjOpLjpkjkJVKNmNTnpj%oKJJ","19618F%Tn%M%l%j",""]
,[7,24290,69,1,"24291ALn%OlLjT%pKJR%mOjnKNqlnOj%ML%JTjJ%kjPmjMTNOTJ9M2J07K68k1k84","24341A64j09l3j3joM%Tjlj%TkR%o",""]
,[8,25129,42,1,"25130BolNTljJLkLlORjloQK2N9R8j37l3j2J%kpoNjKLkjTk%K%o",""]
,[9,25322,62,2,"25324AkmKLMmkOLmKJ%LMONJ0K1M9K00j36j21k4j0om%kOjmkOMJ%NJ2L4M3j4","25366I1o0j5j0nJ%Lln%L%lTJK%",""]
,[10,25726,68,1,"25727GLplkJmMN%kjLTMNk%NnTLkJTpLJ0jK%NOJ3RK2K7N2J41L44L62k54n13j32","25770A01m7k2jj2p%TklrkKoMJ%JjLMOok",""]
,[11,26089,49,1,"26090CJlJoKJOLojJMjK%TkRQPK0L7J14K37k12j62m0qjnKkjpoN%jqQKkT%o","26135iJL",""]
,[12,26556,98,1,"26557DmKTlj%TnOMmMNjTKlonOMJknkQJj%TknNMomM%nLTpJ%LJMjLTMljojN","26613HkKkmL%MLjoK%LJkPLJ8M0J10J16k08o4j8pkm%MkjOKl%TrmLK",""]
,[13,26948,87,1,"26949B%j%qLMOLlT%LJLnKjLjMPLjk%Ln%njLOJTJ0PKJ1TK1L0O4J73L18K79k89","26995F59m67j08l5qlJ0L7M5J9r0l7j4nklQJjMNmPkmqpKLUklpNJj%mK",""]
,[14,27141,53,1,"27142CnO%TPpnJKTkN%MmMOJ0L0L6K6J7o9l9j3mnjKRJ5J9J6j2m0ojp%Lkjk","27185bOmoJLKmL",""]
,[15,27245,69,3,"27248EklLP%TllmNTK%LPJ2K2O1L8r1m3j1%oklJ%M%mT%MJMJlLlJjmKUJ2J8J9","27297E4%m6j3LOomkKNPlMoTk",""]
,[16,27512,40,1,"27513clJTN%jRJpmJQjPNJ1J9N8P7k3j17k9rkmJkTMJ%mjmlPkM",""]
,[17,28103,99,1,"28104FM%nl%JKmKMnMJMLMmoKmKNMolOnlKNlK%QNQJ4J6J5j8l6jmPkNLjLJ0%","28155D4KRJ3J8K2M4J21K14kk37p7J8J15J70J21J82l6m91j52m2k9j2JLr%p","28182CLk%MjrKQnj%kmjNOKqk",""]
,[18,28508,53,1,"28509CkmPkTOlJmlJNM%VJMJTP%TPNL2O9N9O2M4j63q8k6j2klTmLTmjT%nR%","28557B%Om",""]
)
