SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<13C>'; SpecInfo.Data.EXP='<C13CPD32>';SpecInfo.Data.SFO1=100.622829803;
SpecInfo.Data.O1=10061.277;SpecInfo.Data.F2=219.438350248103;SpecInfo.Data.SW=238.896695566946;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=91;
SpecInfo.Data.OFFSET=219.4603;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team2/nmr/Aug03-2023/1294910/pdata/1/intrng, 8/3/2023 10:27:45 AM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team2/nmr/Aug03-2023/1294910/pdata/1/intgap_ole, 8/8/2023 8:36:37 AM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=32768
SpecInfo.Data.nint=7
SpecInfo.Data.realymin=-9416852
SpecInfo.Data.realymax=409781808
SpecInfo.Data.realyave=2159012
SpecInfo.Data.realyint=13554672207
SpecInfo.Data.snr=194.162264961936
SpecInfo.Data.nbytes=1152
SpecInfo.Data.miny=-23
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=5.15033134886452
SpecInfo.Data.firstnz=11827
SpecInfo.Data.compressionratio=113.7/1
SpecInfo.Data.htratio=2.44032307066203E-06
SpecData=new Array([0,-1,32768,'g:/data/chem-synthesis-summer-a-team2/nmr/Aug03-2023/1294910/pdata/1/1r']
,[1,11826,132,1,"11827CMJprjLJ1mkjJjLNTKOJ1K5N4J63K75k77j61o1k2j6mjj2NK%oLMkjNk","11867Ajk%kKkKjJnJNpjNJ0jTMLqM%Kj1mlLOTQjkmjpOJkmjnJkLTKNkmkJLL","11921EJ1J9M6l4l3j3kMJm%jKMnk%ONkPkLj0oj0NTkLJkN%pm",""]
,[2,12021,68,1,"12022DKplnMOjKTjlkMTJ2Nj0oq%NJRL4Rk8pj0qMTnKLjMKlNPLPQL6J02L15j15","12069C82k56p6l2K%Jj5lkJKOkWKp",""]
,[3,12461,74,1,"12462A0KLnJ%KmlnMToJ%JKJ8J4K8J1m4j7MLJKmlkJ3PJ0K5Mk1J7N2J69J94k08","12502B80j75m8j0nTJ0qj5lrkKJl%LoM%MTLprLkTlO%nK",""]
,[4,12535,42,1,"12536IPlpTJJPk%MJNOJ8M0P4O3q0p6k5j3q%nJ%Klj3LKjOK%p%jMl",""]
,[5,14437,47,2,"14439Hjk%rNJjK%pMLNTJ%J5TL2R6L10n9k82p5k3j8j0mKjqJojPJ1oKnT%nK","14482aL",""]
,[6,19444,165,1,"19445Hj1m%J1Lj2MjQLj3MTPmKmMk%J4jmkmjNjN%PLMRKlPKJ4J9K7N1Q3J60K68","19490F71K54k1l04k60j42p7m0j6j3roj%j4lJ2JokMmo%k%lQJnQT%OLJTJ2K8","19528H4K3K6O1J11K00L13J82j99l27k11j04n5l1j8j5nTj0OLnjJNj0nLN%l","19558A9nLjTNQJPnRO%K0J8L1M9P6J45K61K78Rk99k78j52q0m3k4j0rj0jj2m","19591A1%TKnj0QJmnOnMTq%QK",""]
,[7,22493,46,1,"22494A1l%n%TkJOoJlLJ4MLJ5K8J04R4j48p1j2j6lmlR%omknoLmOmNTJLmkr","22538f",""]
)
