SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<13C>'; SpecInfo.Data.EXP='<C13CPD32>';SpecInfo.Data.SFO1=100.622829803;
SpecInfo.Data.O1=10061.277;SpecInfo.Data.F2=219.438350248103;SpecInfo.Data.SW=238.896695566946;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=91;
SpecInfo.Data.OFFSET=219.4603;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team3/nmr/Aug01-2023/1285210/pdata/1/intrng, 8/1/2023 10:50:07 AM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team3/nmr/Aug01-2023/1285210/pdata/1/intgap_ole, 8/1/2023 11:25:42 AM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=32768
SpecInfo.Data.nint=3
SpecInfo.Data.realymin=-10006797
SpecInfo.Data.realymax=380484527
SpecInfo.Data.realyave=2071735
SpecInfo.Data.realyint=10127109861
SpecInfo.Data.snr=188.485170159311
SpecInfo.Data.nbytes=653
SpecInfo.Data.miny=-26
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=5.30545718347381
SpecInfo.Data.firstnz=12312
SpecInfo.Data.compressionratio=200.7/1
SpecInfo.Data.htratio=2.62822777021889E-06
SpecData=new Array([0,-1,32768,'g:/data/chem-synthesis-summer-a-team3/nmr/Aug01-2023/1285210/pdata/1/1r']
,[1,12310,85,2,"12312a0pML%JjQROjrjJ0lTMJ0K2M7M3Lq2k2j9nmkOJoJkQKmT%OJ9K8O3L7q7","12355F9l9lpmqJnLkQMnjoJ1KMK5O8O7j00m4j9mlnjmLnkOjLmjnJT",""]
,[2,12430,49,1,"12431BJKLpoLNQjlmoKQJTO%J4QL6P9j3q7k8j5kMmMmJNLoj2%jMLkTJmMjn",""]
,[3,19452,161,1,"19453DmTQmJMlkJQlmLJ0kmkJ1rNTkNkjPkOJ8J3QJ5PJ9K9N3J06J96K81K03j01","19494H77l10k32j34o3l8k7j3j2j5kLQMkNnrj1nK%nLOLkRNTJ0KMJJ7TJ5K3L9","19532A73P0J41K47K87Q2k47l10j86r4m9k6j3Tj1k1k%To%NjqM%MoMLOK%lJ","19566C3MJ0RMJ4QJ0J6L2N7R8J83K74K21p3l01k56j29o7m0k0j8Tj6nj3JQj","19595B5j1Okpj1%MNlkONpoKTn",""]
)
