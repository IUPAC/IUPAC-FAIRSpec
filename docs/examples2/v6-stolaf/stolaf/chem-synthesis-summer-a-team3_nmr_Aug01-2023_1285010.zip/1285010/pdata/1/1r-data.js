SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<1H>'; SpecInfo.Data.EXP='<PROTON>';SpecInfo.Data.SFO1=400.132470802;
SpecInfo.Data.O1=2470.802;SpecInfo.Data.F2=16.1876696570707;SpecInfo.Data.SW=20.0254193236558;
SpecInfo.Data.INTSCL=8.01247693212512E-05;
SpecInfo.Data.NC_procplus100=93;
SpecInfo.Data.OFFSET=16.18777;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team3/nmr/Aug01-2023/1285010/pdata/1/intrng, 8/1/2023 11:21:22 AM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team3/nmr/Aug01-2023/1285010/pdata/1/intgap_ole, 8/1/2023 11:21:23 AM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=65536
SpecInfo.Data.nint=8
SpecInfo.Data.realymin=-442582
SpecInfo.Data.realymax=538976606
SpecInfo.Data.realyave=1785022
SpecInfo.Data.realyint=112232834465
SpecInfo.Data.snr=302.191899035418
SpecInfo.Data.nbytes=1882
SpecInfo.Data.miny=-1
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=3.30915555046959
SpecInfo.Data.firstnz=26679
SpecInfo.Data.compressionratio=139.2/1
SpecInfo.Data.htratio=1.85536809736785E-06
SpecData=new Array([0,-1,65536,'g:/data/chem-synthesis-summer-a-team3/nmr/Aug01-2023/1285010/pdata/1/1r']
,[1,26678,479,1,"26679C%T2Jj%VJ%Tj%S0J%U2J%T0J%S8J%Z%SJ%YJ%XJ%XJ%TJ%TJ%UJ%UJ%J%","26844A6%J%UJ%TJJ%J%JT%JTKJUKJTKKULKLKLMVNNOTPOQVJ0J0TJ2J2TJ3J4J3","26901B44J3J2J1RPNLjknprj0Tj1j2j1Tj0j0TrrqrqpqopnTmmlkjUJ%JKLTMN","26948A07NOTPPQRQJ0RJ0RJ0WJ1J0RJ0QPNLJkmpj0j2j4Tj6j6j5Uj3j3j1j0j0","26991A18qUpoUnnmnlWkkTjkjkjZ%j%jT%%j%j%Tj%Tj%Wj%Xj%Vj%S3j%W0J%","27122E%XJ%S3j%Wj%Vj%J",""]
,[2,27410,284,1,"27411H%J%VJ%TJ%VJ%TJ%J%TJJ%JU%JTKJTKKJLKTLLMLMNUOOPYNNMKTjklmo","27478A32pUqqTppoTnnmTllTkkVjjk%jW%j%j%Tj%j%Xj%UJ%j%UJ%WJ%WJ%UJ%","27552A4J%J%J%JT%JYKJTKKTLKLUMMNUOPURRTJ0J0RJ0RQPNTK%kloprj0j1j0","27610A44j2j0j1j0rTqponTmmlUklkjkTjjZ%j%Tjj%Uj%Uj%Uj%Wj%j%Vj%S0j%","27684D%Z%S",""]
,[3,27961,230,1,"27962H%WJ%XJ%ZJ%YJ%TJ%XJ%UJ%J%TJ%J%JT%J%JU%JYKJKJKJKLKTLLUMMUNM","28050H6NUOOTPQTRJ0J1TJ3J2J3UJ1J0QOMJjmnqrj0Tj1j0UqrqpXoonTmmTlk","28103I3kjT%JTKLTMMNTPOPQTRQRXJ0J0TJ1J2J1J2J1J0RONKkmqj1j3j5j7j8","28150B55j8Tj7j5j4j3j2j0rqpTooTnnTmnmTlmlTkkVjjkjU%jT",""]
,[4,28218,203,1,"28219A9%TJ%UJ%J%J%J%JWKJKJKTLKLTMLNMNOTPQRTJ0J0J2WJ0RONJjmpj0j1","28276A94j3Tj4j4j2Tj0j0qTpnUmlmklkljkUjkjY%j%j%j%j%j%Tj%Tj%WjJ%","28334A3%S0J%WJ%UJ%TJ%J%J%J%JUKJUKKULKLTMMTNOUPQURJ0QTPNMK%lmpq","28404A44rj0VrqpTonTmlU",""]
,[5,28605,213,1,"28606A7%J%TJ%JT%J%JT%JYKJKTJLKTLKLTMMUNNTOOUPPUQRTJ1J1J2J3J4J5J6","28664B58J6J5TJ4J2ROMjlpj0j1j4Uj5j3Tj2j1j0TrrqWpponTmmlkTjj%JUKL","28712I4LTMNONPOPTQPQTPQWRQUPOMK%knqj0j2j3j4j5Tj4j3Tj1rTqoUnmnm","28764G0lmlmlTklTkkUjkjkjW%jU%j%j%j%j%Tj%Uj%Wj%X",""]
,[6,28853,236,1,"28854A5%XjJ%XJ%WJ%UJ%TJ%J%J%TJ%J%JU%JWKJTKKWLKLMLMTNMONOTPQURR","28929A51J0TJ1J1J2J1J2TJ1J0TRQOML%TlmoqTrj0Uj1j0UrrTqqTpoTnnmTlk","28975I9kj%UKJLTMMNTOPOPQURQRTQRTQQTONTLK%jmTpqTj0j1j2Vj1j2j1j0r","29028A25rqpqoTnnUmmlUkklkTjkjkjV%jT%j%jT%%j%Vj%TJ%S2J",""]
,[7,0,1,0,"0@",""]
,[8,0,1,0,"0@",""]
)
