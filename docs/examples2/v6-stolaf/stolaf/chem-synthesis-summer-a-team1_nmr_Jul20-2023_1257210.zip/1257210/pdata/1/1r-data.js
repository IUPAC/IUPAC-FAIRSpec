SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<13C>'; SpecInfo.Data.EXP='<C13CPD32>';SpecInfo.Data.SFO1=100.622829803;
SpecInfo.Data.O1=10061.277;SpecInfo.Data.F2=219.438350248103;SpecInfo.Data.SW=238.896695566946;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=91;
SpecInfo.Data.OFFSET=219.4603;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team1/nmr/Jul20-2023/1257210/pdata/1/intrng, 7/20/2023 12:56:51 PM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team1/nmr/Jul20-2023/1257210/pdata/1/intgap_ole, 7/23/2023 10:00:47 PM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=32768
SpecInfo.Data.nint=4
SpecInfo.Data.realymin=-9724090
SpecInfo.Data.realymax=403353729
SpecInfo.Data.realyave=2089009
SpecInfo.Data.realyint=8277983436
SpecInfo.Data.snr=197.738649761681
SpecInfo.Data.nbytes=677
SpecInfo.Data.miny=-24
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=5.05718027914735
SpecInfo.Data.firstnz=19453
SpecInfo.Data.compressionratio=193.6/1
SpecInfo.Data.htratio=2.47921347468192E-06
SpecData=new Array([0,-1,32768,'g:/data/chem-synthesis-summer-a-team1/nmr/Jul20-2023/1257210/pdata/1/1r']
,[1,19451,157,2,"19453AMjO%nPKj0n%LOJ0kJToPkTQPKJKnLQMLJ9J7K0L1M4Q6J53K64K62j1l06","19494F27k72j52p1m4k7j2opnk%lONlj7%lLKLJ0KlTLlkQJ3NOLJ0K2K7M8N8J15","19533C41K00K88J71j80l36k17j08n1l9k0oqjj1npLKLJlqQNL%qlMmJ0RMnJ1","19568D3PJ2J5RJ3K8M3P8J40K55K79K9k91k93j62p8m5k3j7j1nklmTjj3jQJ","19598GpJkLKNMJk",""]
,[2,24530,54,1,"24531Cj%MQqlPmjkJjPN%oOnKPTJ3L4Q1K22l2k34n7l0rkrnRJ0lk%krKmjK%","24576@LTnQKmT",""]
,[3,25897,43,1,"25898A2oqM%JLmNkm%MJLJ0J3K9N6J79J39k58r7l8rUj0nTOJjMnKQlomJ1M",""]
,[4,27434,39,1,"27435A%KnjL%NjKk%PRK7N4P1O1j1j38m0j5j2j1njJ%NTlnjknl%L",""]
)
