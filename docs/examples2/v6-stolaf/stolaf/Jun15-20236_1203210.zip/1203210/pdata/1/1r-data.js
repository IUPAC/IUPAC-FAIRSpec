SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<1H>'; SpecInfo.Data.EXP='<PROTON>';SpecInfo.Data.SFO1=400.132470802;
SpecInfo.Data.O1=2470.802;SpecInfo.Data.F2=16.1876696570707;SpecInfo.Data.SW=20.0254193236558;
SpecInfo.Data.INTSCL=1.02106594944537E-04;
SpecInfo.Data.NC_procplus100=95;
SpecInfo.Data.OFFSET=16.18777;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-a-team6/nmr/Jun15-2023/1203210/pdata/1/intrng, 6/20/2023 9:11:57 AM'
SpecInfo.Data.using='g:/data/chem-synthesis-a-team6/nmr/Jun15-2023/1203210/pdata/1/intgap_ole, 6/20/2023 9:11:58 AM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=65536
SpecInfo.Data.nint=5
SpecInfo.Data.realymin=-57981
SpecInfo.Data.realymax=531717551
SpecInfo.Data.realyave=1033573
SpecInfo.Data.realyint=67095136084
SpecInfo.Data.snr=514.502151275236
SpecInfo.Data.nbytes=995
SpecInfo.Data.miny=0
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=1.94362646982411
SpecInfo.Data.firstnz=28053
SpecInfo.Data.compressionratio=263.4/1
SpecInfo.Data.htratio=1.88069774661247E-06
SpecData=new Array([0,-1,65536,'g:/data/chem-synthesis-a-team6/nmr/Jun15-2023/1203210/pdata/1/1r']
,[1,28052,567,1,"28053C%T2J%W8J%T0J%W1J%S9J%S3J%S4J%ZJ%Z%SJ%YJ%WJ%WJ%YJ%VJ%VJ%%","28316A8%TJ%UJ%UJ%UJ%TJ%TJ%TJ%TJ%TJ%TJ%TJ%J%TJ%J%TJ%J%J%TJ%J%J%","28374C8J%TJ%J%J%TJ%J%TJ%J%TJ%UJ%UJ%S9j%Uj%Tj%Tj%Tj%j%j%Tj%j%j%","28448C9%j%j%j%j%j%j%Tj%j%j%Tj%Tj%j%Tj%Tj%Tj%Tj%Tj%Uj%Uj%Uj%Uj%","28507A8%Uj%Wj%Wj%Wj%Yj%Z%Sj%Z%Sj%S9j%V1",""]
,[2,28643,260,1,"28644A1%ZJ%S0J%YJ%WJ%UJ%UJ%TJ%J%J%J%J%J%JS0KJKWLKLVMLMWNMOUQQJ0","28738A43J0J1TJ2J2J1TRQNKjlorTj1j1UrrqoUnnTonVmmlTkjU%%JTKKLUMM","28791I2NTOOPTOPWOPTQQRUJ0RQOMKknqj1j4j6j7Uj6j4j3j1j0qpomnlmlTml","28842E0lWkkWjjkj%jU%j%j%j%j%Tj%Uj%Uj%Wj%Xj%Z%S",""]
,[3,29547,326,1,"29548A5%VJ%TJ%TJ%TJ%J%J%J%JT%JZJSKJTKKWLKLUMLMUNMNTOOTPQTRRJ0J1","29614A81J1TJ0J0TQPNLJ%lmoqTj0j0VrrTqpTopnonTmmTllkU%j%JUKLKLMM","29667I1MNVOONOUPOTPOUNNMLK%jlmoqrTj1j1Vj0rTqpoTmnlmlklklkXjjkj","29729A7jV%jT%j%Tj%j%Uj%Vj%Xj%S2j%X1J%U0J%Y",""]
,[4,0,1,0,"0@",""]
,[5,0,1,0,"0@",""]
)
