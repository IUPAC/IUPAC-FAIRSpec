SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<13C>'; SpecInfo.Data.EXP='<C13CPD32>';SpecInfo.Data.SFO1=100.622829803;
SpecInfo.Data.O1=10061.277;SpecInfo.Data.F2=219.438350248103;SpecInfo.Data.SW=238.896695566946;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=90;
SpecInfo.Data.OFFSET=219.4603;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team3/nmr/Jul27-2023/1274010/pdata/1/intrng, 7/27/2023 11:45:30 AM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team3/nmr/Jul27-2023/1274010/pdata/1/intgap_ole, 7/28/2023 9:54:51 AM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=32768
SpecInfo.Data.nint=2
SpecInfo.Data.realymin=-17406866
SpecInfo.Data.realymax=311247882
SpecInfo.Data.realyave=4045925
SpecInfo.Data.realyint=11140403922
SpecInfo.Data.snr=81.2310529730531
SpecInfo.Data.nbytes=663
SpecInfo.Data.miny=-56
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=12.3105630593233
SpecInfo.Data.firstnz=12307
SpecInfo.Data.compressionratio=197.6/1
SpecInfo.Data.htratio=3.21287326864444E-06
SpecData=new Array([0,-1,32768,'g:/data/chem-synthesis-summer-a-team3/nmr/Jul27-2023/1274010/pdata/1/1r']
,[1,12306,85,1,"12307anjqJ8%mNj2j3J4qKNK0K7pKj2pqJ4Kj2K3J3nTk1JOlJ1qk7K7J1jj7j6","12346@J5K8K1Pj1k0oJ3Mj2qmj5K6j8o%nNL4%nRp%KPJ5mlk4mk3j0poJPJ5j8","12386gj2NJ4L",""]
,[2,19430,175,1,"19431B7j8oJ1Kj7j1J6J1jj8pqL3ONJJ8MJ4k1j7J3qj%K1J0K1K4qmJ7PJ3K2K","19467A53%J2J6J2kKJ8J2J8K7L2lOK9J2K5L8M8O4M6L2O3J05Q7Q2O6l6k10k80","19496D74k03r9l5jkk3MK7J1J3l%TnJ2lK0OKJ8J1kMK0M1L3J7K1jK2M3L3M1M2","19530E38M5P7O3O2P6Q1L6j00k66k32j35o6m3l8KL%QRpOK0j2J8MK2POL3qO","19561B15mK4L3J3J7J1L3K4J3L1N6M4L7P2N3R3O1O6Q2l4k04k93k12q4m9k6k7","19588D5k1%nj1nlj6MJ3J7pPOpk7j0",""]
)
