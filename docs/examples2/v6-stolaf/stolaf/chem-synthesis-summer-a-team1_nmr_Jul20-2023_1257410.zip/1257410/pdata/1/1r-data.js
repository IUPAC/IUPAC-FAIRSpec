SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<13C>'; SpecInfo.Data.EXP='<C13CPD32>';SpecInfo.Data.SFO1=100.622829803;
SpecInfo.Data.O1=10061.277;SpecInfo.Data.F2=219.438350248103;SpecInfo.Data.SW=238.896695566946;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=93;
SpecInfo.Data.OFFSET=219.4603;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team1/nmr/Jul20-2023/1257410/pdata/1/intrng, 7/20/2023 1:09:42 PM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team1/nmr/Jul20-2023/1257410/pdata/1/intgap_ole, 7/25/2023 8:02:54 AM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=32768
SpecInfo.Data.nint=6
SpecInfo.Data.realymin=-2362108
SpecInfo.Data.realymax=452187361
SpecInfo.Data.realyave=623614
SpecInfo.Data.realyint=5583319942
SpecInfo.Data.snr=728.895549169839
SpecInfo.Data.nbytes=966
SpecInfo.Data.miny=-5
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=1.37193868331194
SpecInfo.Data.firstnz=8197
SpecInfo.Data.compressionratio=135.6/1
SpecInfo.Data.htratio=2.21147269085214E-06
SpecData=new Array([0,-1,32768,'g:/data/chem-synthesis-summer-a-team1/nmr/Jul20-2023/1257410/pdata/1/1r']
,[1,8196,48,1,"8197bK%UKJlk%KT%lKJT%%jJKTNJ4N1M7m4m6k2oj%kjT%J%jTJJk%jK",""]
,[2,11083,119,2,"11085AJ%kjJjKTjk%TK%JLjlL%lj%J%k%TJ%Jj%K%VjJKJ%TKKTJKOQJ4K3M4J23","11140B33M30L37o84j96n6k3j5qmlkjkTjk%VJJ%jJ%UkjUKJjTMjJjJTk%LKm","11187Ck%Tk%UJj%TJj",""]
,[3,14096,93,1,"14097G%lT%JjK%jk%UJLjTJ%JT%jKTJJKNRJ2K0L2P3K37N63l90l78j03l7j9j2","14139B4plmjTljJ%k%TJk%Tj%VJjTJjK%j%TJ%UKjkjk%KMlj%k%J",""]
,[4,18728,53,3,"18731AJTjlJj%TjKTJ%JKJMRK2O1L7p8l6j3nm%kTK%JjJjUJ%TJJkjTJKj%",""]
,[5,19434,175,2,"19436AJ%k%JjJ%TJkK%JTkj%K%jJ%UjKJT%%JjTKLJKNPJ3J9L9O6N1k7p3m8k5","19485D0j3qmTljK%TJ%jklkJL%j%k%J%JKJjKLKJLMRJ5K7N2O9K1n9o7l8k0j1","19530B0pkTjk%jlJ%TJ%TJk%JLljJ%JUjJLJTNPJ1J8L8O2N7j6p0n5k9j5rlk","19576A1ljUk%jT%KJj%kJ%j%TkJ%TK%TjJUkj",""]
,[6,22473,76,1,"22474Aj%UKjJ%jT%JK%jT%J%JjKJj%LKNLPJ6K9P7K55L0k89p8k7j4pmlkljJ","22520DjT%j%kK%TK%j%jJk%JjJ%UkjKj",""]
)
