SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<1H>'; SpecInfo.Data.EXP='<PROTON>';SpecInfo.Data.SFO1=400.132470802;
SpecInfo.Data.O1=2470.802;SpecInfo.Data.F2=16.1876696570707;SpecInfo.Data.SW=20.0254193236558;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=97;
SpecInfo.Data.OFFSET=16.18777;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team2/nmr/Jul20-2023/1258310/pdata/1/intrng, 7/20/2023 2:05:45 PM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team2/nmr/Jul20-2023/1258310/pdata/1/intgap_ole, 7/20/2023 7:16:13 PM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=65536
SpecInfo.Data.nint=3
SpecInfo.Data.realymin=-89845
SpecInfo.Data.realymax=460588732
SpecInfo.Data.realyave=503864
SpecInfo.Data.realyint=32667799912
SpecInfo.Data.snr=914.291509216773
SpecInfo.Data.nbytes=1217
SpecInfo.Data.miny=0
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=1.0937430676313
SpecInfo.Data.firstnz=26530
SpecInfo.Data.compressionratio=215.4/1
SpecInfo.Data.htratio=2.17113431250854E-06
SpecData=new Array([0,-1,65536,'g:/data/chem-synthesis-summer-a-team2/nmr/Jul20-2023/1258310/pdata/1/1r']
,[1,25884,6000,646,"26530A%S0J%T7j%Xj%Y89J%S2J%UJ%UJ%TJ%TJ%J%Xj%Yj%Tj%Tj%j%Uj%S5J%","27439B%UJ%TJ%UJ%TJ%TJ%J%Yj%Wj%Uj%j%j%j%Uj%X5j%T64J%S57J%V4J%T5J%","28047D%ZJ%YJ%VJ%TJ%TJ%J%J%JUKJKJKJTKJKJKJKJKJKJKJKLTOQRJ1TJ2J1J1","28115A32J1TJ2J1J2UJ1J1J0RPOKkrj3j6Uj5j5j4j3j1qTnnTlnmopTopnTml","28157C6kTjjJTKLUMMTLMUNOTPRQJ0J1J2UJ1RPONOTPPQPTNL%kmqj2j7k2k3k3","28208A51k0j9j6j4j1j0qonmkTjj%j%Tj%jTkklkVjjkjT%jT%j%Tj%Xj%S7j%","28276A%U0j%V80J%V9j%S3J%T5J%S1J%WJ%Z%Sj%Z%Sj%Vj%T3J%VJ%UJ%TJ%%","28959EJ%VJ%Vj%Wj%Tj%Uj%Tj%Tj%T4J%XJ%VJ%Yj%Z%Sj%Uj%Xj%X2J%WJ%TJ%","29128C%J%UJ%TJ%VJj%Tj%jT%j%Tj%Uj%S148J%S47j%T1J%T1J%UJ%UJ%TJ%J","30512F%J%TJ%Yj%Uj%Tj%j%j%Tj%Uj%T2J%VJ%UJ%TJ%J%TJ%S0j%Uj%Tj%j%%","30605Cj%Tj%T4j%T8J%S46J%T0J%WJ%UJ%VJ%Zj%Yj%Wj%S1J%Z%SJ%TJ%UJ%%","30900GJ%J%J%J%UJ%Uj%Yj%Uj%XJ%TJ%TJJWKJKJKJKJKJKVJKXLNOQJ0J1J2J2","30974A20J3J1J2TJ1J3J2TJ3J2J1J0RPNJlrj3j6j7Uj5j5j3j2rqoTmnUopUoo","31015E0nTllkT%%JTLLTMLMWNOPTQQJ0J1UJ2J0RPONOUPPOTNK%kmqj2j6k0k2","31068A68k1k0j7j6j3j2rqpmTlkjT%j%Tj%jTkkWjkjW%j%Tj%Tj%Vj%S5j%T9j%","31164@%T03J%S0J%Z%Sj%Yj%V0J%S2J%Yj%Xj%S62J%V4j%T1J%W1",""]
,[2,0,1,0,"0@",""]
,[3,0,1,0,"0@",""]
)
