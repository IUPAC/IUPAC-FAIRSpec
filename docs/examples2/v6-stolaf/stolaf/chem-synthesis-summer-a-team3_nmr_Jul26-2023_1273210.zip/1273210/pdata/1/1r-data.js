SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<1H>'; SpecInfo.Data.EXP='<PROTON>';SpecInfo.Data.SFO1=400.132470802;
SpecInfo.Data.O1=2470.802;SpecInfo.Data.F2=16.1876696570707;SpecInfo.Data.SW=20.0254193236558;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=95;
SpecInfo.Data.OFFSET=16.18777;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team3/nmr/Jul26-2023/1273210/pdata/1/intrng, 7/27/2023 5:38:55 AM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team3/nmr/Jul26-2023/1273210/pdata/1/intgap_ole, 7/27/2023 9:47:58 AM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=65536
SpecInfo.Data.nint=3
SpecInfo.Data.realymin=-26267
SpecInfo.Data.realymax=301319736
SpecInfo.Data.realyave=1942380
SpecInfo.Data.realyint=127046195729
SpecInfo.Data.snr=155.142661580123
SpecInfo.Data.nbytes=948
SpecInfo.Data.miny=0
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=6.44568031652306
SpecInfo.Data.firstnz=27027
SpecInfo.Data.compressionratio=276.5/1
SpecInfo.Data.htratio=3.31873382498915E-06
SpecData=new Array([0,-1,65536,'g:/data/chem-synthesis-summer-a-team3/nmr/Jul26-2023/1273210/pdata/1/1r']
,[1,26440,4282,587,"27027A%U0j%U2J%U2j%U18Jj%J%S1j%J%S37J%V3J%S1J%WJ%UJ%UJ%JT%JZKJ","27682B0KLKLMUNONONONONMNMTLLJUjklmnmonVmnmXllTkkUjjT%%UJJTKJKL","27747C0KTLLMLNMNOVNONTMLMLKTJ%jTllmoUppUoonTmmTllUkkUjjW%jT%%j","27811D%j%Vj%Z%Sj%W3j%V79J%S55j%S30J%Vj%T2J%Z2%S0J%S6j%S07J%Z2J%","28979C%S8J%ZJ%WJ%UJ%TJ%J%J%JU%JKJTKJKLKLKMLMNMNWONUMMTLLKJT%jk","29065A18kTlmS2llUklkVjkjT%j%J%JTKJKLKLTMLMUNMNMNMNMLMLMKLKJ%Tjj","29133A26kVllUmlmUnmVlmlmlmlTmlTklkVjkjV%j%j%YJ%TJ%J%JT%JUKJUKJ","29204B3J%JU%J%VjjVkkTjkjkjX%j%Tj%Vj%Y0J%S0J%VJ%J%TJJ%JS0KJKJTKJ","29354B8JKJY%%J%Tj%TjjU%jTkjT%jT%j%WJJUKKWLKLTKLTKLKWJJT%%Tjjkj","29425G3kTlklUmlUmlVklkVjjW%j%j%Tj%S1J%TJ%J%JZJSKJKJTKJKJW%J%J%","29505C5%Tj%jT%jkjUkjTkjUkjW%j%j%Tj%J%TJ%J%JU%JS0%J%J%Xj%j%jS2%j","29587A0jV%j%j%j%Tj%Vj%T2j%Y5J%U5j%T8J%U8j%T57J%WjJ%T",""]
,[2,0,1,0,"0@",""]
,[3,0,1,0,"0@",""]
)
