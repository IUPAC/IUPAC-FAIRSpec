SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<13C>'; SpecInfo.Data.EXP='<C13CPD32>';SpecInfo.Data.SFO1=100.622829803;
SpecInfo.Data.O1=10061.277;SpecInfo.Data.F2=219.438350248103;SpecInfo.Data.SW=238.896695566946;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=92;
SpecInfo.Data.OFFSET=219.4603;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-a-team2/nmr/Jun20-2023/1210710/pdata/1/intrng, 6/20/2023 9:51:48 AM'
SpecInfo.Data.using='g:/data/chem-synthesis-a-team2/nmr/Jun20-2023/1210710/pdata/1/intgap_ole, 6/23/2023 3:39:30 PM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=32768
SpecInfo.Data.nint=7
SpecInfo.Data.realymin=-4490698
SpecInfo.Data.realymax=498206672
SpecInfo.Data.realyave=1152290
SpecInfo.Data.realyint=8158811822
SpecInfo.Data.snr=436.259422541201
SpecInfo.Data.nbytes=1135
SpecInfo.Data.miny=-9
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=2.2922141009013
SpecInfo.Data.firstnz=7426
SpecInfo.Data.compressionratio=115.4/1
SpecInfo.Data.htratio=2.0071991328129E-06
SpecData=new Array([0,-1,32768,'g:/data/chem-synthesis-a-team2/nmr/Jun20-2023/1210710/pdata/1/1r']
,[1,7425,41,1,"7426BljKTljJjJUkJLJjMORK0N1M1p4l6j2nlTK%o%KJ%Tj",""]
,[2,9425,46,1,"9426BjJ%J%Tk%jJKjmMJVMQNRJ7J6%j3j5j2pTnkl%MJlmjTKj%k",""]
,[3,11493,83,1,"11494aK%kj%L%jT%jL%KJTK%J0K9J02Pj00l6rmkjK%lKjJT%mkJTljLjlJjKK","11543@M%kjKJTjJkUNK%jV%l%JTKlJTjmJ%",""]
,[4,12123,110,1,"12124EnlLNJjTkk%NjmO%lJ%jnJU%KJ%ljKL%K%kJKjKjMRPJ1J7K9O1J89M90J75","12174A000o35k13o8k3k0j3plmT%%l%lj%NklKm%kjTLN%k%Llm%LK%KJ%ljTKj","12220Ck%J%JTjlKjKj",""]
,[5,13118,69,1,"13119A%KJ%k%j%TkJlKNKLJlm%J%TjMLT%KNOTJ6K3L5Q9K93M08n9n53j57n3k4","13162E0j8rqkJmKlklk%jJjMKjnkKJkL",""]
,[6,19434,178,1,"19435CkjkJKMkKJ%klJV%Jj%TJj%TJ%jKTljUKNJj%J%MNMTQJ0J3K6N0R5J19M6","19488C95j04j32p0l4j8rnmo%Kk%jT%JmkT%KJ%WJLJLTMMNPJ1K0L3O8J13J07j7","19532C73j34j12n3k6j7pomlTLjlTj%jLjT%JUKLT%mJKJJ1MNTPJ1K5M3Q5J16O9","19575C95p4j37q6m4k1j1njTpk%Km%jJT%jk%TkJTKlkl%LJ%TK",""]
,[7,22748,130,1,"22749dMjT%KTjjK%TkKMkjLkjJjJjljlLT%mLKTkljmMjN%l%K%kjTN%lJlJ%J","22805@J%JjJ%JjJjLkJ%kmjJOKjTlJk%TJJjJNj%TjJTLlKjTLNQJ3K7O8O9O6R3","22857C59j19j65m3j6npkjTkK%jklKP%jJ",""]
)
