SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<1H>'; SpecInfo.Data.EXP='<PROTON>';SpecInfo.Data.SFO1=400.132470802;
SpecInfo.Data.O1=2470.802;SpecInfo.Data.F2=16.1876696570707;SpecInfo.Data.SW=20.0254193236558;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=95;
SpecInfo.Data.OFFSET=16.18777;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team3/nmr/Jul25-2023/1265510/pdata/1/intrng, 7/25/2023 12:32:51 PM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team3/nmr/Jul25-2023/1265510/pdata/1/intgap_ole, 7/25/2023 7:20:43 PM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=65536
SpecInfo.Data.nint=3
SpecInfo.Data.realymin=-24975
SpecInfo.Data.realymax=379740091
SpecInfo.Data.realyave=1919955
SpecInfo.Data.realyint=125576561304
SpecInfo.Data.snr=197.798941121016
SpecInfo.Data.nbytes=908
SpecInfo.Data.miny=0
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=5.05563879327437
SpecInfo.Data.firstnz=27027
SpecInfo.Data.compressionratio=288.7/1
SpecInfo.Data.htratio=2.63338010312954E-06
SpecData=new Array([0,-1,65536,'g:/data/chem-synthesis-summer-a-team3/nmr/Jul25-2023/1265510/pdata/1/1r']
,[1,26298,4360,729,"27027A%Wj%YJ%S1j%V2J%T1j%U29J%S58J%U7J%S2J%XJ%UJ%TJ%JT%JVKJUKJ","27686B1KULLMNOPTQQTPPOMK%lmnpopToomTllTklYkkTjjT%j%VJ%JUKJKLKL","27750B8LUMLUMLMNTOOPUONMK%knpqj0UrqponmlkUjkjkjkjX%j%j%Tj%Vj%%","27815B%Xj%W3j%V89J%S38j%S90J%T12J%Y2J%S9J%Z%SJ%WJ%UJ%TJ%J%JT%J","29032A2JUKJKJKULLTMMNTOOXMMKJTjjlmnmnWmlmlkWjkjkTjkUjkjU%%J%JK","29101B4JKWLKLVMMUNMNMVLKTJ%TjkTllmlTkklklmlmlklTklTklWklkUjkjj","29168A0jU%j%Tj%S0J%TJ%TJ%J%J%J%JT%KJTKKUJK%J%kjklTklkTjjV%j%Wj%","29238B%T4j%YJj%TJ%jJ%V3J%ZJ%UJ%TJ%JT%JS0KJUKJW%JT%%Vj%jZjSkjT%j","29386A7%j%J%JT%KJTKJKTJLKTLKLKLKLKJKJ%J%Tjj%kjTkklklXmklTkkTjk","29445IjT%j%j%Tj%Vj%S5J%UJ%JT%JTKJUKJKJZJS%%J%Uj%jYkjYkj%jU%j%%","29534Ej%WJ%J%J%JX%JV%JT%J%J%Wj%jV%jX%jV%jT%j%Tj%Uj%T3j%Z7J%T1j%","29734@%V1J%T3",""]
,[2,0,1,0,"0A",""]
,[3,0,1,0,"0A",""]
)
