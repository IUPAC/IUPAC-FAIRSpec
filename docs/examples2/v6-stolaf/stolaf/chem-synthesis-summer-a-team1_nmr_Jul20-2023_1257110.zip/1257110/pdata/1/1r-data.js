SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<1H>'; SpecInfo.Data.EXP='<PROTON>';SpecInfo.Data.SFO1=400.132470802;
SpecInfo.Data.O1=2470.802;SpecInfo.Data.F2=16.1876696570707;SpecInfo.Data.SW=20.0254193236558;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=95;
SpecInfo.Data.OFFSET=16.18777;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team1/nmr/Jul20-2023/1257110/pdata/1/intrng, 7/20/2023 12:49:04 PM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team1/nmr/Jul20-2023/1257110/pdata/1/intgap_ole, 7/23/2023 9:58:51 PM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=65536
SpecInfo.Data.nint=2
SpecInfo.Data.realymin=-96544
SpecInfo.Data.realymax=528772014
SpecInfo.Data.realyave=773728
SpecInfo.Data.realyint=49789028442
SpecInfo.Data.snr=683.532918545018
SpecInfo.Data.nbytes=235
SpecInfo.Data.miny=0
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=1.46298733077643
SpecInfo.Data.firstnz=29089
SpecInfo.Data.compressionratio=1115.5/1
SpecInfo.Data.htratio=1.89117421785488E-06
SpecData=new Array([0,-1,65536,'g:/data/chem-synthesis-summer-a-team1/nmr/Jul20-2023/1257110/pdata/1/1r']
,[1,28707,1275,382,"29089A%T0J%WJ%TJ%JTKKLMUNOUNMUKKJTjklmoTnmnmUllkljkjV%j%Tj%Wj%","29174B%S0j%Y1",""]
,[2,0,1,0,"0@",""]
)
