SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<13C>'; SpecInfo.Data.EXP='<C13CPD32>';SpecInfo.Data.SFO1=100.622829803;
SpecInfo.Data.O1=10061.277;SpecInfo.Data.F2=219.438350248103;SpecInfo.Data.SW=238.896695566946;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=93;
SpecInfo.Data.OFFSET=219.4603;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team3/nmr/Jul20-2023/1257910/pdata/1/intrng, 7/20/2023 1:34:51 PM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team3/nmr/Jul20-2023/1257910/pdata/1/intgap_ole, 7/22/2023 12:18:02 AM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=32768
SpecInfo.Data.nint=6
SpecInfo.Data.realymin=-2436750
SpecInfo.Data.realymax=480502597
SpecInfo.Data.realyave=620005
SpecInfo.Data.realyint=5580756582
SpecInfo.Data.snr=778.928148966541
SpecInfo.Data.nbytes=1059
SpecInfo.Data.miny=-5
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=1.28381546016378
SpecInfo.Data.firstnz=8201
SpecInfo.Data.compressionratio=123.7/1
SpecInfo.Data.htratio=2.08115420445896E-06
SpecData=new Array([0,-1,32768,'g:/data/chem-synthesis-summer-a-team3/nmr/Jul20-2023/1257910/pdata/1/1r']
,[1,8200,44,1,"8201Aj%UkKJTj%j%TKK%KLKQK9O8l1m1k7rnj%TkkJ%KkJ%Tj",""]
,[2,11021,179,1,"11022bJU%%UjJUk%J%Jj%TjjJj%TjJkJ%J%JjTJjJKkK%Tjj%kJ%TjJUjJ%Uj%","11083@%jKJT%j%UJjT%jJ%LTlJTm%J%klK%JUk%J%jJLjJUK%TLLKLONJ5K2L3R5","11140A96L25M79o75k12n7j9j4pnlTjJj%j%jlJVjjT%Jj%j%JU%kJT%JLkT%M","11186Fmkj%J%jkjTKKT",""]
,[3,14074,87,1,"14075AJ%j%j%TJj%JTjK%UjJjLTmjT%j%Tj%KjJ%jJjJ%Lj%J%KJKLMONJ1K2L3","14130I4P5K41N01m55l01p8l0j7j0oml%JkT%jk%JjJTjkK%U",""]
,[4,18731,80,1,"18732A%Tj%J%TJ%jkKVLRK3N6L0q0l0j0kTj%UKkT%%jK%Jjkj%TKJ%kjTKJ%%","18785AjJjJUk%TJj%j%JjJ%j%j%J%j",""]
,[5,19443,169,2,"19445aJ%TJjJTjj%TJJ%Jj%TJj%J%LJ%JMUOJ1K1M1O2L2m0o4l8j8j1pmjVlJ","19494EJK%l%Jk%TjK%k%TKK%kKVNOQJ4K8N2N9Mo3n7k9j3j0mTklKJjljJ%Jj","19543Cj%J%J%UjJ%UKKTJMTOJ1J9L9O2M0l2o6m4k1j1nmTjjJjkTj%KJjUK%j","19592C%TJ%jTk%TJ%J%k%TJJ%",""]
,[6,22476,94,1,"22477A%J%j%jJjUK%K%Jj%J%TJ%JLTOQJ7L5J06K80j80j81m9k1j2omjWkjkJ","22524A%JTj%Tj%jJ%TkJT%jKkjJT%%jK%J%Ukj%j%Jj%jKJ%TJ",""]
)
