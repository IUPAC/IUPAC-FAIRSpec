SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<1H>'; SpecInfo.Data.EXP='<PROTON>';SpecInfo.Data.SFO1=400.132470802;
SpecInfo.Data.O1=2470.802;SpecInfo.Data.F2=16.1876696570707;SpecInfo.Data.SW=20.0254193236558;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=95;
SpecInfo.Data.OFFSET=16.18777;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team3/nmr/Jul25-2023/1268810/pdata/1/intrng, 7/25/2023 11:31:38 PM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team3/nmr/Jul25-2023/1268810/pdata/1/intgap_ole, 7/26/2023 8:32:24 PM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=65536
SpecInfo.Data.nint=3
SpecInfo.Data.realymin=-21736
SpecInfo.Data.realymax=361367655
SpecInfo.Data.realyave=1659746
SpecInfo.Data.realyint=108546515151
SpecInfo.Data.snr=217.737768911629
SpecInfo.Data.nbytes=850
SpecInfo.Data.miny=0
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=4.59268047522734
SpecInfo.Data.firstnz=27047
SpecInfo.Data.compressionratio=308.4/1
SpecInfo.Data.htratio=2.76726482341094E-06
SpecData=new Array([0,-1,65536,'g:/data/chem-synthesis-summer-a-team3/nmr/Jul25-2023/1268810/pdata/1/1r']
,[1,26488,4145,559,"27047A%Uj%V6J%S4j%V13J%S11J%S8J%ZJ%UJ%TJ%J%JWKJTKJKJKTLMNTPQTRR","27700H4RQNLJkmoTqpTonmlkTlklUmlmklkTjjT%j%YJJUKKULMLTMLTKLUMNO","27764G1PTQQTOMKklprj0j1j0rqpomTkkVjkVjjk%jU%%j%Tj%Tj%Wj%W0j%W03J%","28373A%S15j%T58J%T23J%T8J%S0J%WJ%VJ%J%J%JYKJKTJLKMLMNTOOUPPNLL","29056I8LK%jlUnmnUmmlmlkXjkjkYjk%j%TJJVKJKULKLKLTMLMTNMNMVLL%Tj%","29128I7jkTlkljkj%jklmUlmlklklYklkUjjkjT%j%j%Tj%S1J%TJ%JT%JT%J%","29198A1J%JUKJKVJJ%jklklklkjTk%jT%j%Tj%S1j%Y0J%S4J%UJ%TJ%JT%JS2KJ","29354B2JY%%J%Uj%j%jXkjTkjT%j%VJ%JUKJUKKVLKLVKLKJKJT%%Tj%jUkkVll","29431D1mlYkkjkjT%jT%j%Uj%Yj%Z%SJ%WJ%J%JXKJTKJUKJ%JU%J%XjjZkjS0%j","29530E%j%Z%SJ%J%JU%JX%JT%J%J%J%Vj%jT%jV%jV%jV%j%j%j%Vj%S4j%Z9%S0J%","29714A%S1",""]
,[2,0,1,0,"0@",""]
,[3,0,1,0,"0@",""]
)
