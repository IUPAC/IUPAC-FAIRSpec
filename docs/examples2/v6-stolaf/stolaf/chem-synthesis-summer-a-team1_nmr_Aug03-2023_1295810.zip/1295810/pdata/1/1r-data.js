SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<1H>'; SpecInfo.Data.EXP='<PROTON>';SpecInfo.Data.SFO1=400.132470802;
SpecInfo.Data.O1=2470.802;SpecInfo.Data.F2=16.1876696570707;SpecInfo.Data.SW=20.0254193236558;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=95;
SpecInfo.Data.OFFSET=16.18777;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team1/nmr/Aug03-2023/1295810/pdata/1/intrng, 8/3/2023 12:31:58 PM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team1/nmr/Aug03-2023/1295810/pdata/1/intgap_ole, 8/8/2023 8:37:52 AM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=65536
SpecInfo.Data.nint=3
SpecInfo.Data.realymin=-84118
SpecInfo.Data.realymax=408637811
SpecInfo.Data.realyave=1040399
SpecInfo.Data.realyint=67420512654
SpecInfo.Data.snr=392.851135958416
SpecInfo.Data.nbytes=355
SpecInfo.Data.miny=0
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=2.54549346678191
SpecInfo.Data.firstnz=28249
SpecInfo.Data.compressionratio=738.4/1
SpecInfo.Data.htratio=2.4471548473521E-06
SpecData=new Array([0,-1,65536,'g:/data/chem-synthesis-summer-a-team1/nmr/Aug03-2023/1295810/pdata/1/1r']
,[1,28243,1627,6,"28249A%S2j%T6J%T8j%U23J%U5j%T0J%S9J%Uj%S6j%S04J%WJ%TJ%Wj%Wj%Zj%","28876@%T2J%T6j%T8J%U6j%T3J%U5j%U0J%U1J%VJ%TJ%JUKKLMXKJ%jklklkl","29146B5lTklkjkjU%j%j%Tj%Vj%S0j%X9J%T3j%X4j%T1J%U8",""]
,[2,0,1,0,"0@",""]
,[3,0,1,0,"0@",""]
)
