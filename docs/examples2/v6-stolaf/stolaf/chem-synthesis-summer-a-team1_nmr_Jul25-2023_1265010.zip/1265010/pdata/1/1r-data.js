SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<13C>'; SpecInfo.Data.EXP='<C13CPD32>';SpecInfo.Data.SFO1=100.622829803;
SpecInfo.Data.O1=10061.277;SpecInfo.Data.F2=219.438350248103;SpecInfo.Data.SW=238.896695566946;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=92;
SpecInfo.Data.OFFSET=219.4603;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team1/nmr/Jul25-2023/1265010/pdata/1/intrng, 7/25/2023 12:12:52 PM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team1/nmr/Jul25-2023/1265010/pdata/1/intgap_ole, 7/27/2023 9:48:16 AM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=32768
SpecInfo.Data.nint=11
SpecInfo.Data.realymin=-4516866
SpecInfo.Data.realymax=333342263
SpecInfo.Data.realyave=1206354
SpecInfo.Data.realyint=10424918246
SpecInfo.Data.snr=280.066322986453
SpecInfo.Data.nbytes=1603
SpecInfo.Data.miny=-14
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=3.57058281530111
SpecInfo.Data.firstnz=19470
SpecInfo.Data.compressionratio=81.7/1
SpecInfo.Data.htratio=2.99991963515289E-06
SpecData=new Array([0,-1,32768,'g:/data/chem-synthesis-summer-a-team1/nmr/Jul25-2023/1265010/pdata/1/1r']
,[1,19469,151,1,"19470DmjN%JlKJTmJlMJ%OLJ0P%PJ0J7K9M5Q4J51J59K5j62j74r2m3k6j8j0j","19507C2qonTPMNTqmlNjnTP%KjTJLKLMlMJ4J2K2L3N9J15J69J28p6j94j43o6","19546A02l6j5j0rkqjlTnkLKTnjNj%LTm%jJKjmOJ1NJ1RJ3K1L8Q7J43J60L9j57","19587C98j70r8n5k5j3onkopmKLloJjLjqKNKjKmlLkJ%j",""]
,[2,25126,88,1,"25127CjkJjklO%JjJKTJ%jJLJ0K4Q2L5j14l2rmLjJkJlkjTMk%jT%LKlTPLmp","25176eL%KN%l%jLlJTnJNKj%jTP%ln%kl%jJTKJ%nJK",""]
,[3,25294,91,1,"25295fKJKMl%Lk%k%MJTj%jK%JTkjTkjLKmjKkJjNTomkMNkJjLOJ4K6R2K12k38","25346A20q1k0r%pLk%TJLmJLTJ0K9N5j8n9j7kmjl%J%m%KLkKkjL%",""]
,[4,25729,66,1,"25730BnlKPKkNnmJlOLJTmJM%TnLJLlKPlQJ2TK5M9J13L45M22j32n96j58n1k1","25771D2rj0pjkmoM%nLNjo%klMKJjkK",""]
,[5,26052,83,1,"26053ajJ%UjKJKlKLJML%r%kjTnJNLMJpoM%KUmLkJnJmNjLlJLjJjTkNTQPJ0K5","26111F0O6K11K7k58o4j9qnTmmP%kLmjK%jknk",""]
,[6,26615,43,1,"26616cOMkq%MTlkK%KOJ2TL7J37P8j99m9j7j0j%ljljkMKJn%KkqL%NM",""]
,[7,26957,79,1,"26958AJ%kTKLlLkTLRJ%onJTRPqlMTKN%NPJ4K1L2R3K96L43J63o43k20o5k2n","26999D2qjJ0L8M7K9r6l4poTnlJLUNJpnjkjlKTLjkKJmjlj",""]
,[8,27206,108,1,"27207AkJT%KlkjJjMOmKQRTNJ2j5j9pl%ljTKmkJPMjm%TklLjL%l%kJLJ%l%K","27260AKMNKRJ6N3O7o9o0j5qpJK%kL%JTmljMKl%PmkKMNJ4J9K2m1k4k%jJjn","27305enJL%M%jK",""]
,[9,27513,45,1,"27514CKmkLljJLljkPJMOPJ8N9Q6j0j14l7j1o%MLlpklUJKLMKJkmlk",""]
,[10,28123,82,1,"28124C%UjljKjJT%MTlKTRJ7J4J6lm0rlkTlLKTLJ1K4M8Nm8k0LJ0K6Mj2J1L4","28168A10J01K11J53K12Q2n44j94o1k2j5ormonMLJjTmjnKJ%J%NTlo%KPm",""]
,[11,28518,47,1,"28519fJTjjmPN%k%kOTJNTJ0J8O4O5TO6j63r2k7j2loJkJqMJkTjO%m%Mm%N",""]
)
