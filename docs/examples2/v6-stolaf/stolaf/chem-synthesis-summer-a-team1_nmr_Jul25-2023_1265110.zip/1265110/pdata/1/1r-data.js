SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<1H>'; SpecInfo.Data.EXP='<PROTON>';SpecInfo.Data.SFO1=400.132470802;
SpecInfo.Data.O1=2470.802;SpecInfo.Data.F2=16.1876696570707;SpecInfo.Data.SW=20.0254193236558;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=95;
SpecInfo.Data.OFFSET=16.18777;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team1/nmr/Jul25-2023/1265110/pdata/1/intrng, 7/25/2023 12:14:58 PM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team1/nmr/Jul25-2023/1265110/pdata/1/intgap_ole, 7/27/2023 9:49:08 AM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=65536
SpecInfo.Data.nint=3
SpecInfo.Data.realymin=-62330
SpecInfo.Data.realymax=464639807
SpecInfo.Data.realyave=1833163
SpecInfo.Data.realyint=119849630741
SpecInfo.Data.snr=253.497445126265
SpecInfo.Data.nbytes=170
SpecInfo.Data.miny=0
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=3.94481293293472
SpecInfo.Data.firstnz=-1
SpecInfo.Data.compressionratio=1542/1
SpecInfo.Data.htratio=2.1522047507221E-06
SpecData=new Array([0,-1,65536,'g:/data/chem-synthesis-summer-a-team1/nmr/Jul25-2023/1265110/pdata/1/1r']
,[1,0,1,0,"0@",""]
,[2,0,1,0,"0@",""]
,[3,0,1,0,"0@",""]
)
