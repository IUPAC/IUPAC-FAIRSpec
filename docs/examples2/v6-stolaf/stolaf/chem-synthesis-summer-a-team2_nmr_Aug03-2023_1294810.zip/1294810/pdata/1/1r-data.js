SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<1H>'; SpecInfo.Data.EXP='<PROTON>';SpecInfo.Data.SFO1=400.132470802;
SpecInfo.Data.O1=2470.802;SpecInfo.Data.F2=16.1876696570707;SpecInfo.Data.SW=20.0254193236558;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=95;
SpecInfo.Data.OFFSET=16.18777;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team2/nmr/Aug03-2023/1294810/pdata/1/intrng, 8/3/2023 10:19:55 AM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team2/nmr/Aug03-2023/1294810/pdata/1/intgap_ole, 8/8/2023 8:35:49 AM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=65536
SpecInfo.Data.nint=3
SpecInfo.Data.realymin=-81851
SpecInfo.Data.realymax=464781217
SpecInfo.Data.realyave=978201
SpecInfo.Data.realyint=63403424177
SpecInfo.Data.snr=475.222442013451
SpecInfo.Data.nbytes=1876
SpecInfo.Data.miny=0
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=2.10427772679072
SpecInfo.Data.firstnz=26370
SpecInfo.Data.compressionratio=139.7/1
SpecInfo.Data.htratio=2.15154994096932E-06
SpecData=new Array([0,-1,65536,'g:/data/chem-synthesis-summer-a-team2/nmr/Aug03-2023/1294810/pdata/1/1r']
,[1,25470,6914,900,"26370Aj%T6J%S9j%V7J%S5j%Y8J%Tj%VJ%Tj%J%Wj%Jj%VJ%S0j%J%U0J%Vj%%","26639A%U26J%S8j%U3J%U9j%S16J%S5j%WJ%T6j%U6J%T7j%Y8J%U7j%T3J%V2j%","27475A%TJ%ZjJ%V4J%ZJ%T0j%S2j%UJ%S4J%Z%SJ%T0j%Xj%U5J%S5j%V5JjJ%","27734D%Tj%V9J%S4j%UJj%ZJj%X5J%Z9J%Z7J%S3J%VJ%VJ%S5J%U1J%XJ%TJ%","28144A3%J%J%TJ%J%J%JT%JXK%JT%J%J%J%TJJUKJKJUKJU%JU%%j%J%Tj%j%j","28207E0jU%jW%j%j%TJJTKKULLKLTMMNOTPQTRJ1J0J2J0QONMLJTj%kV%%Zkm","28271A78opUopToononmTkkTj%TJKULLMTNNMLMNOPOVQPOK%JTKJ%jT%%jmop","28329A80oTnqTj1j1Vj0rpnlTjjT%%VJJX%%jJ%VJKMTPRJ1J3J5J7J8K0K1J7J1","28383B29POML%oqj2Tj3j3j4j2j1qoUpnUonoTpoTnnmlkjk%j%UJJKTLLNMON","28434F7POTNMNMNOTPQJ0J2J3UJ5J6TJ3Ojlmprj3j6j9Vj8j6j4j0qnmlTkkk","28479D7kXlkTlkUjkj%jT%j%j%j%Tj%Vj%Z%Sj%V3J%W3J%XJ%WJ%S3j%T1J%%","28671A1%UJ%UJ%UJ%WJ%VJ%VJ%Zj%Zj%UJ%WJ%J%J%JW%JU%J%Yj%j%Tj%VJ%%","28763B6JT%JT%JT%JT%JUKJKJKTLKLMLWKKUJKZKSLLVKKJU%jkVllVkkTlkTjj","28836H4%XJJKTLMTOOPRTJ1J1J2J4J3J2J1J0J1TRPLT%knopqUrj1Vj0rTqop","28887A30nomTljUJJLMTOOQUPPQPOPOQTRRTJ0J1J2J3J4J2PNJjnoj0j1j4j5j6","28934B52j6Tj5j5j3j2rpoTnopVooUnmUklj%TJKVJJV%%TjjTlklkTlklklUkl","28993B6kTjkjU%j%j%ZJJ%JT%JT%%TJ%S6j%j%j%jT%j%Tj%j%Tj%Tj%Uj%S8j%","29085I%S8J%VJ%UJ%TJ%TJ%JUKLMTNNOPTQQNJT%%jkmnpopToonmkVjjV%j%j","29164H%Tj%Wj%S1j%W4j%S19J%V9j%XJ%U6j%S5J%T5J%S0j%S1j%TJ%S9j%W1j%","29595C%J%Uj%VJ%U4j%S3J%W0j%S0J%V6j%S89J%Wj%V5J%S5J%Wj%U5j%TJ%%","30069D%S2J%VJ%S8j%S1j%T4J%WJ%VJ%S4j%Uj%S5j%S6J%ZJ%YJ%S2J%T0j%%","30259G%WJ%S0J%VJ%UJ%J%J%JVKJKVLKLKTJKJKJTKKTMNPRJ1J4J5J7J9K1TK0J6","30327B33J1QOMJlpj0j2j3j5j4Tj3j1qpUooTnoTpopoTnnmlTkjU%%TJJKTLL","30375D2MNTOOPNUMNTOPTRJ0J1J2TJ3J4TJ3RMjlnpj0j3j6j7j8j7j8j6j4j2r","30416F9pomlkS1lkWjjW%j%j%j%Uj%Wj%S2j%W6j%TJ%j%U36jJ%S06J%T7j%%","31009A%U7J%Wj%Y1jJ%S0j%TJ%S5j%S0Jj%S74J%S1j%S15J%T2j%V7J%S5",""]
,[2,0,1,0,"0@",""]
,[3,0,1,0,"0@",""]
)
