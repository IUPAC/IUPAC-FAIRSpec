SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<1H>'; SpecInfo.Data.EXP='<PROTON>';SpecInfo.Data.SFO1=400.132470802;
SpecInfo.Data.O1=2470.802;SpecInfo.Data.F2=16.1876696570707;SpecInfo.Data.SW=20.0254193236558;
SpecInfo.Data.INTSCL=1.16291274822331E-04;
SpecInfo.Data.NC_procplus100=96;
SpecInfo.Data.OFFSET=16.18777;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-a-team5/nmr/Jun27-2023/1226610/pdata/1/intrng, 6/27/2023 12:13:40 PM'
SpecInfo.Data.using='g:/data/chem-synthesis-a-team5/nmr/Jun27-2023/1226610/pdata/1/intgap_ole, 6/27/2023 12:13:40 PM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=65536
SpecInfo.Data.nint=4
SpecInfo.Data.realymin=-7072
SpecInfo.Data.realymax=443702681
SpecInfo.Data.realyave=681906
SpecInfo.Data.realyint=44610790211
SpecInfo.Data.snr=650.690495464184
SpecInfo.Data.nbytes=884
SpecInfo.Data.miny=0
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=1.53682896395563
SpecInfo.Data.firstnz=21118
SpecInfo.Data.compressionratio=296.5/1
SpecInfo.Data.htratio=2.2537614551849E-06
SpecData=new Array([0,-1,65536,'g:/data/chem-synthesis-a-team5/nmr/Jun27-2023/1226610/pdata/1/1r']
,[1,21117,356,1,"21118A%U8J%V7J%S2J%S5J%T5J%ZJ%WJ%UJ%TJ%TJ%JT%JUKKUMMNPTRJ0J2J3J3","21306A08J2TJ0PNKJ%UKMNQRUQOKjnqj0j3j2j3j1j0qomTlkmlnoUpopnonmn","21355C4mlmlklkTjjV%j%j%Vj%Yj%V7j%T5",""]
,[2,27556,539,1,"27557A%Z3J%X5J%U4J%T2J%S6J%Z%SJ%ZJ%WJ%VJ%TJ%TJ%J%J%JT%JTKJTKJJ","27834B6JT%JUKKTLMNTOPTRRUPNLJT%j%JTLNOQRTQOLJlnpqUponlkjT%JjTlm","27893A14noTnnUllTjk%VJJ%TJ%TKJLMNPTRJ0URPNJjlVj%KMNTPONLJknorr","27952A51j0rqpomTlkjUkklnYmmUllTkkTjkjZ%jT%j%j%j%Tj%Uj%Wj%S1j%%","28030B%T2j%V1",""]
,[3,30979,516,1,"30980A%Z0J%X4J%U5J%T2J%S6J%Z%SJ%ZJ%WJ%UJ%TJ%TJ%JT%JXKJZKKLTMMO","31263E4OQTRRTQPOLKJ%jT%JKLMOPVNLKjlmnpoUnmTlkTjkjTkkTlmXlklkjj","31325G4%TjJ%TJ%KTLLNTPPQPQONLJ%kW%%KLMNMNLKJjmTppWnnmlTkkjVkll","31388G9mTnnTmmVllTkkUjkjX%j%jT%j%Tj%Tj%Vj%Z%Sj%T2j%U0",""]
,[4,0,1,0,"0@",""]
)
