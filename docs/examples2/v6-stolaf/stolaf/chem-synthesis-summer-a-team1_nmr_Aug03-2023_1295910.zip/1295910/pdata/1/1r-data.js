SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<13C>'; SpecInfo.Data.EXP='<C13CPD32>';SpecInfo.Data.SFO1=100.622829803;
SpecInfo.Data.O1=10061.277;SpecInfo.Data.F2=219.438350248103;SpecInfo.Data.SW=238.896695566946;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=92;
SpecInfo.Data.OFFSET=219.4603;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team1/nmr/Aug03-2023/1295910/pdata/1/intrng, 8/3/2023 12:39:50 PM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team1/nmr/Aug03-2023/1295910/pdata/1/intgap_ole, 8/4/2023 11:05:14 AM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=32768
SpecInfo.Data.nint=7
SpecInfo.Data.realymin=-5110896
SpecInfo.Data.realymax=294765621
SpecInfo.Data.realyave=1186775
SpecInfo.Data.realyint=9527112943
SpecInfo.Data.snr=252.681862189547
SpecInfo.Data.nbytes=1466
SpecInfo.Data.miny=-17
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=3.95754563202426
SpecInfo.Data.firstnz=6454
SpecInfo.Data.compressionratio=89.4/1
SpecInfo.Data.htratio=3.39252588754236E-06
SpecData=new Array([0,-1,32768,'g:/data/chem-synthesis-summer-a-team1/nmr/Aug03-2023/1295910/pdata/1/1r']
,[1,6453,42,1,"6454AlkMJM%oM%KrMLJNQJ%kLJ0J8L4M6K2o3o1j7oKnpk%M%jLjJ",""]
,[2,12481,114,1,"12482DjrjOLNkjkKMmlRjm%LjTKmjJMJjoMkTJLkljJTjJKmjLU%%lLmpL%kNj","12539BPj%jmkK%TJjJ0LlkKk%KLMQLJ%PJ3J4L0O0J43K59l1l39j11l8j5TJm","12579F%lLlTjJQmjJKlnT",""]
,[3,19435,198,1,"19436almQK%jJ%Lk%jKjLKJmLmLKn%PJlmLJMNJ%kNMjMOPTJ0J5J4K6M5P2J20K08","19486E59K83J52j85l12k10j03n8l2j9j7j0nmq%kPLpT%jkLTKKJqjPMPMNJ0P","19523F8K0TK5M9Q7J65K64K74Mk97k82j62q3m5k6k2qrmNnpmJoLnoMNj%JLk","19558B4ONM%KQJ1QTJ5K7M3O4J13J93K81J88j40l11k28j23p2l5k6j7pmojn","19588B5oKJm%koJjK%LnlLj%JnJLjN%jokJ%jLmTjL%jMjmJKJj",""]
,[4,21634,67,1,"21635aLkT%%jMK%NmkKMjmLM%jTJOTRK7N4R5J32R9m9j92j04l4k1j2opQMjL","21677B6K%kjrl%mLnmLJTlLkmMTlqL",""]
,[5,24474,86,1,"24475EjlnMJ%TOlMmlKMTNOPK4M8J02K60K81m16j85o7k7qj2nkJmonKjkOlq","24516BLJkTKPj%TMqkJmjOlTjMTJoLNLj%kKj0mLJ1qjljJkKLj",""]
,[6,26398,227,1,"26399FjJ%l%KMlmkJO%lKjJL%lT%%JnNk%OMKMjKrpkpLKmJ%kLQLKPJlklTkj","26455D%lJ%MpJkTOM%KkL%mn%TJJpjLk%LKLkjJKNKUplLnmJLTjlTk%jJ%OJJ","26512DmOKNkjJMJQKkpJjJlmnjTok%jNTjJT%mKmlOK%MJNLJploKmjKojOjL%","26568CKjTrJKOKLKTlmjKjK%lTNMlUjk%JPJjKkTNnNJjJkpljKTJ%jlJlTK",""]
,[7,28151,163,1,"28152CLmqJKLkjTmLQRM%TmjQRJ2L2N9J42K22O8k36j72o7k9j8qlnqnLJTlK","28193A6LnqLlkJn%POmJ%ljJnTOK%KLjq%LlMjTkkjkOMj%lJlokNJUMJMJjll","28249CkT%LJjU%MnJLmlKjLlO%lkJlmkLTJNKl%VpKNKNmkJKPKolkj%joNLJl","28308AJKJnK",""]
)
