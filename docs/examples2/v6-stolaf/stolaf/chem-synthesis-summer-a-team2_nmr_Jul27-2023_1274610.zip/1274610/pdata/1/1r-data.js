SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<1H>'; SpecInfo.Data.EXP='<PROTON>';SpecInfo.Data.SFO1=400.132470802;
SpecInfo.Data.O1=2470.802;SpecInfo.Data.F2=16.1876696570707;SpecInfo.Data.SW=20.0254193236558;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=96;
SpecInfo.Data.OFFSET=16.18777;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team2/nmr/Jul27-2023/1274610/pdata/1/intrng, 7/27/2023 12:29:21 PM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team2/nmr/Jul27-2023/1274610/pdata/1/intgap_ole, 7/27/2023 8:36:58 PM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=65536
SpecInfo.Data.nint=2
SpecInfo.Data.realymin=-54885
SpecInfo.Data.realymax=310843827
SpecInfo.Data.realyave=875824
SpecInfo.Data.realyint=56863825121
SpecInfo.Data.snr=354.978525365827
SpecInfo.Data.nbytes=726
SpecInfo.Data.miny=0
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=2.81707181855421
SpecInfo.Data.firstnz=28563
SpecInfo.Data.compressionratio=361/1
SpecInfo.Data.htratio=3.2170495700402E-06
SpecData=new Array([0,-1,65536,'g:/data/chem-synthesis-summer-a-team2/nmr/Jul27-2023/1274610/pdata/1/1r']
,[1,28146,4535,417,"28563A%S0j%S96J%T0j%T0J%S8J%T7j%Z0j%S4J%S25J%S3J%YJ%WJ%VJ%WJ%J","29123H%JTKKVLLKMLMLTKKT%%kWlkYjkVjjW%%S0J%TJ%JVKKULMLMNMNONVMK","29206H3LJTj%kTlmnTonoTnnmTllkTjjU%j%S1J%JTKJKLKLTMLNMTNMLUKJ%%","29271G0jkTllmTnnmVllkUjkjT%j%j%Uj%Xj%S0j%U5J%S4J%Z%SJ%VJ%TJ%J%","29391IJXKJKTLKLKLUMLUMLTMLKLTKKJV%jVkklTkmlmTlmlmTlklkUj%j%J%J","29458B4JKVMLMNUOPTQPRQRTQRQPQONMLTK%jlTmmnpTqrqUrrTqpUonUmlUkk","29520B3kTjjW%j%j%Vj%WJ%TJ%JVKJKLKLUMLMTLMTLLUKKTJJ%J%jUkkTllTml","29589E7lmlXklkVjjU%%UJJVKKVLKLKLKXJKJT%J%TjjkjkTlklklkTlklkXjk","29664A2jW%j%Tj%Uj%Yj%T1j%Y0j%U5J%Vj%U11J%S4j%S93",""]
,[2,0,1,0,"0@",""]
)
