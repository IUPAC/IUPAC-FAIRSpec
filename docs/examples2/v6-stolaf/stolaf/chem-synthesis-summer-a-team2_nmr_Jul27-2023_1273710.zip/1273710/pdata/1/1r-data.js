SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<1H>'; SpecInfo.Data.EXP='<PROTON>';SpecInfo.Data.SFO1=400.132470802;
SpecInfo.Data.O1=2470.802;SpecInfo.Data.F2=16.1876696570707;SpecInfo.Data.SW=20.0254193236558;
SpecInfo.Data.INTSCL=9.40985188537284E-05;
SpecInfo.Data.NC_procplus100=95;
SpecInfo.Data.OFFSET=16.1437364265235;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team2/nmr/Jul27-2023/1273710/pdata/1/intrng, 8/8/2023 12:14:12 PM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team2/nmr/Jul27-2023/1273710/pdata/1/intgap_ole, 8/8/2023 12:14:12 PM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=65536
SpecInfo.Data.nint=6
SpecInfo.Data.realymin=-77015
SpecInfo.Data.realymax=338145345
SpecInfo.Data.realyave=866638
SpecInfo.Data.realyint=55995788749
SpecInfo.Data.snr=390.269478144277
SpecInfo.Data.nbytes=1531
SpecInfo.Data.miny=0
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=2.5623320705349
SpecInfo.Data.firstnz=26528
SpecInfo.Data.compressionratio=171.2/1
SpecInfo.Data.htratio=2.95730819538563E-06
SpecData=new Array([0,-1,65536,'g:/data/chem-synthesis-summer-a-team2/nmr/Jul27-2023/1273710/pdata/1/1r']
,[1,26527,478,1,"26528H%XJ%Z%SJ%WJ%WJ%UJ%TJ%TJ%TJ%J%J%JT%JZKJKWLLUMLMVNOTQRJ0J1J3","26611A44J4TJ5J4J3J1J0RQPOLK%kmorUj0j0UrrqrWqqTponmlkTj%JTKLTMN","26662H5NUONUOOPRJ0J1J3J4J5J6J5J3J2QM%koUponmnToqj0j2Tj4j4Vj2j2j0","26708G6rqponmlUkkjkjTkj%jU%jT%j%Tj%Tj%Tj%Vj%Xj%S1j%S5j%S9J%S2j%","26817C%T1J%T1j%S6j%UJ%j%TJ%T0J%S3j%S2j%U4j%XJ%j%J%Vj%UJ%Zj%W",""]
,[2,27231,472,1,"27232E%S1J%XJ%WJ%VJ%TJ%TJ%J%J%J%JZKKJKTLLUNMOTPQTRJ0RUQONLJkln","27312A46qTrj0j1j0rUppnTmmlkUjkjV%jT%j%j%Tj%Vj%U2J%UJ%UJ%TJ%J%J","27400A5J%JYKJKULKMLMTONPQRTJ1J1J2VJ1RPNK%moqj0j2j3Tj4j2j3j1j0r","27451F5qponTllTkkjkjY%jT%j%Tj%Uj%Xj%T3j%T0j%V0J%T0j%X6J%YJ%S7j%","27690D%Zj%U",""]
,[3,28054,605,1,"28055E1KLKLJKTLKMLNTPPQRQRPOMK%kmnpqUpponmlTkkWlkUjjU%%JUKKLUMN","28119G8NOPOPUOOPOPTQRQTPOTMMNTPQTJ1J1TJ2J0RPOKjlprj1j2j4Wj2j2j1","28169A86j0TrrqUppoTnmTlkTj%TJJKLTMMNOPTQQRWJ0J0TJ1J1J2J3J4J3TJ2J1","28219C21QOJjorj2j5j6j8j9j8Tj7j5j3j2j1rpTonTmmlkUj%TJJKLTMMNTOP","28263A20PQRJ1UJ2J2J1RQPMKjlnopTopnmTlk%TKMOQRJ2J3UJ2QNJnpj2j3j5","28310B36j5Tj4j3j0qnl%KMPTRJ0RUQQPQRVPOK%mqj0j2j5j6Tj7j5Tj4j3j1j1","28354A24rTqqopnTmmlTkjkj%UJJTKKTLLS0NMONUMLJ%jkUllmlmUllTkjT%J","28419H3LTOOQJ0J1TJ2J2J1QNKlnrj1j3j4Uj3j1Tj0qpnTmlTkkTjkjW%jT%j","28467A1%Tj%j%Wj%Z%Sj%Xj%Yj%S1j%S6J%ZJ%S9j%S1j%S1j%T0J%T7j%S6j%","28652B%X",""]
,[4,29274,183,1,"29275A77j3Uj2j1j0rTqopnUmmlmklklkTjkjY%jT%j%Tj%Tj%Uj%Wj%Zj%S1j%","29351C%S8j%S8J%T0j%V6",""]
,[5,0,1,0,"0@",""]
,[6,0,1,0,"0@",""]
)
