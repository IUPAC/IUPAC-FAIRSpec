SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<1H>'; SpecInfo.Data.EXP='<PROTON>';SpecInfo.Data.SFO1=400.132470802;
SpecInfo.Data.O1=2470.802;SpecInfo.Data.F2=16.1876696570707;SpecInfo.Data.SW=20.0254193236558;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=95;
SpecInfo.Data.OFFSET=16.18777;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team2/nmr/Jul27-2023/1274510/pdata/1/intrng, 7/27/2023 12:24:07 PM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team2/nmr/Jul27-2023/1274510/pdata/1/intgap_ole, 7/27/2023 8:36:34 PM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=65536
SpecInfo.Data.nint=4
SpecInfo.Data.realymin=-117214
SpecInfo.Data.realymax=301921283
SpecInfo.Data.realyave=419171
SpecInfo.Data.realyint=26313545049
SpecInfo.Data.snr=720.561529781402
SpecInfo.Data.nbytes=366
SpecInfo.Data.miny=0
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=1.38780653513847
SpecInfo.Data.firstnz=29073
SpecInfo.Data.compressionratio=716.2/1
SpecInfo.Data.htratio=3.31212159031531E-06
SpecData=new Array([0,-1,65536,'g:/data/chem-synthesis-summer-a-team2/nmr/Jul27-2023/1274510/pdata/1/1r']
,[1,28708,1109,365,"29073A%Tj%J%T4J%WJ%UJ%J%JTKKLMTOQRJ1J2J3J2UJ1J0J1J0PK%lprj2j1j3","29145A13j2j4j3j1TrpomlTkkjkjV%jT%j%j%j%Tj%Zj%S4j%J%j%Y9j%ZJj%J","29296A%XjJ%S0j%UJ%Tj%S7J%Xj%T9J%j%TJ%T",""]
,[2,0,1,0,"0@",""]
,[3,0,1,0,"0@",""]
,[4,0,1,0,"0@",""]
)
