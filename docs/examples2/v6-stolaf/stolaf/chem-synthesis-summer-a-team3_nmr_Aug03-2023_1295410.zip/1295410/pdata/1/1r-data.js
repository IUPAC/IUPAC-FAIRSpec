SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<13C>'; SpecInfo.Data.EXP='<C13CPD32>';SpecInfo.Data.SFO1=100.622829803;
SpecInfo.Data.O1=10061.277;SpecInfo.Data.F2=219.438350248103;SpecInfo.Data.SW=238.896695566946;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=91;
SpecInfo.Data.OFFSET=219.4603;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team3/nmr/Aug03-2023/1295410/pdata/1/intrng, 8/3/2023 11:24:45 AM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team3/nmr/Aug03-2023/1295410/pdata/1/intgap_ole, 8/3/2023 11:27:27 AM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=32768
SpecInfo.Data.nint=7
SpecInfo.Data.realymin=-9269864
SpecInfo.Data.realymax=394658123
SpecInfo.Data.realyave=2207661
SpecInfo.Data.realyint=12101396123
SpecInfo.Data.snr=182.966491232123
SpecInfo.Data.nbytes=1183
SpecInfo.Data.miny=-23
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=5.4654816478463
SpecInfo.Data.firstnz=11824
SpecInfo.Data.compressionratio=110.7/1
SpecInfo.Data.htratio=2.53383863582608E-06
SpecData=new Array([0,-1,32768,'g:/data/chem-synthesis-summer-a-team3/nmr/Aug03-2023/1295410/pdata/1/1r']
,[1,11823,117,1,"11824dJKL%k%jNjnJnkJ2PK%kJ3J5K7M6J30L45Rl89j21m1j5j7mnjLmOPnmk","11864DJjnJL%kNmJ%p%MOqkO%RjQp%MLnj0NnLPqoLTjmOLnpmJ0Jqn%J3LTMj","11917A3lTjRK5N8K4p1k9j1j3LOPlTnLlLn%",""]
,[2,12037,50,1,"12038A6pqLlJnJ0J1nkTqJNjJ1Jj0OjmJ3JPTQK6P9K31L40m25j80o0k0rTj4O","12076A0komMTKjpM%",""]
,[3,12442,86,1,"12443FjkN%JNlqKjPKj1NJ%LpMTkKmojRlMLJUkJ2TJ0L9N1m5m4j1rqLkl%QJ1","12492C9NJ1QJJ6M8J69K79n8l28r7m7qkJj0rklQJ0mj3j%j0j2OJ4jon%J0M",""]
,[4,12528,56,1,"12529HmLmKmJPRj1mKJ1jq%QLKNK4L8R7R6l3j44o3k1m%rTMMTl%MkJ1oKoj0m","12573ejN%kTOjPLJ",""]
,[5,14406,76,1,"14407bKnl%J3koNjMp%MJ1KjklTLpnNOkTOlMj0qlJ0lTQkljLNR%nLTJ3J4K0L1","14457I2Q1K58K80m14j84o0k1j6lJjopJPJlT%jRqoO",""]
,[6,19440,165,1,"19441BqPTmj%nrMmNRK%NkMkLJOMpnKJjMOKj1KPNKUMROKJ1K4L9N5R5J60K59K54","19490I53k7l07k69j51p4l5k2j4qj0rmOLnMKrJlkOTJjKJmQJkmPQRJ4J8K8L8","19529A56O3J10K06L03J62j88l19k19j16o0l1j3oj2rjj3mK%KlKTOmkjPRjL","19561C1jTPmJJ2PJ0J2K7TM1Q6J48K63K65Ok88k79j62p7m5l0qj7pLprnklJ","19594BNLoJjMlnNJ",""]
,[7,22490,45,1,"22491HoqKPKopjJ2KpONLjlQK6TN4J55N0k07p2k4j0klNjj3lkLNK%Lp%nJN",""]
)
