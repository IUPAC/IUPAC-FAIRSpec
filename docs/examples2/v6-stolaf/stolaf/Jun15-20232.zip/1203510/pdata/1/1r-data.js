SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<1H>'; SpecInfo.Data.EXP='<PROTON>';SpecInfo.Data.SFO1=400.132470802;
SpecInfo.Data.O1=2470.802;SpecInfo.Data.F2=16.1876696570707;SpecInfo.Data.SW=20.0254193236558;
SpecInfo.Data.INTSCL=1.47122024282431E-04;
SpecInfo.Data.NC_procplus100=97;
SpecInfo.Data.OFFSET=16.18777;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-a-team2/nmr/Jun15-2023/1203510/pdata/1/intrng, 6/20/2023 9:16:57 AM'
SpecInfo.Data.using='g:/data/chem-synthesis-a-team2/nmr/Jun15-2023/1203510/pdata/1/intgap_ole, 6/20/2023 9:16:58 AM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=65536
SpecInfo.Data.nint=3
SpecInfo.Data.realymin=-14932
SpecInfo.Data.realymax=387243522
SpecInfo.Data.realyave=308292
SpecInfo.Data.realyint=20055490427
SpecInfo.Data.snr=1256.14175521908
SpecInfo.Data.nbytes=641
SpecInfo.Data.miny=0
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=0.796088495462516
SpecInfo.Data.firstnz=25665
SpecInfo.Data.compressionratio=408.9/1
SpecInfo.Data.htratio=2.58235436666646E-06
SpecData=new Array([0,-1,65536,'g:/data/chem-synthesis-a-team2/nmr/Jun15-2023/1203510/pdata/1/1r']
,[1,25664,288,1,"25665C%S8J%T4J%S5J%S1J%XJ%UJ%TJ%J%JT%JXKKVLKLKLTMNTPPQRJ0J2TJ3J1","25786A48QNJkmnUonTmlWnnpVoomTllkWjkjT%%JUKKTLLTMNTPPVONMNTPJ0J0","25851A46J3J5TJ7J8J7TJ4J0Njrj4j8Tj6j5j2j1j0qWj0j0j1Tj0qpTnmlTkk","25890C0klkVjkjT%jT%j%j%Tj%Tj%Vj%S1j%S6J%V",""]
,[2,25959,261,1,"25960E%Z%SJ%Z%SJ%YJ%WJ%TJ%J%J%J%J%J%JWKKULLTMMNOVNOTQRJ1J3J5J7J9","26037A83K2K3TK0J5Q%qj3Tj4j4Tj3j1rqpWqrj0j1Tj0rpomnlXkljkjT%%J%","26086B5JKJLKLTMNTOONTLKLTNNPQRUQQPNKkoj0j2Tj1rqpTnonVonmnmTklk","26141A9jkjY%jT%j%j%Tj%Vj%Vj%S0j%U6",""]
,[3,0,1,0,"0@",""]
)
