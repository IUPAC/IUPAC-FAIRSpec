SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<1H>'; SpecInfo.Data.EXP='<PROTON>';SpecInfo.Data.SFO1=400.132470802;
SpecInfo.Data.O1=2470.802;SpecInfo.Data.F2=16.1876696570707;SpecInfo.Data.SW=20.0254193236558;
SpecInfo.Data.INTSCL=3.46242699519029E-05;
SpecInfo.Data.NC_procplus100=93;
SpecInfo.Data.OFFSET=16.18777;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team3/nmr/Jul20-2023/1257510/pdata/1/intrng, 7/26/2023 8:16:33 PM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team3/nmr/Jul20-2023/1257510/pdata/1/intgap_ole, 7/26/2023 8:16:34 PM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=65536
SpecInfo.Data.nint=10
SpecInfo.Data.realymin=-311843
SpecInfo.Data.realymax=279846707
SpecInfo.Data.realyave=5434077
SpecInfo.Data.realyint=353138335297
SpecInfo.Data.snr=51.5558668012985
SpecInfo.Data.nbytes=834
SpecInfo.Data.miny=-1
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=19.3964346260359
SpecInfo.Data.firstnz=28991
SpecInfo.Data.compressionratio=314.3/1
SpecInfo.Data.htratio=3.57338491033236E-06
SpecData=new Array([0,-1,65536,'g:/data/chem-synthesis-summer-a-team3/nmr/Jul20-2023/1257510/pdata/1/1r']
,[1,28990,207,1,"28991A3%S5J%S1J%S0J%ZJ%S0J%S4J%WJ%TJ%S2J%WJ%WJ%XJ%TJ%XJ%UJ%VJ%","29126B9%J%J%J%JT%J%J%JYKKTLLMLTJJ%jkjklkTlkTlklWklkTlkTjkjT%%j","29189E%j%Uj%",""]
,[2,31885,653,1,"31886A3%VJ%Z%SJ%YJ%Tj%UJ%Z%SJ%jJ%YJ%S3J%S1J%XJ%Z%SJ%Z%SJ%XJ%XJ%","32005B5%VJ%WJ%XJ%UJ%UJ%VJ%UJ%YJ%TJ%TJ%VJ%TJ%J%TJJ%TJ%Xj%jU%jV%j","32089C2jT%jU%j%j%j%Tj%Tj%T0J%YJ%Xj%S4J%Uj%Vj%Vj%S2j%Zj%Tj%Wj%%","32205A7j%Zj%T1jJ%ZJ%S1J%YJ%VJ%UJ%TJ%TJ%Yj%Uj%Tj%Tj%Tj%Uj%S0J%%","32320A7%S4j%Uj%Vj%Zj%VJj%VJ%S2J%VJ%j%TJ%Uj%J%j%UJ%Tj%S3J%UJ%VJ%","32426A8%S0j%Vj%Vj%Uj%T4J%VJ%T3j%Wj%Vj%Yj%S1j%",""]
,[3,0,1,0,"0H",""]
,[4,0,1,0,"0H",""]
,[5,0,1,0,"0H",""]
,[6,0,1,0,"0H",""]
,[7,0,1,0,"0H",""]
,[8,0,1,0,"0H",""]
,[9,0,1,0,"0H",""]
,[10,0,1,0,"0H",""]
)
