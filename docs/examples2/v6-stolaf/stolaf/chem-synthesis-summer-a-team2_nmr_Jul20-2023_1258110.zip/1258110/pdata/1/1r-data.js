SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<1H>'; SpecInfo.Data.EXP='<PROTON>';SpecInfo.Data.SFO1=400.132470802;
SpecInfo.Data.O1=2470.802;SpecInfo.Data.F2=16.1876696570707;SpecInfo.Data.SW=20.0254193236558;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=94;
SpecInfo.Data.OFFSET=16.18777;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team2/nmr/Jul20-2023/1258110/pdata/1/intrng, 7/20/2023 1:52:22 PM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team2/nmr/Jul20-2023/1258110/pdata/1/intgap_ole, 7/20/2023 7:15:45 PM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=65536
SpecInfo.Data.nint=1
SpecInfo.Data.realymin=-134644
SpecInfo.Data.realymax=375185018
SpecInfo.Data.realyave=2420139
SpecInfo.Data.realyint=157394077297
SpecInfo.Data.snr=155.081861826945
SpecInfo.Data.nbytes=130
SpecInfo.Data.miny=0
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=6.44820734171928
SpecInfo.Data.firstnz=-1
SpecInfo.Data.compressionratio=2016.4/1
SpecInfo.Data.htratio=2.66535163192471E-06
SpecData=new Array([0,-1,65536,'g:/data/chem-synthesis-summer-a-team2/nmr/Jul20-2023/1258110/pdata/1/1r']
,[1,0,1,0,"0@",""]
)
