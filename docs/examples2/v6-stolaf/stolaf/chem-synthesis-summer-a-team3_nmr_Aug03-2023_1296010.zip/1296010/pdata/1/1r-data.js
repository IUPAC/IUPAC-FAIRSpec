SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<13C>'; SpecInfo.Data.EXP='<C13CPD32>';SpecInfo.Data.SFO1=100.622829803;
SpecInfo.Data.O1=10061.277;SpecInfo.Data.F2=219.438350248103;SpecInfo.Data.SW=238.896695566946;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=91;
SpecInfo.Data.OFFSET=219.4603;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team3/nmr/Aug03-2023/1296010/pdata/1/intrng, 8/3/2023 3:59:16 PM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team3/nmr/Aug03-2023/1296010/pdata/1/intgap_ole, 8/3/2023 6:17:06 PM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=32768
SpecInfo.Data.nint=11
SpecInfo.Data.realymin=-9939390
SpecInfo.Data.realymax=358053180
SpecInfo.Data.realyave=2161171
SpecInfo.Data.realyint=12788498726
SpecInfo.Data.snr=170.274619639075
SpecInfo.Data.nbytes=1514
SpecInfo.Data.miny=-28
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=5.87286585704706
SpecInfo.Data.firstnz=10484
SpecInfo.Data.compressionratio=86.5/1
SpecInfo.Data.htratio=2.79288121390236E-06
SpecData=new Array([0,-1,32768,'g:/data/chem-synthesis-summer-a-team3/nmr/Aug03-2023/1296010/pdata/1/1r']
,[1,10483,40,1,"10484a1JJ1N%rlMqkJR%OMOnK2L8K9L4K3p1n0j5jqokTPjTkPNJlo",""]
,[2,12310,96,1,"12311A0Mlm%TLJMqnpMLPRJ5J0L2P2J13R6p3j59o2k2j8mJnkjNmRkKOJ1J4J9","12351G1N2J20J35q1j64o2k6j2rlUPlojTmMJ4K6K8M9J25J88j75j50m8l0j0n","12382B3qkn%LJTknKMj8KJ0jpNQJjmoL",""]
,[3,12416,63,1,"12417AmRnlMJPTj7Lj0JQNjJNpLjMlMKj4kNK%J0J3OJ6L1O7J58J03j97j28l9","12457D5j1mqj0%LkTnokOpOJ%ONKnj3",""]
,[4,13266,43,1,"13267AoLJ5rMpqkQK%l%PJKQjLMK8N8Kk7k4jqk5j7momJ1om%lrJ4QJ",""]
,[5,19441,109,1,"19442aMmQPkq%JMkJrJ0%OnJlJJ1pMNnjJjJ%TNJ3%jJ0LQJ9J2J3K3L0N0Q1J24","19487D07K05K52J29j68l05k19j17n1l6k3j2j8m%jroJ2JnkKjTMKprNQmnLJ4","19521D1NJ3J5NJ7K7L7N1R2J57K61K46Lk90k81j65q4m7l3k4j9oj0lPNKj1",""]
,[6,19550,57,1,"19551FKOTnO%LnNjnJPQRTJ7K0K5L0M1O7J18K07K67J56j34l10k45j19o7m0k6","19584E9k1rnjqkJnJqmMJ2pjMpJrKTj",""]
,[7,20077,99,1,"20078gnKMJKPKnlmKNMJ0QK5M3k9l8j4%j1nJ0KojQJ5MOj2QqJ3J5Ok8k2ORL","20120B2j2nKOopjP%JnMj4NOMKlOJ0L0K0m1j8rJ2pmKjKoLjOTmoRkokj1LJ0J","20166HnlkKkjMTN",""]
,[8,20401,67,1,"20402dJ2%plMJoPLNloNRPJ0OqrJ3J9L6j0l8j3j1mOLRJ1K0K7Kk1j4j8JQMR","20443F2J8Pj1rk2k4pr%PJkqkmLkMLjTKLN",""]
,[9,20468,46,1,"20469EJjK%NTkj1nJNJ1lJ3J1J3lqj5mLknpQJ3K6K9j0k7k5j9pMLTJj1PklR","20511HkJ",""]
,[10,21610,64,2,"21612cLjkLNOoLnoKP%J%kNRJ6K7%k7j4omj7%RjNkMJ0MORoJ4L7J1k3j8KRm","21657F0j6k3rTKokMJlMQjnj1N",""]
,[11,27097,52,1,"27098AlNpmTKKJ0ojQKLKjkNjJmQjlK4J8K6K1L6m6n6qTj1JKmpkLpqNJ4%ko","27144cmJjn",""]
)
