SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<13C>'; SpecInfo.Data.EXP='<C13CPD32>';SpecInfo.Data.SFO1=100.622829803;
SpecInfo.Data.O1=10061.277;SpecInfo.Data.F2=219.438350248103;SpecInfo.Data.SW=238.896695566946;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=94;
SpecInfo.Data.OFFSET=219.4603;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team2/nmr/Jul20-2023/1258410/pdata/1/intrng, 7/20/2023 2:13:33 PM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team2/nmr/Jul20-2023/1258410/pdata/1/intgap_ole, 7/20/2023 7:16:18 PM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=32768
SpecInfo.Data.nint=8
SpecInfo.Data.realymin=-1113764
SpecInfo.Data.realymax=357162069
SpecInfo.Data.realyave=336584
SpecInfo.Data.realyint=3431976634
SpecInfo.Data.snr=1064.4470117415
SpecInfo.Data.nbytes=1012
SpecInfo.Data.miny=-3
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=0.939454936666074
SpecInfo.Data.firstnz=8201
SpecInfo.Data.compressionratio=129.5/1
SpecInfo.Data.htratio=2.79984938714195E-06
SpecData=new Array([0,-1,32768,'g:/data/chem-synthesis-summer-a-team2/nmr/Jul20-2023/1258410/pdata/1/1r']
,[1,8200,45,1,"8201AjJ%j%TjJ%Tj%K%JUMMJ7O4J1m5l9j2m%j%Tjk%UjJ%UjK%",""]
,[2,11111,89,1,"11112A%Uj%TJ%UJjTJK%JVLNTJ1K1L3R0L20N05o76k05n8k1j5qmTj%kjk%Jj","11157C%jJj%Zjj%J%J%Tj%JLjkJMlkT%%TJJjTJ%U",""]
,[3,14064,108,1,"14065A%Tj%YK%kJ%Jj%VM%lj%Kj%KjT%j%J%J%Tjj%TJJ%TJ%jJK%TJKLMPQJ7K8","14128G6P1K45N24m72k93p7k9j6romjlkJjT%jJj%UjJ%Uj%jK%jT%%TJ%TJ",""]
,[4,18694,77,1,"18695bJ%TJj%K%VjK%jJj%jJ%jT%JK%kJkJT%%jUKJj%JTj%KJLNQK9N6J8q2k5","18750A6qkUj%Tj%TJj%j%J%TJ",""]
,[5,19438,65,2,"19440A%jJ%Uj%J%jJ%TJ%jJ%VKjJKJLJNTRJ9L7M3Lm4l9k2j1pljT%k%UKJjk","19493B%UjJj%J%",""]
,[6,19503,90,1,"19504BJ%J%TJKTMLPJ3K8M3L2k2m8l3j4pnkjTk%Tjj%jJ%Jj%Jj%TJJj%UJJJ","19553F%JKMORJ7L5M3J3m1m4k3j1nmlT%%Vj%TjJj%TjJTj%UJ",""]
,[7,22337,60,2,"22339AjJ%Vj%VJJMlj%j%JjTJ%j%j%UJJLMJ3mj1l%j%j%TjJ%jTJ%UjJ%J",""]
,[8,22466,69,1,"22467aK%lJT%J%JjT%KjJT%j%UJ%JjJ%JU%LKMRJ4L1P9K70r6k20n3k2j2mll","22514FkjUJj%j%TJ%jJTj%Tjj",""]
)
