SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<1H>'; SpecInfo.Data.EXP='<PROTON>';SpecInfo.Data.SFO1=400.132470802;
SpecInfo.Data.O1=2470.802;SpecInfo.Data.F2=16.1876696570707;SpecInfo.Data.SW=20.0254193236558;
SpecInfo.Data.INTSCL=1.07115074360184E-04;
SpecInfo.Data.NC_procplus100=95;
SpecInfo.Data.OFFSET=16.18777;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team1/nmr/Jul27-2023/1273510/pdata/1/intrng, 8/1/2023 9:36:23 AM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team1/nmr/Jul27-2023/1273510/pdata/1/intgap_ole, 8/1/2023 9:36:24 AM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=65536
SpecInfo.Data.nint=8
SpecInfo.Data.realymin=-76607
SpecInfo.Data.realymax=447633113
SpecInfo.Data.realyave=935508
SpecInfo.Data.realyint=60551626770
SpecInfo.Data.snr=478.573908507463
SpecInfo.Data.nbytes=1737
SpecInfo.Data.miny=0
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=2.08954141089454
SpecInfo.Data.firstnz=26956
SpecInfo.Data.compressionratio=150.9/1
SpecInfo.Data.htratio=2.23397235583865E-06
SpecData=new Array([0,-1,65536,'g:/data/chem-synthesis-summer-a-team1/nmr/Jul27-2023/1273510/pdata/1/1r']
,[1,26955,276,1,"26956D%T5J%S7J%Z%SJ%ZJ%XJ%VJ%UJ%UJ%J%J%TJJ%J%J%JT%JWKJKVLLXMML","27076F8MNTOQTRJ1TJ4J4TJ5J4TJ2RNKjmprTj1j0UrqTppUopTopnonmnlUkj","27126E4jT%%JUKLTMMNTOOPTQPQPQPQTJ0J0J1J3UJ4J3J1QOJlpj1j3j6j7Uj6j5","27174A59j4j3j1j0rponVmnmUllVkkTjkjW%jU%j%j%j%j%Tj%Tj%Uj%U",""]
,[2,27295,219,1,"27296I%WJ%WJ%UJ%J%JT%JXKJKULLTMMNOTPPQWPONMJTklmoTqpqUppoTnnmm","27368C8lTkkUjkjY%j%j%j%Tj%S3J%WJ%UJ%UJ%Vj%S0J%UJ%J%J%JXKJKULLL","27459D1MNTOPTQRUJ0RQTONLJ%lmoqTrrWppTnnTmlTklkjkTjjY%",""]
,[3,27783,192,1,"27784G%Z%SJ%XJ%XJ%VJ%VJ%UJ%VJ%TJ%TJ%J%J%J%JT%JT%JUKJTKKULLVMML","27864F4NMTNMNOPQRJ0J2J3J4J6J7VJ5J2QM%npj0j2Tj3j3j2j1Tj0rqUpqpq","27907A14pToonTmmlTkkjT%%TJJTKLTMMNTOOPOPQPVQRTJ0J1TJ2J1J0QOL%m","27958B59oj0j1j2Tj3j1Tj0rpTnmlk",""]
,[4,27976,193,1,"27977A23%TKKMNOPRJ0J1J2J3TJ2J1RPNKkloqrj1j0Tj1rTqqpTopoYnmnlmk","28027F7lkjT%%TJJKUMLNMNOVPOTPOPTQRTJ0J0J1UJ0ROMJknqj0j3j4j5j6j5","28077A70j4Tj3j1j0rqpnTmmlTklTklTklklkUjkjTkj%jU%jT%%j%Tj%Vj%Tj%","28132A1%j%j%Tj%Uj%Xj%Yj%Xj%U",""]
,[5,28688,303,1,"28689C%UJ%S3J%S1J%YJ%WJ%UJ%UJ%UJ%J%JT%JWKJKULKLMNTOOQRTJ0J2J1J3","28776A34J2J1J0QOKknprj1Tj2j1Uj0rqpTnmUlklkTjkjkjU%jT%jT%%j%j%%","28826H%j%Xj%T0J%ZJ%UJ%TJ%TJ%J%JT%JVKJKVLMLNTOPTRRTJ0J0TRQOLJln","28912A45pqrj0TrrTqqoTnmTlklkTjkjTkj%jU%jT%%j%j%Tj%Uj%Yj%S3j%S1",""]
,[6,29899,476,1,"29900A%T7J%X3J%U9J%j%J%S9J%Z%SJ%ZJ%YJ%WJ%UJ%VJ%J%TJ%J%J%JT%JVKJ","30117B4KJKVLKLKLKLKLKLKMUOOQRJ0J1J3J4TJ6J5UJ2J1PMJknpj0Tj1j1Tj0j0","30166A77rqTpopopoTpononTmlmklkjT%%TJJKULMUNONOZPQTRJ0UJ1J0QTNL","30226B47jlprj2j3j4Vj3j2j1j0rqoTmmTlklklklkTlkTlkjkTjkjW%jT%j%%","30278Ij%Tj%Uj%Uj%Xj%Zj%T1j%U0j%S5",""]
,[7,0,1,0,"0@",""]
,[8,0,1,0,"0@",""]
)
