SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<1H>'; SpecInfo.Data.EXP='<PROTON>';SpecInfo.Data.SFO1=400.132470802;
SpecInfo.Data.O1=2470.802;SpecInfo.Data.F2=16.1876696570707;SpecInfo.Data.SW=20.0254193236558;
SpecInfo.Data.INTSCL=2.38227456014731E-04;
SpecInfo.Data.NC_procplus100=96;
SpecInfo.Data.OFFSET=16.18777;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team3/nmr/Jul27-2023/1274810/pdata/1/intrng, 7/31/2023 10:15:24 AM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team3/nmr/Jul27-2023/1274810/pdata/1/intgap_ole, 7/31/2023 10:15:25 AM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=65536
SpecInfo.Data.nint=5
SpecInfo.Data.realymin=-29525
SpecInfo.Data.realymax=298878693
SpecInfo.Data.realyave=682478
SpecInfo.Data.realyint=44354150740
SpecInfo.Data.snr=437.974876845847
SpecInfo.Data.nbytes=569
SpecInfo.Data.miny=0
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=2.28323598650607
SpecInfo.Data.firstnz=29443
SpecInfo.Data.compressionratio=460.7/1
SpecInfo.Data.htratio=3.34583904246396E-06
SpecData=new Array([0,-1,65536,'g:/data/chem-synthesis-summer-a-team3/nmr/Jul27-2023/1274810/pdata/1/1r']
,[1,29442,629,1,"29443A%S0J%TJ%TJJ%JU%JT%J%Uj%jU%jT%j%Uj%S7J%YJ%UJ%JWKJKUJKJK%J","29534B7%UjjkjkUjkjX%j%Tj%Tj%S1J%YJ%UJJWKJKTJJK%J%jUkkjkUjkjT%j","29614D%j%Tj%Yj%Y2J%S2J%VJ%TJ%JT%JT%JS2K%JV%J%Yj%j%j%j%j%YJ%JWKJ","29780C2JKJKJKJY%%Vj%TjjVkjkS1jkjkjU%jT%j%j%Uj%Wj%S0J%VJ%J%JU%J","29867IKJS2%J%J%Vj%j%jS5%jT%j%j%ZJ%J%J%JT%JV%JT%J%J%J%Xj%j%jT%j","29958A3jT%jU%jT%jT%j%Tj%Uj%S3",""]
,[2,0,1,0,"0@",""]
,[3,0,1,0,"0@",""]
,[4,0,1,0,"0@",""]
,[5,0,1,0,"0@",""]
)
