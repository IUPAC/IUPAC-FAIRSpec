SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<1H>'; SpecInfo.Data.EXP='<PROTON>';SpecInfo.Data.SFO1=400.132470802;
SpecInfo.Data.O1=2470.802;SpecInfo.Data.F2=16.1876696570707;SpecInfo.Data.SW=20.0254193236558;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=97;
SpecInfo.Data.OFFSET=16.18777;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team1/nmr/Jul20-2023/1257310/pdata/1/intrng, 7/20/2023 1:01:54 PM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team1/nmr/Jul20-2023/1257310/pdata/1/intgap_ole, 7/25/2023 9:26:26 AM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=65536
SpecInfo.Data.nint=3
SpecInfo.Data.realymin=-9519
SpecInfo.Data.realymax=324427533
SpecInfo.Data.realyave=394589
SpecInfo.Data.realyint=25773125945
SpecInfo.Data.snr=822.215145379116
SpecInfo.Data.nbytes=1177
SpecInfo.Data.miny=0
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=1.21622668424444
SpecInfo.Data.firstnz=26532
SpecInfo.Data.compressionratio=222.7/1
SpecInfo.Data.htratio=3.08235244633198E-06
SpecData=new Array([0,-1,65536,'g:/data/chem-synthesis-summer-a-team1/nmr/Jul20-2023/1257310/pdata/1/1r']
,[1,25896,6305,636,"26532A%YJ%XJ%YJ%j%S6j%Vj%Xj%Y79J%S7J%VJ%UJ%UJ%TJ%Z%Sj%Xj%Tj%Uj%","27425B%Vj%ZJ%ZJ%UJ%UJ%UJ%TJ%Zj%Wj%Uj%j%Tj%Vj%X7j%S63J%T24J%X7J%","28018C%S9J%S2J%Z%SJ%WJ%UJ%TJ%J%J%JWKJTKJTKJKJTKJKJKJTKKTLNTPRJ0","28111H6J0J1UJ2J3J2J3J2UJ1J1QPNK%npj1Tj2j3Uj2j2j0qpoUnnoXnnmTkl","28159C8jT%JTKKLTMLMUNNOTPQRTJ0J0J1J0TRQTRQTPQPONMJkmoj0j4j6j7j9","28207A73j8j7j6j5j3j2j0qonTlkUjjVkjkYjkTjjU%jT%j%Tj%Tj%Xj%Z%Sj%","28272A%W3j%V61J%W2j%ZJ%T9J%S1J%T1j%Wj%T5J%WJ%TJ%UJ%WJ%Wj%Wj%Uj%","28982C%Tj%Vj%T5J%XJ%S7j%Xj%Zj%W6J%YJ%TJ%J%J%J%J%J%TJ%Wj%jU%j%j","29152Cj%Tj%Yj%S137J%S88J%VJ%UJ%TJ%TJ%UJ%Yj%Uj%Tj%Tj%Tj%Wj%T0J%","30559B%VJ%UJ%TJ%TJ%S3j%Uj%Tj%Tj%Vj%S97J%U1J%XJ%VJ%WJ%Vj%Z%Sj%%","30868D%Uj%S4J%XJ%UJ%TJ%TJ%J%TJ%TJ%S3j%S0J%TJJXKJKJTKJKTJKUJKTJK","30964D7LTNOPRJ0J1TJ2J2J3YJ2J1RQOL%mprj2j3Tj4j4j3Tj1j0qpTooUpop","31011G7oUnnmTlkjTJ%KTLLUMMTNNTPOQTRRJ0WQQTPQPUONMJ%loqj2j4j6j7j7","31068A58j7j6j5j3j2j1qpomTlkTjjkjVkkjkWjjkjT%jT%j%j%Tj%Tj%Wj%S0j%","31133A%W3j%S55J%YJ%XJ%S0j%Vj%Z%Sj%T8J%Z%SJ%XJ%Zj%Vj%Yj%S75J%V6j%","31676@%S8J%W2",""]
,[2,0,1,0,"0@",""]
,[3,0,1,0,"0@",""]
)
