SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<1H>'; SpecInfo.Data.EXP='<PROTON>';SpecInfo.Data.SFO1=400.132470802;
SpecInfo.Data.O1=2470.802;SpecInfo.Data.F2=16.1876696570707;SpecInfo.Data.SW=20.0254193236558;
SpecInfo.Data.INTSCL=1.47691784696192E-04;
SpecInfo.Data.NC_procplus100=96;
SpecInfo.Data.OFFSET=16.18777;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team3/nmr/Jul20-2023/1257710/pdata/1/intrng, 7/26/2023 9:09:05 PM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team3/nmr/Jul20-2023/1257710/pdata/1/intgap_ole, 7/26/2023 9:09:06 PM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=65536
SpecInfo.Data.nint=4
SpecInfo.Data.realymin=-34417
SpecInfo.Data.realymax=382031962
SpecInfo.Data.realyave=507643
SpecInfo.Data.realyint=32931216469
SpecInfo.Data.snr=752.628085091294
SpecInfo.Data.nbytes=190
SpecInfo.Data.miny=0
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=1.32867749663992
SpecInfo.Data.firstnz=-1
SpecInfo.Data.compressionratio=1379.7/1
SpecInfo.Data.htratio=2.61758203362053E-06
SpecData=new Array([0,-1,65536,'g:/data/chem-synthesis-summer-a-team3/nmr/Jul20-2023/1257710/pdata/1/1r']
,[1,0,1,0,"0@",""]
,[2,0,1,0,"0@",""]
,[3,0,1,0,"0@",""]
,[4,0,1,0,"0@",""]
)
