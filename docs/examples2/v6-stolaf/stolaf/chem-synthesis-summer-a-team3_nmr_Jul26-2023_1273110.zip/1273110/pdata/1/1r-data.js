SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<13C>'; SpecInfo.Data.EXP='<C13CPD32>';SpecInfo.Data.SFO1=100.622829803;
SpecInfo.Data.O1=10061.277;SpecInfo.Data.F2=219.438350248103;SpecInfo.Data.SW=238.896695566946;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=92;
SpecInfo.Data.OFFSET=219.4603;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team3/nmr/Jul26-2023/1273110/pdata/1/intrng, 7/27/2023 5:36:47 AM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team3/nmr/Jul26-2023/1273110/pdata/1/intgap_ole, 7/27/2023 9:47:39 AM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=32768
SpecInfo.Data.nint=17
SpecInfo.Data.realymin=-4434856
SpecInfo.Data.realymax=282896811
SpecInfo.Data.realyave=1253993
SpecInfo.Data.realyint=11428880691
SpecInfo.Data.snr=229.133389899306
SpecInfo.Data.nbytes=2210
SpecInfo.Data.miny=-16
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=4.36427008931111
SpecInfo.Data.firstnz=11212
SpecInfo.Data.compressionratio=59.3/1
SpecInfo.Data.htratio=3.53485780368164E-06
SpecData=new Array([0,-1,32768,'g:/data/chem-synthesis-summer-a-team3/nmr/Jul26-2023/1273110/pdata/1/1r']
,[1,11211,76,1,"11212AnkNLljPkmnLJKOJT%JnKJJ3K5mj3rlMrjlU%%jN%LloKnmLKMTLmjpJR","11266FLJ3K2nk2lTolTQko%M%lJ%K",""]
,[2,12282,70,1,"12283DkKJjlk%k%ljNKNkMJ2LK9N2K8p8l5j6k%KLl%KkjLjLP%o%LPNJ6L3Q3J50","12330C04J33j95j63m0j4qKJqj0LKnmK%JmnjL",""]
,[3,12647,62,1,"12648alMjLKmLMom%TLMP%lj%jNJ0RK5N3K00K77l93j10l5j7lj1kjK%KLJ8O8","12689A06M8r8l3j0pkKm%NkjnkJMkT",""]
,[4,13188,37,1,"13189d%JK%J%k%NkqLMPTK6O9K1p1l3j5oJmjTMo%LMlqN%",""]
,[5,19459,159,1,"19460F%LmJ%NlkTLklMTKK%L%l%KNJ0NPJ8K3L2O0J12J83J67j5j99j83j00m5","19498I6k9k0j1j3jLnT%LOJmTM%nojLOKMjnKmJ1LQJ3J2QK4M3P5J48J93J02j12","19538E44k12j41p4m2k1j3TmlmTKnoJM%MJlkjMJ%jKT%LMKNJ3QJ1K4L3N6R8J72","19579D45J72J2j81j93j08m3l2j9j4rmnmjl%m%kJTLmkl%kmj%JRjkTjJT",""]
,[6,24310,72,1,"24311AKk%jmOKkTjKlQKNloMK%OLPJ0K5M4J13K66l5k79r7l2j4lrkoTN%kJj","24354DkoJjKJ%KP%M%oJmlkTlMJLJlkPl",""]
,[7,25132,36,1,"25133EjnMJjnJlNLkONMJ0O3J09j36l8j7rJNknlJOnTLMj%",""]
,[8,25317,66,2,"25319FkTjKkKkKk%LTk%OKomMNJMJ0K0N4K09j31j26l0mTljoTNkMJjkJKJ1K9","25364D7N2j0n8j7j2%kL%n%pLjMKjn",""]
,[9,25738,54,1,"25739EJ%qMPlTKlkKPlJ%KJKjPJ3J1J8K3M9J26L48L94k47n08j33n1k3j0oj1","25775A1kKqK%TkJLl%kjJKM",""]
,[10,26093,45,1,"26094DLJjoM%LnKnKNOUKJ9L4J09K50k06j60m1j4ojmlj%J%JTjKklJjnlj",""]
,[11,26603,52,1,"26604cNKjJkMJKLj2%MTjLk%pLJqO%OMKJ1L5J20J26k13n9j6koTklKk%JLjn","26649bmLMJL",""]
,[12,26937,90,1,"26938DLNrl%qJK%OJKNLknJ%l%lMJLjmJj%lJ%TNnJlOlLTmj%PRMJMJ5K1K6N7","26991A47J65L25L21k91m58j15l3j4oJ0M2M8K3r6l7j4j1kLNlq%M%JPlqPlk","27023DKkL",""]
,[13,27136,58,1,"27137cMT%JnJLMmTJJKOlm%TPMkKRK9L8K7K6q2l8j1qM%MQJ4J2J8j9k8nj0k","27180AlMTml%KTmKTo",""]
,[14,27248,67,2,"27250bKNlkTLKLq%PTJ0J5K3O4L8r8m2mUjjNjmTKkKmkMmNoLJkMKlMJ2K3Tqm2","27299A6j2n%KMnK%oM%j%Nk",""]
,[15,27514,37,1,"27515a%TLk%LTJlk%NQJ3K0N8Q2l6j06j9j4j0lQNnkTpjJkmJ0L",""]
,[16,28108,92,1,"28109BklKjJkPjlmNT%NlNKj2lLTOlMlkMkMTJ2J5J2K1j5l2qnokJjKlPMOQJ1","28158D5J0K3M5J29K21Kk41q2J0J15J78J39K18p6m82j34n3k3pTj1%nLjnmm","28186CNm%OLoKjJk%Nm",""]
,[17,28515,90,1,"28516e%QjJ%j%JklNM%JjKQLJ0K9O8O0O9N9j82q3k6j1n%qKMjoLjT%LmjTMk","28561aKTjLTKopJOmnNjKTm%N%LJKkNp%k%kLTJopmnNT%M%n",""]
)
