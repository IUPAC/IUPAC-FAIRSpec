SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<13C>'; SpecInfo.Data.EXP='<C13CPD32>';SpecInfo.Data.SFO1=100.622829803;
SpecInfo.Data.O1=10061.277;SpecInfo.Data.F2=219.438350248103;SpecInfo.Data.SW=238.896695566946;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=91;
SpecInfo.Data.OFFSET=219.4603;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-summer-a-team1/nmr/Jul27-2023/1273610/pdata/1/intrng, 7/27/2023 11:00:19 AM'
SpecInfo.Data.using='g:/data/chem-synthesis-summer-a-team1/nmr/Jul27-2023/1273610/pdata/1/intgap_ole, 8/1/2023 9:36:35 AM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=32768
SpecInfo.Data.nint=9
SpecInfo.Data.realymin=-9885186
SpecInfo.Data.realymax=376255310
SpecInfo.Data.realyave=2153902
SpecInfo.Data.realyint=13059374452
SpecInfo.Data.snr=179.274867658789
SpecInfo.Data.nbytes=1361
SpecInfo.Data.miny=-26
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=5.57802670870346
SpecInfo.Data.firstnz=10108
SpecInfo.Data.compressionratio=96.3/1
SpecInfo.Data.htratio=2.6577697999797E-06
SpecData=new Array([0,-1,32768,'g:/data/chem-synthesis-summer-a-team1/nmr/Jul27-2023/1273610/pdata/1/1r']
,[1,10106,87,2,"10108CKkmlLkLjlNk%J2JkjMkrP%njpkp%RJ0No%j2NTJnKmjMNlTMlnJ0opJ1o","10160cLKrQlPQRTJ2J3L2P4O2k0j07n6jj2k3m%JKmlnKjQkQ",""]
,[2,11987,90,1,"11988BLnKTLLj1KoPLTmMNKJ4NKjPK3M4R8K23J54l16j57n1k0j4j0km%j5QN","12026Hnl%LOjpnQkmjMTjJTkKTnoOpLonJ6OljMKn%OmTkmkOpMTjmKmk",""]
,[3,12169,75,1,"12170F%kTnNjMOTjoTlPJ%jPjqljmQM%np%jLTkPJonOJJ3oj%RORJ0K4M7R6J50","12221C62J02q7k21o4l3j7j0j2j5LoJK%KokTj1J0J6q",""]
,[4,12247,58,1,"12248BMj0NJ1kj3KJjJnL%J3JlKJ3jKOQL2M9J01K05J20k63j65o2j6qj1mTlm","12285FJ5pTM%jlnTjMnQpNrkmJ8",""]
,[5,12577,65,1,"12578BpjJ1Mj1PnkLQnmlRJkJ7TK9K5J4n2l5j2olK%TjjJ%J3M%KJ9O2Ml3l1j7","12621B3j1lLJ0mjlmqoNMmTMrKLnP",""]
,[6,13725,47,1,"13726aqkRjJjOTKqjkMNjTOJKNTJ2J5O2P8j7m2l3k5k8k3j2nqK%lj0MQO%kK","13770Gn",""]
,[7,14372,53,1,"14373BOnNRjj3lKMlJ0qlJ0J1MNK3M0O4J78K45j99k19q1l3j9oj3kMnoNJ3l","14409A8JqnmkpONkMLj2lJ0%",""]
,[8,19449,160,1,"19450CNJKkTMkj3%nQjRMlkMNqKJ1npOJkNJ2NLJ3J6J9K4K7M9Q5J41K41K62O1","19491I76k46k90j83r4n0l0j8j3mj4kmJLjMJlnpjTJj%J0LjQMjQjRJ6K1K3M2","19529A60O5J02J86K82K05r5l14k55j36p1l7k9k2j0KnkjklOnTKLMJpjkLPL","19562B9MKnOQJ0J4J5J9L8M3P0J41K29K73R3k24l06j91j03n4l8j5nrknj0l","19591B4qlJrlJTlKPLlpLkl",""]
,[9,22473,45,1,"22474iOPKjlnkmMP%KPMTJK1K2N2R3N5j14r4k6j2m%MrJojolOkKLmKOk%",""]
)
