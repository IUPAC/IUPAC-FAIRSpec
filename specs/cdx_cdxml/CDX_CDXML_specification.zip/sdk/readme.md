Note

This CDX/CDXML documentation was recovered from https://web.archive.org/web/20190911015950/http://www.cambridgesoft.com/services/documentation/sdk/chemdraw/cdx/index.htm
and related waybackMachine records. 

The key information is here, but a few images relating to examples were not available from the archive.

To improve performance, the HTML has been modified to make references only to this set of files rather than to the archive itself.


Bob Hanson
2024.10.21
