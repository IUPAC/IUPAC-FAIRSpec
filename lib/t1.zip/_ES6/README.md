This directory contains files that are to be 
put into the site/swingjs/j2s/ directory for JavaScript only.


InChI WASM code from InChI-SwingJS/docs/inchi

This is content that cannot be included in google-compressor compiled packages.
