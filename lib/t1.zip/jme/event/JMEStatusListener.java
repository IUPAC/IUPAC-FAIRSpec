package jme.event;

public interface JMEStatusListener {
  public void info(String msg);
}
