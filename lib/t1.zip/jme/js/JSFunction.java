package jme.js;

public interface JSFunction {
	public void apply(Object objThis, Object paramsArray);
}
