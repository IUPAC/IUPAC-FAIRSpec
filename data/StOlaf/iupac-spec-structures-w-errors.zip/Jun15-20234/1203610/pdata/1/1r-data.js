SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<1H>'; SpecInfo.Data.EXP='<PROTON>';SpecInfo.Data.SFO1=400.132470802;
SpecInfo.Data.O1=2470.802;SpecInfo.Data.F2=16.1876696570707;SpecInfo.Data.SW=20.0254193236558;
SpecInfo.Data.INTSCL=1.47361343352714E-04;
SpecInfo.Data.NC_procplus100=97;
SpecInfo.Data.OFFSET=16.18777;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-a-team4/nmr/Jun15-2023/1203610/pdata/1/intrng, 6/20/2023 9:59:36 AM'
SpecInfo.Data.using='g:/data/chem-synthesis-a-team4/nmr/Jun15-2023/1203610/pdata/1/intgap_ole, 6/20/2023 9:59:37 AM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=65536
SpecInfo.Data.nint=3
SpecInfo.Data.realymin=-9547
SpecInfo.Data.realymax=396332072
SpecInfo.Data.realyave=310621
SpecInfo.Data.realyint=20251012182
SpecInfo.Data.snr=1275.96530498582
SpecInfo.Data.nbytes=645
SpecInfo.Data.miny=0
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=0.783720369270632
SpecInfo.Data.firstnz=25774
SpecInfo.Data.compressionratio=406.4/1
SpecInfo.Data.htratio=2.52313670946115E-06
SpecData=new Array([0,-1,65536,'g:/data/chem-synthesis-a-team4/nmr/Jun15-2023/1203610/pdata/1/1r']
,[1,25773,236,1,"25774C%Z%SJ%S4J%ZJ%WJ%UJ%TJ%JT%JWKJKTJLKTLKLTMMNPTQJ0TJ1J3J4TJ2J1","25856A72OMJjmpj0j1j2Tj0qpomTllmTnmonoTnmlkTjjT%%UJJTKKLUNMNTOP","25908G0PQPUNOPTQRJ1J3J5J7J8J9K0J9J7J5RJnj1j6k0k3k6k7k6k3k0j5j1q","25944I1pnVmnUonmTlkUjkjU%jT%j%j%Tj%Uj%Xj%S9j%",""]
,[2,26031,221,1,"26032D%ZJ%ZJ%WJ%UJ%TJ%J%J%JT%J%JWKKTLLMLMNTONOUPQJ0J2J3J4J6J8K0","26102A99K3K4TK3J7J1N%oj2j7k2k5Tk4k1j8j5j1qomlTnnopTqqTponmlkjk","26142B2%j%WJJTKKLTMLNUOOTNNMTNNOTPQRWOMjnqj0j2j4j6j5Tj4j1ronll","26197C7kZlkUjjU%j%j%Uj%Tj%Uj%Xj%S6",""]
,[3,0,1,0,"0@",""]
)
