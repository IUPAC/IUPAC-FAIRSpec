SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<1H>'; SpecInfo.Data.EXP='<PROTON>';SpecInfo.Data.SFO1=400.132470802;
SpecInfo.Data.O1=2470.802;SpecInfo.Data.F2=16.1876696570707;SpecInfo.Data.SW=20.0254193236558;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=96;
SpecInfo.Data.OFFSET=16.18777;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-a-team3/nmr/Jun15-2023/1203410/pdata/1/intrng, 6/15/2023 12:33:06 PM'
SpecInfo.Data.using='g:/data/chem-synthesis-a-team3/nmr/Jun15-2023/1203410/pdata/1/intgap_ole, 6/20/2023 8:38:23 AM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=65536
SpecInfo.Data.nint=2
SpecInfo.Data.realymin=-25247
SpecInfo.Data.realymax=371520787
SpecInfo.Data.realyave=619221
SpecInfo.Data.realyint=40315496935
SpecInfo.Data.snr=600.021695000654
SpecInfo.Data.nbytes=1169
SpecInfo.Data.miny=0
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=1.66660640495492
SpecInfo.Data.firstnz=27144
SpecInfo.Data.compressionratio=224.2/1
SpecInfo.Data.htratio=2.69163943173925E-06
SpecData=new Array([0,-1,65536,'g:/data/chem-synthesis-a-team3/nmr/Jun15-2023/1203410/pdata/1/1r']
,[1,25657,5785,1487,"27144A%Uj%TJ%T56J%S11J%V9J%T9J%T2J%S6J%S2J%S0J%ZJ%YJ%XJ%XJ%VJ%","27701A4%UJ%VJ%UJ%UJ%UJ%TJ%UJ%TJ%TJ%J%TJ%TJ%J%J%TJ%J%J%J%J%J%J%","27763C5J%J%J%J%J%J%TJ%J%J%TJ%J%UJ%UJ%S5j%Uj%Tj%Tj%j%j%j%j%j%j%","27833C8j%j%j%j%j%j%j%j%j%j%j%j%j%j%Tj%j%Tj%Tj%Tj%Tj%Tj%Uj%Uj%%","27890A5%j%Vj%Vj%Vj%Xj%Xj%Zj%Z%Sj%S2j%S5j%T1j%U2j%Z0%S0j%T6J%U3j%","28177B%U5j%T05J%S43J%U8J%T3J%S6J%S0J%YJ%WJ%VJ%UJ%UJ%TJ%J%TJ%J%","28692A6JT%JZKJKXLLKLUMLTMMTNOTQRJ0J1J2J3UJ2J2RQMKjmorj0j1Tj0j1r","28750A51qTooUnonononmUlkTjj%UJKVMLNMONOPOPTOPOPOPQTJ0J0TJ1J1TRP","28806B55MKknrj2j4j6j7Uj5j4j3j1rqpomUllYklkVjkjW%jT%j%Tj%Tj%Vj%","28866F%Vj%Z%Sj%S2j%T9j%X4J%Z8J%U4J%XJ%TJ%TJJUKKTLLTMLTKKJjknon","29146B2mlTjkjkj%j%Uj%S8j%S25J%U0J%S8J%S7J%S4J%W5J%T0j%T6j%U1J%","29525G%T1J%S2J%YJ%WJ%VJ%UJ%TJ%TJ%TJ%J%J%J%JU%JXKJTKKWLKLUMLMVNN","29631I1OPTQRTJ0J1TJ2J1TJ0J0QOML%jmnoqrj0Trj0TrqrpUopnonTmmTlll","29679F0kjT%%TJKULLMUNNUOOWPPUOPTONMLK%jmTpqrTj1j1Vrj0qpTonmTlm","29740D1klklkVjkjkjX%jT%j%Tj%Tj%Vj%Z%Sj%S9j%U6J%U0J%X3j%U7j%T4j%","30000B%T5j%Z8%S0j%J%j%V5J%S2j%W7J%S42",""]
,[2,0,1,0,"0@",""]
)
