SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<13C>'; SpecInfo.Data.EXP='<C13CPD32>';SpecInfo.Data.SFO1=100.622829803;
SpecInfo.Data.O1=10061.277;SpecInfo.Data.F2=219.438350248103;SpecInfo.Data.SW=238.896695566946;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=93;
SpecInfo.Data.OFFSET=219.4603;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-a-team1/nmr/Jun20-2023/1210610/pdata/1/intrng, 6/20/2023 9:40:42 AM'
SpecInfo.Data.using='g:/data/chem-synthesis-a-team1/nmr/Jun20-2023/1210610/pdata/1/intgap_ole, 6/27/2023 12:24:12 PM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=32768
SpecInfo.Data.nint=7
SpecInfo.Data.realymin=-2351489
SpecInfo.Data.realymax=360433323
SpecInfo.Data.realyave=656795
SpecInfo.Data.realyint=6089914042
SpecInfo.Data.snr=552.356232918947
SpecInfo.Data.nbytes=1292
SpecInfo.Data.miny=-7
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=1.81042584550094
SpecInfo.Data.firstnz=3951
SpecInfo.Data.compressionratio=101.4/1
SpecInfo.Data.htratio=2.77443825581022E-06
SpecData=new Array([0,-1,32768,'g:/data/chem-synthesis-a-team1/nmr/Jun20-2023/1210610/pdata/1/1r']
,[1,3950,111,1,"3951bJ%J%jk%K%TkJKJK%j%JTl%JjJ%ljJ%TJJ%j%J%TK%kjKLTJJLPQK0N4M7L2","4006A81M5P5L1j61j03k9j4j0lTkkJjTkkJ%TJK%lj%Uj%JT%J%UJJjJk%k%JJ","4053B%lJTk%j",""]
,[2,8904,52,1,"8905a%VKkjJ%jKLkJKJTKNTJ4M3R7k2q4l6j3oT%Jjk%j%J%klJT%JjJlKj",""]
,[3,11932,138,1,"11933AjKJ%j%TKljK%kKJ%jJjTKjKJ%JjT%JT%%TJ%VKJTklJKj%MJKULMKTOO","11992D2PJ1J3J2J7K2K8K9L4K6J4mk1l1l6l0k3k0j5j3rqonTkmlkTJ%kljkk","12029G%Kj%j%j%jJT%JTjkjJTjjT%%kJ%jT%kKLJkjlJKJ",""]
,[4,12881,157,3,"12884aJjJjJ%j%Kj%KJLKmj%kjTJjJ%TJ%TJ%VJjk%Jj%JUKLOJ3M5N0rk7j8j6","12938E2j5Tj3m%lkK%kK%J%J%kTJj%TjjMKnjJL%jk%TJ%JLJjTJkj%Uj%Tj%j","12992bK%JjT%J%JTj%Jj%TjJk%TjjJTLJjJ%jJjklJK%J%U",""]
,[5,14819,91,1,"14820BlJjK%jJ%JjTJ%LMJlm%ULJkjJ%JjT%%TjKJKk%L%J%LKLOJ1J2K4M4Q7K41","14873D42N58j17m82k11p9m0k4j5rnkT%lT%k%k%kL%ljK%JjT%%j%TK",""]
,[6,19435,170,1,"19436c%JK%JKJkmJjKNJTlk%ULkj%TKLJjMNTJ0J8L0M5O2M5qo4o5l9k0j1pm","19482A3kUJJj%JTkkT%j%J%VJj%LTJJKMPJ2K0L5N6O0L3l2p6o0l0j6plTjkl","19529HjJjKJmj%jUJ%TjJ%J%K%KTLLMQJ3K4M2N8N3J2n2p1m6k4j3pmlj%kjk","19575DjTK%JKjTlJjJTjjUK%jljMJkjJU",""]
,[7,24577,89,2,"24579Aj%Kk%K%JTm%KJj%KLKTJMPTRJ8M0J07K11K12J23l43k40q1l3j8romk","24618A4lT%%kjJTkk%jTJKkJ%Jjk%JjTJ%KJ%Tjj%jT%%j%UJjT%",""]
)
