SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<13C>'; SpecInfo.Data.EXP='<C13CPD32>';SpecInfo.Data.SFO1=100.622829803;
SpecInfo.Data.O1=10061.277;SpecInfo.Data.F2=219.438350248103;SpecInfo.Data.SW=238.896695566946;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=91;
SpecInfo.Data.OFFSET=219.4603;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-a-team6/nmr/Jun20-2023/1210410/pdata/1/intrng, 6/20/2023 9:15:52 AM'
SpecInfo.Data.using='g:/data/chem-synthesis-a-team6/nmr/Jun20-2023/1210410/pdata/1/intgap_ole, 6/20/2023 10:18:06 AM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=32768
SpecInfo.Data.nint=8
SpecInfo.Data.realymin=-9210523
SpecInfo.Data.realymax=421973194
SpecInfo.Data.realyave=2147376
SpecInfo.Data.realyint=10800918767
SpecInfo.Data.snr=200.79563010856
SpecInfo.Data.nbytes=1254
SpecInfo.Data.miny=-22
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=4.98018806215727
SpecInfo.Data.firstnz=6964
SpecInfo.Data.compressionratio=104.5/1
SpecInfo.Data.htratio=2.36981878047922E-06
SpecData=new Array([0,-1,32768,'g:/data/chem-synthesis-a-team6/nmr/Jun20-2023/1210410/pdata/1/1r']
,[1,6963,71,1,"6964h%QKmkJLljJ%KJJ4TPRQJ0J8Jj6j7j2j4oTmLjNjT%Kj1pJ0KmKQj1kJ1%","7010A1jplPJ%KlKl%kpjJkJ2jLmoJm",""]
,[2,11517,50,1,"11518iMTjkNlMKJ%j1JKRKRTJ5K1L7J9l0l6k6j2KJ%nKmTJkMnkMnTNjTLmOM","11565Hn",""]
,[3,11701,39,1,"11702AJmMmkmQkPkTJmJ6J7K0M4L8pn4l5j8kTrpOlKJLJ%olkO",""]
,[4,12316,86,1,"12317gMNJnLNJmj%JLlKONnTJPJ7K2J7K6N6J28K47J42k36k03r3n0k8j7j1r","12353B2OmrKljoj0QNpokPMlLljmJOJnJ%oMPj%JPlTKj5lLNOkmqjMRP",""]
,[5,13590,55,1,"13591ekRknjMJVmN%NOlMJ2J6J9K3L9Q2J82K74j05k58j37p5l2j5jTj0mjj0l","13629A0Nlol%ljK%MjkKNq",""]
,[6,19445,161,1,"19446CqlJMKUJm%OkMNjKlJMO%ojklRLJ1NmQKNJ0J6J9L0M6R4J73K82K48o9l30","19490E68k54j33o2l8j7k0j0kKj%mLPjoj2lTMJlOn%OL%MOoMRK0J6K5L8O6J18","19529C26K26L06J42k28l31j95r6n3k8j5j1rj1KnjnKlTJjMOMJkjMNp%O%ON","19565D1PJ5TK1K0M7Q6J53K68K71j6l19k75j46q2l5j5k0pqJ%lmnoJkLpOLm","19598DoJK%M%q",""]
,[7,26733,93,1,"26734DOrjNJljMKj1NJ1J2TJ0L0M2O1K8l9p0m2j0j5Tj0mMjlKJKMkqjLlKj%","26776BP%pLTKmLmoKL%TjNkjlPkrNnMl%RMUpJjpnKkNrjKjLlJjoj",""]
,[8,27190,102,1,"27191EMTolRnrnKnLJ4LKo%QmpmJ%J0OrojlOjKkKJ1%TPKojPjOJ5K2L7O1N6N","27240B26r8o6k9j9ln%JTqJjJ2op%TLmpkMKOKkTJlMOKJ1okLmj0kTJMjpMRl","27287DqK%j",""]
)
