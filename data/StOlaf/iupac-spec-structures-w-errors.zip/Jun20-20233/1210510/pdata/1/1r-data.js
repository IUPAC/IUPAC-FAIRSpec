SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<13C>'; SpecInfo.Data.EXP='<C13CPD32>';SpecInfo.Data.SFO1=100.622829803;
SpecInfo.Data.O1=10061.277;SpecInfo.Data.F2=219.438350248103;SpecInfo.Data.SW=238.896695566946;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=91;
SpecInfo.Data.OFFSET=219.4603;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-a-team3/nmr/Jun20-2023/1210510/pdata/1/intrng, 6/20/2023 9:29:19 AM'
SpecInfo.Data.using='g:/data/chem-synthesis-a-team3/nmr/Jun20-2023/1210510/pdata/1/intgap_ole, 6/20/2023 9:36:17 AM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=32768
SpecInfo.Data.nint=8
SpecInfo.Data.realymin=-10602800
SpecInfo.Data.realymax=463727586
SpecInfo.Data.realyave=2205681
SpecInfo.Data.realyint=15738529370
SpecInfo.Data.snr=215.049404696327
SpecInfo.Data.nbytes=1220
SpecInfo.Data.miny=-23
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=4.65009424886391
SpecInfo.Data.firstnz=6940
SpecInfo.Data.compressionratio=107.4/1
SpecInfo.Data.htratio=2.15643845695218E-06
SpecData=new Array([0,-1,32768,'g:/data/chem-synthesis-a-team3/nmr/Jun20-2023/1210510/pdata/1/1r']
,[1,6939,54,1,"6940B%NmnlPMljKNjnKLP%J3J1ROJ6K2QJkj0k3k2j2j4oLpmKL%kTljKTkmjK","6988@LkON",""]
,[2,11479,72,1,"11480Ip%jkjTKMnJKJjLPOon%mqoMPTlkJmK%jJLTjOkpJKMkJ3J1%MK4M6N0K2","11531A77n4o0l0j5j0kTlK%NkljpmMK%",""]
,[3,11698,49,1,"11699gKON%kNmjk%QpjPNjkLTnlJ2K3K7P1O7m1q2m1k1j2LTrknJTk%Nlo%QM","11745A0o",""]
,[4,12288,102,1,"12289cjmRjP%q%N%KoKNlMLMl%pJLOoJkoOLm%NK%nqKO%lNjlQPMLTPJLJ8K6M8","12344A35O8J42L15L40k53l79j74p7m0k6j6qj2%kKlkjKlT%kL%QLqJ%KpqMj","12380@%MqM%kjU",""]
,[5,13573,69,1,"13574A2mKpnONkqlLlMJM%jKjMK%TMNPkNJ2J9K0L3N8J24K62L64p3m02k18r8","13613A31m4k1j6Tplj0oKm%LKJnjlOlmKmlOJmLM",""]
,[6,19450,156,1,"19451CMmnLNLj1%J5jolPjJNKkJnRMTQRPJ0J1J6K8O4J17J98K47J06j97k74j68","19489B10q4m7k5k1lpjT%LJl%MmoJ%nLKUjJK%NRnNJ5RJ9K2M1P4J41K53K24l4","19530H01k80k37j28n6k8j8pTj1nTkm%j%TjLknNJ1%okLMOKN%lNJ1QK1L5M8J03","19570B63J85K55J43j52k87j88r3n0k7j2j1r%Knkn%jPNoj0JK%JknLr%kJR",""]
,[7,26738,54,1,"26739FKljkKPlm%nKRJ0J4MJ3K6M6R6J00J5j14j06n3k2nqj8j2LKNQmTKlMo","26778Cjn%TkKJoMLTJJ",""]
,[8,27210,58,1,"27211A0KmqJKTjlkTOJRJqKNTmJRPJ3J4K0O1J01P7L5j39j12m6k7j0oJTmKm","27251H%koLJLlTNrm%NOLo",""]
)
