SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<1H>'; SpecInfo.Data.EXP='<PROTON>';SpecInfo.Data.SFO1=400.132470802;
SpecInfo.Data.O1=2470.802;SpecInfo.Data.F2=16.1876696570707;SpecInfo.Data.SW=20.0254193236558;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=97;
SpecInfo.Data.OFFSET=16.18777;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-a-team1/nmr/Jun15-2023/1203110/pdata/1/intrng, 6/15/2023 12:14:02 PM'
SpecInfo.Data.using='g:/data/chem-synthesis-a-team1/nmr/Jun15-2023/1203110/pdata/1/intgap_ole, 7/11/2023 2:21:33 PM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=65536
SpecInfo.Data.nint=4
SpecInfo.Data.realymin=-42361
SpecInfo.Data.realymax=365345943
SpecInfo.Data.realyave=475109
SpecInfo.Data.realyint=30877048589
SpecInfo.Data.snr=769.062055233641
SpecInfo.Data.nbytes=1335
SpecInfo.Data.miny=0
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=1.30028518920518
SpecInfo.Data.firstnz=4105
SpecInfo.Data.compressionratio=196.3/1
SpecInfo.Data.htratio=2.73713180386952E-06
SpecData=new Array([0,-1,65536,'g:/data/chem-synthesis-a-team1/nmr/Jun15-2023/1203110/pdata/1/1r']
,[1,2873,2904,1232,"4105A%S87J%W4J%T7J%S7J%S2J%Z%SJ%XJ%XJ%VJ%UJ%UJ%TJ%TJ%TJ%J%J%J%","4460A8JT%JT%JS0KJTKKJKVLKTLLKLS1KLKJKJT%%TjjkVllYmlWklklkWjkjk","4546C0jTkjW%jU%jT%j%j%j%j%Tj%Tj%Tj%Uj%Vj%Wj%Xj%Zj%S2j%S9j%U8j%","4682A%S22j%X6J%T2",""]
,[2,10013,4609,1959,"11972A%S30j%S05J%S19J%Z%Sj%V0J%V8j%T5J%X7J%U5J%S8J%Z%SJ%XJ%VJ%","12601H%UJ%VJ%TJ%TJ%TJ%J%TJJYKJKJKTJKJWKKMTNOQRJ0J1J2J3J2J3TJ2J2","12661A88RPKjnrj2Tj4j3j1TqpnmlkTllTnnonTmmTkkTjjT%%JUKKLUNMNTOO","12713G8OTPOPNONOTQRJ0J3TJ5J5J6TJ4J3J0O%oj3j9k2k6k5k4k2k0j6j4j0r","12750G0onmkTjjWklkmlVkkjkjU%jT%j%Tj%Tj%j%Uj%Wj%S2j%U3j%T0J%V4J%","12913D%S8J%Z%SJ%XJ%WJ%UJ%UJ%J%J%JU%JKJTKKTLKLKLXKJT%J%KLOPJ1J3J6","13002A17J8J9K1K2K3VK2J8J2Noj6k3k8l0k9k7k3j9j4j0pnkTjjlnoqrTqpo","13040D2mTlkTjj%WJJTKLUMNMNONOUNNLMLMNQTJ0J1J3UJ2J1QMjqj4j9k3Tk2k0","13094I6j7j4j1ronlkTj%j%Uj%jTkkjkUjjU%j%j%j%Tj%Wj%S6j%X4j%S6J%j","13239@%Z2J%W7j%S7J%V4j%S73J%S8j%U8J%V0j%U1J%V1",""]
,[3,24692,3448,1057,"25749A%S70J%W7J%T8J%S7J%S3J%S1J%YJ%VJ%VJ%UJ%UJ%TJ%TJ%J%J%J%J%J","26093A9%JT%JU%JVKJTKKWLLTMMNOTQQJ1J2J5J9K1K6L0L4L9M2M5M9N0UM8M4","26141F79L9L3K5J4Mpj9l0m1m9n5o0o1o0n6n1m5l9l3k7k2j9j5j2j1qToomm","26172D6mlTkkWjjkjV%j%jT%%j%j%Tj%Tj%Tj%Uj%Vj%Yj%Zj%S3j%S4j%W0j%","26314A%S36",""]
,[4,28595,-28594,0,"",""]
)
