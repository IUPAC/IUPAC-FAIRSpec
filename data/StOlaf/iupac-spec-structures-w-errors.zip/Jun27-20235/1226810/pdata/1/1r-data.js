SpecInfo={};SpecData=[];SpecInfo.Data={}; SpecInfo.Data.NUC1='<13C>'; SpecInfo.Data.EXP='<C13CPD32>';SpecInfo.Data.SFO1=100.622829803;
SpecInfo.Data.O1=10061.277;SpecInfo.Data.F2=219.438350248103;SpecInfo.Data.SW=238.896695566946;
SpecInfo.Data.INTSCL=1;
SpecInfo.Data.NC_procplus100=94;
SpecInfo.Data.OFFSET=219.4603;
SpecInfo.Data.O1 = SpecInfo.Data.O1 + (SpecInfo.Data.OFFSET - SpecInfo.Data.F2)*SpecInfo.Data.SFO1;
SpecInfo.Data.source='g:/data/chem-synthesis-a-team5/nmr/Jun27-2023/1226810/pdata/1/intrng, 6/27/2023 12:32:04 PM'
SpecInfo.Data.using='g:/data/chem-synthesis-a-team5/nmr/Jun27-2023/1226810/pdata/1/intgap_ole, 6/27/2023 12:33:11 PM'
SpecInfo.Data.isJDX=-1
SpecInfo.Data.n=32768
SpecInfo.Data.nint=7
SpecInfo.Data.realymin=-1187244
SpecInfo.Data.realymax=369955931
SpecInfo.Data.realyave=425015
SpecInfo.Data.realyint=6484682594
SpecInfo.Data.snr=873.247238332765
SpecInfo.Data.nbytes=1254
SpecInfo.Data.miny=-3
SpecInfo.Data.maxy=1000
SpecInfo.Data.avey=1.14515105929134
SpecInfo.Data.firstnz=3981
SpecInfo.Data.compressionratio=104.5/1
SpecInfo.Data.htratio=2.70302464754917E-06
SpecData=new Array([0,-1,32768,'g:/data/chem-synthesis-a-team5/nmr/Jun27-2023/1226810/pdata/1/1r']
,[1,3978,98,3,"3981A%J%jT%%jJ%UJ%Jj%JTjj%JTKJT%%JKMPQJ6L7M7M0M1M9L9m7q1p6n3j6r","4028A6nmkjTJ%jk%JTj%UjJ%j%ZJjJj%J%TjjT%J%UJ%T",""]
,[2,8899,67,1,"8900a%TKJ%Tjj%WJJ%Jj%K%UKJKLKNQJ7N0P5k3o9m4j6nmkTjj%Vj%JT%kj%J","8956A%jT%%KjT",""]
,[3,11930,174,1,"11931AJ%jTJ%VjJTkK%J%j%Jj%K%TjJj%VJ%JTjJT%J%j%VJJj%JKJU%JKJKJL","11994B4KMTNPTQJ0TJ4J8K1K5K7K8K3J1kj7k7k9l0k4k1j8j2j1qTmnmlkljk","12031A7jUkjJkUJJ%k%Uj%TJjJj%Uj%j%TJjT%J%TjjJ%Jj%WjJ%jJ%Jj%Uk%J","12094A%JTk%jJTj",""]
,[4,12894,118,2,"12896A%jJ%JjT%j%K%J%K%TjjTJ%j%Uj%JjK%TJk%JjJ%JT%jJKMTNJ3L8N4kk6","12950I6k1j4j3j7j6ql%jU%jJ%j%JT%j%j%Tj%TJ%JKk%J%j%JT%k%UJj%Tj%%","13002@%Zj",""]
,[5,14817,124,1,"14818B%UjJ%J%TjjT%J%JTj%KLM%mkjT%%j%TJJ%jJT%%JT%%JTKLJKTNQPJ5K9","14874H3M2O0J15K93M07k22m02j98p6l7k3j2qnmjkjkjT%%jT%k%TJ%Tj%Jj%","14911AJj%WJjJLMJmlk%jJ%Tj%WJ",""]
,[6,19395,173,8,"19403a%J%jJT%Jj%Jj%JjJ%WjJ%UJ%ZKJU%KJMLMOJ0J5J8J2%j3k3j9j1olT%j","19463DJkJ%Vj%jJTjjJ%TJK%TJKJUNKMPJ1J6J9J0lj7k4j7j0nklk%UjjJTj%","19515B%WJ%J%J%TJK%KJKTLMQJ4J6J8Qoj9k3j6pnljkjT%jU%",""]
,[7,24569,87,1,"24570Aj%YJ%j%J%TJ%WJ%TJ%J%TJ%JTjKLKULOPJ2K1L7P7J65K06J71j38k57j91","24622A37p1k7j4pnkT%kjW%%j%J%k%JjJj%J%j%Tj",""]
)
